the "NEW" directory contains a save game that you will choose whenever you are starting a new game.  the game will automatically created a long named directory for each playthough.

Don't change the name of the "NEW" directory.  The game needs it named "NEW"

for any of the other directories created by the game, while the game is closed down you can rename them for organizational purposes.

you SHOULD be able to copy/paste any of these directory completely to manually create a copy of the save information.  IN the game, the "Branch" button does the same thing.

you SHOULD be able to email the directory to someone else if you are trying to play by email.