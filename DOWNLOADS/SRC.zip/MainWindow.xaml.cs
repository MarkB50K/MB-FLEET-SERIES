﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using CWApp.Helpers;
using log4net;
using Newtonsoft.Json;
namespace CWApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        //files we need
        //public string BaseDir = System.AppDomain.CurrentDomain.BaseDirectory;//"C:/Users/MBRP/Data";
        public string AppDir;// = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);//System.AppDomain.CurrentDomain.BaseDirectory;// + "/CWApp";
        string gameDir = "FS";
        string scenarioDir = "CombinedGame";
        string sessionDir = null;
        public bool sessionDirExists = false;
        public string GetImageDir(){
            return AppDir + "/Images";
        }
        public string GetScenarioImageDir(){
            return AppDir + "/" + gameDir + "/Images";
        }
        const string GameStateFile = "1.scenario.cwsav";
        const string RulesFile = "RULES.txt";
        public string GetGameSaveDir(){
            return AppDir + "/" + gameDir + "/Scenarios/" + scenarioDir + "/SavedGames";
        }
        public string GetGameSessionDir(){
            return GetGameSaveDir() + "/" + sessionDir;
        }
        public string GetGameStateFile(){
            return GetGameSessionDir() + "/" + GameStateFile;
        }
        string GetRulesFile()
        {
            return GetGameSessionDir() + "/" + RulesFile;
        }
        const string GameObjectFile = "GameObjects.csv";
        public List<string> GameObjectFields = new();
        string GetGOFile(){
            return AppDir + "/" + gameDir + "/Scenarios/" + scenarioDir + "/" + GameObjectFile;
        }
        const string GameLocationFile = "GameLocations.csv";
        public List<string> GameLocationFields = new();
        string GetGLFile(){
            return AppDir + "/" + gameDir + "/Scenarios/" + scenarioDir + "/" + GameLocationFile;
        }
        const string GameConnectorFile = "GameConnectors.csv";
        public List<string> GameConnectorFields = new();
        string GetGConnFile(){
            return AppDir + "/" + gameDir + "/Scenarios/" + scenarioDir + "/" + GameConnectorFile;
        }
        JsonSerializerSettings JSONSettings = new()
        {
            Formatting = Newtonsoft.Json.Formatting.Indented
        };
        public const int Z_HIDDEN = 1;
        public const int Z_BORDER_INDICATOR = 1004;
        public const int Z_CONNECTOR_INDICATOR = 99;
        public const int Z_MAP_CONNECTOR_INDICATOR = 15;
        public const int Z_LOCATION_INDICATOR = 500;
        public const int Z_MARKER_INDICATOR = 99; 
        public const int Z_MARKER = 100;
        public const int Z_DRAGGING_MARKER_INDICATOR = 1000015; 
        public const int Z_DRAGGING_MARKER = 1000025;
        public int XY_MARKER_OFFSET = 3;
        public const int Z_MARKER_OFFSET = 10;
        public const int Z_MARKER_RECTANGLE_OFFSET = 1;
        public const int Z_BLINDER = 2000000;
        public const int Z_BACKGROUND = 4;
        public const int Z_INSPECTION = 13800;
        public double MapZoomLevel = 1;
        public double ViewportHorizontalOffset = -1;
        public double ViewportVerticalOffset = -1;
        public double MouseWheelOffset = 0;
        public double MouseWheelOffsetDifference = 0;
        public double LeftRightKeyOffset = 0;
        public double LeftRightKeyOffsetDifference = 0;
        public double UpDownKeyOffset = 0;
        public double UpDownKeyOffsetDifference = 0;
        public const double MiniMarkerRatio = 0.5;
        public double MinDockMarkerSize = 100;
        public GameState configurationState;
        public CombinedState combinedState = new();
        public string RULES = null;
        public GO DraggingPIECE;
        public GO DraggingSHEET;
        public GO MouseOverMarker;
        public GO ChoiceMenuMarker;
        public GO InfoMenuMarker;
        public bool SHOWACTIONS = true;
        public GO OriginGO;
        public List<GO> DropTargets;
        public HashSet<GO> ExpandedGOs = new();
        public List<string> ActionContext = [];
        //data structures
        public Dictionary<MenuItem, GO> STACKMENUGOs = [];
        public Dictionary<MenuItem, GO> CHOICEMENUGOs = [];
        public Dictionary<MenuItem, GO> AIREVIEWMENUGOs = [];
        public HashSet<GO> GOsToDraw = [];
        public List<GO> IndicatorsToDraw = [];
        public List<GO> IndicatorsDrawn = [];
        public List<UIElement> DrawnUIElements = [];
        public List<string> ColorPriorities = ["GRAY", "LIGHTGRAY", "BLACK", "WHITE", "YELLOW", "RED", "LIGHTBLUE"];

        Dictionary<string, SolidColorBrush> GOIndicatorColorMap = new(){
            {"RED", System.Windows.Media.Brushes.Red},
            {"YELLOW", System.Windows.Media.Brushes.Yellow},
            {"WHITE", System.Windows.Media.Brushes.White},
            {"LIGHTGRAY", System.Windows.Media.Brushes.LightGray},
            {"GRAY", System.Windows.Media.Brushes.Gray},
            {"BLACK", System.Windows.Media.Brushes.Black},            
            {"LIGHTBLUE", System.Windows.Media.Brushes.LightBlue}
        };
        GameScenario GS;
        Image MarkerIndicator = new Image();
        public Menu MarkerChoiceMenu{ get{return (Menu)this.FindName("menuMarkerChoice");}}
        public Menu MarkerInfoMenu { get { return (Menu)this.FindName("menuMarkerInfo"); } }
        public Menu SelectedMarkerInfoMenu { get { return (Menu)this.FindName("menuSelectedMarkerInfo"); } }
        public Menu SelectedMarkerTargetInfoMenu { get { return (Menu)this.FindName("menuSelectedMarkerTargetInfo"); } }
        public Menu MainMenu{ get{return (Menu)this.FindName("menuMain");}}
        public bool TEMPLATEMODE = false;
        public Menu OptionsMenu { get { return (Menu)this.FindName("menuOptions"); } }
        public Menu StackMenu { get { return (Menu)this.FindName("menuStack"); } }
        public List<Menu> AllMenus = [];
        public Dictionary<MenuItem, string> SaveGameFileToPath = new();
        public ContextMenu MapDynamicMenu = new ContextMenu();
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public Canvas WORLD_CANVAS{ get{return (Canvas)this.FindName("worldCanvas");}}
        public ScrollViewer CANVAS_SCROLL_VIEWER{ get{return (ScrollViewer)this.FindName("svCanvas");}}
        public double GetHorizontalOffset{ get{return ViewportHorizontalOffset >= 0 ? ViewportHorizontalOffset : CANVAS_SCROLL_VIEWER.HorizontalOffset;}}
        public double GetVerticalOffset{ get{return ViewportVerticalOffset >= 0 ? ViewportVerticalOffset : CANVAS_SCROLL_VIEWER.VerticalOffset;}}
        public Image SELECTED_MARKER_IMAGE{ get{return (Image)this.FindName("imgSelectedMarker");}}
        public Button SELECTED_MARKER_BUTTON{ get{return (Button)this.FindName("btnSelectedMarker");}}
        public Image CLICKED_MARKER_IMAGE{ get{return (Image)this.FindName("imgClickedMarker");}}
        public Button CLICKED_MARKER_BUTTON{ get{return (Button)this.FindName("btnClickedMarker");}}
        public StackPanel BACKGROUND { get { return (StackPanel)this.FindName("spMap"); } }
        //bool VIEWREFRESHED = false;
        public bool INIT = false;
        public void throwError(Exception ex)
        {
            log.Error("Error: " + ex.Message + " " + ex.StackTrace);
            MessageBox.Show(ex.Message.ToString());
        }
        public string GenerateSessionID(){
            return scenarioDir + "." + DateTime.Now.ToString("yyyyMMdd.HHmmss");
        }
        public MainWindow()
        {
            try
            {
                //Loaded += (x, y) => Keyboard.Focus(WORLD_CANVAS);
                INIT = true;
                var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
                log4net.Config.XmlConfigurator.Configure(logRepository, new FileInfo(ConfigurationManager.AppSettings.Get("log4net-config-file")));
                InitializeComponent();
                this.DataContext = this;
                AllMenus = new List<Menu> { MarkerChoiceMenu, MainMenu, StackMenu, MarkerInfoMenu, SelectedMarkerInfoMenu, SelectedMarkerTargetInfoMenu, OptionsMenu };
                //initialize marker indicator
                WORLD_CANVAS.Children.Add(MarkerIndicator);
                
                //MarkerDynamicMenu = (Menu)this.FindName("MarkerChoiceMenu");
                //WORLD_CANVAS.Children.Add(MarkerDynamicMenu);
                HideMenus();
                ///CHOOSE SAVE DIRECTORY AND LOAD GAME STATE
                //determine session (savegame)
                string[] clargs = System.Environment.GetCommandLineArgs();
                AppDir = clargs.Length > 1 ? clargs[1] : System.IO.Path.GetDirectoryName(clargs[0]);
                List<Image> menuImages = new(){
                    (Image)this.FindName("imgPreviousMarker"),
                    (Image)this.FindName("imgNextMarker")
                };
                List<string> menuImageFilenames = new(){"Icon_Previous.png", "Icon_Next.png"};

                for(int i = 0; i < menuImages.Count; i++){
                    Image img = menuImages[i];
                    string filename = menuImageFilenames[i];
                    SetImage(img, GetImageDir() + "/" + filename, 30);
                }
                double dockImgSize = Math.Max(Math.Min(SystemParameters.PrimaryScreenWidth, SystemParameters.PrimaryScreenHeight) * 0.1, MinDockMarkerSize);
                SetImage(SELECTED_MARKER_IMAGE, GetImageDir() + "/EMPTY.png", dockImgSize);
                SetImage(CLICKED_MARKER_IMAGE, GetImageDir() + "/EMPTY.png", dockImgSize);
                Canvas.SetTop(MarkerIndicator, 0);
                Canvas.SetLeft(MarkerIndicator, 0);
                Canvas.SetZIndex(MarkerIndicator, Z_HIDDEN);
                SetImage(MarkerIndicator, GetImageDir() + "/COLOR.BLACK.png", 30);
                GS = new FS.ScenarioCombined(scenarioDir, this);
                //((LabelChangeDialog)LABELCHANGEPOPUP.Child)._Window = this;
                //((LabelChangeDialog)LABELCHANGEPOPUP.Child).GS = GS;
                for (int row = 0; row <= 1; row++){
                    for(int column = 0; column <= 9; column++){
                        String n = column.ToString("00") + row.ToString("00");
                        Image ssImage = (Image)FindName("imgbtn" + n);
                        string filename = GS.GetScenarioSpecificImage(column, row);
                        SetImage(ssImage, GetScenarioImageDir() + "/" + filename, 30);
                        Button b = (Button)FindName("btn" + n);
                        b.ToolTip = GS.GetToolTip(column, row);
                    }
                }
                
                /*((Button)this.FindName("btn0000")).ToolTip = GS.GetToolTip(0, 0);
                ((Button)this.FindName("btn0001")).ToolTip = GS.GetToolTip(0, 1);
                ((Button)this.FindName("btn0100")).ToolTip = GS.GetToolTip(1, 0);
                ((Button)this.FindName("btn0101")).ToolTip = GS.GetToolTip(1, 1);
                ((Button)this.FindName("btn0200")).ToolTip = GS.GetToolTip(2, 0);
                ((Button)this.FindName("btn0201")).ToolTip = GS.GetToolTip(2, 1);
                ((Button)this.FindName("btn0300")).ToolTip = GS.GetToolTip(3, 0);
                ((Button)this.FindName("btn0301")).ToolTip = GS.GetToolTip(3, 1);
                ((Button)this.FindName("btn0400")).ToolTip = GS.GetToolTip(4, 0);
                ((Button)this.FindName("btn0401")).ToolTip = GS.GetToolTip(4, 1);
                ((Button)this.FindName("btn0500")).ToolTip = GS.GetToolTip(5, 0);
                ((Button)this.FindName("btn0501")).ToolTip = GS.GetToolTip(5, 1);
                ((Button)this.FindName("btn0600")).ToolTip = GS.GetToolTip(6, 0);
                ((Button)this.FindName("btn0601")).ToolTip = GS.GetToolTip(6, 1);
                ((Button)this.FindName("btn0700")).ToolTip = GS.GetToolTip(7, 0);
                ((Button)this.FindName("btn0701")).ToolTip = GS.GetToolTip(7, 1);
                ((Button)this.FindName("btn0800")).ToolTip = GS.GetToolTip(8, 0);
                ((Button)this.FindName("btn0801")).ToolTip = GS.GetToolTip(8, 1);
                ((Button)this.FindName("btn0900")).ToolTip = GS.GetToolTip(9, 0);
                ((Button)this.FindName("btn0901")).ToolTip = GS.GetToolTip(9, 1);   */
                string NEWSTATEFILE = GetGameSaveDir() + "/NEW/1.scenario.cwsav";
                configurationState = JsonConvert.DeserializeObject<GameState>(File.ReadAllText(NEWSTATEFILE));
                SetBackground();
			    PresentMainMenu(GetGameSaveDir(), null);
                /*OpenFileDialog openFileDialog = new()
                {
                    Filter = "CW App Saved Games (*.cwsav)|*.cwsav"
                };
                string dir = System.IO.Path.GetFullPath(GetGameSaveDir());
			    openFileDialog.InitialDirectory = dir;
                if(openFileDialog.ShowDialog() == true){
                    string oFDfn = openFileDialog.FileName;
                    DirectoryInfo dirInfo = new(System.IO.Path.GetDirectoryName(oFDfn));
                    sessionDir = dirInfo.Name;
                    if(sessionDir == "NEW"){
                        sessionDir = GenerateSessionID();
                        Directory.CreateDirectory(GetGameSessionDir());
                    }
                } else {
                    return;
                }*/
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void PresentMainMenu(string path, MenuItem mi){
            Menu m = MainMenu;
            bool topLevel = path == GetGameSaveDir();
            if (!TEMPLATEMODE)
            {
                if (topLevel)
                {
                    m.Items.Clear();
                    SaveGameFileToPath.Clear();
                    MenuItem mmi = new() { Header = "How do I use this app?", FontWeight = FontWeights.UltraBold };
                    mmi.Click += MainMenucmiImg_Click;
                    m.Items.Add(mmi);
                    m.Items.Add(new Separator());
                    mmi = new() { Header = "Start: EMPTY SANDBOX", FontWeight = FontWeights.UltraBold };
                    mmi.Click += MainMenucmiImg_Click;
                    m.Items.Add(mmi);
                    m.Items.Add(new Separator());
                    mmi = new() { Header = "Start: PRE-BUILT MISSION", FontWeight = FontWeights.UltraBold };
                    mmi.Click += MainMenucmiImg_Click;
                    m.Items.Add(mmi);
                }
                //get list of save game files
                string[] ofiles = System.IO.Directory.GetFiles(path);
                string[] odirectories = System.IO.Directory.GetDirectories(path);
                bool isAGameSaveDir = false;
                if (!topLevel)
                {
                    foreach (string s in ofiles)
                    {
                        string fileName = System.IO.Path.GetFileName(s);
                        if (fileName == GameStateFile && !topLevel)
                        {
                            isAGameSaveDir = true;
                            DirectoryInfo dirInfo = new(System.IO.Path.GetDirectoryName(s));
                            SaveGameFileToPath[mi] = path;
                            mi.Click += GameFilecmiImg_Click;
                            break;
                        }
                    }
                }
                if (!isAGameSaveDir)
                {
                    foreach (string s in odirectories)
                    {
                        string fileName = System.IO.Path.GetFileName(s);
                        if (topLevel && (fileName == "NEW" || fileName == "TEMPLATES")) { continue; }

                        int count = topLevel ? m.Items.Count : mi.Items.Count;
                        if (count > 0)
                        {
                            if (topLevel)
                            {
                                m.Items.Add(new Separator());
                            }
                            else
                            {
                                mi.Items.Add(new Separator());
                            }
                        }
                        MenuItem mmi = new() { Header = fileName, FontWeight = FontWeights.UltraBold };
                        if (topLevel)
                        {
                            m.Items.Add(mmi);
                        }
                        else
                        {
                            mi.Items.Add(mmi);
                        }
                        PresentMainMenu(s, mmi);
                    }
                }
            }
            else
            {
                //skip down
                path = GetGameSaveDir() + "/TEMPLATES";
                
                //get list of save game files
                string[] ofiles = System.IO.Directory.GetFiles(path);
                m.Items.Clear();
                SaveGameFileToPath.Clear();
                foreach (string s in ofiles)
                {
                    string fileName = System.IO.Path.GetFileName(s);
                    if (fileName.EndsWith(".cwsav"))
                    {
                        int count = m.Items.Count;
                        if (count > 0)
                        {
                            m.Items.Add(new Separator());
                        }
                        fileName = fileName.Replace(".cwsav", "");
                        MenuItem mmfi = new() { Header = fileName, FontWeight = FontWeights.UltraBold };
                        SaveGameFileToPath[mmfi] = fileName;
                        mmfi.Click += GameFilecmiImg_Click;
                        m.Items.Add(mmfi);
                    }
                }
                m.Items.Add(new Separator());
                MenuItem mmi = new() { Header = "RETURN TO MAIN MENU", FontWeight = FontWeights.UltraBold };
                mmi.Click += MainMenucmiImg_Click;
                m.Items.Add(mmi);
            }
            if (topLevel)
            {
                Canvas.SetLeft(m, 1);
                Canvas.SetTop(m, 1);
                Canvas.SetZIndex(m, 1000000);
            }
        }
        public void SetDockedMenuZ(Menu m)
        {
            Canvas.SetZIndex(m, Z_BLINDER - 1);
        }
        private async void LoadGame(Dictionary<string, string> info){
            try{
                combinedState = JsonConvert.DeserializeObject<CombinedState>(File.ReadAllText(GetGameStateFile()));
            }
            catch(Exception e){
                String debug = e.Message;
                combinedState.state.Add("SCENARIO.VARS", new());
            }
            try
            {
                RULES = File.ReadAllText(GetRulesFile());
            }
            catch (Exception e)
            {
                String debug = e.Message;
                RULES = "No file named " + RulesFile + " in Scenario dir.  Please create one if you'd like that available for view.";
            }
            //scenario setup
            GS.PreLoadProcessing();
            Dictionary<string, GO> allGOsMap = new();
            GS.LoadGameObjects(new CSVFile(GetGLFile(), GameLocationFields)).ForEach(n => allGOsMap.Add(n.ID, n));
            GS.LoadGameObjects(new CSVFile(GetGConnFile(), GameConnectorFields)).ForEach(n => allGOsMap.Add(n.ID, n));
            GS.LoadGameObjects(new CSVFile(GetGOFile(), GameObjectFields)).ForEach(n => allGOsMap.Add(n.ID, n));
            GS.LoadGameState(combinedState, allGOsMap, configurationState);
            //do stuff with skipping setup and setting AI
            if (info != null)
            {
                if (info.TryGetValue("SKIPSETUP", out string value))
                {
                    GS.SkipSetup = value == "true";
                }
                if (info.TryGetValue("SOVAI", out value))
                {
                    GS.Set("AI.SOV", value == "true" ? "NORMAL" : "NONE");
                }
                if (info.TryGetValue("ALLIESAI", out value))
                {
                    GS.Set("AI.ALLIES", value == "true" ? "NORMAL" : "NONE");
                }
            }
            GS.PostLoadProcessing();
            //kick off where we left off
            GamePhase startPhase = GS.ExecutingGamePhase();
            GS.PreCallProcess();
            GS.AdvancingPhase = null;
            if (startPhase == null){
                GS.Start();
            }
            else{
                startPhase.Execute(true);            
            }
            if (GS.AdvancingPhase != null)
            {
                await Task.Run(() =>
                {
                    Dispatcher.InvokeAsync(AdvanceScenarioInitial, DispatcherPriority.SystemIdle);
                });
            }
            else
            {
                ActionContext = ["SAVE", "SCROLL"];
                HandleInitialScenarioCall();
            }
            INIT = false;
        }
        public void Line_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
        }
        public bool HandlingScenarioUpdate = false;
        public async void UpdateScenario(string data){
            GamePhase phase = GS.ExecutingGamePhase();
            GS.PreCallProcess();
            phase.Update(data);
            if (GS.AdvancingPhase != null)
            {
                if (GS.AdvancingPhase.RequiresMapUpdate)
                {
                    HandleScenarioCall(false);
                }
                await Task.Run(() =>
                {
                    Dispatcher.InvokeAsync(AdvanceScenario, DispatcherPriority.SystemIdle);
                });
            }
            else
            {
                HandleScenarioCall(false);
            }
        }
        public async void UpdateScenario(double realX, double realY)
        {
            GamePhase phase = GS.ExecutingGamePhase();
            GS.PreCallProcess();
            phase.Update(realX, realY);
            if (GS.AdvancingPhase != null)
            {
                if (GS.AdvancingPhase.RequiresMapUpdate)
                {
                    HandleScenarioCall(false);
                }
                await Task.Run(() =>
                {
                    Dispatcher.InvokeAsync(AdvanceScenario, DispatcherPriority.SystemIdle);
                });
            }
            else
            {
                HandleScenarioCall(false);
            }
        }
        public void AdvanceScenario()
        {
            HandlingScenarioUpdate = true;
            GS.Advance(true);
            if (GS.AdvancingPhase != null)
            {
                if (GS.AdvancingPhase.RequiresMapUpdate)
                {
                    HandleScenarioCall(false);
                }
                Dispatcher.InvokeAsync(AdvanceScenario, DispatcherPriority.SystemIdle);
            }
            else
            {
                HandleScenarioCall(false);
                HandlingScenarioUpdate = false;
            }           
        }
        public void AdvanceScenarioInitial()
        {
            HandlingScenarioUpdate = true;
            GS.Advance(true);
            if (GS.AdvancingPhase != null)
            {
                Dispatcher.InvokeAsync(AdvanceScenarioInitial, DispatcherPriority.SystemIdle);
            }
            else
            {
                ActionContext = ["SAVE", "SCROLL"];
                HandleInitialScenarioCall();
                HandlingScenarioUpdate = false;
            }
        }
        public async void RefreshScenario(){
            GS.PreCallProcess();
            GS.ExecutingGamePhase().Start(false);
            if (GS.AdvancingPhase != null)
            {
                if (GS.AdvancingPhase.RequiresMapUpdate)
                {
                    HandleScenarioCall(false);
                }
                await Task.Run(() =>
                {
                    Dispatcher.InvokeAsync(AdvanceScenario, DispatcherPriority.SystemIdle);
                });
            }
            else
            {
                HandleScenarioCall(false);
            }
        }
        public void HandleInitialScenarioCall(){
            SetBackground();
            SetImageForMaps();
            foreach (GO location in GS.PIECES().Where(n => n.GAMELOCATIONID != null).Select(n => n.GAMELOCATION).Distinct()){
                DrawMarkerStack(location);
            } 
            foreach(GO location in GS.SHEETS().Where(n => n.GAMELOCATIONID != null).Select(n => n.GAMELOCATION).Distinct()){
                DrawMarkerStack(location);
            } 
            HandleScenarioCall(true);
        }
        public void HandleScenarioCall(bool initial){
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            bool InProgress = GS.AdvancingPhase != null;
            bool save = ActionContext.Contains("SAVE");
            bool scroll = ActionContext.Contains("SCROLL") && !InProgress;
            bool clicked = ActionContext.Contains("CLICKED");

            if(GS.advanced){
                //if(MapZoomLevel != GS.ExecutingGamePhase().zoomLevel){
                //    MapZoomLevel = GS.ExecutingGamePhase().zoomLevel;
                //    ZoomAll();
                //}
                foreach(GO loc in ExpandedGOs){
                    loc.EXPANDED = false;
                    DrawMarkerStack(loc);                    
                }
                ExpandedGOs.Clear();
            }
            Title = gameDir + " | " + scenarioDir + " | " + sessionDir + " | " + GS.TURNTITLE() + " | " + GS.TURNPHASE();
            GS.SHOWINSTRUCTIONS();
            if(GS.RESULT != null){
                MessageBox.Show("Scenario " + GS.data.ID + " is over. " + GS.RESULT);
            }
            if(GS.SelectedMarker != null){
                if(scroll && DraggingPIECE == null && DraggingSHEET == null){
                    PickMarker(GS.SelectedMarker);
                } else {
                    SelectMarker(GS.SelectedMarker);
                    if (clicked) { ShuffleMarker(GS.SelectedMarker); }
                    DrawMarkerStack(GS.SelectedMarker.GAMELOCATION);
                }
            }
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 100)
            {
                Debug.Print($"{stopwatch.Elapsed} : HandleScenario Pre-Work {GS.EXECUTINGPHASE}");
            }
            AfterScenarioCall(false);

            /*foreach(string imagefile in Directory.GetFiles(GetScenarioImageDir(), "*")){
                string imagefileName = System.IO.Path.GetFileName(imagefile);
                if(!imagefileName.Contains('.')){
                    string[] nameParts = imagefileName.Split(' ');
                    string first = nameParts.First();
                    string rest = "";
                    for(int n = 1; n < nameParts.Length; n++){
                        rest += nameParts[n] + " ";
                    }
                    rest = rest.Trim();
                    string newfileName = GetScenarioImageDir() + "/" + rest + " " + first + ".png";
                    System.IO.File.Move(imagefile, newfileName);
                }
            }*/
            //VIEWREFRESHED = true;
            stopwatch = new Stopwatch(); 
            stopwatch.Start();
            if (GS.SelectedMarker != null)
            {
                ShiftMarkerIndicator(GS.SelectedMarker);
            }
            if (!InProgress)
            {
                GS.ShowPrompt(initial);
            }
            if (GS.advanced && save && !InProgress)
            {
                SaveGameStateToLocalFiles();
                GS.advanced = false;
            }
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 100)
            {
                Debug.Print($"{stopwatch.Elapsed} : HandleScenario SaveGame {GS.EXECUTINGPHASE}");
            }
        }
        public void AfterScenarioCall(bool forceRefresh)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            GS.PostCallProcess();
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 100)
            {
                Debug.Print($"{stopwatch.Elapsed} : PostCallProcess {GS.EXECUTINGPHASE}");
            }

            stopwatch = new Stopwatch(); 
            stopwatch.Start();
            GS.DrawGOs();
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 100)
            {
                Debug.Print($"{stopwatch.Elapsed} : DrawGOs {GS.EXECUTINGPHASE}");
            }

            stopwatch = new Stopwatch();
            stopwatch.Start();
            DrawIndicators(forceRefresh);
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 100)
            {
                Debug.Print($"{stopwatch.Elapsed} : DrawIndicators {GS.EXECUTINGPHASE}");
            }
            if (GS.AdvancingPhase == null)
            {
                ActionContext = [];
            }
        }
        public int RollDice(int d1sides, int d2sides){
            int rollResult = 0;
            //reset die images
            //SetImage((Image)this.FindName("imgDie1"), GetImageDir() + "/" + "EMPTY.png", 25);
            //SetImage((Image)this.FindName("imgDie2"), GetImageDir() + "/" + "EMPTY.png", 25);

            if(d1sides > 0){
                int dieResult = CWConstants._random.Next(d1sides) + 1;
                rollResult += dieResult;
                //SetImage((Image)this.FindName("imgDie1"), GetImageDir() + "/" + "D6_Black" + dieResult + ".png", 25);
            }
            if(d2sides > 0){
                int dieResult = CWConstants._random.Next(d2sides) + 1;
                rollResult += dieResult;
                //SetImage((Image)this.FindName("imgDie2"), GetImageDir() + "/" + "D6_Black" + dieResult + ".png", 25);
            }

            return rollResult;
        }
        public static void Alert(string alert){
            Alert(alert, true, true);
        }
        public void Alert(GO obj, string alert){
            ScrollToMarker(obj, true);
            Alert(alert, true, true);           
        }
        public static void Alert(string alert, bool popup, bool print){
            if(popup){MessageBox.Show(alert);}
            if(print){Log(alert);}
        }
        public static void Log(string alert){
            Debug.Print(alert);
            MainWindow.log.Debug(alert);
        }
        public List<GO> DrawMarkerStackImmediately(GO location){
            bool refreshImages = location.refreshImages;
            List<GO> markers = GS.STACKSATLOCATION(location.ID);
            List<GO> sheets = GS.SHEETSATLOCATION(location.ID);
            bool inspected = GS.InspectedLocations.Contains(location);
            if (markers.Count != 0)
            {
                List<GO> drawnmarkers = DrawMarkers(markers, location.x, location.y, inspected ? Math.Max(Z_INSPECTION, location.z) : location.z, location.HIDDEN, location.EXPANDED, false, refreshImages, inspected);
                foreach(GO marker in markers.Where(n => !drawnmarkers.Contains(n) && n.GAMELOCATION == location)){
                    if(marker.DOMAIN == GO.DOMAIN_PIECE){
                        marker.x = 0;
                        marker.y = 0;
                    }
                    Image img = refreshImages ? GS.GOImage(marker, true) : marker.image;
                    if (img != null)
                    {
                        Canvas.SetTop(img, 0);
                        Canvas.SetLeft(img, 0);
                        Canvas.SetZIndex(img, Z_HIDDEN);

                        foreach (CWRectangleWrapper rw in GS.GORectangles(marker))
                        {
                            Rectangle rect = rw.rect;
                            Canvas.SetTop(rect, 0);
                            Canvas.SetLeft(rect, 0);
                            Canvas.SetZIndex(rect, Z_HIDDEN);
                        }
                    }
                }
                markers = drawnmarkers;
            }
            if(sheets.Count != 0){
                DrawMarkers(sheets, location.x, location.y, location.z, location.HIDDEN, location.EXPANDED, true, refreshImages, false);
            }
            location.refreshImages = false;
            return markers;
        }
        public void DrawMarkerStack(GO location)
        {
            DrawMarkerStack(location, false);
        }
        public void DrawMarkerStack(GO location, bool refreshImages){
            location.refreshImages = refreshImages || location.refreshImages;
            GOsToDraw.Add(location);
        }
        public void HideMarker(GO marker){
            Image img = GS.GOImage(marker, false);
            if(img != null){
                Canvas.SetZIndex(img, Z_HIDDEN);
            }
            //build rectangles
            foreach(CWRectangleWrapper rw in GS.GORectangles(marker)){
                Canvas.SetZIndex(rw.rect, Z_HIDDEN);
            }
        }
        private List<GO> DrawMarkers(List<GO> objs, 
                                double xStart, 
                                double yStart, 
                                int zStart, 
                                Boolean hidden, 
                                Boolean expanded, 
                                Boolean sheet,
                                Boolean refreshImages,
                                Boolean inspecting){
            bool ADJUSTSELECTIONMARKER = objs.Contains(GS.SelectedMarker);
            List<GO> gameObjects = [..objs.Where(n => !hidden && !n.HIDDEN)];
            Dictionary<GO, List<double>> MARKEROFFSETS = GS.INSPECTIONOFFSETS(gameObjects, inspecting);
            gameObjects = [.. MARKEROFFSETS.Keys];
            if(inspecting && gameObjects.Count <= 1)
            {
                inspecting = false;
            }
            //show
            foreach(GO marker in gameObjects){
                bool minimized = sheet && (marker.DRAGGING || !marker.EXPANDED);
                int i = gameObjects.IndexOf(marker);
                double sizeRatio = !inspecting || i == gameObjects.Count - 1 ? 1 : MiniMarkerRatio;
                marker.image_ratio = sizeRatio;
                int xyOffset = inspecting ? 0 : XY_MARKER_OFFSET * i * (expanded ? 3 : 1);
                int zOffset = zStart + (inspecting ? 0 : Z_MARKER_OFFSET * i);
                List<double> markerOffsets = inspecting switch{
                    true => MARKEROFFSETS[marker],
                    false => new(){(minimized ? marker.MINIMIZEDWIDTHVALUE : marker.IMAGEWIDTHVALUE) * -0.5, 
                                    (minimized ? marker.MINIMIZEDWIDTH / marker.IMAGEWIDTHVALUE * marker.IMAGEHEIGHTVALUE : marker.IMAGEHEIGHTVALUE) * -0.5}
                };
                double top = (yStart + markerOffsets[1] - xyOffset) * MapZoomLevel;
                double left = (xStart + markerOffsets[0] + xyOffset) * MapZoomLevel;
                int z = sheet ? marker.z : Z_MARKER + zOffset;
                Image img = GS.GOImage(marker, refreshImages);
                if (img != null){
                    Canvas.SetTop(img, top);
                    Canvas.SetLeft(img, left);
                    Canvas.SetZIndex(img, z);
                }
                foreach(CWRectangleWrapper rw in GS.GORectangles(marker)){
                    Rectangle rect = rw.rect;
                    Canvas.SetTop(rect, top + rw.y * MapZoomLevel * sizeRatio);
                    Canvas.SetLeft(rect, left + rw.x * MapZoomLevel * sizeRatio);
                    Canvas.SetZIndex(rect, !rw.show ? Z_HIDDEN : z + Z_MARKER_RECTANGLE_OFFSET + rw.z);
                }
            }
            if(ADJUSTSELECTIONMARKER){
                ShiftMarkerIndicator(GS.SelectedMarker);
            }
            return gameObjects;
        }
        private void DrawIndicators(bool forceRefresh){
            IndicatorsDrawn.Clear();
            HashSet<UIElement> drawn = [];
            List<GO> LINEGOS = [.. IndicatorsToDraw.Where(n => n._LINECOLOR != null)];
            List<GO> CONNECTORLINES = [..LINEGOS.Where(n => n.GAMEPIECE.DOMAIN == GO.DOMAIN_CONNECTOR)];
            List<GO> SHEETLINES = [.. LINEGOS.Where(n => n.GAMEPIECE.DOMAIN == GO.DOMAIN_SHEET)];
            List<GO> LOGICLINES = [.. LINEGOS.Where(n => n.GAMEPIECE.DOMAIN == GO.DOMAIN_LOGIC)];

            List<GO> ELLIPSEGOS = [.. IndicatorsToDraw.Where(n => n._ELLIPSECOLOR != null)];
            List<GO> PIECEELLIPSES = [.. ELLIPSEGOS.Where(n => n.GAMEPIECE.DOMAIN == GO.DOMAIN_PIECE)];
            List<GO> LOCATIONELLIPSES = [.. ELLIPSEGOS.Where(n => n.GAMEPIECE.DOMAIN == GO.DOMAIN_LOCATION)];
            List<GO> LOGICELLIPSES = [.. ELLIPSEGOS.Where(n => n.GAMEPIECE.DOMAIN == GO.DOMAIN_LOGIC)];

            CONNECTORLINES.ForEach(n => GS.GetLine(n.GAMEPIECE, forceRefresh));
            foreach (GO obj in IndicatorsToDraw.Select(n => n.GAMEPIECE).Distinct().ToList())
            {
                GO draw = null;
                Line l = null;
                Ellipse e = null;
                SolidColorBrush b = null;
                switch (obj.DOMAIN)
                {
                    case GO.DOMAIN_CONNECTOR:
                        //line only
                        draw = CONNECTORLINES.Where(n => n.GAMEPIECE.lineIndicator == obj.lineIndicator).OrderByDescending(n => ColorPriorities.IndexOf(n._LINECOLOR)).First();
                        l = obj.lineIndicator;
                        drawn.Add(l);
                        DrawnUIElements.Remove(l);
                        IndicatorsDrawn.Add(draw);
                        l.Stroke = GOIndicatorColorMap[draw._LINECOLOR];
                        Canvas.SetZIndex(l, obj.ALWAYSSHOW ? Z_MAP_CONNECTOR_INDICATOR : Z_CONNECTOR_INDICATOR);
                        break;
                    case GO.DOMAIN_SHEET:
                        draw = SHEETLINES.Where(n => n.GAMEPIECE == obj).OrderByDescending(n => ColorPriorities.IndexOf(n._LINECOLOR)).First();
                        l = GS.GetDynamicConnectorLine(obj, true);
                        drawn.Add(l);
                        DrawnUIElements.Remove(l);
                        IndicatorsDrawn.Add(draw);
                        l.Stroke = GOIndicatorColorMap[draw._LINECOLOR];
                        Canvas.SetZIndex(l, obj.ALWAYSSHOW ? Z_MAP_CONNECTOR_INDICATOR : Z_CONNECTOR_INDICATOR);
                        break;
                    case GO.DOMAIN_LOGIC:
                        draw = LOGICLINES.Where(n => n.GAMEPIECE == obj).OrderByDescending(n => ColorPriorities.IndexOf(n._LINECOLOR)).FirstOrDefault();
                        if (draw != null)
                        {
                            l = GS.GetDynamicConnectorLine(obj, true);
                            drawn.Add(l);
                            DrawnUIElements.Remove(l);
                            IndicatorsDrawn.Add(draw);
                            l.Stroke = GOIndicatorColorMap[draw._LINECOLOR];
                            Canvas.SetZIndex(l, obj.ALWAYSSHOW ? Z_MAP_CONNECTOR_INDICATOR : Z_CONNECTOR_INDICATOR);
                        }

                        draw = LOGICELLIPSES.Where(n => n.GAMEPIECE == obj).OrderByDescending(n => ColorPriorities.IndexOf(n._ELLIPSECOLOR)).FirstOrDefault();
                        if (draw != null)
                        {
                            e = GS.GetIndicator(obj, true, draw._ELLIPSESIZE);
                            b = GOIndicatorColorMap[draw._ELLIPSECOLOR];
                            e.Fill = draw._ELLIPSEFILL ? b : null;
                            e.Stroke = draw._ELLIPSEFILL ? null : b;
                            drawn.Add(e);
                            DrawnUIElements.Remove(e);
                            IndicatorsDrawn.Add(draw);
                            Canvas.SetZIndex(e, Z_INSPECTION - 1);
                        }
                        break;
                    case GO.DOMAIN_LOCATION:
                        draw = LOCATIONELLIPSES.Where(n => n.GAMEPIECE == obj).OrderByDescending(n => ColorPriorities.IndexOf(n._ELLIPSECOLOR)).First();
                        e = GS.GetIndicator(obj, true, draw._ELLIPSESIZE);
                        b = GOIndicatorColorMap[draw._ELLIPSECOLOR];
                        if (!obj.HIDDEN)
                        {
                            e.Fill = draw._ELLIPSEFILL ? b : null;
                            e.Stroke = draw._ELLIPSEFILL ? null : b;
                            int z = obj.PARENTSHEETID != null ? obj.PARENTSHEET.z + Z_LOCATION_INDICATOR : Z_LOCATION_INDICATOR;
                            drawn.Add(e);
                            DrawnUIElements.Remove(e);
                            IndicatorsDrawn.Add(draw);
                            Canvas.SetZIndex(e, z);
                        }
                        break;
                    case GO.DOMAIN_PIECE:
                        draw = PIECEELLIPSES.Where(n => n.GAMEPIECE == obj).OrderByDescending(n => ColorPriorities.IndexOf(n._ELLIPSECOLOR)).First();
                        e = GS.GetIndicator(obj, true, draw._ELLIPSESIZE);
                        b = GOIndicatorColorMap[draw._ELLIPSECOLOR];
                        if (!obj.HIDDEN)
                        {
                            e.Fill = draw._ELLIPSEFILL ? b : null;
                            e.Stroke = draw._ELLIPSEFILL ? null : b;
                            int z = obj.PARENTSHEETID != null ? obj.PARENTSHEET.z + Z_LOCATION_INDICATOR : Z_LOCATION_INDICATOR;
                            drawn.Add(e);
                            DrawnUIElements.Remove(e);
                            IndicatorsDrawn.Add(draw);
                            Canvas.SetZIndex(e, z);
                        }
                        break;
                    default:
                        break;
                }
            }
            foreach(UIElement uie in DrawnUIElements)
            {
                Canvas.SetZIndex(uie, MainWindow.Z_HIDDEN);
            }
            DrawnUIElements = [.. drawn];
            IndicatorsToDraw.Clear();
        }
        private void ShiftMarkerIndicator(GO marker){
            HideMarkerIndicator();
            if(marker.DOMAIN == GO.DOMAIN_PIECE && marker.GAMELOCATION?.HIDDEN == false && marker.image != null){
                GO location = marker.GAMELOCATION;
                double margin = marker.IMAGEWIDTHVALUE * 0.06125 * MapZoomLevel * marker.image_ratio;
                double width = marker.IMAGEWIDTHVALUE * 1.125 * MapZoomLevel * marker.image_ratio;
                SetImage(MarkerIndicator, GetImageDir() + "/COLOR.BLACK.png", width);
                DrawMarkerIndicator(Canvas.GetTop(marker.image) - margin, Canvas.GetLeft(marker.image) - margin, Canvas.GetZIndex(marker.image) - 1);
            }
        }
        private void DrawMarkerIndicator(double top, double left, int z){
            Canvas.SetTop(MarkerIndicator, top);
            Canvas.SetLeft(MarkerIndicator, left);
            Canvas.SetZIndex(MarkerIndicator, z);
        }
        public void HideMarkerIndicator(){
            //remove marker indicator from current position
            DrawMarkerIndicator(0, 0, Z_HIDDEN);
        }
        public void ScrollToMarker(GO marker, Boolean forceScroll){
            ScrollToCoordinate(marker.GAMELOCATION.x, marker.GAMELOCATION.y, forceScroll);
        }
        public void ScrollToCoordinate(double x, double y, Boolean forceScroll){
            //center on indicator
            double currentWidth = Math.Max(CANVAS_SCROLL_VIEWER.ViewportWidth, 1000);
            double currentHeight = Math.Max(CANVAS_SCROLL_VIEWER.ViewportHeight, 500);
            double currentOffsetWidth = CANVAS_SCROLL_VIEWER.HorizontalOffset;
            double currentOffsetHeight = CANVAS_SCROLL_VIEWER.VerticalOffset;
            double nearEdgeDistance = 100 * MapZoomLevel * 0.5;
            double left = currentOffsetWidth + nearEdgeDistance;
            double right = (currentOffsetWidth + currentWidth) - nearEdgeDistance;
            double top = currentOffsetHeight + nearEdgeDistance;
            double bottom = (currentOffsetHeight + currentHeight) - nearEdgeDistance;
            
            //if location coordinates are near or beyond the edge, scroll
            double locationX = x * MapZoomLevel;
            double locationY = y * MapZoomLevel;
            if(locationX <= left || locationX >= right || locationY <= top || locationY >= bottom || forceScroll){
                double rectLeft = Math.Max(0, locationX - (currentWidth * 0.5));
                double rectTop = Math.Max(0, locationY - (currentHeight * 0.5));
                CANVAS_SCROLL_VIEWER.ScrollToHorizontalOffset(rectLeft);
                CANVAS_SCROLL_VIEWER.ScrollToVerticalOffset(rectTop);
                ViewportHorizontalOffset = rectLeft;
                ViewportVerticalOffset = rectTop;
                HideMenu(StackMenu);
                HideMenu(MainMenu);
                HideMenu(MarkerChoiceMenu);
                HideMenu(OptionsMenu);
                ChoiceMenuMarker = null;
                InfoMenuMarker = null;
            }
        }
        private void SetBackground(){
            //GO background = GS.TYPE("BACKGROUND").First();
            BACKGROUND.Width = GS.WorldSize * MapZoomLevel;
            BACKGROUND.Height = GS.WorldSize * MapZoomLevel;
            BACKGROUND.Background = System.Windows.Media.Brushes.Gray;
            //SetZoomableImage((Image)this.FindName("imgBackground"), GetImageDir() + "/BACKGROUND.png", GS.WorldSize);
        }
        private void SetImageForMaps(){
            foreach(GO map in GS.TYPE("MAP")){
                Image img = GS.GOImage(map, true);
                Canvas.SetTop(img, map.YCOORD * MapZoomLevel);
                Canvas.SetLeft(img, map.XCOORD * MapZoomLevel);
                Canvas.SetZIndex(img, map.ZCOORD);
                if(map.GetInt("ROTATION") != 0){
                    RotateTransform rotateTransform = new RotateTransform(map.GetInt("ROTATION"));
                    img.RenderTransform = rotateTransform; 
                }             
            }
        }
        public void SetZoomableImage(Image img, string filename, double width){
            SetImage(img, filename, width * MapZoomLevel);
        }
        public void SetImage(Image img, string filename, double width){
            try{
                BitmapImage bmImg = new();
                bmImg.BeginInit();
                bmImg.UriSource = new Uri(filename, UriKind.Absolute);
                bmImg.DecodePixelWidth = (int)width;
                bmImg.EndInit();
                img.Width = width;
                img.Source = bmImg;
            } catch(Exception ex){
                BitmapImage bmImg = new();
                bmImg.BeginInit();
                bmImg.UriSource = new Uri(GetImageDir() + "/EMPTY.png", UriKind.Absolute);
                bmImg.DecodePixelWidth = (int)width;
                bmImg.EndInit();
                img.Width = width;
                img.Source = bmImg;
                log.Error("Error: " + ex.Message + " " + ex.StackTrace);
            }
        }
        public void SetZoomableImage(Image img, string filename, double width, double height){
            SetImage(img, filename, width * MapZoomLevel, height * MapZoomLevel);
        }
        public void SetImage(Image img, string filename, double width, double height){
            try{
                BitmapImage bmImg = new();
                bmImg.BeginInit();
                bmImg.UriSource = new Uri(filename, UriKind.Absolute);
                bmImg.DecodePixelWidth = (int)width;
                bmImg.DecodePixelHeight = (int)height;
                bmImg.EndInit();
                img.Width = width;
                img.Height = height;
                img.Source = bmImg;
            } catch(Exception ex){
                BitmapImage bmImg = new();
                bmImg.BeginInit();
                bmImg.UriSource = new Uri(GetImageDir() + "/EMPTY.png", UriKind.Absolute);
                bmImg.DecodePixelWidth = (int)width;
                bmImg.EndInit();
                img.Width = width;
                img.Source = bmImg;
                log.Error("Error: " + ex.Message + " " + ex.StackTrace);
            }
        }
        public void ExpandOrCollapseSheet(GO obj, Boolean expanded){
            ExpandOrCollapseSheet(obj, expanded, false);
        }
        public void ExpandOrCollapseSheet(GO obj, Boolean expanded, Boolean immediately){
            obj.EXPANDED = expanded;
            if(immediately){
                obj.GAMELOCATION.refreshImages = true;
                DrawMarkerStackImmediately(obj.GAMELOCATION);
            } 
            else 
            {
                DrawMarkerStack(obj.GAMELOCATION, true);
            }
            List<GO> sheetLocs = GS.TYPE(GO.DOMAIN_PIECE, "PARENTSHEETID", obj.ID).Select(n => n.GAMELOCATION).ToList();
            foreach(GO loc in GS.TYPE(GO.DOMAIN_LOCATION, "PARENTSHEETID", obj.ID)){
                loc.HIDDEN = !obj.EXPANDED;
                if(sheetLocs.Contains(loc)){
                    if(immediately){
                        loc.refreshImages = true;
                        DrawMarkerStackImmediately(loc);
                    } 
                    else 
                    {
                        DrawMarkerStack(loc);
                    }
                }
            }
        }
        public void Img_MouseMove(object sender, MouseEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            //show x, y of location
            Point clickPoint = e.GetPosition(WORLD_CANVAS);
            double realY = clickPoint.Y / MapZoomLevel;
            double realX = clickPoint.X / MapZoomLevel;
            if(GS.ExecutingGamePhase().MapMouseMove){
                GS.ProcessMapMouseMove(realX, realY);
            }
            Title = gameDir + " | " + scenarioDir + " | " + sessionDir + " | " + GS.TURNTITLE() + " | " + GS.TURNPHASE() + " | " + Math.Round(realX, 0) + " | " + Math.Round(realY, 0);
            //GO hex = GS.TYPE("HEX").Where(n => Math.Abs(n.x - realX) < 40 && Math.Abs(n.y - realY) < 40).FirstOrDefault();
            //Title = Math.Round(realX, 0) + " | " + Math.Round(realY, 0) + (hex == null ? "" : " " + hex.ID);
            /*if(VIEWREFRESHED){
                VIEWREFRESHED = false;
                GS.PromptHelp(false);
            }*/
            if (DraggingPIECE == null && DraggingSHEET == null)
            {
                Image clickedImage = (Image)e.Source;
                GO marker = GetMarkerFromImage(clickedImage);
                try
                {
                    using (new WaitCursor())
                    {
                        ViewportHorizontalOffset = -1;
                        ViewportVerticalOffset = -1;
                        GS.ProcessImageMouseMove(marker);
                    }
                }
                catch (Exception ex)
                {
                    throwError(ex);
                }
            }
            else
            {
                MouseOverMarker = null;
                ChoiceMenuMarker = null;
                InfoMenuMarker = null;
            }
        }
        private void Img_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                using(new WaitCursor())
                {
                    Point dropPoint = e.GetPosition(WORLD_CANVAS);
                    Image clickedImage = (Image)e.Source;
                    GO marker = GetMarkerFromImage(clickedImage);
                    bool PIECE = marker.DOMAIN == GO.DOMAIN_PIECE;
                    bool SHEET = !PIECE;
                    GO sheet = SHEET ? marker : marker.PARENTSHEET;
                    bool inspecting = PIECE && GS.InspectedLocations.Contains(marker.GAMELOCATION);
                    bool UNIVERSALDROP = GS.ExecutingGamePhase().UniversalDrop;
                    Boolean canInteract = GS.CANINTERACT(marker);
                    if(e.ClickCount == 1){
                        SHOWACTIONS = true;
                        bool DRAGOVER = GS.ExecutingGamePhase().DragOver;
                        bool CENTERED = !inspecting || (marker.x == 0 && marker.y == 0);
                        Boolean PIECECANDRAG = PIECE && GS.CANDRAG(marker) || (PIECE && canInteract && UNIVERSALDROP);
                        bool MOVETOCENTER = DRAGOVER && !CENTERED && PIECECANDRAG;
                        Boolean SHEETCANDRAG = !PIECECANDRAG && sheet != null && GS.CANDRAG(sheet);
                        if(PIECE){
                            //treat draggable pieces in DragOver phases differently.  move them to center and require them center before allowing drag
                            if(canInteract){
                                if (inspecting && !MOVETOCENTER)
                                {
                                    SelectMarker(marker);
                                }
                                else
                                {
                                    PickMarkerImmediately(marker);
                                }
                            } else {
                                ClickMarker(marker, !inspecting);                               
                            }
                        } else if(canInteract) {
                            GS.SelectedMarker = marker;
                        }
                        if(PIECECANDRAG && !MOVETOCENTER){
                            marker.TEMPLOCATIONID = marker.GAMELOCATIONID;
                            DraggingPIECE = marker;
                            DraggingSHEET = null;
                            DropTargets = new();
                            if(!UNIVERSALDROP){
                                DropTargets = GS.DRAGTARGETS(marker);
                                DropTargets.Add(marker.GAMELOCATION);
                            }                  
                            if((DRAGOVER || GS.ExecutingGamePhase().DragDrop) && GS.InteractionMap.ContainsKey(DraggingPIECE)){
                                if (inspecting)
                                {
                                    ActionContext = [];
                                }
                                else
                                {
                                    ActionContext = ["CLICKED"];
                                }
                                RefreshScenario();
                            }
                            OriginGO = new(){
                                x = dropPoint.X,//Canvas.GetLeft(clickedImage), 
                                y = dropPoint.Y,//Canvas.GetTop(clickedImage),
                                z = Canvas.GetZIndex(marker.image)
                            };
                            DragDrop.DoDragDrop(marker.image, new DataObject(DataFormats.Serializable, marker), DragDropEffects.Move);
                        } else if(SHEETCANDRAG){
                            sheet.TEMPLOCATIONID = sheet.GAMELOCATIONID;
                            DraggingSHEET = sheet;
                            DraggingPIECE = null;
                            DropTargets = GS.DRAGTARGETS(sheet);
                            if((GS.ExecutingGamePhase().DragOver || GS.ExecutingGamePhase().DragDrop) && GS.InteractionMap.ContainsKey(DraggingSHEET)){
                                ActionContext = ["SCROLL", "SAVE", "CLICKED"];
                                UpdateScenario(null);
                            }
                            if(sheet.EXPANDED){
                                ExpandOrCollapseSheet(sheet, false, true);
                                DrawIndicators(true); 
                                sheet.EXPANDED = true;
                            }
                            OriginGO = new(){
                                x = dropPoint.X,//Canvas.GetLeft(clickedImage), 
                                y = dropPoint.Y,//Canvas.GetTop(clickedImage),
                                z = Canvas.GetZIndex(sheet.image)
                            };
                            DragDrop.DoDragDrop(sheet.image, new DataObject(DataFormats.Serializable, sheet), DragDropEffects.Move);
                        } else if(canInteract){
                            DraggingPIECE = null;
                            DraggingSHEET = null;
                            ActionContext = inspecting && !MOVETOCENTER ? [] : ["CLICKED"];
                            RefreshScenario();
                        }
                    } else if(e.ClickCount == 2){
                        GS.ProcessDoubleLeftClick(marker);     
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void Img_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                using(new WaitCursor())
                {
                    Image clickedImage = (Image)e.Source;
                    GO marker = GetMarkerFromImage(clickedImage);
                    bool PIECE = marker.DOMAIN == GO.DOMAIN_PIECE;
                    bool inspecting = PIECE && GS.InspectedLocations.Contains(marker.GAMELOCATION);
                    Boolean canInteract = GS.CANINTERACT(marker);
                    if(e.ClickCount == 1){
                        //SHOWACTIONS = false;
                        if(PIECE){
                            if(canInteract){
                                if (inspecting)
                                {
                                    SelectMarker(marker);
                                    ActionContext = [];
                                }
                                else
                                {
                                    PickMarkerImmediately(marker);
                                    ActionContext = ["CLICKED"];
                                }
                                RefreshScenario();
                            } else {
                                ClickMarker(marker, !inspecting);                               
                            }
                        }
                    } else if(e.ClickCount == 2){
                        GS.ProcessDoubleRightClick(marker);     
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void worldCanvas_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Serializable))
            {
                Point dropPoint = e.GetPosition(WORLD_CANVAS);
                double realY = dropPoint.Y / MapZoomLevel;
                double realX = dropPoint.X / MapZoomLevel;        
                if(DraggingPIECE != null){
                    DraggingPIECE.DRAGGING = true;
                    List<GO> gameObjects = new(){ DraggingPIECE };
                    HideMenus();
                    DrawMarkers(gameObjects, realX, realY, Z_DRAGGING_MARKER, false, false, false, false, false);
                    ShiftMarkerIndicator(DraggingPIECE);
                    if(GS.ExecutingGamePhase().DragOver && DropTargets.Any()){
                        //we can only drag to hexes or the current location the marker is at
                        GO nearestLocation = DropTargets.OrderBy(x => GetDistance(x, realX, realY)).First();
                        if(nearestLocation.ID != DraggingPIECE.TEMPLOCATIONID){
                            DraggingPIECE.TEMPLOCATIONID = nearestLocation.ID;
                            if(GS.InteractionMap.ContainsKey(DraggingPIECE)){
                                ActionContext = ["CLICKED", "SAVE"];
                                UpdateScenario(null);
                                DropTargets = GS.DRAGTARGETS(DraggingPIECE);
                                DropTargets.Add(DraggingPIECE.GAMELOCATION);
                            }
                        }
                    }
                } else if(DraggingSHEET != null){
                    DraggingSHEET.DRAGGING = true;
                    List<GO> gameObjects = new(){ DraggingSHEET };
                    DrawMarkers(gameObjects, realX, realY, Z_MARKER, false, false, true, false, false);
                    /*GO nearestLocation = DropTargets.OrderBy(x => GetDistance(x, realX, realY)).First();
                    if(nearestLocation.ID != DraggingGO.TEMPLOCATIONID){
                        DraggingGO.TEMPLOCATIONID = nearestLocation.ID;
                    }*/              
                }
            }
        }
        private void worldCanvas_Drop(object sender, DragEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    if (e.Data.GetDataPresent(DataFormats.Serializable))
                    {
                        GO DraggingGO = DraggingPIECE ?? DraggingSHEET;
                        DraggingPIECE = null;
                        DraggingSHEET = null;
                        Point dropPoint = e.GetPosition(WORLD_CANVAS);
                        double realY = dropPoint.Y / MapZoomLevel;
                        double realX = dropPoint.X / MapZoomLevel;
                        bool DIDNTMOVE =    Math.Abs(OriginGO.x - dropPoint.X) <= 1 &&
                                            Math.Abs(OriginGO.y - dropPoint.Y) <= 1;
                        Canvas.SetZIndex(DraggingGO.image, OriginGO.z);
                        OriginGO = null;
                        if(DraggingGO.DOMAIN == GO.DOMAIN_SHEET && !DIDNTMOVE){
                            GO nearestLocation = DropTargets.OrderBy(x => GetDistance(x, realX, realY)).FirstOrDefault();
                            if(DraggingGO.SHEETANCHORLOCATIONID != null){
                                DraggingGO.TEMPLOCATIONID = DraggingGO.SHEETANCHORLOCATIONID;
                                //where do we move the anchor. if too far away from drop targets, snap to nearest drop target
                                GO anchorLocation = GS.LOCATION(DraggingGO.SHEETANCHORLOCATIONID);
                                if(nearestLocation != null && GetDistance(nearestLocation, realX, realY) >= 60){
                                    realX = nearestLocation.x;
                                    realY = nearestLocation.y;
                                }
                                anchorLocation.x = realX;
                                anchorLocation.XCOORD = realX;
                                anchorLocation.y = realY;
                                anchorLocation.YCOORD = realY;
                            } else if(nearestLocation != null){
                                DraggingGO.TEMPLOCATIONID = nearestLocation.ID;
                            } else {
                                DraggingGO.TEMPLOCATIONID = DraggingGO.GAMELOCATIONID;
                            }
                        } else if(!GS.ExecutingGamePhase().DragOver && !DIDNTMOVE){
                            GO nearestLocation = DropTargets.OrderBy(x => GetDistance(x, realX, realY)).FirstOrDefault();
                            nearestLocation ??= GS.LOCATIONS().Where(n => !n.HIDDEN).OrderBy(x => GetDistance(x, realX, realY)).First();
                            DraggingGO.TEMPLOCATIONID = nearestLocation.ID;
                        }
                        DropTargets = null;
                        if(DraggingGO.DOMAIN == GO.DOMAIN_PIECE){
                            if(DraggingGO.DRAGGING){
                                DraggingGO.DRAGGING = false;
                                if(GS.InteractionMap.ContainsKey(DraggingGO)){
                                    if(GS.ExecutingGamePhase().DragDrop){
                                        if (!DIDNTMOVE)
                                        {
                                            ActionContext = ["SAVE", "CLICKED"];
                                            UpdateScenario(null);
                                        }
                                        else
                                        {
                                            ActionContext = [];
                                            RefreshScenario();
                                        }
                                    }
                                }
                            }
                            DraggingGO.TEMPLOCATIONID = null;
                        } else if(DraggingGO.DOMAIN == GO.DOMAIN_SHEET){
                            DraggingGO.DRAGGING = false;
                            string dropLoc = DraggingGO.TEMPLOCATIONID;
                            GO droppedSheet = DraggingGO;
                            DraggingGO.TEMPLOCATIONID = null;
                            GS.CHANGELOCATION(droppedSheet, dropLoc);
                            ExpandOrCollapseSheet(droppedSheet, droppedSheet.EXPANDED);
                            ActionContext = [];
                            RefreshScenario();
                        }                
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void ImgSelected_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            if (INIT){return;}
            Image clickedImage = (Image)e.Source;
            GO marker = clickedImage == SELECTED_MARKER_IMAGE ? GS.SelectedMarker : GetMarkerFromImage(clickedImage);
            PickMarkerImmediately(marker);
            if(Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) {
                GS.ProcessControlClick(marker);
            }
            ActionContext = ["CLICKED"];
            RefreshScenario();
        }
        private GO GetMarkerFromImage(Image img){
            return GS.GOImageMap.TryGetValue(img, out GO value) ? value : null;
        }
        private List<GO> GetConnectorsFromLine(Line l){
            return GS.CONNECTORS().Where(n => n.lineIndicator == l || n.lineIndicator2 == l).ToList();
        }
        public void HideMenus(){
            foreach (Menu m in AllMenus){
                HideMenu(m);
            }
        }
        public void HideMenu(Menu m)
        {
            if (m == StackMenu || m == OptionsMenu)
            {
                Canvas.SetRight(m, 1);
            }
            else
            {
                Canvas.SetLeft(m, 1);
            }
            if(m == MarkerInfoMenu || m == SelectedMarkerInfoMenu || m == SelectedMarkerTargetInfoMenu)
            {
                Canvas.SetBottom(m, 1);
            }
            else
            {
                Canvas.SetTop(m, 1);
            }
            Canvas.SetZIndex(m, Z_HIDDEN);
        }
        public void MarkercmiImg_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                using(new WaitCursor())
                {
                    HideMenu(MarkerChoiceMenu);
                    MenuItem mi = sender as MenuItem;
                    string header = mi.Header.ToString();
                    ActionContext = ["SCROLL", "SAVE", "CLICKED"];
                    if(header == "END PHASE") { header = "NEXT"; }
                    UpdateScenario(header);                                      
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void StackcmiImg_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                using (new WaitCursor())
                {
                    MenuItem mi = sender as MenuItem;
                    if(STACKMENUGOs.TryGetValue(mi, out GO marker))
                    {
                        GS.ProcessStackMenuClick(marker);
                    } 
                    else if (CHOICEMENUGOs.TryGetValue(mi, out marker))
                    {
                        GS.ProcessStackMenuClick(marker);
                    }
                    else if (AIREVIEWMENUGOs.TryGetValue(mi, out marker))
                    {
                        GS.ProcessStackMenuClick(marker);
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void MapcmiImg_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                using(new WaitCursor())
                {
                    MenuItem mi = sender as MenuItem;
                    string header = mi.Header.ToString();
                    ActionContext = ["SCROLL", "SAVE", "CLICKED"];
                    UpdateScenario(header);                                      
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void MainMenucmiImg_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                using(new WaitCursor())
                {
                    MenuItem mi = sender as MenuItem;                    
                    string header = mi.Header.ToString();
                    switch(header){
                        case "How do I use this app?":
                            GS.APPTOUR();
                            break;
                        case "Start: EMPTY SANDBOX":
                            HideMenu(MainMenu);
                            sessionDir = GenerateSessionID();
                            LoadGame([]);
                            break;
                        case "RETURN TO MAIN MENU":
                        case "Start: PRE-BUILT MISSION":
                            TEMPLATEMODE = !TEMPLATEMODE;
                            PresentMainMenu(GetGameSaveDir(), null);
                            break;
                        case "DONE":
                            HideMenu(OptionsMenu);
                            break;
                        default:
                            break;
                    }                                  
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void GameFilecmiImg_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                Dictionary<string, string> dialogInfo = [];
                MenuItem mi = sender as MenuItem;
                string h = mi.Header.ToString();
                string p1 = GetGameSaveDir().Replace("\\", "/") + "/";
                string p2 = SaveGameFileToPath[mi].Replace("\\", "/");
                if (TEMPLATEMODE)
                {
                    string template = p2.Replace(p1, "");
                    sessionDir = "TEMPLATES";
                    //copy template to new dir
                    string newSaveGameName = template + "." + DateTime.Now.ToString("yyyyMMdd.HHmmss");
                    string newDirectory = GetGameSaveDir() + "/" + newSaveGameName;
                    Dictionary<string, string> FilesToCopy = [];
                    string[] ofiles = System.IO.Directory.GetFiles(GetGameSessionDir(), "*.*");
                    foreach (string s in ofiles)
                    {
                        // Use static Path methods to extract only the file name from the path.
                        string fileName = System.IO.Path.GetFileName(s);
                        if (fileName == template + ".cwsav")
                        {
                            FilesToCopy[s] = System.IO.Path.Combine(newDirectory, GameStateFile);
                        }
                        else if (fileName == template + ".txt")
                        {
                            FilesToCopy[s] = System.IO.Path.Combine(newDirectory, RulesFile);
                            RULES = File.ReadAllText(s);
                        }
                    }
                    //dialog
                    dialogInfo["RULES"] = RULES;
                    dialogInfo["TITLE"] = template;
                    Window scenarioOptionsDialog = new ScenarioOptions(dialogInfo);
                    bool? result = scenarioOptionsDialog.ShowDialog();
                    if (result == true)
                    {
                        using (new WaitCursor())
                        {

                            HideMenu(MainMenu);

                            //after processing

                            System.IO.Directory.CreateDirectory(newDirectory);
                            foreach (string s in FilesToCopy.Keys)
                            {
                                string _currFileName = FilesToCopy[s];
                                System.IO.File.Copy(s, _currFileName, true);
                            }
                            MainWindow.Alert("New Save Game folder created: " + newSaveGameName);
                            sessionDir = newSaveGameName;
                            sessionDirExists = true;
                            LoadGame(dialogInfo);
                        }
                    }
                }
                else
                {
                    using (new WaitCursor())
                    {

                        HideMenu(MainMenu);
                        sessionDir = p2.Replace(p1, "");
                        sessionDirExists = true;
                        LoadGame(dialogInfo);
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void ConfigMenucmiImg_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                using(new WaitCursor())
                {
                    MenuItem mi = sender as MenuItem;                    
                    string header = mi.Header.ToString();
                    GS.ProcessMainMenuClick(header, "CONFIG", mi.IsCheckable);                                 
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void VPMenucmiImg_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                using(new WaitCursor())
                {
                    MenuItem mi = sender as MenuItem;                    
                    string header = mi.Header.ToString();
                    GS.ProcessMainMenuClick(header, "VP", false);                                 
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void AIMenucmiImg_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            try
            {
                using (new WaitCursor())
                {
                    MenuItem mi = sender as MenuItem;
                    string header = mi.Header.ToString();
                    GS.ProcessMainMenuClick(header, "AI", mi.IsCheckable);
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void UpdateBanner(string banner, string side)
        {
            TextBlock textBlock = ((TextBlock)FindName("TXTINFO"));
            textBlock.Inlines.Clear();
            string PROMPT = banner ?? GS.ExecutingGamePhase().ID;
            textBlock.Inlines.Add(new Run(PROMPT)
            {
                FontWeight = FontWeights.Bold,
                FontSize = SystemFonts.MessageFontSize > 24 ? SystemFonts.MessageFontSize : Math.Min(24, SystemFonts.MessageFontSize * 2)
            });
            //textBlock.Inlines.Add(new Run("\n" + GS.INSTRUCTIONS));
            switch (side)
            {
                case "SOV":
                    textBlock.Background = Brushes.Red;
                    textBlock.Foreground = Brushes.White;
                    break;
                case "ALLIES":
                    textBlock.Background = Brushes.Blue;
                    textBlock.Foreground = Brushes.White;
                    break;
                default:
                    textBlock.Background = Brushes.White;
                    textBlock.Foreground = Brushes.Black;
                    break;
            }           
        }
        private void Img_MouseEnter(object sender, MouseEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
        }
        private void Img_MouseLeave(object sender, MouseEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
        }
        public static double GetDistance(GO location, double x, double y){
            return Math.Sqrt(Math.Pow(location.x - x, 2) + Math.Pow(location.y - y, 2));
        }  
        public void ShuffleMarker(GO marker){
            GS.ShuffleMarker(marker);
        }
        public void PickMarker(GO pickedMarker){
            SelectMarker(pickedMarker);
            ShuffleMarker(pickedMarker);
            ScrollToMarker(pickedMarker, false);
            DrawMarkerStack(pickedMarker.GAMELOCATION);                        
        }
        public void PickMarkerImmediately(GO pickedMarker){
            SelectMarker(pickedMarker);
            ShuffleMarker(pickedMarker);
            ScrollToMarker(pickedMarker, false);
            DrawMarkerStackImmediately(pickedMarker.GAMELOCATION);                        
        }
        public void SelectMarker(GO selectedMarker) {
            if (selectedMarker != null)
            {
                double imgWidth = Math.Max(Math.Min(SystemParameters.PrimaryScreenWidth, SystemParameters.PrimaryScreenHeight) * 0.1, MinDockMarkerSize);
                SetImage(SELECTED_MARKER_IMAGE, GetScenarioImageDir() + "/" + selectedMarker.IMAGEFILENAME, imgWidth);
                ((TextBlock)this.FindName("txtSelectedMarkerInfo")).Text = GS.INFO(GS, selectedMarker);
                if (selectedMarker != GS.SelectedMarker)
                {
                    //clear clicked on marker info
                    SetImage(CLICKED_MARKER_IMAGE, GetImageDir() + "/EMPTY.png", imgWidth);
                    ((TextBlock)this.FindName("txtClickedMarkerInfo")).Text = "";
                }
                GS.SelectedMarker = selectedMarker;
                ShiftMarkerIndicator(selectedMarker);
            }
        }
        public void ClearSelectedMarker(){

            double imgWidth = Math.Max(Math.Min(SystemParameters.PrimaryScreenWidth, SystemParameters.PrimaryScreenHeight) * 0.1, MinDockMarkerSize);
            SetImage(SELECTED_MARKER_IMAGE, GetImageDir() + "/EMPTY.png", imgWidth); 
            ((TextBlock)this.FindName("txtSelectedMarkerInfo")).Text = "";
            //clear clicked on marker info
            SetImage(CLICKED_MARKER_IMAGE, GetImageDir() + "/EMPTY.png", imgWidth);
            ((TextBlock)this.FindName("txtClickedMarkerInfo")).Text = "";
            GS.SelectedMarker = null;
            HideMarkerIndicator();
        }
        public void ClickMarker(GO marker, bool full){
            double imgWidth = Math.Max(Math.Min(SystemParameters.PrimaryScreenWidth, SystemParameters.PrimaryScreenHeight) * 0.1, MinDockMarkerSize);
            SetImage(CLICKED_MARKER_IMAGE, GetScenarioImageDir() + "/" + marker.IMAGEFILENAME, imgWidth);
            ((TextBlock)this.FindName("txtClickedMarkerInfo")).Text = GS.INFO(GS, marker);
            if (full)
            {
                ShuffleMarker(marker);
                DrawMarkerStack(marker.GAMELOCATION);
                AfterScenarioCall(false);
            }
            GS.ClickedMarker = marker;
        }      
        public void AddImageToGame(Image img){
            img.MouseMove += Img_MouseMove;
            img.MouseLeftButtonDown += Img_MouseLeftButtonDown;
            img.MouseRightButtonDown += Img_MouseRightButtonDown;
            img.MouseEnter += Img_MouseEnter;
            img.MouseLeave += Img_MouseLeave;
            WORLD_CANVAS.Children.Add(img);
        }
        public void AddRectToGame(Rectangle rect){
            WORLD_CANVAS.Children.Add(rect);
        }
        public bool InterruptAIProcessing = false;
        private void btnScenario_Click(object sender, RoutedEventArgs e){
            Button button = sender as Button;

            if (HandlingScenarioUpdate) 
            {
                if(GS.AI_Sides.Count == 2 && (string)button.ToolTip == "Next Phase")
                {
                    InterruptAIProcessing = true;
                }
                return; 
            }
            string name = button.Name.Replace("btn", "");
            int column = CWApp.Helpers.CSVFile.ParseInt(name[..2], 0);
            int row = CWApp.Helpers.CSVFile.ParseInt(name[2..], 0);
            ScenarioButtonClick(column, row);
            return;
        }
        public void ZoomAll(){
            SetBackground();
            SetImageForMaps();
            IndicatorsToDraw = [..IndicatorsDrawn];
            HashSet<GO> zoomingGOs = [];
            foreach(GO location in GS.PIECES().Where(n => n.GAMELOCATION != null).Select(n => n.GAMELOCATION)){
                zoomingGOs.Add(location);
            }
            foreach(GO location in GS.SHEETS().Where(n => n.GAMELOCATION != null).Select(n => n.GAMELOCATION)){
                zoomingGOs.Add(location);
            }
            zoomingGOs.ToList().ForEach(n => DrawMarkerStack(n, true));
            
            AfterScenarioCall(true);
            HideMenu(StackMenu);
            HideMenu(MainMenu);
            HideMenu(OptionsMenu);
            ChoiceMenuMarker = null;
            InfoMenuMarker = null;
        }
        private void mnuNextMarker_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            if (INIT){return;}
            try
            {
                using(new WaitCursor())
                {
                    GS.SelectedMarker = GS.NEXTINTERACTIVE(GS.SelectedMarker);
                    ActionContext = ["SCROLL", "CLICKED"];
                    SHOWACTIONS = true;
                    RefreshScenario();
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void ScenarioButtonClick(int column, int row)
        {
            GS.ScenarioButtonClick(column, row);
            GS.GetToolTip(column, row);
        }

        private void mnuPreviousMarker_Click(object sender, RoutedEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            if (INIT){return;}
            try
            {
                using(new WaitCursor())
                {
                    GS.SelectedMarker = GS.PREVIOUSINTERACTIVE(GS.SelectedMarker);
                    ActionContext = ["SCROLL", "CLICKED"];
                    SHOWACTIONS = true;
                    RefreshScenario();
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void SaveGameStateToLocalFiles()
        {
            combinedState.state["SCENARIO.VARS"].Clear();
            foreach(string k in GS.data._data.Keys.Order()){
                combinedState.state["SCENARIO.VARS"].Add(k, GS.data._data[k]);
            };
            foreach(GO obj in GS._ChangedObjects.Keys){
                if(obj.RECYCLED || GS._ChangedObjects[obj].Count == 0)
                {
                    combinedState.state.Remove(obj.ID);
                    obj.SavedState.Clear();
                } else {
                    combinedState.state[obj.ID] = GS._ChangedObjects[obj];
                    obj.SavedState = new(obj._data);
                }
            }
            if (!sessionDirExists)
            {
                Directory.CreateDirectory(GetGameSessionDir());
                sessionDirExists = true;
            }
            using (StreamWriter file = File.CreateText(GetGameStateFile())){
                JsonSerializer serializer = JsonSerializer.Create(JSONSettings);                
                serializer.Serialize(file, combinedState);
            }
            GS._ChangedObjects.Clear();

            /*gameState = GS.GetScenarioState();
            using (StreamWriter file = File.CreateText(GetGameStateFile())){
                JsonSerializer serializer = JsonSerializer.Create(JSONSettings);                
                serializer.Serialize(file, gameState);
            }
            foreach(GameState discard in GS.GetObjectStates(true)){
                DeleteFile(discard.state["ID"]);
            }
            foreach(GameState update in GS.GetObjectStates(false)){
                string filename = GetGameSessionDir() + "/" + update.state["ID"] + ".o.txt";
                using StreamWriter file = File.CreateText(filename);
                JsonSerializer serializer = JsonSerializer.Create(JSONSettings);
                serializer.Serialize(file, update);
            }
            GS._ChangedObjects.Clear();*/
        }
        public void DeleteFile(string id){
            try{
                File.Delete(GetGameSessionDir() + "/" + id + ".o.txt");
            } catch(Exception e){
                String debug = e.Message;
            }
        }
        public void SaveConnectors()
        {
            using (StreamWriter outputFile = new StreamWriter(GetGConnFile()))
            {
                outputFile.WriteLine(String.Join(',',GameConnectorFields));
                foreach (GO obj in GS.CONNECTORS()){
                    string line = "";
                    foreach(string field in GameConnectorFields){
                        line += (line.Length > 0 ? "," : "") + obj.Get(field);
                    }
                    outputFile.WriteLine(line);
                }
            }
        }
        public void SaveLocations()
        {
            using (StreamWriter outputFile = new StreamWriter(GetGLFile()))
            {
                outputFile.WriteLine(String.Join(',',GameLocationFields));
                foreach (GO obj in GS.LOCATIONS()){
                    string line = "";
                    foreach(string field in GameLocationFields){
                        line += (line.Length > 0 ? "," : "") + obj.Get(field);
                    }
                    outputFile.WriteLine(line);
                }
            }
        }
        Boolean scrollingMap = false;
        Point scrollMousePoint = new Point();
        double hOff = 1;
        double vOff = 1;
        private void worldCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            if (INIT){return;}
            try
            {
                using(new WaitCursor())
                {
                    if (e.ButtonState == MouseButtonState.Pressed)
                    {
                        scrollMousePoint = e.GetPosition(CANVAS_SCROLL_VIEWER);
                        hOff = CANVAS_SCROLL_VIEWER.HorizontalOffset;
                        vOff = CANVAS_SCROLL_VIEWER.VerticalOffset;
                        scrollingMap = true;  
                        if(e.ClickCount == 1){
                            if(GS.ExecutingGamePhase().MapClick){
                                Point clickPoint = e.GetPosition(WORLD_CANVAS);
                                double realY = clickPoint.Y / MapZoomLevel;
                                double realX = clickPoint.X / MapZoomLevel;
                                ActionContext = ["SCROLL", "SAVE"];
                                UpdateScenario(realX, realY);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void worldCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            if (INIT){return;}
            if(scrollingMap){
                ViewportHorizontalOffset = -1;
                ViewportVerticalOffset = -1;
                CANVAS_SCROLL_VIEWER.ScrollToHorizontalOffset(hOff + (scrollMousePoint.X - e.GetPosition(CANVAS_SCROLL_VIEWER).X));
                CANVAS_SCROLL_VIEWER.ScrollToVerticalOffset(vOff + (scrollMousePoint.Y - e.GetPosition(CANVAS_SCROLL_VIEWER).Y));
                HideMenu(MainMenu);
                HideMenu(StackMenu);
                HideMenu(MarkerChoiceMenu);
                HideMenu(OptionsMenu);
                ChoiceMenuMarker = null;
                InfoMenuMarker = null;
            }
        }
        private void worldCanvas_MouseWheel(object sender, MouseWheelEventArgs e){
            if (HandlingScenarioUpdate) { return; }
            if (INIT){return;}
            //var o = Keyboard.FocusedElement;
            if(MouseWheelOffset == 0)
            {
                MouseWheelOffset = CANVAS_SCROLL_VIEWER.VerticalOffset;
            }
            else if(MouseWheelOffsetDifference == 0)
            {
                MouseWheelOffsetDifference = Math.Abs(CANVAS_SCROLL_VIEWER.VerticalOffset - MouseWheelOffset);
                ResetDockedMenus();
                //ShiftDockedMenus(MouseWheelOffsetDifference * (e.Delta < 0 ? 1 : -1), 0);                 
            }
            ShiftDockedMenus(MouseWheelOffsetDifference * (e.Delta < 0 ? 1 : -1), 0);
            //Alert("" + (Canvas.GetTop(GS.SelectedMarker.image) - CANVAS_SCROLL_VIEWER.VerticalOffset));
        }
        private void worldCanvas_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            if (INIT){return;}
            try
            {
                using(new WaitCursor())
                {
                    if (e.ButtonState == MouseButtonState.Pressed)
                    {
                        if(GS.ExecutingGamePhase().MapClick){
                            Point clickPoint = e.GetPosition(WORLD_CANVAS);
                            double realY = clickPoint.Y / MapZoomLevel;
                            double realX = clickPoint.X / MapZoomLevel;
                            GS.ProcessCanvasRightClick(realX, realY); 
                        }               
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void worldCanvas_MouseLeave(object sender, MouseEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            scrollingMap = false;
        }
        private void worldCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            scrollingMap = false;
            //simulate mouse move
            MouseOverMarker = null;
            GS.ProcessImageMouseMove(GS.SelectedMarker);
            GS.ProcessImageMouseMove(GS.SelectedMarker);
        }
        private void worldCanvas_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (HandlingScenarioUpdate) { return; }
            if (INIT) { return; }
            if (e.Key == Key.Right || e.Key == Key.Left || e.Key == Key.NumPad4 || e.Key == Key.NumPad6)
            {
                bool left = e.Key == Key.Left || e.Key == Key.NumPad4;
                if (LeftRightKeyOffset == 0)
                {
                    LeftRightKeyOffset = CANVAS_SCROLL_VIEWER.HorizontalOffset;
                }
                else if (LeftRightKeyOffsetDifference == 0)
                {
                    LeftRightKeyOffsetDifference = Math.Abs(CANVAS_SCROLL_VIEWER.HorizontalOffset - LeftRightKeyOffset);
                    ResetDockedMenus();
                }
                ShiftDockedMenus(0, LeftRightKeyOffsetDifference * (left ? -1 : 1));
            }
            if (e.Key == Key.Up || e.Key == Key.Down || e.Key == Key.NumPad2 || e.Key == Key.NumPad8)
            {
                bool up = e.Key == Key.Up || e.Key == Key.NumPad2;
                if (UpDownKeyOffset == 0)
                {
                    UpDownKeyOffset = CANVAS_SCROLL_VIEWER.VerticalOffset;
                }
                else if (UpDownKeyOffsetDifference == 0)
                {
                    UpDownKeyOffsetDifference = Math.Abs(CANVAS_SCROLL_VIEWER.VerticalOffset - UpDownKeyOffset);
                    ResetDockedMenus();
                }
                ShiftDockedMenus(UpDownKeyOffsetDifference * (up ? -1 : 1), 0);
            }
        }
        public void ResetDockedMenus()
        {
            foreach (Menu m in new List<Menu>() { MainMenu, StackMenu, MarkerChoiceMenu, OptionsMenu })
            {
                if (m == StackMenu || m == OptionsMenu)
                {
                    Canvas.SetRight(m, GS.WorldSize * MapZoomLevel - (CANVAS_SCROLL_VIEWER.HorizontalOffset + CANVAS_SCROLL_VIEWER.ViewportWidth) + 1);
                    Canvas.SetTop(m, CANVAS_SCROLL_VIEWER.VerticalOffset + 1);
                }
                else
                {
                    Canvas.SetLeft(m, CANVAS_SCROLL_VIEWER.HorizontalOffset + 1);
                    Canvas.SetTop(m, CANVAS_SCROLL_VIEWER.VerticalOffset + 1);
                }
            }
        }
        public void ShiftDockedMenus(double verticalChange, double horizontalChange)
        {
            ViewportHorizontalOffset = -1;
            ViewportVerticalOffset = -1;
            foreach (Menu m in new List<Menu>() { MainMenu, StackMenu, MarkerChoiceMenu, OptionsMenu })
            {
                if (Canvas.GetZIndex(m) > 1)
                {
                    if (verticalChange != 0)
                    {
                        Canvas.SetTop(m, Canvas.GetTop(m) + verticalChange);
                    }
                    else if (horizontalChange != 0)
                    {
                        if (m == StackMenu)
                        {
                            Canvas.SetRight(m, Canvas.GetRight(m) - horizontalChange);
                        }
                        else
                        {
                            Canvas.SetLeft(m, Canvas.GetLeft(m) + horizontalChange);

                        }
                    }
                }
            }
        }
        public void mnuSelectedMarkerInfo_Click(object sender, RoutedEventArgs e)
        {
            GS.GOLabelChange(GS.SelectedMarker);
        }
        private void mnuClickedMarkerInfo_Click(object sender, RoutedEventArgs e)
        {
            GS.GOLabelChange(GS.ClickedMarker);
        }
    }
}
/*public void Line_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
{
    if (HandlingScenarioUpdate) { return; }
    Line clickedLine = (Line)e.Source;
    List<GameObject> connectors = GetConnectorsFromLine(clickedLine);
    if(e.ClickCount == 1){
        List<string> connectorTypes = new(){
            "LAND", 
            "MOUNTAIN",
            "PASS", 
            "MOUNTAINMINORRIVER",
            "MOUNTAINMAJORRIVER",
            "MOUNTAINSEA",
            "MOUNTAINSALT",
            "PASSMINORRIVER", 
            "MINORRIVER", 
            "MAJORRIVER", 
            "BRIDGE",
            "SALT", 
            "SEA"};
        List<System.Windows.Media.SolidColorBrush> colorBrushes = new(){
            System.Windows.Media.Brushes.White, 
            System.Windows.Media.Brushes.Brown,
            System.Windows.Media.Brushes.Yellow,
            System.Windows.Media.Brushes.Pink,
            System.Windows.Media.Brushes.Orange,
            System.Windows.Media.Brushes.Red,
            System.Windows.Media.Brushes.Gold,
            System.Windows.Media.Brushes.PaleVioletRed,
            System.Windows.Media.Brushes.LightBlue, 
            System.Windows.Media.Brushes.Blue,
            System.Windows.Media.Brushes.Gray,
            System.Windows.Media.Brushes.Tan,
            System.Windows.Media.Brushes.Transparent};
        int index = connectorTypes.IndexOf(connectors[0].CONNECTORTYPE);
        int newIndex = (index + 1) % connectorTypes.Count;
        foreach(GameObject connector in connectors){
            connector.CONNECTORTYPE = connectorTypes[newIndex];
        }
        clickedLine.Stroke = colorBrushes[newIndex];
        clickedLine.StrokeThickness = 5;
        foreach(GameObject location in GS.LOCATIONS(connectors[0]).Where(n => n.TERRAIN == "MOUNTAIN")){
            List<GameObject> borders = GS.CONNECTORS(location);
            if((location.PASS && borders.Where(n => n.CONNECTORTYPE.Contains("PASS")).Count() < 2) || borders.Where(n => !n.CONNECTORTYPE.Contains("MOUNTAIN") && !n.CONNECTORTYPE.Contains("PASS")).Any()){
                location.INDICATORWIDTH = 20;
                DrawEllipse(location);
            }
            else
            {
                Canvas.SetZIndex(GS.GetIndicator(location), MainWindow.Z_HIDDEN);
            }
        }
        SaveConnectors();
    }
}*/
