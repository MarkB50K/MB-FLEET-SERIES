﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CWApp.FS
{
    public class ActionCLOSEDEFENSESSMCombat : GamePhaseLoopLogic
    {
        public ActionCLOSEDEFENSESSMCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario)
        {
            AddGamePhase(new ActionCLOSEDEFENSESSMCombatLoadTrays("Load Trays", this, GS));
            AddGamePhase(new ActionCLOSEDEFENSESSMCombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionSSMCombatDefenderSetup("Defender Setup", this, GS));
            AddGamePhase(new ActionSSMCombatRollForTargets("Roll For Targets", this, GS));
            AddGamePhase(new ActionCombatAllocation("Allocation", this, GS, "SSM"));
            AddGamePhase(new ActionCLOSEDEFENSESSMCombatResolution("Resolution", this, GS));
        }
        public override Boolean ProcessCheck() { return FS.SCENARIOLOGICS(GS, "ACTION.CLOSEDEFENSESSMCOMBAT").Any(); }
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.CLOSEDEFENSESSMCOMBAT");
            GO firstcombat = GS.RANDOMGAMEOBJECT(combats);
            List<GO> combined_combats = new() { firstcombat };
            if (FS.COMBINEDATTACKS)
            {
                combined_combats = combats.Where(n => n.SIDE == firstcombat.SIDE && n.DEFENDERLOCATION == firstcombat.DEFENDERLOCATION).ToList();
            }
            List<GO> attackingUnits = combined_combats.Select(n => n.ATTACKER).ToList();
            Set("ACTIVE.SIDE", attackingUnits.First().SIDE);
            Set("ACTIVE.SIDE1", Get("ACTIVE.SIDE"));
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIONING", attackingUnits);
            combats.RemoveAll(n => combined_combats.Contains(n));
            FS.SETSCENARIOOBJECTS(GS, "ACTION.CLOSEDEFENSESSMCOMBAT", combats);
            List<GO> defendingUnits = combined_combats.Select(n => n.DEFENDER).ToList();
            List<GO> defenders = FS.TYPESIDELOCATION(GS, "SHIP", FS.ENEMY(firstcombat.SIDE), firstcombat.DEFENDERLOCATIONID).Where(n =>
                n.ENROUTEDELAY == 0 &&
                !n.DOCKED &&
                n.UNITCATEGORY == "SURFACE" &&
                FS.LOGICALPARENT(n) == n &&
                (n.STRATDETECTED || n.LOCALDETECTED) &&
                defendingUnits.Contains(n)).ToList();

            List<GO> attackers = new();
            if (defenders.Any() && !FS.STORM(firstcombat.DEFENDERLOCATION))
            {
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", defenders);
                attackers = [..attackingUnits];
            }
            string reason = "";
            if (!attackers.Any()) { reason = "no units able to attack"; }
            if (!defenders.Any()) { reason = "no viable targets in target location"; }
            if (reason != "")
            {
                MainWindow.Alert("Planned " + firstcombat.SIDE + " " + firstcombat.TYPE + " combat not possible: " + reason);
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", attackers);
            combined_combats.ForEach(FS.DISCARDLOGIC);
        }
        public override void End()
        {
            FS.REMOVECOMBATSHEET();
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionCLOSEDEFENSESSMCombatLoadTrays : GamePhaseAutomated
    {
        public ActionCLOSEDEFENSESSMCombatLoadTrays(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) { }
        public override void Execute(Boolean init)
        {
            if (FS.SCENARIOUNITS(GS, "ACTION.ATTACKER").Any())
            {
                List<GO> INHEX = [.. FS.SCENARIOUNITS(GS, "ACTION.DEFENDER")];
                List<GO> defenders = [.. INHEX.Where(n => !FS.ISGROUP(n))];
                defenders.AddRange(INHEX.Where(FS.ISGROUP));
                foreach (GO obj in defenders)
                {
                    obj.HOMEBASEID = obj.GAMELOCATIONID;
                    obj.HOMEBASE = obj.GAMELOCATION;
                }
                FS.DISPLAYCOMBATSHEET(GS, defenders);
            }
            GS.Done(this);
        }
    }
    public class ActionCLOSEDEFENSESSMCombatDeclaration : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, Dictionary<string, double>> ATTACKS = new();
        Dictionary<GO, int> RANGES = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = new();
        public ActionCLOSEDEFENSESSMCombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario)
        {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init)
        {
            if (init)
            {
                ATTACKS.Clear();
                RANGES.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new() { "CHOOSE UNITS THAT WILL PARTICIPATE AND WHAT ATTACK TYPE" });
                GS.HELPTEXT =
                "SSM COMBAT.  Declare which units you will attack with\n\n" +
                "- Choose which ammunition, game will only allow ones in range, and will only allow one choice\n\n" +
                "When done with your declaration(s) you can click the NEXT button.  The Defender will be given a chance to reposition forces in the target hex.";
                GO defenseLocation = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").FirstOrDefault()?.HOMEBASE;
                foreach (GO obj in FS.SCENARIOUNITS(GS, "ACTION.ATTACKER"))
                {
                    GS.InteractionMap.Add(obj, new());
                    RANGES.Add(obj, FS.FINDAIRMOVEMENTPATH(FS.PARENTGROUPLOCATION(obj), defenseLocation).Sum(n => n.DISTANCE));
                }
            }
            FS.SETINSTRUCTIONS(GS, new() { "ALLOCATE SSM POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"]) });
            BANNER = "SSM " + ID + " - Allocated: " + ATTACKS.Values.Sum(n => n["PTS"]);
            attackData = FS.ATTACKDATA(GS.InteractionMap.Keys.ToList(), "SSM");
            if (GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker))
            {
                if (GS.InteractionMap.Any())
                {
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if (GS.SelectedMarker != null)
            {
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "USE SSM");
                if (GS.InteractionMap.Count == 1 && !ATTACKS.Any())
                {
                    Update("USE SSM");
                    return;
                }
                GS.AddAction(obj, "END PHASE");
            }
            if (!GS.InteractionMap.Keys.Any())
            {
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init) { FS.SETVIEW(GS); }
        }
        public override void Update(string pData)
        {
            GO gp = GS.SelectedMarker;
            switch (pData)
            {
                case "NEXT":
                    if (ATTACKS.Any() || !GS.InteractionMap.Any())
                    {
                        //collect attack data
                        int numattackers = ATTACKS.Keys.Count;
                        double numseaskimmer = ATTACKS.Values.Sum(n => n["SEASKIMMER"]);
                        double numfastssm = ATTACKS.Values.Sum(n => n["FAST"]);
                        SetBoolean("ACTION.SEASKIMMER", numseaskimmer * 2 >= numattackers);
                        SetBoolean("ACTION.FAST", numfastssm * 2 >= numattackers);
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", ATTACKS.Keys.ToList());
                        GS.Done(this);
                    }
                    else
                    {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE SSM":
                    ATTACKS.Add(gp, FS.ATTACKDATA([gp], "SSM")[gp]["SSM"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionCLOSEDEFENSESSMCombatDefenderSetup : GamePhaseInteractive
    {
        string side = null;
        List<string> groupingOrder = new();
        List<GO> UNDOCKEDTRAYLOCATIONS = new();
        public ActionCLOSEDEFENSESSMCombatDefenderSetup(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario)
        {
            DragDrop = true;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init)
        {
            List<GO> DefendersOnDefenseSheet = GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID);
            if (init)
            {
                side = FS.ENEMY(Get("ACTIVE.SIDE"));
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new() { "DRAG OR USE MENU TO REARRANGE SHIP IN STACK" });
                GS.HELPTEXT =
                "Adjust Defender Positioning. This will determine which units provide Close AA assistance\n\n" +
                "- You can arrange units within a TF/TG\n" +
                "- You can arrange units within the hex by group and then within group\n" +
                "- All undocked ships not in TF/TG will always be grouped together.  Use context menu options to move up/down the grouping as a whole\n" +
                "- Dragging ships within a group will only rearrange the ships within the group, the grouping will not move.  Grouping position is only determined with context menu options\n\n" +
                "When done with your setup you can click the NEXT button.  A roll will determine which units the attacking player can target. " +
                "The attacking player will then be allowed to allocate pts prior to combat resolution.";
                foreach (GO obj in FS.SCENARIOUNITS(GS, "ACTION.DEFENDER"))
                {
                    GS.InteractionMap.Add(obj, new());
                    if (FS.ISGROUP(obj))
                    {
                        List<GO> groupmembers = FS.GROUPMEMBERS(obj);
                        if (groupmembers.Count <= 1) { continue; }
                        foreach (GO obj2 in groupmembers)
                        {
                            GS.InteractionMap.Add(obj2, new());
                        }
                    }
                }
                if (DefendersOnDefenseSheet.Count == 1)
                {
                    foreach (GO obj in GS.InteractionMap.Keys.Where(n => n.PARENTSHEET == FS.DEFENDSHEET).ToList())
                    {
                        GS.InteractionMap.Remove(obj);
                    }
                }
                if (!(DefendersOnDefenseSheet.Count > 1 || DefendersOnDefenseSheet.Max(n => FS.GROUPMEMBERS(n).Count) > 1))
                {
                    Update("NEXT");
                    return;
                }
                //determine initial grouping
                HashSet<string> groupings = new();
                foreach (GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).OrderBy(n => n.GAMELOCATIONID))
                {
                    if (FS.ISGROUP(obj))
                    {
                        groupings.Add(obj.ID);
                    }
                    else
                    {
                        groupings.Add("UNDOCKED");
                    }
                }
                groupingOrder = groupings.ToList();
            }
            UNDOCKEDTRAYLOCATIONS = DefendersOnDefenseSheet.Where(n => !FS.ISGROUP(n) && !n.DOCKED).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).ToList();
            if (GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker))
            {
                if (GS.InteractionMap.Any())
                {
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if (GS.SelectedMarker != null)
            {
                GO obj = GS.SelectedMarker;
                List<GO> targets = GS.InteractionMap[obj];
                targets.Clear();
                if (obj.HOMEBASE != null)
                {
                    if (!FS.ISGROUP(obj))
                    {
                        targets.AddRange(UNDOCKEDTRAYLOCATIONS.Where(n => n != obj.GAMELOCATION));
                    }
                }
                else
                {
                    List<GO> groupMembers = FS.GROUPMEMBERS(FS.LOGICALPARENT(obj));
                    int count = groupMembers.Count;
                    if (obj.GROUPINDEX > 0)
                    {
                        GS.AddAction(obj, "MOVE UP IN GROUP");
                    }
                    if (obj.GROUPINDEX < count - 1)
                    {
                        GS.AddAction(obj, "MOVE DOWN IN GROUP");
                    }
                }
                if (obj.HOMEBASE != null)
                {
                    int index = groupingOrder.IndexOf(FS.ISGROUP(obj) ? obj.ID : "UNDOCKED");
                    if (index > 0) { GS.AddAction(obj, "MOVE GROUP UP"); }
                    if (index < groupingOrder.Count - 1) { GS.AddAction(obj, "MOVE GROUP DOWN"); }
                }
                GS.AddAction(obj, "END PHASE");
            }
            if (!GS.InteractionMap.Keys.Any())
            {
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init) { FS.SETVIEW(GS); }
        }
        private void ARRANGEUNITS(GO gp, bool left)
        {
            //always keep non TF/TG grouped together
            GO newsheet = FS.DEFENDSHEET;
            List<GO> grouptraylocations = GS.TYPE("PIECE", "PARENTSHEETID", newsheet.ID).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).Distinct().ToList();
            List<GO> groupMembers = new();
            List<GO> tfs = new();
            List<GO> undocked = new();
            foreach (GO loc in grouptraylocations)
            {
                List<GO> unitsAtLoc = FS.TYPELOCATION(GS, "PIECE", loc.ID);
                if (unitsAtLoc.Any())
                {
                    if (unitsAtLoc.Count == 1)
                    {
                        GO u = unitsAtLoc.First();
                        if (FS.ISGROUP(u))
                        {
                            tfs.Add(u);
                        }
                        else
                        {
                            undocked.Add(u);
                        }
                    }
                    else
                    {
                        if (left)
                        {
                            undocked.Add(gp);
                        }
                        GO u = unitsAtLoc.Where(n => n != gp).Single();
                        if (FS.ISGROUP(u))
                        {
                            tfs.Add(u);
                        }
                        else
                        {
                            undocked.Add(u);
                        }
                        if (!left)
                        {
                            undocked.Add(gp);
                        }
                    }
                }
            }
            foreach (string grouping in groupingOrder)
            {
                switch (grouping)
                {
                    case "UNDOCKED":
                        groupMembers.AddRange(undocked);
                        break;
                    default:
                        groupMembers.Add(tfs.Where(n => n.ID == grouping).Single());
                        break;
                }
            }
            FS.DISPLAYCOMBATSHEET(GS, groupMembers);
        }
        private void REORDERGROUPINGS(GO gp, bool up)
        {
            string key = FS.ISGROUP(gp) ? gp.ID : "UNDOCKED";
            int index = groupingOrder.IndexOf(key);
            groupingOrder.Remove(key);
            if (up)
            {
                groupingOrder.Insert(index - 1, key);
            }
            else
            {
                if (index >= groupingOrder.Count - 1)
                {
                    groupingOrder.Add(key);
                }
                else
                {
                    groupingOrder.Insert(index + 1, key);
                }
            }
            ARRANGEUNITS(gp, true);
        }
        public override void Update(string pData)
        {
            GO gp = GS.SelectedMarker;
            switch (pData)
            {
                case "NEXT":
                    GS.Done(this);
                    break;
                case "MOVE UP IN GROUP":
                    FS.MOVEUPINGROUP(GS, gp, FS.LOGICALPARENT(gp));
                    Start(false);
                    break;
                case "MOVE DOWN IN GROUP":
                    FS.MOVEDOWNINGROUP(GS, gp, FS.LOGICALPARENT(gp));
                    Start(false);
                    break;
                case "MOVE GROUP UP":
                    REORDERGROUPINGS(gp, true);
                    Start(false);
                    break;
                case "MOVE GROUP DOWN":
                    REORDERGROUPINGS(gp, false);
                    Start(false);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if (gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID)
                    {
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        GO newloc = gp.GAMELOCATION;
                        if (oldloc.PARENTSHEET == FS.DEFENDSHEET && newloc.PARENTSHEET == FS.DEFENDSHEET)
                        {
                            int oldindex = UNDOCKEDTRAYLOCATIONS.IndexOf(oldloc);
                            int newindex = UNDOCKEDTRAYLOCATIONS.IndexOf(newloc);
                            ARRANGEUNITS(gp, oldindex > newindex);
                        }
                        Start(false);
                    }
                    else
                    {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionCLOSEDEFENSESSMCombatRollForTargets : GamePhaseAutomated
    {
        public ActionCLOSEDEFENSESSMCombatRollForTargets(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) { }
        public override void Execute(Boolean init)
        {
            List<GO> defenders = new();
            foreach (GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).OrderBy(n => n.GAMELOCATIONID))
            {
                if (FS.ISGROUP(obj))
                {
                    defenders.AddRange(FS.GROUPMEMBERS(obj));
                }
                else
                {
                    defenders.Add(obj);
                }
            }
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
            if (defenders.Any())
            {
                List<GO> targets = new();
                if (defenders.Count == 1)
                {
                    targets.AddRange(defenders);
                }
                else
                {
                    int dieRoll = FS.DIEROLL();
                    if (dieRoll == 0 || dieRoll == 9)
                    {
                        MainWindow.Alert("Roll: " + dieRoll + ". No targets acquired!");
                        FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
                    } else if(dieRoll % 2 == 0){
                        for(int i = 0; i < defenders.Count * 0.5; i++){
                            targets.Add(defenders[i]);
                        }
                        //MainWindow.Alert("Roll: " + dieRoll + ". Top half of stack targeted!");
                        Set("ACTION.SSMTARGETROLL", "**TARGETING TOP HALF**\n");
                    } else {
                        for(int i = defenders.Count - 1; i >= defenders.Count * 0.5; i--){
                            targets.Add(defenders[i]);
                        }
                        //MainWindow.Alert("Roll: " + dieRoll + ". Bottom half of stack targeted!");
                        Set("ACTION.SSMTARGETROLL", "**TARGETING BOTTOM HALF**\n");
                    }
                }
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", targets);
            }
            GS.Done(this);
        }
    }
    public class ActionCLOSEDEFENSESSMCombatResolution : GamePhaseAutomated
    {
        public ActionCLOSEDEFENSESSMCombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) { }
        public override void Execute(Boolean init)
        {
            List<GO> attackers = FS.SCENARIOUNITS(GS, "ACTION.ATTACKER");
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            if (defenders.Any())
            {
                List<GO> actioningGroups = FS.SCENARIOUNITS(GS, "ACTION.ACTIONING");
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                GO defenseLocation = defenders.First().HOMEBASE ?? FS.LOGICALPARENT(defenders.First()).HOMEBASE;
                Dictionary<GO, int> RANGES = new();
                foreach (GO attacker in attackers)
                {
                    RANGES.Add(attacker, FS.FINDAIRMOVEMENTPATH(FS.PARENTGROUPLOCATION(attacker), defenseLocation).Sum(n => n.DISTANCE));
                }
                string report = "CLOSE DEFENSE SSM COMBAT : " + attackingSide + " vs " + defendingSide + "\n" + Get("ACTION.SSMTARGETROLL") + "\n";
                List<List<FSMovement>> ssmPaths = new();
                foreach (GO attackingGroup in actioningGroups)
                {
                    GO attackLocation = attackingGroup.GAMELOCATION;
                    ssmPaths.Add(FS.FINDSSMDIRECTPATH(attackLocation, defenseLocation));
                }
                List<GO> freeShips = new();
                List<GO> DEFENDERSONSHEET = GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID);
                //put defenders in groups
                foreach (GO obj in DEFENDERSONSHEET.OrderBy(n => n.GAMELOCATIONID))
                {
                    if (!FS.ISGROUP(obj))
                    {
                        freeShips.Add(obj);
                    }
                }
                //create Dict of targets to ships beneath them
                Dictionary<GO, GO> targetsAndBeneath = new();
                foreach (GO defender in defenders)
                {
                    if (defender.HOMEBASE != null)
                    {
                        int position1 = freeShips.IndexOf(defender);
                        int position2 = (position1 + 1) % freeShips.Count;
                        GO beneath = freeShips[position2];
                        if (beneath == defender || defenders.Contains(beneath))
                        {
                            beneath = null;
                        }
                        targetsAndBeneath.Add(defender, beneath);
                    }
                    else
                    {
                        GO group = FS.LOCATIONPARENT(defender);
                        List<GO> groupMembers = FS.GROUPMEMBERS(group);
                        int position1 = groupMembers.IndexOf(defender);
                        int position2 = (position1 + 1) % groupMembers.Count;
                        GO beneath = groupMembers[position2];
                        if (beneath == defender || defenders.Contains(beneath))
                        {
                            beneath = null;
                        }
                        targetsAndBeneath.Add(defender, beneath);
                    }
                }
                FS.REMOVECOMBATSHEET();
                //combine AA values
                int combinedAAValue = 0;
                double fst = 1;

                //CAA of targets
                double targetCAA = 0;
                foreach (GO obj in defenders)
                {
                    targetCAA += obj.TEMPLATE.CAA;
                    report += obj.UNITTYPE + " " + obj.LABEL + " CAA=" + obj.TEMPLATE.CAA + "\n";
                }
                //CAA of beneath
                foreach (GO obj in targetsAndBeneath.Values.Where(n => n != null))
                {
                    targetCAA += obj.TEMPLATE.CAA;
                    report += obj.UNITTYPE + " " + obj.LABEL + " CAA=" + obj.TEMPLATE.CAA + "\n";
                }
                report += "contributes " + Math.Floor(targetCAA * fst) + "\n";
                combinedAAValue += (int)Math.Floor(targetCAA * fst);
                report += "TOTAL AA = " + combinedAAValue + "\n\n";
                int defenseModifier = 0;
                int rollModifier = 0;
                if (combinedAAValue > 0)
                {
                    if (defenders.Where(n => n.GROUP?.UNITTYPE == "TF").Any())
                    {
                        rollModifier += 2;
                        report += "TF: Roll +2\n";
                    }
                    if (!defenders.Where(n => n.GROUP != null).Any())
                    {
                        rollModifier -= 4;
                        report += "NO TG/TF: Roll -4\n";
                    }
                    List<GO> capAir = FS.CAPSQNS(GS, defendingSide).Where(n => !n.DONE && n.GAMELOCATION == defenseLocation).ToList();
                    if (capAir.Any())
                    {
                        if (capAir.Where(n => n.UNITTYPE == "AEW").Any())
                        {
                            rollModifier += 2;
                            report += "AEW: Roll +2\n";
                        }
                    }
                    report += "DEFENSE ROLL MODIFIER: " + rollModifier + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + rollModifier) + "\n";
                    dieRoll += rollModifier;
                    defenseModifier = FS.COMBATRESULTSTABLE(false, dieRoll, combinedAAValue);
                }
                report += "DEFENSE MODIFIER: " + defenseModifier + "\n\n";
                rollModifier = -defenseModifier;
                if (FS.STRATEGICTACCOORD)
                {
                    if (FS.ALLSHIPSINHEX(defendingSide, defenseLocation, true, false).Where(n => n.TACCOORDPIECEID != null).Any())
                    {
                        rollModifier += 2;
                        report += "TAC COORD: Roll +2\n";
                    }
                }
                else
                {
                    if (FS.TYPESIDE(GS, "SURFACE TACCOORD", attackingSide).Where(n => n.DEFENDERLOCATION == defenseLocation).Any())
                    {
                        rollModifier += 2;
                        report += "TAC COORD: Roll +2\n";
                    }
                }
                if (defenseLocation.RESTRICTED || defenseLocation.FJORD)
                {
                    rollModifier -= 4;
                    report += "RESTRICTED/FJORD: Roll -4\n";
                }
                else if (defenseLocation.COASTAL)
                {
                    rollModifier -= 2;
                    report += "COASTAL: Roll -2\n";
                }
                foreach (GO obj in defenders)
                {
                    report += "\nATTACK ON " + obj.UNITTYPE + " " + obj.LABEL + " with " + obj.ATK + " pts:\n";
                    report += "ATTACK ROLL MODIFIER: " + rollModifier + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + rollModifier) + "\n";
                    dieRoll += rollModifier;
                    double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)obj.ATK);
                    obj.ATK = 0;
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    //compare to ship defense
                    double defense = FS.GETDEFENSE(obj);
                    if (attackResult >= defense)
                    {
                        GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * (obj.DAMAGED ? 0.5 : 1)); 
                        FS.DESTROY(obj);
                        report += "Target Destroyed\n";
                    }
                    else if (attackResult >= defense * 0.5)
                    {
                        GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * 0.5); 
                        FS.DAMAGE(obj);
                        if ((obj.DAMAGED ? 1 : 0) + obj.UNAPPLIEDDAMAGE >= 2)
                        {
                            report += "Target Destroyed\n";
                        }
                        else
                        {
                            report += "Target Damaged\n";
                        }
                    }
                    else
                    {
                        report += "No effect\n";
                    }
                }
                if (report != "")
                {
                    MainWindow.Alert(report);
                }
            }
            GS.Done(this);
        }
    }
    public class ActionCLOSEDEFENSEASWCombat : GamePhaseLoopLogic
    {
        public ActionCLOSEDEFENSEASWCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario)
        {
            AddGamePhase(new ActionCLOSEDEFENSEASWCombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionCombatAllocation("Allocation", this, GS, "ASW"));
            AddGamePhase(new ActionCLOSEDEFENSEASWCombatResolution("Resolution", this, GS));
        }
        public override Boolean ProcessCheck() { return FS.SCENARIOLOGICS(GS, "ACTION.CLOSEDEFENSEASWCOMBAT").Any(); }
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.CLOSEDEFENSEASWCOMBAT");
            GO combat = GS.RANDOMGAMEOBJECT(combats);
            GO attackingUnit = combat.ATTACKER;
            Set("ACTIVE.SIDE", attackingUnit.SIDE);
            Set("ACTIVE.SIDE1", Get("ACTIVE.SIDE"));
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIONING", new() { attackingUnit });
            Set("ACTION.TYPE", "SUB");
            combats.Remove(combat);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.CLOSEDEFENSEASWCOMBAT", combats);
            List<GO> attackers = new();
            //if defender is not in location we expect cancel
            bool canAttack = FS.PARENTGROUPLOCATION(combat.DEFENDER) == combat.DEFENDERLOCATION;
            if (canAttack)
            {
                attackers = [attackingUnit];
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", [combat.DEFENDER]);
            }
            string reason = "";
            if (!attackers.Any()) { reason = "no units able to attack"; }
            if (!canAttack) { reason = "target SUB is no longer in target location or has already been attacked"; }
            if (reason != "")
            {
                MainWindow.Alert("Planned " + combat.TYPE + " combat (" + combat.SIDE + " vs " + FS.ENEMY(combat.SIDE) + ") not possible: " + reason);
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", attackers);
            FS.DISCARDLOGIC(combat);
        }
        public override void End()
        {
            FS.REMOVECOMBATSHEET();
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionCLOSEDEFENSEASWCombatDeclaration : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, Dictionary<string, double>> ATTACKS = new();
        public ActionCLOSEDEFENSEASWCombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario)
        {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init)
        {
            if (init)
            {
                ATTACKS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new() { "CHOOSE UNITS THAT WILL PARTICIPATE" });
                GS.HELPTEXT =
                "ASW COMBAT.  Declare which units you will attack with\n\n" +
                "- SURFACE:  Max 3 units\n" +
                "- AIR:  Max 2 units\n" +
                "When done with your allocation you can click the NEXT button";
                foreach (GO obj in FS.SCENARIOUNITS(GS, "ACTION.ATTACKER"))
                {
                    GS.InteractionMap.Add(obj, new());
                }
            }
            FS.SETINSTRUCTIONS(GS, new() { "ALLOCATE ASW POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"]) });
            BANNER = "Anti-Sub " + ID + " - Allocated: " + ATTACKS.Values.Sum(n => n["PTS"]);
            if (GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker))
            {
                if (GS.InteractionMap.Any())
                {
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if (GS.SelectedMarker != null)
            {
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "USE ASW");
                if (GS.InteractionMap.Count == 1 && !ATTACKS.Any())
                {
                    Update("USE ASW");
                    return;
                }
                GS.AddAction(obj, "END PHASE");
            }
            if (!GS.InteractionMap.Keys.Any())
            {
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init) { FS.SETVIEW(GS); }
        }
        public override void Update(string pData)
        {
            GO gp = GS.SelectedMarker;
            switch (pData)
            {
                case "NEXT":
                    if (ATTACKS.Any() || !GS.InteractionMap.Any())
                    {
                        //collect attack data
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", ATTACKS.Keys.ToList());
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        GS.Done(this);
                    }
                    else
                    {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE ASW":
                    ATTACKS.Add(gp, FS.ATTACKDATA([gp], "ASW")[gp]["ASW"]["ASW"]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionCLOSEDEFENSEASWCombatResolution : GamePhaseAutomated
    {
        public ActionCLOSEDEFENSEASWCombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) { }
        public override void Execute(Boolean init)
        {
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            if (defenders.Any())
            {
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                GO attackLocation = FS.PARENTGROUPLOCATION(FS.SCENARIOUNITS(GS, "ACTION.ATTACKER").First());
                GO defenseLocation = FS.PARENTGROUPLOCATION(defenders.First());
                string report = "CLOSE DEFENSE ASW COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                int rollModifier = 0;
                foreach (GO obj in defenders)
                {
                    int objRollModifer = rollModifier;
                    report += "\nATTACK ON " + obj.UNITTYPE + " " + obj.LABEL + " with " + obj.ATK + " pts:\n";
                    if (FS.STRATEGICTACCOORD)
                    {
                        if (obj.TACCOORDPIECEID != null && !FS.STORM(defenseLocation))
                        {
                            objRollModifer += 2;
                            report += "TAC COORD: Roll +2\n";
                        }
                    }
                    else
                    {
                        if (FS.TYPESIDE(GS, "SUB TACCOORD", attackingSide).Where(n => n.DEFENDER == obj).Any())
                        {
                            objRollModifer += 2;
                            report += "TAC COORD: Roll +2\n";
                        }
                    }
                    if (obj.UNITTYPE != "SS" && !obj.DOCKED && defenseLocation.SHALLOW)
                    {
                        objRollModifer += 3;
                        report += "SHALLOW SN: Roll +3\n";
                    }
                    if (Get("ACTION.TYPE") == "SURFACE" && obj.DOCKED && defenseLocation.PORTDAMAGELEVEL == 0)
                    {
                        objRollModifer -= 3;
                        report += "UNDAMAGED PORT: Roll -3\n";
                    }
                    else if (defenseLocation.RESTRICTED || defenseLocation.FJORD || obj.DOCKED)
                    {
                        objRollModifer += 3;
                        report += "RESTRICTED/FJORD/DOCKED: Roll +3\n";
                    }
                    if (obj.DEEPMODE)
                    {
                        objRollModifer -= 2;
                        report += "DEEPMODE: Roll -2\n";
                    }
                    report += "ATTACK ROLL MODIFIER: " + objRollModifer + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + objRollModifer) + "\n";
                    dieRoll += objRollModifer;
                    double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)obj.ATK);
                    obj.ATK = 0;
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    //compare to ship defense
                    double defense = FS.GETDEFENSE(obj);
                    if (attackResult >= defense)
                    {
                        GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * (obj.DAMAGED ? 0.5 : 1)); 
                        FS.DESTROY(obj);
                        report += "Target Destroyed\n";
                    }
                    else if (attackResult >= defense * 0.5)
                    {
                        GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * 0.5); 
                        FS.DAMAGE(obj);
                        if ((obj.DAMAGED ? 1 : 0) + obj.UNAPPLIEDDAMAGE >= 2)
                        {
                            report += "Target Destroyed\n";
                        }
                        else
                        {
                            report += "Target Damaged\n";
                        }
                    }
                    else
                    {
                        report += "No effect\n";
                    }
                }
                if (report != "")
                {
                    MainWindow.Alert(report);
                }
            }
            GS.Done(this);
        }
    }
}
