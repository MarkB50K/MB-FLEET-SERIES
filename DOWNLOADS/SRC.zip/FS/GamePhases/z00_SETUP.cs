using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CWApp.FS
{
    public class SetupSegment : GamePhaseGroup
    {
        public SetupSegment(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            //AddGamePhase(new SetupHexesAndConnectors("Setup Hexes and Connectors", this, GS));
            AddGamePhase(new SetupBases("Setup Bases And Allegiences", this, GS));
            AddGamePhase(new SetupForces("Setup Forces", this, GS));
            AddGamePhase(new DeploymentLoop("Loop", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
    }
    public class SetupHexesAndConnectors : GamePhaseInteractive
    {
        Dictionary<String, System.Windows.Media.SolidColorBrush> TypeColorMap= new(){
            {"SEA", System.Windows.Media.Brushes.Blue},
            {"COASTAL", System.Windows.Media.Brushes.Gray},
            {"LAND", System.Windows.Media.Brushes.Black},
            {"AIR", System.Windows.Media.Brushes.White},
            {"OMAF", System.Windows.Media.Brushes.White}
        };
        public string GOMode = null;
        public string ClipBoardCountry = null;
        public string ClipBoardZone = null;
        public string ClipBoardHexType = null;
        public string ClipBoardIceType = null;
        public string ClipBoardConnectorType = null;
        public Boolean CopyCountryMode = false;
        public Boolean CopyZoneMode = false;
        public SetupHexesAndConnectors(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            MapClick = true;
        }
        public override void Execute(Boolean init){
            //if(GS.Get("_CONFIG_HEXSETUP_THEATERS") == null){GS.Advance(this); return;}
            List<string> instructions = new();
            if(init){
                List<string> theaters = ["INDIAN"]; //GS.Get("_CONFIG_HEXSETUP_THEATERS").Split(',').ToList();
                ClipBoardCountry = null;
                ClipBoardZone = null;
                ClipBoardIceType = null;
                ClipBoardHexType = null;
                ClipBoardConnectorType = null;
                GOMode = null;
                CopyCountryMode = false;
                CopyZoneMode = false;
                //INIT HEXTYPES
                foreach(GO hex in GS.TYPE("HEX").Where(n => theaters.Contains(n.ORGLEVEL1))){
                    Ellipse clicked = GS.GetIndicator(hex, true, hex.COUNTRY != null ? 40 : 20);
                    Canvas.SetZIndex(clicked, MainWindow.Z_LOCATION_INDICATOR);
                    if(hex.TERRAIN == "COASTAL"){hex.TERRAIN = "SEA";}
                    clicked.Fill = TypeColorMap[hex.TERRAIN];
                }

                //INIT CONNECTORS
                foreach(GO nearestLocation in GS.TYPE("HEX").Where(n => theaters.Contains(n.ORGLEVEL1))){
                    foreach(GO otherLocation in GS.TYPE("HEX").Where(n => n != nearestLocation && MainWindow.GetDistance(n, nearestLocation.x, nearestLocation.y) < 100)){
                        GO conn = GS.CONNECTOR(nearestLocation, otherLocation, "NATO");
                        if(conn == null){
                            string connectionTerrain = "SEA";
                            if(nearestLocation.TERRAIN == "OMAF" || otherLocation.TERRAIN == "OMAF"){connectionTerrain = "AIR";}
                            else if(nearestLocation.TERRAIN == "LAND" && otherLocation.COUNTRY == null || otherLocation.TERRAIN == "LAND" && nearestLocation.COUNTRY == null){connectionTerrain = "AIR";}
                            else if(nearestLocation.TERRAIN == "LAND" || otherLocation.TERRAIN == "LAND"){connectionTerrain = "LAND";}
                            else if(nearestLocation.TERRAIN == "SEA" && otherLocation.TERRAIN == "SEA" && nearestLocation.COUNTRY != null && otherLocation.COUNTRY != null){connectionTerrain = "COASTAL";}
                            Dictionary<string, string> newConnData = new();
                            newConnData.Add("ID",nearestLocation.ID + "." + otherLocation.ID);
                            newConnData.Add("DOMAIN", GO.DOMAIN_CONNECTOR);
                            newConnData.Add("CONNECTORLOCATIONID", nearestLocation.ID);
                            newConnData.Add("CONNECTORLOCATION2ID", otherLocation.ID);
                            newConnData.Add("TERRAIN", connectionTerrain);
                            conn = new GO(GS, newConnData, newConnData, newConnData);
                            Dictionary<string, string> newConnData2 = new();
                            newConnData2.Add("ID",otherLocation.ID + "." + nearestLocation.ID);
                            newConnData2.Add("DOMAIN", conn.DOMAIN);
                            newConnData2.Add("CONNECTORLOCATIONID", otherLocation.ID);
                            newConnData2.Add("CONNECTORLOCATION2ID", nearestLocation.ID);
                            newConnData2.Add("TERRAIN", conn.TERRAIN);
                            conn = new GO(GS, newConnData2, newConnData2, newConnData2);
                        }
                        Line clickedLine = GS.GetLine(conn, true);
                        Canvas.SetZIndex(clickedLine, MainWindow.Z_CONNECTOR_INDICATOR);
                        Boolean error = false;
                        if((conn.TERRAIN == "COASTAL" || conn.TERRAIN == "LAND") && (nearestLocation.COUNTRY == null || otherLocation.COUNTRY == null)){error = true;}
                        if((conn.TERRAIN == "COASTAL" || conn.TERRAIN == "SEA") && (nearestLocation.TERRAIN == "LAND" || otherLocation.TERRAIN == "LAND")){error = true;}
                        clickedLine.Stroke = error ? System.Windows.Media.Brushes.Red : TypeColorMap[conn.TERRAIN];
                        clickedLine.StrokeThickness = 5;
                    }
                }
            }
            GO map = GS.TYPE("MAP").First();
            if(CopyCountryMode){
                instructions.Add("CLICK A HEX TO COPY COUNTRY TO CLIPBOARD");
            } else if(CopyZoneMode){
                instructions.Add("CLICK A HEX TO COPY ZONE TO CLIPBOARD");
            }else {
                if(GOMode != "HEX"){GS.AddAction(map, "EDIT HEXES");}
                if(GOMode != "CONNECTOR"){GS.AddAction(map, "EDIT CONNECTORS");}
                string clipboard = "";
                if(GOMode == "HEX"){
                    switch(ClipBoardHexType){
                        case "LAND":
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "SEA":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "SHALLOW":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "RESTRICTED":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "FJORD":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "SHOALS":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "OMAF":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            break;
                        default:
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                    }
                    switch(ClipBoardIceType){
                        case "DRIFTICE":
                            GS.AddAction(map, "PACKICE To ClipBoard");
                            GS.AddAction(map, "REMOVE-ICE To ClipBoard");
                            break;
                        case "PACKICE":
                            GS.AddAction(map, "DRIFTICE To ClipBoard");
                            GS.AddAction(map, "REMOVE-ICE To ClipBoard");
                            break;
                        case "REMOVE-ICE":
                            GS.AddAction(map, "DRIFTICE To ClipBoard");
                            GS.AddAction(map, "PACKICE To ClipBoard");
                            break;
                        default:
                            GS.AddAction(map, "DRIFTICE To ClipBoard");
                            GS.AddAction(map, "PACKICE To ClipBoard");
                            GS.AddAction(map, "REMOVE-ICE To ClipBoard");
                            break;
                    }
                    if(ClipBoardCountry != null){clipboard+="|" + ClipBoardCountry + "|"; GS.AddAction(map, "CLEAR COUNTRY FROM CLIPBOARD");} else {GS.AddAction(map, "COPY COUNTRY FROM NEXT CLICK"); GS.AddAction(map, "REMOVE-COUNTRY To ClipBoard");}
                    if(ClipBoardZone != null){clipboard+="|" + ClipBoardZone + "|"; GS.AddAction(map, "CLEAR ZONE FROM CLIPBOARD");} else {GS.AddAction(map, "COPY ZONE FROM NEXT CLICK");}
                    if(ClipBoardHexType != null){clipboard+="|" + ClipBoardHexType + "|"; GS.AddAction(map, "CLEAR HEX TYPE FROM CLIPBOARD");}
                    if(ClipBoardIceType != null){clipboard+="|" + ClipBoardIceType + "|"; GS.AddAction(map, "CLEAR ICE TYPE FROM CLIPBOARD");}
                }
                if(GOMode == "CONNECTOR"){
                    switch(ClipBoardConnectorType){
                        case "LAND":
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "COASTAL To ClipBoard");
                            GS.AddAction(map, "AIR To ClipBoard");
                            break;
                        case "SEA":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "COASTAL To ClipBoard");
                            GS.AddAction(map, "AIR To ClipBoard");
                            break;
                        case "COASTAL":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "AIR To ClipBoard");
                            break;
                        case "AIR":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "COASTAL To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            break;
                        default:
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "COASTAL To ClipBoard");
                            GS.AddAction(map, "AIR To ClipBoard");
                            break;
                    }
                    if(ClipBoardConnectorType != null){clipboard+="|" + ClipBoardConnectorType + "|"; GS.AddAction(map, "CLEAR CONNECTOR TYPE FROM CLIPBOARD");}
                }
                if(clipboard.Length > 0){instructions.Add("CLIPBOARD: " + clipboard);}
                instructions.Add("RIGHT CLICK MAP FOR OPTIONS");
            }         
            FS.SETINSTRUCTIONS(GS, instructions);
            //INDIAN   
            //=18506+(B38905+0.5-79-(0.5*MOD(A38905,2)))*81.462-(A38905-45)*-41.289
            //=9741+(B38905+0.5-79-(0.5*MOD(A38905,2)))*47.077-(A38905-45)*71.526
            //PACIFIC
            //=19159+(B38905+0.5-1-(0.5*MOD(A38905,2)))*47+(A38905-13)*70.976
            //=8622+(B38905+0.5-1-(0.5*MOD(A38905,2)))*-81.375+(A38905-13)*41
        }
        public override void Update(string pData){
            if(pData == null){
                Start(false);
            } else if(pData == "NEXT"){
                //HIDE CONNECTORS
                foreach(GO conn in GS.CONNECTORS()){
                    Line clicked = GS.GetLine(conn, true);
                    Canvas.SetZIndex(clicked, MainWindow.Z_HIDDEN);
                    clicked.Stroke = System.Windows.Media.Brushes.Transparent;
                }
                foreach(GO hex in GS.TYPE("HEX")){
                    Ellipse clicked = GS.GetIndicator(hex, true);
                    Canvas.SetZIndex(clicked, MainWindow.Z_HIDDEN);
                    clicked.Stroke = System.Windows.Media.Brushes.White;
                    clicked.Fill = System.Windows.Media.Brushes.Black;
                    clicked.Width = 20 * Window().MapZoomLevel;
                    clicked.Height = 20 * Window().MapZoomLevel;
                }
                GS.Done(this); 
            } else if(pData == "EDIT HEXES"){
                GOMode = "HEX";
                Start(false);
            } else if(pData == "EDIT CONNECTORS"){
                GOMode = "CONNECTOR";
                Start(false);
            } else if(pData.Contains("To ClipBoard")){
                if(GOMode == "HEX"){
                    string[] pDataParts = pData.Split(' ');
                    string clip = pDataParts[0];
                    if(clip.Contains("ICE")){
                        ClipBoardIceType = clip;
                    } else if(clip.Contains("COUNTRY")){
                        ClipBoardCountry = clip;
                    } else {
                        ClipBoardHexType = clip;
                    }
                } else if(GOMode == "CONNECTOR"){
                    string[] pDataParts = pData.Split(' ');
                    ClipBoardConnectorType = pDataParts[0];
                }
                Start(false);
            } else if(pData.StartsWith("COPY COUNTRY")){
                CopyCountryMode = true;
                Start(false);
            } else if(pData.StartsWith("CLEAR COUNTRY")){
                ClipBoardCountry = null;
                Start(false);
            } else if(pData.StartsWith("COPY ZONE")){
                CopyZoneMode = true;
                Start(false);
            } else if(pData.StartsWith("CLEAR ZONE")){
                ClipBoardZone = null;
                Start(false);
            } else if(pData.StartsWith("CLEAR HEX TYPE")){
                ClipBoardHexType = null;
                Start(false);
            } else if(pData.StartsWith("CLEAR CONNECTOR TYPE")){
                ClipBoardConnectorType = null;
                Start(false);
            } else {
                Start(false);  
            }
        }
        public override void Update(double realX, double realY)
        {
            base.Update(realX, realY);
            GO hex = GS.TYPE("HEX").OrderBy(x => MainWindow.GetDistance(x, realX, realY)).FirstOrDefault();
            if(GOMode == "HEX"){
                if(hex != null){
                    if(CopyCountryMode){
                        ClipBoardCountry = hex.COUNTRY;
                    } else if(CopyZoneMode){
                        ClipBoardZone = hex.ZONE;
                    }else {
                        if(ClipBoardCountry != null){
                            hex.COUNTRY = ClipBoardCountry == "REMOVE-COUNTRY" ? null : ClipBoardCountry;
                            Ellipse clicked = GS.GetIndicator(hex, true, hex.COUNTRY != null ? 40 : 20);
                            Canvas.SetZIndex(clicked, MainWindow.Z_CONNECTOR_INDICATOR);                    
                        }
                        if(ClipBoardZone != null){
                            hex.ZONE = ClipBoardZone;
                        }
                        if(ClipBoardHexType != null){
                            Ellipse clicked = GS.GetIndicator(hex, true, hex.COUNTRY != null ? 40 : 20);
                            Canvas.SetZIndex(clicked, MainWindow.Z_CONNECTOR_INDICATOR);                    
                            hex.TERRAIN = ClipBoardHexType == "LAND" || ClipBoardHexType == "OMAF" ? ClipBoardHexType : "SEA";
                            hex.SHALLOW = ClipBoardHexType == "SHALLOW";
                            hex.RESTRICTED = ClipBoardHexType == "RESTRICTED";
                            hex.FJORD = ClipBoardHexType == "FJORD";
                            hex.SHOALS = ClipBoardHexType == "SHOALS";
                            clicked.Fill = TypeColorMap[hex.TERRAIN];
                        }
                        if(ClipBoardIceType != null && hex.TERRAIN == "SEA"){
                            Ellipse clicked = GS.GetIndicator(hex, true, hex.COUNTRY != null ? 40 : 20);
                            Canvas.SetZIndex(clicked, MainWindow.Z_CONNECTOR_INDICATOR);                    
                            hex.DRIFTICE = ClipBoardIceType == "DRIFTICE";
                            hex.PACKICE = ClipBoardIceType == "PACKICE";
                        }
                        Window().SaveLocations();
                    }
                }
            } else if(GOMode == "CONNECTOR"){
                List<GO> locations = GS.TYPE("HEX").OrderBy(x => MainWindow.GetDistance(x, realX, realY)).ToList();
                if(locations.Count >= 2){
                    GO nearestLocation = locations[0];
                    GO otherLocation = locations[1];
                    GO conn = GS.CONNECTOR(nearestLocation, otherLocation, "NATO");
                    if(conn != null){
                        if(ClipBoardConnectorType != null){
                            Line clickedLine = GS.GetLine(conn, false);
                            Canvas.SetZIndex(clickedLine, MainWindow.Z_CONNECTOR_INDICATOR);
                            foreach(GO connector in GS.CONNECTORS().Where(n => n.lineIndicator == clickedLine || n.lineIndicator2 == clickedLine)){
                                connector.TERRAIN = ClipBoardConnectorType;
                            }
                            clickedLine.Stroke = TypeColorMap[ClipBoardConnectorType];
                            Window().SaveConnectors();
                        }
                    }
                }
            }
            CopyCountryMode = false;
            CopyZoneMode = false;
            string info = "X: " + Math.Round(realX, 0) + " Y: " + Math.Round(realY, 0);
            if(hex != null){
                info += " " + hex.ID + " TERRAIN: " + hex.TERRAIN + "\n" +
                    (hex?.COUNTRY != null ? " COUNTRY: " + hex.COUNTRY : "") + (hex?.ZONE != null ? " ZONE: " + hex.ZONE : "") + "\n" +
                    (hex?.SHALLOW == true ? "SHALLOW " : "") + 
                    (hex?.RESTRICTED == true ? "RESTRICTED " : "") + 
                    (hex?.SHOALS == true ? "SHOALS " : "") +
                    (hex?.FJORD == true ? "FJORD " : "") +
                    (hex?.DRIFTICE == true ? "DRIFTICE " : "") +
                    (hex?.PACKICE == true ? "PACKICE " : "");
            }
            ((TextBlock)Window().FindName("txtClickedMarkerInfo")).Text = info;
            Start(false);
        }        
    }
    public class SetupBases : GamePhaseAutomated
    {
        public SetupBases(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            List<string> NONEDITABLE = new() { "USSR", "USA" };
            foreach(GO baseLocation in GS.LOCATIONS().Where(n => n.LOGISTICALBASE)){
                string baseSide = GS.Get(baseLocation.COUNTRY + ".SIDE");
                baseSide ??= "NEUT";
                GO flagClone = FS.UPDATELOGISTICALBASE(baseLocation, baseSide, baseSide);
                flagClone.INITSIDE = baseSide;
                if(!NONEDITABLE.Contains(flagClone.COUNTRY)){
                    GS.InteractionMap.Add(flagClone, new());
                }
            }
            Dictionary<string, string> countrySides = new()
                {
                    { "APW", "ALLIES" },
                    { "USA", "ALLIES" },
                    { "SPW", "SOV" },
                    { "USSR", "SOV" },
                    { "NPW", "NEUT" }
                };
            foreach (GO obj in GS.InteractionMap.Keys)
            {
                GS.Set(obj.COUNTRY + ".SIDE", obj.INITSIDE);
                if (!countrySides.ContainsKey(obj.COUNTRY))
                {
                    countrySides.Add(obj.COUNTRY, obj.INITSIDE);
                }
            }

            foreach (GO hex in GS.LOCATIONS().Where(n => n.COUNTRY != null))
            {
                hex.SIDE = countrySides.ContainsKey(hex.COUNTRY) ? countrySides[hex.COUNTRY] : "NEUT";
                hex.INITSIDE = hex.SIDE;
                if (hex.PORT || hex.AIRFIELD)
                {
                    FS.UPDATEBASE(hex.GAMEPIECE, FS.FACILITYTEMPLATES.Where(n => n.ID == hex.SIDE + (hex.PORT ? ".PORT" : "") + (hex.AIRFIELD ? ".AIRFIELD" : "")).Single(), hex);
                }
                if (hex.CLOSEDEFENSE)
                {
                    FS.UPDATECLOSEDEFENSE(hex.CLOSEDEFENSEFACILITY, FS.CLOSEDEFENSETEMPLATES.Where(n => n.ID == hex.SIDE + ".CLOSEDEFENSE").Single(), hex);
                }
            }
            foreach (string s in new List<string> { "NEUT", "SOV", "ALLIES" })
            {
                foreach (GO obj in FS.TYPESIDE(GS, "PIECE", s).Where(n => n.COUNTRY != null))
                {
                    if (GS.InteractionMap.ContainsKey(obj)) { continue; }
                    string newSide = countrySides.TryGetValue(obj.COUNTRY, out string value) ? value : "NEUT";
                    obj.SIDE = newSide;
                    if (obj.SIDE == "NEUT")
                    {
                        obj.INITSIDE = obj.SIDE;
                    }
                    if (obj.TEMPLATEID != null)
                    {
                        if (FS.GENERICCOUNTRIES.Contains(obj.TEMPLATE.COUNTRY))
                        {
                            List<string> ss = obj.TEMPLATE.ID.Split('.').ToList();
                            ss[0] = obj.SIDE;
                            obj.TEMPLATEID = string.Join('.', ss);
                        }
                    }
                    if ((obj.TYPE == "SQN" || obj.TYPE == "SHIP") && obj.GAMELOCATIONID != "TEMP")
                    {
                        GS.CHANGELOCATION(obj, "UNUSED");
                    }
                    if (obj.UNITTYPE != null && obj.GAMELOCATION != null && FS.AI_UNITTYPE_ROLES.TryGetValue(obj.UNITTYPE, out List<string> roles))
                    {
                        obj.AIPRIMARYROLE = roles.First();
                    }
                }
            }
            GS.Done(this);
        }
    }
    public class SetupForces : GamePhaseInteractive
    {
        List<string> CANNOTCHANGESIDE = new() { "USSR", "USA", "APW", "SPW", "NPW" };
        List<string> CLONEABLEMARKERTYPES = new(){"FC", "SC", "TK"};
        List<GO> SQNALLOWED = new();
        List<GO> SURFACEALLOWED = [];
        List<GO> SNALLOWED = [];
        List<GO> SSALLOWED = [];
        List<GO> LOGICALLOWED = new();
        List<GO> MINEALLOWED = new();
        string UNITCATEGORY = null;
        string COUNTRY = null;
        string UNITTYPE = null;
        string TEMPLATE = null;
        List<GO> UNUSED = new();
        List<GO> CANDIDATES = new();
        Dictionary<string, GO> CURRENTLOGICLINKS = [];
        bool ADDUNIT = false;
        bool AILINK = false;
        bool AILINKOBJECTIVE = false;
        bool AILINKDEPLOYMENT = false;
        bool AILINKTRIGGER = false;
        GO baseMarker = null;
        public SetupForces(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario)
        {
            DragDrop = true;
            ManualAdvance = true;
            InProgressSave = true;
            NoShowLocationIndicators = true;
        }
        public override void Execute(Boolean init){
            if(init){
                FS.SETUP = true;
                //ZONES = [..GS.TYPE("WEATHERLOCATION").Select(n => n.PARENTSHEET.ZONE)];
                SQNALLOWED = [..GS.LOCATIONS().Where(n => n.AIRFIELD || n.LOGAIR)];
                SNALLOWED = [..GS.LOCATIONS().Where(n => n.TERRAIN == "SEA" || n.LOGSEA)];
                SURFACEALLOWED = [..SNALLOWED.Where(n => !n.PACKICE)];
                SSALLOWED = [..SURFACEALLOWED];
                LOGICALLOWED = GS.TYPE("HEX");
                MINEALLOWED = [..GS.TYPE("HEX").Where(n => FS.THEATERS.ContainsKey(n.ORGLEVEL1) &&
                n.TERRAIN == "SEA" && (n.COUNTRY != null || n.RESTRICTED || n.FJORD || n.SHALLOW))];      
                FS.SETINSTRUCTIONS(GS, new(){"ADD UNITS/OBJECTIVES TO GAME"});
                GS.HELPTEXT =
                "SETUP COUNTRIES\n\nThe world map is composed of logic zones that represent the different countries and regions in the game.  Each logic zone represents either a base or group of bases on the proper hex map areas, or a singular area representing certain offmap areas.\n\n" +
                "Use this phase to align countries and bases to either ALLIES, SOV, or NEUT.\n\n" +
                "If you'd like to start a country or logistical zone to be conquered, first align it with ALLIES or SOV, then select the option to CONQUER it\n\n" +
                "Setting a logic zone to a side doesn't necessarily mean there are additional units awarded to the side, some areas have no units and alignment simply allows for usage of the base by a side.\n\n" +
                "If an area is set to be NEUT, in the game, the SOV side can attack these to either gain VPs for each base or to allow connectivity with an area beyond.  Example,  SOV player may declare war on Costa Rica to allow access to Panama via land combat.\n\n" +
                "Off map sea travel is not affected by alignment, for example, any side can move ships through South Africa no matter what side its aligned to. However, air transfers are affected by alignment, and air units can only end a transfer in an area aligned to that side\n\n" + 
                "SETUP FORCES\n\nAdd units, and then move to their starting location.  In the DEPLOYMENT phase you can create TF/TGs and do final adjustments to this setup\n\n" +
                "Convoy units like SC, FC, and TK are not limited.  However, all other units are limited by what is pre-setup in the data files\n\n" +
                "When done with your setup you can click the NEXT button.  Stacking restrictions won't be enforced until the DEPLOYMENT phase\n\n" + 
                "Additionally, at any point, you can hit the button on the top tool bar to create a BRANCH.  This will COPY THE CURRENT SETUP into a new folder in the Saved Games dir.  You can use this to create templates for future setups.  You are fully able to edit the names of the Branch FOLDER NAME ONLY for easier organization.\n\n" + 
                "OBJECTIVES & DEPLOYMENT LOGICS\n\n" +
                "Select option from any base.  Add an objective for either side.  The AI button on the top menu bar will either show or hide many of the options you can do, to help with clutter in the left side menu\n" + 
                "*Objective LOGICs are vital for the AI, and can be helpful to the human player for context.  As a designer you will assign units to 1 or more objectives, and during the play, AI will choose\n" + 
                "*Deployment LOGICs are guidance for human players, but when an AI unit arrives and is linked to a Deployment logic, it will randomly choose a location covered by the logic\n" + 
                "*Trigger LOGICs have no purpose for human vs human matches, but they can be used to either turn on or off any AI objectives linked to it.  Perfect example is a trigger logic that prevents Soviets from leaving the Black Sea until its turned on.  It is the human players responsibility to toggle these triggers\n\n" +
                "STRENGTH AND SUPPLIES settings are for the LAND/GARRISON WAR component.  Defaults are established by some research into world military power.  Supply levels are guesses.  Each STRENGTH point represent approx. 100 troops worth of power. For production rates, this is per turn, so be careful setting these too high.  Other settings are discussed in the Land Combat phase\n\n" +               
                "*If you see a white box in the lower left corner of the marker, that unit is an EXPANSION unit, meaning it wasn't in the physical game.  The EXPANSION tag on all units will be cleared after this phase, since its only use is notational for this phase specifically\n\n" +
                "*Interacting with markers in the game can be done by clicking or double-clicking.  Double clicking expands the hex to show all units in it\n\n" +
                "NAME CHANGES can now be done.  Either click the top of the left-side choice menu where the unit name is, or the box with the unit info in the main menu bar"; 
                List<string> types = ["SHIP", "SQN", "OBJECTIVE", "DEPLOYMENTLOGIC", "OBJECTIVELOGIC", "TRIGGERLOGIC", "MINEMARKER"];
                foreach (GO unit in GS.PIECES().Where(n => types.Contains(n.TYPE) && n.GAMELOCATION != null && !n.GAMELOCATION.HIDDEN)){
                    if (unit.UNITTYPE != null && unit.AIPRIMARYROLE == null && FS.AI_UNITTYPE_ROLES.TryGetValue(unit.UNITTYPE, out List<string> value))
                    {
                        unit.AIPRIMARYROLE = value[0];
                    }
                    GS.InteractionMap.Add(unit, new());
                }
                foreach (GO unit in GS.PIECES().Where(n => n.UNITTYPE != null && n.GAMELOCATION?.HIDDEN == true))
                {
                    if (unit.AIPRIMARYROLE == null && FS.AI_UNITTYPE_ROLES.TryGetValue(unit.UNITTYPE, out List<string> value))
                    {
                        unit.AIPRIMARYROLE = value[0];
                    }
                    if (unit.CARRIERID != null && GS.InteractionMap.ContainsKey(unit.CARRIER))
                    {
                        GS.InteractionMap.Add(unit, new());
                    }
                }
                foreach (GO unit in GS.PIECES().Where(n => (FS.BASETYPES.Contains(n.TYPE) || n.TYPE == "POSSESSIONFLAG") && n.GAMELOCATION != null && !n.GAMELOCATION.HIDDEN)){
                    GS.InteractionMap.Add(unit, new());
                }
                UNUSED.AddRange(FS.TYPELOCATION(GS, "PIECE", "UNUSED").Where(n => n.CARRIERID == null));
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if (GS.SkipSetup)
            {
                Update("NEXT");
                return;
            }
            if (GS.SelectedMarker != null) {
                GO obj = GS.SelectedMarker;
                GO loc = FS.PARENTGROUPLOCATION(obj);
                if (baseMarker != obj)
                {
                    baseMarker = obj;
                    UNITCATEGORY = null;
                    COUNTRY = null;
                    UNITTYPE = null;
                    TEMPLATE = null;
                    ADDUNIT = false;
                    AILINK = false;
                    AILINKDEPLOYMENT = false;
                    AILINKOBJECTIVE = false;
                    AILINKTRIGGER = false;
                }
                bool UNITOPTIONS = !(ADDUNIT || AILINK);
                if (ADDUNIT || AILINK)
                {
                    GS.AddAction(obj, "<<BACK");
                }
                if (FS.LOGICALPARENT(obj) == obj)
                {
                    if (obj.TYPE == "OBJECTIVELOGIC" || obj.TYPE == "DEPLOYMENTLOGIC")
                    {
                        if (UNITOPTIONS)
                        {
                            if (obj.TYPE == "OBJECTIVELOGIC")
                            {
                                GS.AddAction(obj, "OBJECTIVE TYPE: " + obj.OBJECTIVETYPE);
                                GS.AddAction(obj, "AWARDS VP|" + (obj.VP_AWARD ? "TRUE" : "FALSE"));
                                GS.AddAction(obj, "REMOVE UNIT WHEN COMPLETE|" + (obj.REMOVEUNIT ? "TRUE" : "FALSE"));
                                GS.AddAction(obj, "REMOVE LINK WHEN COMPLETE|" + (obj.REMOVELINK ? "TRUE" : "FALSE"));
                                GS.AddAction(obj, "VP MULTIPLIER: " + obj.VP_MULTIPLE + "x");
                                GS.AddAction(obj, "VISIBLE TO ALL|" + (obj.OBJECTIVE ? "TRUE" : "FALSE"));
                            }
                            if (obj.TYPE == "DEPLOYMENTLOGIC")
                            {
                                GS.AddAction(obj, "DEPLOYMENT TYPE: " + obj.DEPLOYMENTTYPE);
                            }
                            GS.AddAction(obj, "CLONE");
                            GS.AddAction(obj, "CLONE FOR ENEMY");
                            string[] COVERAGE = obj.LOCATIONCOVERAGE != null ? obj.LOCATIONCOVERAGE.Split('|') : [];
                            GS.AddAction(obj, "ADD SEA HEX RADIUS TO COVERAGE");
                            GS.AddAction(obj, "ADD HEX RADIUS TO COVERAGE");
                            if (obj.GAMELOCATION.ZONE != null)
                            {
                                GS.AddAction(obj, "ADD THIS ZONE TO COVERAGE");
                            }
                            if (!COVERAGE.Contains(obj.GAMELOCATIONID))
                            {
                                GS.AddAction(obj, "ADD THIS HEX TO COVERAGE");
                            }
                            if (COVERAGE.Contains(obj.GAMELOCATIONID))
                            {
                                GS.AddAction(obj, "REMOVE THIS HEX FROM COVERAGE");
                                if (obj.GAMELOCATION.ZONE != null)
                                {
                                    GS.AddAction(obj, "REMOVE THIS ZONE FROM COVERAGE");
                                }
                            }
                            if (COVERAGE.Length != 0)
                            {
                                GS.AddAction(obj, "CLEAR LOCATIONS");
                            }
                        }
                    }
                    else if (obj.TYPE == "TRIGGERLOGIC")
                    {
                        if (UNITOPTIONS)
                        {
                            GS.AddAction(obj, "TRIGGER IS ON|" + (obj.ACTIVE ? "TRUE" : "FALSE"));
                            GS.AddAction(obj, "CLONE");
                            GS.AddAction(obj, "CLONE FOR ENEMY");
                        }
                    }
                    switch (obj.TYPE)
                    {
                        case "SHIP":
                            GS.InteractionMap[obj].Clear();
                            GS.InteractionMap[obj].AddRange(obj.UNITCATEGORY == "SURFACE" ? SURFACEALLOWED : obj.UNITTYPE == "SS" ? SSALLOWED : SNALLOWED);
                            if (UNITOPTIONS)
                            {
                                if (FS.AI_UNITTYPE_ROLES.TryGetValue(obj.UNITTYPE, out List<string> ai_roles))
                                {
                                    if (ai_roles.Count > 1)
                                    {
                                        GS.AddAction(obj, "AI ROLE: " + obj.AIPRIMARYROLE);
                                    }
                                }
                                if (obj.UNITCATEGORY == "SUB" && obj.SIDE == "SOV")
                                {
                                    int remainingCapacity = obj.TEMPLATE.TORPPTS - (obj.MINEPTS * 3) - (obj.COMMANDOPTS);
                                    if (obj.MINEPTS == 0 && remainingCapacity >= 3)
                                    {
                                        GS.AddAction(obj, "LOAD MINES (EXCHANGE 3 TORP)");
                                    }
                                    if (obj.MINEPTS == 1)
                                    {
                                        GS.AddAction(obj, "REMOVE MINES");
                                    }
                                }
                                if (obj.UNITCATEGORY == "SUB")
                                {
                                    int remainingCapacity = obj.TEMPLATE.TORPPTS - (obj.MINEPTS * 3) - (obj.COMMANDOPTS);
                                    if (obj.COMMANDOPTS == 0 && remainingCapacity >= 1)
                                    {
                                        GS.AddAction(obj, "LOAD COMMANDOS (EXCHANGE 1 TORP)");
                                    }
                                    if (obj.COMMANDOPTS == 1)
                                    {
                                        GS.AddAction(obj, "REMOVE COMMANDOS");
                                    }
                                }
                            }
                            break;
                        case "SQN":
                            if (UNITOPTIONS)
                            {
                                if (FS.AI_UNITTYPE_ROLES.TryGetValue(obj.UNITTYPE, out List<string> ai_roles))
                                {
                                    if (ai_roles.Count > 1)
                                    {
                                        GS.AddAction(obj, "AI ROLE: " + obj.AIPRIMARYROLE);
                                    }
                                }
                            }
                            GS.InteractionMap[obj].Clear();
                            GS.InteractionMap[obj].AddRange(SQNALLOWED.Where(n => n.SIDE == obj.SIDE));
                            break;
                        case "OBJECTIVE":
                            if (UNITOPTIONS)
                            {
                                GS.InteractionMap[obj].Clear();
                                GS.InteractionMap[obj].AddRange(SNALLOWED);
                                GS.AddAction(obj, "DELETE");
                            }
                            break;
                        case "DEPLOYMENTLOGIC":
                        case "OBJECTIVELOGIC":
                        case "TRIGGERLOGIC":
                            GS.InteractionMap[obj].Clear();
                            GS.InteractionMap[obj].AddRange(LOGICALLOWED);
                            if (UNITOPTIONS)
                            {
                                GS.AddAction(obj, "DELETE");
                            }
                            break;
                        case "POSSESSIONFLAG":
                            if (UNITOPTIONS)
                            {
                                if (FS.LANDWAR)
                                {
                                    GS.AddAction(obj, "INCREASE STRENGTH");
                                    GS.AddAction(obj, "INCREASE STRENGTH PRODUCTION");
                                    GS.AddAction(obj, "DECREASE STRENGTH");
                                    GS.AddAction(obj, "DECREASE STRENGTH PRODUCTION");
                                    GS.AddAction(obj, "INCREASE SUPPLIES");
                                    GS.AddAction(obj, "INCREASE SUPPLIES PRODUCTION");
                                    GS.AddAction(obj, "DECREASE SUPPLIES");
                                    GS.AddAction(obj, "DECREASE SUPPLIES PRODUCTION");
                                    if (FS.SIDE_NAMES.Contains(obj.SIDE) && obj.SIDE == obj.INITSIDE)
                                    {
                                        GS.AddAction(obj, "CONQUER LOGISTICAL AREA");
                                    }
                                }
                                if (!CANNOTCHANGESIDE.Contains(obj.COUNTRY))
                                {
                                    if (obj.SIDE != "ALLIES")
                                    {
                                        if (!FS.ALIGNEDCOUNTRIES["SOV"].Contains(obj.COUNTRY))
                                        {
                                            GS.AddAction(obj, "ALIGN COUNTRY TO ALLIES");
                                        }
                                    }
                                    if (obj.SIDE != "NEUT") { GS.AddAction(obj, "ALIGN COUNTRY TO NEUT"); }
                                    if (obj.SIDE != "SOV")
                                    {
                                        if (!FS.ALIGNEDCOUNTRIES["ALLIES"].Contains(obj.COUNTRY))
                                        {
                                            GS.AddAction(obj, "ALIGN COUNTRY TO SOV");
                                        }
                                    }
                                }
                            }
                            break;
                        case "FACILITY":
                            if (UNITOPTIONS)
                            {
                                if (FS.SIDE_NAMES.Contains(obj.SIDE))
                                {
                                    GS.AddAction(obj, "CONQUER BASE");
                                }
                                if (obj.PORT)
                                {
                                    if (obj.PORTDAMAGELEVEL < 4)
                                    {
                                        GS.AddAction(obj, "DAMAGE PORT");
                                    }
                                    if (obj.PORTDAMAGELEVEL > 0)
                                    {
                                        GS.AddAction(obj, "REPAIR PORT");
                                    }
                                }
                                if (obj.AIRFIELD)
                                {
                                    if (obj.AIRFIELDDAMAGELEVEL < 4)
                                    {
                                        GS.AddAction(obj, "DAMAGE AIRFIELD");
                                    }
                                    if (obj.AIRFIELDDAMAGELEVEL > 0)
                                    {
                                        GS.AddAction(obj, "REPAIR AIRFIELD");
                                    }
                                }
                                if (FS.GARRISONWAR)
                                {
                                    GS.AddAction(obj, "INCREASE STRENGTH");
                                    GS.AddAction(obj, "DECREASE STRENGTH");
                                }
                            }
                            break;
                        case "CLOSEDEFENSE":
                            if (UNITOPTIONS)
                            {
                                if (obj.CLOSEDEFENSEDAMAGELEVEL < 4)
                                {
                                    GS.AddAction(obj, "DAMAGE CLOSE DEFENSE");
                                }
                                if (obj.CLOSEDEFENSEDAMAGELEVEL > 0)
                                {
                                    GS.AddAction(obj, "REPAIR CLOSE DEFENSE");
                                }
                            }
                            break;
                        case "MINEMARKER":
                            GS.InteractionMap[obj].Clear();
                            GS.InteractionMap[obj].AddRange(MINEALLOWED);
                            if (UNITOPTIONS)
                            {
                                GS.AddAction(obj, "SWITCH TO " + FS.ENEMY(obj.SIDE));
                                GS.AddAction(obj, "DELETE");
                            }
                            break;
                        default:
                            break;
                    }
                    if (obj.TYPE == "SQN" || obj.TYPE == "SHIP")
                    {
                        if (UNITOPTIONS)
                        {
                            if (loc.TYPE == "ENROUTE" || loc.PORT || loc.AIRFIELD || loc.LOGISTICALBASE)
                            {
                                GS.AddAction(obj, "DELAY: INCREASE");
                                GS.AddAction(obj, "DELAY: INCREASE + 3");
                            }
                            if (obj.ENROUTEDELAY > 0) { GS.AddAction(obj, "DELAY: RESET"); }
                            if (FS.SURFACELADENTYPES.Contains(obj.UNITTYPE))
                            {
                                GS.AddAction(obj, "FULLY LOADED|" + (obj.EMPTY ? "FALSE" : "TRUE"));
                            }
                            if (FS.REMOVABLETYPES.Contains(obj.UNITTYPE))
                            {
                                GS.AddAction(obj, "REMOVABLE DURING PLAY|" + (obj.VP_REMOVABLE ? "TRUE" : "FALSE"));
                            }
                            GS.AddAction(obj, "REMOVE FROM SETUP");
                        }
                        if (ADDUNIT)
                        {
                            int classAvailable = UNUSED.Where(n => n.COUNTRY == obj.COUNTRY && n.TEMPLATE == obj.TEMPLATE).Count();
                            int typeAvailable = UNUSED.Where(n => n.COUNTRY == obj.COUNTRY && n.UNITTYPE == obj.UNITTYPE).Count();
                            if (classAvailable > 0)
                            {
                                GS.AddAction(obj, "ADD ANOTHER OF THIS CLASS : " + classAvailable);
                            }
                            if (typeAvailable > 0 || CLONEABLEMARKERTYPES.Contains(obj.UNITTYPE))
                            {
                                GS.AddAction(obj, "ADD ANOTHER OF THIS TYPE : " + (typeAvailable == 0 ? "unlim" : typeAvailable));
                            }
                        }
                    }
                    if (obj.SIDE != null)
                    {
                        List<string> countries = FS.TYPESIDELOCATION(GS, "PIECE", obj.SIDE, loc.ID).Where(n => n.COUNTRY != null).Select(n => n.COUNTRY).ToList();
                        countries.Add("USA");
                        countries.Add("USSR");
                        countries = countries.Distinct().ToList();
                        if (ADDUNIT)
                        {
                            if (UNITCATEGORY == null)
                            {
                                foreach (string uc in new List<string> { "AIR", "SURFACE", "SUB", "MINE", "LOGIC" })
                                {
                                    List<GO> tmp = UNUSED.Where(n => n.UNITCATEGORY == uc && n.SIDE == obj.SIDE && countries.Contains(n.COUNTRY)).ToList();
                                    bool canClone = (uc == "SURFACE" && obj.SIDE != "NEUT") || uc == "LOGIC" || uc == "MINE";
                                    bool canAdd = uc switch
                                    {
                                        "AIR" => SQNALLOWED.Contains(loc),
                                        "MINE" => MINEALLOWED.Contains(loc),
                                        "LOGIC" => LOGICALLOWED.Contains(loc),
                                        _ => SNALLOWED.Contains(loc),

                                    };
                                    if (canAdd && (tmp.Any() || canClone))
                                    {
                                        GS.AddAction(obj, ">>" + uc);
                                    }
                                }
                            }
                            if (COUNTRY == null)
                            {
                                if (UNITCATEGORY == "LOGIC")
                                {
                                    if (LOGICALLOWED.Contains(loc))
                                    {
                                        GS.AddAction(obj, "OBJECTIVE");
                                        GS.AddAction(obj, "DEPLOYMENT");
                                        GS.AddAction(obj, "TRIGGER");
                                    }
                                }
                                else
                                {
                                    foreach (string c in countries)
                                    {
                                        int countryAvailable = CANDIDATES.Where(n => n.COUNTRY == c).Count();
                                        if (countryAvailable > 0) { GS.AddAction(obj, c + " : " + countryAvailable); }
                                    }
                                    if (obj.SIDE == "SOV")
                                    {
                                        if (UNITCATEGORY == "SURFACE") { GS.AddAction(obj, "SPW : unlim"); }
                                    }
                                    else if (obj.SIDE == "ALLIES")
                                    {
                                        if (UNITCATEGORY == "SURFACE") { GS.AddAction(obj, "APW : unlim"); }
                                    }
                                }
                            }
                            else if (UNITTYPE == null)
                            {
                                if (FS.GENERICCOUNTRIES.Contains(COUNTRY))
                                {
                                    if (obj.SIDE == "SOV")
                                    {
                                        GS.AddAction(obj, "SC");
                                    }
                                    else
                                    {
                                        foreach (string ut in CLONEABLEMARKERTYPES.Order())
                                        {
                                            GS.AddAction(obj, ut);
                                        }
                                    }
                                }
                                else
                                {
                                    foreach (string ut in CANDIDATES.Select(n => n.UNITTYPE).Distinct().Order())
                                    {
                                        int typeAvailable = CANDIDATES.Where(n => n.UNITTYPE == ut).Count();
                                        GS.AddAction(obj, ut + " : " + typeAvailable);
                                    }
                                }
                            }
                            else if (TEMPLATE == null)
                            {
                                GS.AddAction(obj, "RANDOM : " + CANDIDATES.Count);
                                foreach (string ut in CANDIDATES.Select(n => n.TEMPLATE.LABEL).Distinct().Order())
                                {
                                    int classAvailable = CANDIDATES.Where(n => n.TEMPLATE.LABEL == ut).Count();
                                    GS.AddAction(obj, ut + " : " + classAvailable);
                                }
                            }
                            else
                            {
                                GS.AddAction(obj, "RANDOM : " + CANDIDATES.Count);
                                foreach (string t in CANDIDATES.Select(n => n.LABEL).Distinct().Order())
                                {
                                    GS.AddAction(obj, t);
                                }
                            }
                        }
                    }
                    if (AILINK)
                    {
                        //link to logics
                        switch (obj.TYPE)
                        {
                            case "OBJECTIVELOGIC":
                                CURRENTLOGICLINKS.Clear();
                                if (AILINKTRIGGER)
                                {
                                    foreach (GO link in FS.TYPESIDE(GS, "AI.LOGICLINK", obj.SIDE).Where(n => n.UNIT == obj))
                                    {
                                        CURRENTLOGICLINKS["TRIGGER " + link.LOGIC.LABEL] =link;
                                    }
                                    foreach (GO logic in FS.TYPESIDE(GS, "TRIGGERLOGIC", obj.SIDE).Where(n => !CURRENTLOGICLINKS.Values.Select(n => n.LOGIC).Contains(n)))
                                    {
                                        CURRENTLOGICLINKS["TRIGGER " + logic.LABEL] = logic;
                                    }
                                    foreach (string key in CURRENTLOGICLINKS.Keys)
                                    {
                                        GS.AddAction(obj, key + "|" + (CURRENTLOGICLINKS[key].TYPE == "AI.LOGICLINK" ? "TRUE" : "FALSE"));
                                    }
                                }
                                break;
                            case "SHIP":
                            case "SQN":
                                CURRENTLOGICLINKS.Clear();
                                if (AILINKDEPLOYMENT)
                                {
                                    foreach (GO link in FS.TYPESIDE(GS, "AI.LOGICLINK", obj.SIDE).Where(n => n.UNIT == obj && n.LOGIC.TYPE == "DEPLOYMENTLOGIC"))
                                    {
                                        CURRENTLOGICLINKS[(link.LOGIC.OBJECTIVETYPE ?? "DEPLOY") + " " + link.LOGIC.LABEL] = link;
                                    }
                                    foreach (GO logic in FS.TYPESIDE(GS, "DEPLOYMENTLOGIC", obj.SIDE).Where(n => (n.DEPLOYMENTTYPE == obj.TYPE || n.DEPLOYMENTTYPE == null) && !CURRENTLOGICLINKS.Values.Select(n => n.LOGIC).Contains(n)))
                                    {
                                        CURRENTLOGICLINKS[(logic.OBJECTIVETYPE ?? "DEPLOY") + " " + logic.LABEL] = logic;
                                    }
                                    foreach (string key in CURRENTLOGICLINKS.Keys)
                                    {
                                        GS.AddAction(obj, key + "|" + (CURRENTLOGICLINKS[key].TYPE == "AI.LOGICLINK" ? "TRUE" : "FALSE"));
                                    }
                                }
                                if (AILINKOBJECTIVE)
                                {
                                    foreach (GO link in FS.TYPESIDE(GS, "AI.LOGICLINK", obj.SIDE).Where(n => n.UNIT == obj && n.LOGIC.TYPE == "OBJECTIVELOGIC").OrderBy(n => n.LOGIC.OBJECTIVETYPE))
                                    {
                                        CURRENTLOGICLINKS[(link.LOGIC.OBJECTIVETYPE ?? "DEPLOY") + " " + link.LOGIC.LABEL] = link;                                   }
                                    foreach (GO logic in FS.TYPESIDE(GS, "OBJECTIVELOGIC", obj.SIDE).Where(n => FS.AI_ALLOWEDOBJECTIVETYPES[obj.TYPE].Contains(n.OBJECTIVETYPE) && !CURRENTLOGICLINKS.Values.Select(n => n.LOGIC).Contains(n)).OrderBy(n => n.OBJECTIVETYPE))
                                    {
                                        CURRENTLOGICLINKS[(logic.OBJECTIVETYPE ?? "DEPLOY") + " " + logic.LABEL] = logic;
                                    }
                                    foreach (string key in CURRENTLOGICLINKS.Keys)
                                    {
                                        GS.AddAction(obj, key + "|" + (CURRENTLOGICLINKS[key].TYPE == "AI.LOGICLINK" ? "TRUE" : "FALSE"));
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
                else if (obj.TYPE == "SQN")
                {
                    if (UNITOPTIONS)
                    {
                        if (FS.AI_UNITTYPE_ROLES.TryGetValue(obj.UNITTYPE, out List<string> ai_roles))
                        {
                            if (ai_roles.Count > 1)
                            {
                                GS.AddAction(obj, "AI ROLE: " + obj.AIPRIMARYROLE);
                            }
                        }
                    }
                    CURRENTLOGICLINKS.Clear();
                    if (AILINKOBJECTIVE)
                    {
                        foreach (GO link in FS.TYPESIDE(GS, "AI.LOGICLINK", obj.SIDE).Where(n => n.UNIT == obj && n.LOGIC.TYPE == "OBJECTIVELOGIC").OrderBy(n => n.LOGIC.OBJECTIVETYPE))
                        {
                            CURRENTLOGICLINKS[(link.LOGIC.OBJECTIVETYPE ?? "DEPLOY") + " " + link.LOGIC.LABEL] = link;
                        }
                        foreach (GO logic in FS.TYPESIDE(GS, "OBJECTIVELOGIC", obj.SIDE).Where(n => FS.AI_ALLOWEDOBJECTIVETYPES[obj.TYPE].Contains(n.OBJECTIVETYPE) && !CURRENTLOGICLINKS.Values.Select(n => n.LOGIC).Contains(n)).OrderBy(n => n.OBJECTIVETYPE))
                        {
                            CURRENTLOGICLINKS[(logic.OBJECTIVETYPE ?? "DEPLOY") + " " + logic.LABEL] = logic;
                        }
                        foreach (string key in CURRENTLOGICLINKS.Keys)
                        {
                            GS.AddAction(obj, key + "|" + (CURRENTLOGICLINKS[key].TYPE == "AI.LOGICLINK" ? "TRUE" : "FALSE"));
                        }
                    }
                }
                if (UNITOPTIONS)
                {
                    if (obj.SIDE != null)
                    {
                        GS.AddAction(obj, ">>CREATE");
                    }
                    if (FS.UNITTYPES.Contains(obj.TYPE) || obj.TYPE == "OBJECTIVELOGIC")
                    {
                        GS.AddAction(obj, ">>LINKS");
                    }
                }
                else if (AILINK) {
                    if (FS.UNITTYPES.Contains(obj.TYPE))
                    {
                        if (FS.LOGICALPARENT(obj) == obj)
                        {
                            if (!AILINKDEPLOYMENT)
                            {
                                GS.AddAction(obj, ">>DEPLOYMENTS");
                            }
                        }
                        if (!AILINKOBJECTIVE)
                        {
                            GS.AddAction(obj, ">>OBJECTIVES");
                        }
                    }
                    if (obj.TYPE == "OBJECTIVELOGIC")
                    {
                        if (!AILINKTRIGGER)
                        {
                            GS.AddAction(obj, ">>TRIGGERS");
                        }
                    }
                }
                GS.AddAction(obj, "END PHASE");
                GS.InteractionMap[obj].Remove(loc);
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            GO loc = FS.PARENTGROUPLOCATION(gp);
            switch(pData){
                case ">>AIR":
                case ">>SURFACE":
                case ">>SUB":
                    pData = pData.Replace(">>","");
                    FILTERBYUNITCATEGORY(gp, pData);
                    if(CANDIDATES.Any()){
                        UNITCATEGORY = pData;
                    }
                    Start(false);
                    break;
                case ">>LOGIC":
                    pData = pData.Replace(">>", "");
                    UNITCATEGORY = pData;
                    Start(false);
                    break;
                case ">>CREATE":
                    ADDUNIT = true;
                    AILINK = false;  
                    AILINKDEPLOYMENT = false;
                    AILINKOBJECTIVE = false;
                    AILINKTRIGGER = false;
                    Start(false);
                    break;
                case ">>LINKS":
                    ADDUNIT = false;
                    AILINK = true;
                    AILINKDEPLOYMENT = false;
                    AILINKOBJECTIVE = false;
                    AILINKTRIGGER = false;
                    Start(false);
                    break;
                case ">>DEPLOYMENTS":
                    ADDUNIT = false;
                    AILINK = true;
                    AILINKDEPLOYMENT = true;
                    AILINKOBJECTIVE = false;
                    AILINKTRIGGER = false;
                    Start(false);
                    break;
                case ">>OBJECTIVES":
                    ADDUNIT = false;
                    AILINK = true;
                    AILINKDEPLOYMENT = false;
                    AILINKOBJECTIVE = true;
                    AILINKTRIGGER = false;
                    Start(false);
                    break;
                case ">>TRIGGERS":
                    ADDUNIT = false;
                    AILINK = true;
                    AILINKDEPLOYMENT = false;
                    AILINKOBJECTIVE = false;
                    AILINKTRIGGER = true;
                    Start(false);
                    break;
                case "ADD ANOTHER OF THIS CLASS":
                    UNITCATEGORY = gp.UNITCATEGORY;
                    FILTERBYUNITCATEGORY(gp, UNITCATEGORY);
                    COUNTRY = gp.COUNTRY;
                    FILTERBYCOUNTRY(COUNTRY);
                    UNITTYPE = gp.UNITTYPE;
                    FILTERBYUNITTYPE(UNITTYPE);
                    string t = gp.TEMPLATE.LABEL;
                    TEMPLATE = null;
                    Update(t);
                    break;
                case "ADD ANOTHER OF THIS TYPE":
                    TEMPLATE = null;
                    UNITCATEGORY = gp.UNITCATEGORY;
                    FILTERBYUNITCATEGORY(gp, UNITCATEGORY);
                    COUNTRY = gp.COUNTRY;
                    FILTERBYCOUNTRY(COUNTRY);
                    t = gp.UNITTYPE;
                    UNITTYPE = null;
                    Update(t);
                    break;
                case "RANDOM":
                    List<GO> tmpobjs = UNUSED.Where(n => n.COUNTRY == COUNTRY && 
                    n.UNITTYPE == UNITTYPE &&
                    (TEMPLATE == null || n.TEMPLATE.LABEL == TEMPLATE)).ToList();                    
                    GO tmpobj = GS.RANDOMGAMEOBJECT(tmpobjs);
                    GS.CHANGELOCATION(tmpobj, loc.ID);
                    UNUSED.Remove(tmpobj);
                    GS.InteractionMap.Add(tmpobj, new());
                    GS.SelectedMarker = tmpobj;
                    if (gp.TEMPLATE.AIRUNITS != null)
                    {
                        foreach (GO gm in FS.GROUPMEMBERS(gp))
                        {
                            GS.CHANGELOCATION(gm, loc.ID);
                            GS.InteractionMap.Add(gm, new());
                        }
                    }
                    Start(false);
                    break;
                case "REMOVE FROM SETUP":
                    GS.REMOVEINTERACTIVE(gp);
                    if (CLONEABLEMARKERTYPES.Contains(gp.UNITTYPE)){
                        GS.DISCARD(gp);
                    } else {
                        UNUSED.Add(gp);
                        GS.CHANGELOCATION(gp, "UNUSED");
                    }
                    if (gp.TEMPLATE.AIRUNITS != null)
                    {
                        foreach(GO gm in FS.GROUPMEMBERS(gp))
                        {
                            GS.REMOVEINTERACTIVE(gm);
                            GS.CHANGELOCATION(gm, "TEMP");
                        }
                    }
                    Start(false);
                    break;
                case "NEXT":  
                    List<GO> setup = new();
                    foreach(GO obj in GS.InteractionMap.Keys.Where(n => (n.TYPE == "SQN" || n.TYPE == "SHIP") && FS.LOGICALPARENT(n) == n)){
                        setup.Add(obj);
                        if(obj.TEMPLATE.AIRUNITS != null){
                            setup.AddRange(FS.GROUPMEMBERS(obj));
                            FS.GROUPMEMBERS(obj).ForEach(n => GS.CHANGELOCATION(n, obj.GAMELOCATION));
                        }
                    }
                    foreach(GO obj in setup){
                        obj.EXPANSION = false;
                        if(obj.TEMPLATEID != null){
                            //logistics
                            obj.FUELPTS = obj.TEMPLATE.FUELPTS;
                            obj.SSMPTS = obj.TEMPLATE.SSMPTS;
                            obj.SSM2PTS = obj.TEMPLATE.SSM2PTS;
                            int remainingCapacity = obj.TEMPLATE.TORPPTS - (obj.MINEPTS * 3) - (obj.COMMANDOPTS);
                            obj.TORPPTS = remainingCapacity;
                            obj.CMPTS = obj.TEMPLATE.CMPTS;
                            obj.ASWPTS = obj.TEMPLATE.ASWPTS;
                            obj.AAPTS = obj.TEMPLATE.AAPTS;
                            obj.BOMBPTS = obj.TEMPLATE.BOMBPTS;
                            obj.AIRSSMPTS = obj.TEMPLATE.AIRSSMPTS;
                            obj.APTS = obj.TEMPLATE.APTS;
                            obj.FPTS = obj.TEMPLATE.FPTS;
                            obj.MOVEMENTALLOWANCE = obj.TEMPLATE.MOVEMENTALLOWANCE;
                            if(obj.UNITTYPE == "ATR"){
                                obj.EMPTY = true;
                            }
                        }
                    }
                    foreach(GO obj in UNUSED){
                        obj.SIDE = null;
                        obj.INITSIDE = null;
                        if(obj.TEMPLATE.AIRUNITS != null){
                            FS.GROUPMEMBERS(obj).ForEach(n => n.SIDE = null);
                            FS.GROUPMEMBERS(obj).ForEach(n => n.INITSIDE = null);
                        }
                    }
                    foreach(GO obj in GS.TYPE("OBJECTIVELOGIC").Where(n => n.LOCATIONCOVERAGE == null).ToList())
                    {
                        obj.LOCATIONCOVERAGE = obj.GAMELOCATIONID;
                    }
                    foreach (GO obj in GS.TYPE("DEPLOYMENTLOGIC").Where(n => n.LOCATIONCOVERAGE == null).ToList())
                    {
                        obj.LOCATIONCOVERAGE = obj.GAMELOCATIONID;
                    }
                    FS.SETUP = false;
                    //deploy AI
                    foreach (string side in GS.AI_Sides)
                    {
                        FS.AI_DEPLOY([.. FS.TYPESIDE(GS, "PIECE", side).Where(n => (n.TYPE == "SHIP" || n.TYPE == "SQN") && n.CARRIERID == null && n.ENROUTEDELAY == 0)]);
                    }
                    GS.Done(this);
                    break;
                case null:
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != loc.ID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);                 
                    }
                    Start(false);
                    break;
                case "<<BACK":
                    if(COUNTRY == null){
                        UNITCATEGORY = null;
                        AILINK = false;
                        AILINKDEPLOYMENT = false;
                        AILINKOBJECTIVE = false;
                        AILINKTRIGGER = false;
                        ADDUNIT = false;
                        Start(false);
                    } else if(UNITTYPE == null){
                        COUNTRY = null;
                        FILTERBYUNITCATEGORY(gp, UNITCATEGORY);
                        Start(false);
                    } else if(TEMPLATE == null){
                        UNITTYPE = null;
                        FILTERBYUNITCATEGORY(gp, UNITCATEGORY);
                        FILTERBYCOUNTRY(COUNTRY);
                        Start(false);
                    } else {
                        TEMPLATE = null;
                        FILTERBYUNITCATEGORY(gp, UNITCATEGORY);
                        FILTERBYCOUNTRY(COUNTRY);
                        FILTERBYUNITTYPE(UNITTYPE);
                        Start(false);
                    }
                    break;
                case "DELETE":
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    GS.DISCARD(gp);
                    Start(false);
                    break;
                case "OBJECTIVE":
                    GO clone = FS.CREATEOBJECTIVELOGIC(FS.SIDE_NAMES.Contains(gp.SIDE) ? gp.SIDE : "ALLIES", loc);
                    GS.InteractionMap.Add(clone, new());
                    GS.SelectedMarker = clone;
                    Start(false);
                    break;
                case "DEPLOYMENT":
                    clone = FS.CREATEDEPLOYMENTLOGIC(FS.SIDE_NAMES.Contains(gp.SIDE) ? gp.SIDE : "ALLIES", loc);
                    GS.InteractionMap.Add(clone, new());
                    GS.SelectedMarker = clone;
                    Start(false);
                    break;
                case "TRIGGER":
                    clone = FS.CREATETRIGGERLOGIC(FS.SIDE_NAMES.Contains(gp.SIDE) ? gp.SIDE : "ALLIES", loc);
                    GS.InteractionMap.Add(clone, new());
                    GS.SelectedMarker = clone;
                    Start(false);
                    break;
                case "CLONE":
                case "CLONE FOR ENEMY":
                    string clonedSide = pData == "CLONE" ? gp.SIDE : FS.ENEMY(gp.SIDE);
                    clone = gp.TYPE switch
                    {
                        "DEPLOYMENTLOGIC" => FS.CREATEDEPLOYMENTLOGIC(clonedSide, loc),
                        "TRIGGERLOGIC" => FS.CREATETRIGGERLOGIC(clonedSide, loc),
                        _ => FS.CREATEOBJECTIVELOGIC(clonedSide, loc)
                    };
                    clone.OBJECTIVETYPE = gp.OBJECTIVETYPE;
                    clone.DEPLOYMENTTYPE = gp.DEPLOYMENTTYPE;
                    clone.VP_MULTIPLE = gp.VP_MULTIPLE;
                    clone.VP_AWARD = gp.VP_AWARD;
                    clone.REMOVELINK = gp.REMOVELINK;
                    clone.REMOVEUNIT = gp.REMOVEUNIT;
                    clone.LOCATIONCOVERAGE = gp.LOCATIONCOVERAGE;
                    clone.ACTIVE = gp.ACTIVE;
                    clone.OBJECTIVE = gp.OBJECTIVE;
                    GS.InteractionMap.Add(clone, new());
                    GS.SelectedMarker = clone;
                    Start(false);
                    break;
                case ">>MINE":
                    clone = FS.CLONE(GS, GS.PIECE("MINE"), loc.ID);
                    clone.SIDE = FS.SIDE_NAMES.Contains(gp.SIDE) ? gp.SIDE : "SOV";
                    GS.InteractionMap.Add(clone, []);
                    GS.SelectedMarker = clone;
                    Start(false);
                    break;
                case "AI ROLE":
                    gp.AIPRIMARYROLE = !FS.AI_UNITTYPE_ROLES[gp.UNITTYPE].Contains(gp.AIPRIMARYROLE) ? FS.AI_UNITTYPE_ROLES[gp.UNITTYPE].First() : GS.NEXT(FS.AI_UNITTYPE_ROLES[gp.UNITTYPE], gp.AIPRIMARYROLE);
                    Start(false);
                    break;
                case "OBJECTIVE TYPE":
                    gp.OBJECTIVETYPE = !FS.AI_OBJECTIVETYPES.Contains(gp.OBJECTIVETYPE) ? FS.AI_OBJECTIVETYPES.First() : GS.NEXT(FS.AI_OBJECTIVETYPES, gp.OBJECTIVETYPE);
                    Start(false);
                    break;
                case "DEPLOYMENT TYPE":
                    gp.DEPLOYMENTTYPE = !FS.UNITTYPES.Contains(gp.DEPLOYMENTTYPE) ? FS.UNITTYPES.First() : GS.NEXT(FS.UNITTYPES, gp.DEPLOYMENTTYPE);
                    Start(false);
                    break;
                case "VP MULTIPLIER":
                    gp.VP_MULTIPLE = !FS.AI_VPMULTIPLES.Contains(gp.VP_MULTIPLE) ? FS.AI_VPMULTIPLES.First() : GS.NEXT(FS.AI_VPMULTIPLES, gp.VP_MULTIPLE);
                    Start(false);
                    break;
                case "AWARDS VP":
                case "AWARDS VP?":
                    gp.VP_AWARD = !gp.VP_AWARD;
                    Start(false);
                    break;
                case "TRIGGER IS ON":
                case "TRIGGER IS ON?":
                    gp.ACTIVE = !gp.ACTIVE;
                    Start(false);
                    break;
                case "REMOVE UNIT WHEN COMPLETE":
                case "REMOVE UNIT WHEN COMPLETE?":
                    gp.REMOVEUNIT = !gp.REMOVEUNIT;
                    Start(false);
                    break;               
                case "REMOVE LINK WHEN COMPLETE":
                case "REMOVE LINK WHEN COMPLETE?":
                    gp.REMOVELINK = !gp.REMOVELINK;
                    Start(false);
                    break;
                case "VISIBLE TO ALL":
                case "VISIBLE TO ALL?":
                    gp.OBJECTIVE = !gp.OBJECTIVE;
                    if (gp.OBJECTIVE)
                    {
                        gp.HIDDEN = false;
                    }
                    Start(false);
                    break;
                case "SWITCH TO ALLIES":
                case "SWITCH TO SOV":
                    switch(gp.TYPE){
                        case "MINEMARKER":
                            gp.SIDE = FS.ENEMY(gp.SIDE);
                            break;
                        default:
                            break;
                    }
                    Start(false);
                    break;
                case "CLEAR LOCATIONS":
                    gp.LOCATIONCOVERAGE = null;
                    Start(false);
                    break;
                case "ADD THIS ZONE TO COVERAGE":
                    List<string> COVERAGE = (gp.LOCATIONCOVERAGE != null ? gp.LOCATIONCOVERAGE.Split('|') : []).ToList();
                    COVERAGE.AddRange(GS.TYPE("HEX").Where(n => n.ZONE == loc.ZONE).Select(n => n.ID));
                    COVERAGE = COVERAGE.Distinct().ToList();
                    gp.LOCATIONCOVERAGE = string.Join('|', COVERAGE);
                    Start(false);
                    break;
                case "ADD SEA HEX RADIUS TO COVERAGE":
                case "ADD HEX RADIUS TO COVERAGE":
                    COVERAGE = (gp.LOCATIONCOVERAGE != null ? gp.LOCATIONCOVERAGE.Split('|') : []).ToList();
                    for (int i = 1; i < 10; i++)
                    {
                        List<GO> radius = FS.FINDAIRRADIUS(loc, i);
                        if(pData.StartsWith("ADD SEA"))
                        {
                            radius = [.. radius.Where(n => n.TERRAIN == "SEA")];
                        }
                        List<string> tmp = [..radius.Select(n => n.ID)];
                        if (tmp.Where(n => !COVERAGE.Contains(n)).Any())
                        {
                            COVERAGE.AddRange(tmp);
                            COVERAGE = COVERAGE.Distinct().ToList();
                            gp.LOCATIONCOVERAGE = string.Join('|', COVERAGE);
                            break;
                        }
                    }
                    Start(false);
                    break;
                case "ADD THIS HEX TO COVERAGE":
                    COVERAGE = (gp.LOCATIONCOVERAGE != null ? gp.LOCATIONCOVERAGE.Split('|') : []).ToList();
                    COVERAGE.Add(loc.ID);
                    COVERAGE = COVERAGE.Distinct().ToList();
                    gp.LOCATIONCOVERAGE = string.Join('|', COVERAGE);
                    Start(false);
                    break;
                case "REMOVE THIS ZONE FROM COVERAGE":
                    COVERAGE = (gp.LOCATIONCOVERAGE != null ? gp.LOCATIONCOVERAGE.Split('|') : []).ToList();
                    COVERAGE.RemoveAll(n => GS.TYPE("HEX").Where(n2 => n2.ZONE == loc.ZONE).Select(n2 => n2.ID).Contains(n));
                    COVERAGE = COVERAGE.Distinct().ToList();
                    gp.LOCATIONCOVERAGE = string.Join('|', COVERAGE);
                    Start(false);
                    break;
                case "REMOVE THIS HEX FROM COVERAGE":
                    COVERAGE = (gp.LOCATIONCOVERAGE != null ? gp.LOCATIONCOVERAGE.Split('|') : []).ToList();
                    COVERAGE.Remove(loc.ID);
                    COVERAGE = COVERAGE.Distinct().ToList();
                    gp.LOCATIONCOVERAGE = string.Join('|', COVERAGE);
                    Start(false);
                    break;
                case "INCREASE STRENGTH":
                    gp.STRENGTH += gp.TYPE == "FACILITY" ? 10 : FS.LANDCOMBATSIZE;
                    Start(false);
                    break;
                case "INCREASE STRENGTH PRODUCTION":
                    gp.STRENGTHPRODUCTIONRATE += 0.5;
                    Start(false);
                    break;
                case "INCREASE SUPPLIES":
                    gp.SUPPLIES += FS.LANDSUPPLYSIZE;
                    Start(false);
                    break;
                case "INCREASE SUPPLIES PRODUCTION":
                    gp.SUPPLYPRODUCTIONRATE += 0.5;
                    Start(false);
                    break;
                case "DECREASE STRENGTH":
                    gp.STRENGTH = Math.Max(0, gp.STRENGTH - (gp.TYPE == "FACILITY" ? 10 : FS.LANDCOMBATSIZE));
                    Start(false);
                    break;
                case "DECREASE STRENGTH PRODUCTION":
                    gp.STRENGTHPRODUCTIONRATE = Math.Max(0, gp.STRENGTHPRODUCTIONRATE - 0.5);
                    Start(false);
                    break;
                case "DECREASE SUPPLIES":
                    gp.SUPPLIES = Math.Max(0, gp.SUPPLIES - FS.LANDSUPPLYSIZE);
                    Start(false);
                    break;
                case "DECREASE SUPPLIES PRODUCTION":
                    gp.SUPPLYPRODUCTIONRATE = Math.Max(0, gp.SUPPLYPRODUCTIONRATE - 0.5);
                    Start(false);
                    break;
                case "FULLY LOADED":
                case "FULLY LOADED?":
                    gp.EMPTY = !gp.EMPTY;
                    Start(false);
                    break;
                case "REMOVABLE DURING PLAY":
                case "REMOVABLE DURING PLAY?":
                    gp.VP_REMOVABLE = !gp.VP_REMOVABLE;
                    Start(false);
                    break;
                case "DELAY: INCREASE":
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.ENROUTEDELAY++);
                    FS.UPDATEGROUP(gp);
                    Start(false);
                    break;
                case "DELAY: INCREASE + 3":
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.ENROUTEDELAY += 3);
                    FS.UPDATEGROUP(gp);
                    Start(false);
                    break;
                case "DELAY: RESET":
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.ENROUTEDELAY = 0);
                    FS.UPDATEGROUP(gp);
                    Start(false);
                    break;
                case "CONQUER BASE":
                    FS.DESTROYAIRATAIRFIELD(gp.GAMELOCATION, gp.SIDE);
                    gp.GAMELOCATION.SIDE = FS.ENEMY(gp.SIDE);
                    FS.CONQUERBASE(gp.GAMELOCATION);
                    Start(false);
                    break;
                case "CONQUER LOGISTICAL AREA":
                    FS.CONQUERLOGISTICALZONE(gp.GAMELOCATION);
                    Start(false);
                    break;
                case "DAMAGE PORT":
                    FS.DAMAGEBASE(gp.GAMELOCATION, "PORT");
                    Start(false);
                    break;
                case "REPAIR PORT":
                    gp.PORTDAMAGELEVEL = Math.Max(0, gp.PORTDAMAGELEVEL - 1);
                    gp.GAMELOCATION.PORTDAMAGELEVEL = Math.Max(0, gp.GAMELOCATION.PORTDAMAGELEVEL - 1);
                    gp.PORTDESTROYED = false;
                    gp.GAMELOCATION.PORTDESTROYED = false;
                    Start(false);
                    break;
                case "DAMAGE AIRFIELD":
                    FS.DAMAGEBASE(gp.GAMELOCATION, "AIRFIELD");
                    Start(false);
                    break;
                case "REPAIR AIRFIELD":
                    gp.AIRFIELDDAMAGELEVEL = Math.Max(0, gp.AIRFIELDDAMAGELEVEL - 1);
                    gp.GAMELOCATION.AIRFIELDDAMAGELEVEL = Math.Max(0, gp.GAMELOCATION.AIRFIELDDAMAGELEVEL - 1);
                    gp.AIRFIELDDESTROYED = false;
                    gp.GAMELOCATION.AIRFIELDDESTROYED = false;
                    Start(false);
                    break;
                case "DAMAGE CLOSE DEFENSE":
                    FS.DAMAGEBASE(gp.GAMELOCATION, "CLOSEDEFENSE");
                    Start(false);
                    break;
                case "REPAIR CLOSE DEFENSE":
                    gp.CLOSEDEFENSEDAMAGELEVEL = Math.Max(0, gp.CLOSEDEFENSEDAMAGELEVEL - 1);
                    gp.GAMELOCATION.CLOSEDEFENSEDAMAGELEVEL = Math.Max(0, gp.GAMELOCATION.CLOSEDEFENSEDAMAGELEVEL - 1);
                    gp.CLOSEDEFENSEDESTROYED = false;
                    gp.GAMELOCATION.CLOSEDEFENSEDESTROYED = false;
                    Start(false);
                    break;
                case "LOAD MINES (EXCHANGE 3 TORP)":
                    gp.MINEPTS = 1;
                    Start(false);
                    break;
                case "REMOVE MINES":
                    gp.MINEPTS = 0;
                    Start(false);
                    break;
                case "LOAD COMMANDOS (EXCHANGE 1 TORP)":
                    gp.COMMANDOPTS = 1;
                    Start(false);
                    break;
                case "REMOVE COMMANDOS":
                    gp.COMMANDOPTS = 0;
                    Start(false);
                    break;
                case "ALIGN COUNTRY TO ALLIES":
                case "ALIGN COUNTRY TO SOV":
                case "ALIGN COUNTRY TO NEUT":
                    string newSide = pData.Split(' ').Last();
                    FS.ALIGNCOUNTRY(GS, gp.COUNTRY, newSide);
                    Start(false);
                    break;
                default:
                    if(pData.StartsWith("AI ROLE:"))
                    {
                        Update("AI ROLE");
                        break;
                    }
                    if (pData.StartsWith("OBJECTIVE TYPE:"))
                    {
                        Update("OBJECTIVE TYPE");
                        break;
                    }
                    if (pData.StartsWith("DEPLOYMENT TYPE:"))
                    {
                        Update("DEPLOYMENT TYPE");
                        break;
                    }
                    if (pData.StartsWith("VP MULTIPLIER:"))
                    {
                        Update("VP MULTIPLIER");
                        break;
                    }
                    if (pData.StartsWith("ADD ANOTHER OF THIS CLASS")){
                        Update("ADD ANOTHER OF THIS CLASS");
                        break;
                    }
                    if(pData.StartsWith("ADD ANOTHER OF THIS TYPE")){
                        Update("ADD ANOTHER OF THIS TYPE");
                        break;
                    }
                    if(pData.StartsWith("RANDOM")){
                        Update("RANDOM");
                        break;
                    }
                    string keyTest = pData.Replace("?", "");
                    if (CURRENTLOGICLINKS.TryGetValue(keyTest, out GO linkorlogic))
                    {
                        switch (linkorlogic.TYPE)
                        {
                            case "AI.LOGICLINK":
                                FS.DISCARDLOGIC(linkorlogic);
                                break;
                            case "OBJECTIVELOGIC":
                            case "DEPLOYMENTLOGIC":
                            case "TRIGGERLOGIC":
                                FS.CREATEAILOGICLINK(linkorlogic, gp, gp.SIDE);
                                break;
                            default:
                                break;
                        }
                        Start(false);
                        break;
                    }
                    if(UNITCATEGORY != null){
                        if(COUNTRY == null){
                            string tmp = pData.Split(':').First().Trim();
                            FILTERBYCOUNTRY(tmp);
                            COUNTRY = tmp;
                        } else if(UNITTYPE == null){
                            string tmp = pData.Split(':').First().Trim();
                            if(FS.GENERICCOUNTRIES.Contains(COUNTRY)){
                                GO obj = FS.CREATECONVOY(gp, tmp, loc.ID);
                                GS.InteractionMap.Add(obj, new());
                                GS.SelectedMarker = obj;
                            } else {
                                FILTERBYUNITTYPE(tmp);
                                UNITTYPE = tmp;
                            }
                        } else if(TEMPLATE == null){
                            string lbl = pData.Split(':').First().Trim();
                            if(UNITCATEGORY == "AIR"){
                                GO obj = CANDIDATES.Where(n => n.TEMPLATE.LABEL == lbl).First();
                                GS.CHANGELOCATION(obj, loc.ID);
                                UNUSED.Remove(obj);
                                GS.InteractionMap.Add(obj, new());
                                GS.SelectedMarker = obj;
                            } else {
                                FILTERBYTEMPLATE(lbl);
                                TEMPLATE = lbl;
                            }
                        } else {
                            string lbl = pData;
                            GO obj = CANDIDATES.Where(n => n.LABEL == lbl).First();
                            GS.CHANGELOCATION(obj, loc.ID);
                            UNUSED.Remove(obj);
                            GS.InteractionMap.Add(obj, new());
                            GS.SelectedMarker = obj;
                            if (obj.TEMPLATE.AIRUNITS != null)
                            {
                                foreach (GO gm in FS.GROUPMEMBERS(obj))
                                {
                                    GS.CHANGELOCATION(gm, loc.ID);
                                    GS.InteractionMap.Add(gm, new());
                                }
                            }
                        }
                    }
                    Start(false);
                    break;
            }            
        }
        private void FILTERBYUNITCATEGORY(GO gp, string pData){
            List<string> countries = FS.TYPESIDELOCATION(GS, "PIECE", gp.SIDE, FS.PARENTGROUPLOCATION(gp).ID).Where(n => n.COUNTRY != null).Select(n => n.COUNTRY).ToList();
            countries.Add("USA");
            countries.Add("USSR");
            countries = countries.Distinct().ToList();
            CANDIDATES = UNUSED.Where(n => n.UNITCATEGORY == pData && n.SIDE == gp.SIDE && countries.Contains(n.COUNTRY)).ToList();
        }
        private void FILTERBYCOUNTRY(string pData){
            CANDIDATES = CANDIDATES.Where(n => n.COUNTRY == pData).ToList();
        }
        private void FILTERBYUNITTYPE(string pData){
            CANDIDATES = CANDIDATES.Where(n => n.UNITTYPE == pData).ToList();
        }
        private void FILTERBYTEMPLATE(string pData){
            CANDIDATES = CANDIDATES.Where(n => n.TEMPLATE.LABEL == pData).ToList();
        }
    }
    public class DeploymentLoop : GamePhaseLoopLogic
    {
        public DeploymentLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new Deployment("Deployment", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("DEPLOYMENT." + n)).Any();}
        public override void Init()
        {
            //throw new NotImplementedException();
        }
        public override void End()
        {
            if(ProcessCheck()){
                Set("ACTIVE.SIDE", FS.ENEMY(Get("ACTIVE.SIDE")));
            } else {
                Set("ACTIVE.SIDE1", Get("ACTIVE.SIDE"));
            }
        }
    }

    public class Deployment : GamePhaseInteractive
    {
        string side = null;
        List<GO> SQNALLOWED = new();
        List<GO> SNALLOWED = [];
        List<GO> SURFACEALLOWED = [];
        List<GO> SSALLOWED = [];
        List<GO> MINEALLOWED = [];
        bool SWITCHSIDEVIEW = false;
        public Deployment(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            ManualAdvance = true;
            NoShowLocationIndicators = true;
            UniversalDrop = true;
            InProgressSave = true;
        }
        public override void Execute(Boolean init){
            if(init){
                SWITCHSIDEVIEW = false;
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.CREATE_TF_PHASE = true;
                FS.DEPLOYMENT = true;
                SQNALLOWED = [..FS.TYPESIDE(GS, "LOCATION", side).Where(n => n.AIRFIELD || n.LOGAIR)];
                SNALLOWED = [.. GS.LOCATIONS().Where(n => n.TERRAIN == "SEA" || n.LOGSEA)];
                SURFACEALLOWED = [.. SNALLOWED.Where(n => !n.PACKICE)];
                SSALLOWED = [.. SURFACEALLOWED];
                MINEALLOWED = [..GS.TYPE("HEX").Where(n => FS.THEATERS.ContainsKey(n.ORGLEVEL1) &&
                n.TERRAIN == "SEA" && (n.COUNTRY != null || n.RESTRICTED || n.FJORD || n.SHALLOW))];
                FS.SETINSTRUCTIONS(GS, new(){"PLACE UNITS IN STARTING LOCATION", "CREATE TF/TGs"});
                GS.HELPTEXT = 
                "**SIDE MODE HAS BEGUN.  From now on you will only see ships you own or have detected!\n\n" + 
                "This is your final Opportunity to adjust Deployment before game starts\n\n" + 
                "To move units around, just drag the unit to where you would like the unit to start the scenario.  For Air units, this can only be AIRFIELD or off-map base.  For Sea units this can be any sea hex, port, or off map base\n\n" +
                "You can form TF/TGs by choosing options from the unit context menu (upper left side) - CREATE, JOIN, DISBAND, etc\n\n" +
                "DELAY? - You can set units with a delay so they don't show up at that position until a certain amount of turns.  This can simulate reinforcements or unit enroute to a theater.  Either increase the delay by 3 turns (representing a day) or remove the delay, making the unit appear at the start.  (Units with a delay are shown with a large Yellow square in the lower left of the marker)\n\n" +                
                "When done with your setup you can click SWITCH SIDE VIEW or if both sides are done hit the NEXT button.  STACKING restrictions will prevent the game from advancing. Units arriving at a future turn do not count against the stacking limit\n\n" +
                "*The only way the game advances beyond the deployment phase is both side consecutively hitting NEXT.  Each time a SWITCH is done it resets\n\n" +
                "*DOUBLE CLICK will allow for INSPECTING a hex, and units will be expanded out to show all including those on the bottom of the stack\n\n" +
                "*The popup that shows all units in hex is not movable, but the other ones are, just drag the popup.  Pick an area of the popup not covered by a unit marker"; 
                foreach(GO obj in FS.TYPESIDE(GS, "PIECE", side).Where(n => (n.TYPE == "SHIP" || n.TYPE == "SQN") && n.CARRIERID == null)){
                    GS.InteractionMap.Add(obj, new());
                }
                foreach (GO logic in GS.TYPE("DEPLOYMENTLOGIC").Where(n => n.SIDE == side || n.OBJECTIVE))
                {
                    GS.InteractionMap.Add(logic, new());
                }
                foreach (GO logic in GS.TYPE("OBJECTIVELOGIC").Where(n => n.SIDE == side || n.OBJECTIVE))
                {
                    GS.InteractionMap.Add(logic, new());
                }
                foreach (GO logic in GS.TYPE("TRIGGERLOGIC").Where(n => n.SIDE == side || n.OBJECTIVE))
                {
                    GS.InteractionMap.Add(logic, new());
                }
                foreach (GO obj in GS.TYPE("MINEMARKER").Where(n =>  n.GAMELOCATION != null && !n.GAMELOCATION.HIDDEN))
                {
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if (FS.UNITTYPES.Contains(obj.TYPE))
                {
                    if (FS.ISGROUP(obj))
                    {
                        GS.AddAction(obj, "DISBAND");
                    }
                    if (obj.UNITCATEGORY == "SURFACE" && obj.SIDE != "NEUT" && !FS.ISGROUP(obj))
                    {
                        if (FS.LOGICALPARENT(obj) == obj)
                        {
                            GS.AddAction(obj, "CREATE TF/TG");
                            foreach (GO parent in GS.InteractionMap.Keys.Where(n => FS.ISGROUP(n) && n.GAMELOCATION == obj.GAMELOCATION))
                            {
                                GS.AddAction(obj, "JOIN : " + FS.INFOLINE1(parent));
                            }
                        }
                        else
                        {
                            List<GO> groupMembers = FS.GROUPMEMBERS(FS.LOGICALPARENT(obj));
                            int count = groupMembers.Count;
                            if (obj.GROUPINDEX > 0)
                            {
                                GS.AddAction(obj, "MOVE UP IN GROUP");
                            }
                            if (obj.GROUPINDEX < count - 1)
                            {
                                GS.AddAction(obj, "MOVE DOWN IN GROUP");
                            }
                            GS.AddAction(obj, "LEAVE TF/TG");
                        }
                    }
                    if (FS.SURFACELADENTYPES.Contains(obj.UNITTYPE))
                    {
                        GS.AddAction(obj, obj.EMPTY ? "SET TO FULLY LOADED" : "SET TO EMPTY");
                    }
                    if (FS.LOGICALPARENT(obj) == obj)
                    {
                        GO loc = FS.PARENTGROUPLOCATION(obj);
                        if (obj.SIDE != "NEUT")
                        {
                            GS.AddAction(obj, "DELAY: INCREASE");
                            GS.AddAction(obj, "DELAY: INCREASE + 3");
                        }
                        if (obj.ENROUTEDELAY > 0) { GS.AddAction(obj, "DELAY: RESET"); }
                    }
                    if (obj.UNITCATEGORY == "SUB" && obj.SIDE == "SOV")
                    {
                        int remainingCapacity = obj.TEMPLATE.TORPPTS - (obj.MINEPTS * 3) - (obj.COMMANDOPTS);
                        if (obj.MINEPTS == 0 && remainingCapacity >= 3)
                        {
                            GS.AddAction(obj, "LOAD MINES (EXCHANGE 3 TORP)");
                        }
                        if (obj.MINEPTS == 1)
                        {
                            GS.AddAction(obj, "REMOVE MINES");
                        }
                    }
                    if (obj.UNITCATEGORY == "SUB")
                    {
                        int remainingCapacity = obj.TEMPLATE.TORPPTS - (obj.MINEPTS * 3) - (obj.COMMANDOPTS);
                        if (obj.COMMANDOPTS == 0 && remainingCapacity >= 1)
                        {
                            GS.AddAction(obj, "LOAD COMMANDOS (EXCHANGE 1 TORP)");
                        }
                        if (obj.COMMANDOPTS == 1)
                        {
                            GS.AddAction(obj, "REMOVE COMMANDOS");
                        }
                    }
                }
                GS.AddAction(obj, "SWITCH SIDE VIEW");
                GS.AddAction(obj, "END PHASE");
            }
            if(GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        private List<GO> DROPTARGETS(GO obj){
            return obj.TYPE switch
            {
                "SHIP" => obj.UNITCATEGORY == "SURFACE" || obj.UNITTYPE == "SS" ? SURFACEALLOWED : SNALLOWED,
                "SQN" => SQNALLOWED,
                "OBJECTIVELOGIC" => GS.TYPE("HEX"),
                "DEPLOYMENTLOGIC" => GS.TYPE("HEX"),
                "TRIGGERLOGIC" => GS.TYPE("HEX"),
                "MINEMARKER" => MINEALLOWED,
                _ => []
            };          
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "CREATE TF/TG":
                    GO createdTG = FS.CREATEGROUP(GS, gp, gp.GAMELOCATIONID);
                    GS.InteractionMap.Add(createdTG, new());
                    GS.SelectedMarker = createdTG;
                    Start(false);
                    break;
                case "MOVE UP IN GROUP":
                    FS.MOVEUPINGROUP(GS, gp, FS.LOGICALPARENT(gp));
                    Start(false);
                    break;
                case "MOVE DOWN IN GROUP":
                    FS.MOVEDOWNINGROUP(GS, gp, FS.LOGICALPARENT(gp));
                    Start(false);
                    break;
                case "LEAVE TF/TG":
                    FS.REMOVEFROMGROUP(gp, gp.GROUP);
                    Start(false);
                    break;
                case "DISBAND":
                    GO firstMember = GS.TYPE(gp.TYPE, "GROUPID", gp.ID).FirstOrDefault();
                    FS.GROUPMEMBERS(gp).ForEach(n => FS.REMOVEFROMGROUP(n, gp));
                    FS.DISCARDTAGGED(gp);
                    if(firstMember != null){GS.SelectedMarker = firstMember;}
                    Start(false);
                    break;
                case "SET TO FULLY LOADED":
                case "SET TO EMPTY":
                    gp.EMPTY = !gp.EMPTY;
                    Start(false);
                    break;
                case "DELAY: INCREASE":
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.ENROUTEDELAY++);
                    FS.UPDATEGROUP(gp);
                    Start(false);
                    break;
                case "DELAY: INCREASE + 3":
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.ENROUTEDELAY += 3);
                    FS.UPDATEGROUP(gp);
                    Start(false);
                    break;
                case "DELAY: RESET":
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.ENROUTEDELAY = 0);
                    FS.UPDATEGROUP(gp);
                    Start(false);
                    break;
                case "SWITCH SIDE VIEW":
                    SWITCHSIDEVIEW = true;
                    Update("NEXT");
                    break;
                case "NEXT":
                    bool validSetup = true;
                    GO errorGO = null;
                    foreach(GO unit in GS.InteractionMap.Keys){                                                
                        if(unit.TYPE == "SQN"){
                            if(unit.CARRIERID != null){
                                GO parent = unit.CARRIER;
                                if(!parent.TEMPLATE.AIRUNITS.Contains(unit.TEMPLATE.LABEL)){
                                    MainWindow.Alert("SQN type is not allowed on this ship.");
                                    errorGO = parent.GROUPID == null ? parent : parent.GROUP;
                                    validSetup = false;
                                    break;
                                }
                            } else if(!unit.GAMELOCATION.AIRFIELD && !unit.GAMELOCATION.LOGISTICALBASE){
                                MainWindow.Alert("SQN must be at an AIRFIELD or LOGISTICALBASE");
                                errorGO = unit;
                                validSetup = false;
                                break;
                            }
                        } else if(unit.TYPE == "SHIP"){
                            GO unitLoc = unit.GROUPID == null ? unit.GAMELOCATION : unit.GROUP.GAMELOCATION;
                            if(unitLoc.SHOALS && !new List<string>{"PC, CO"}.Contains(unit.UNITTYPE)){
                                MainWindow.Alert("Illegal unit type in SHOALS");
                                errorGO = unit.GROUPID == null ? unit : unit.GROUP;
                                validSetup = false;
                                break;
                            } else if(unitLoc.TERRAIN != "SEA" && !unitLoc.LOGSEA){
                                MainWindow.Alert("Illegal placement of ship in non-sea location");
                                errorGO = unit.GROUPID == null ? unit : unit.GROUP;
                                validSetup = false;
                                break;
                            }
                        }
                    }
                    if(validSetup){
                        foreach(GO parent in GS.InteractionMap.Keys.Where(n => n.TYPE == "SQN" && n.CARRIERID != null).Select(n => n.CARRIER).Distinct()){
                            if(!FS.CANSTACKONCARRIER(GS, parent, GS.TYPE("SQN", "CARRIERID", parent.ID))){
                                MainWindow.Alert("Stacking Violation on Parent Ship");
                                errorGO = parent.GROUPID == null ? parent : parent.GROUP;
                                validSetup = false;
                                break;
                            }
                        }
                    }
                    if(validSetup){
                        foreach(GO location in GS.InteractionMap.Keys.Where(n => n.GAMELOCATIONID != "TEMP").Select(n => n.GAMELOCATION).Distinct()){
                            List<GO> unitsAtLocation = [];
                            foreach (string s in FS.SIDE_NAMES)
                            {
                                foreach (string typ in FS.UNITTYPES)
                                {
                                    unitsAtLocation.AddRange(FS.TYPESIDELOCATION(GS, typ, s, location.ID).Where(n => FS.LOGICALPARENT(n) == n && n.ENROUTEDELAY == 0));
                                }
                            }
                            if(!FS.CANSTACKSURFACE(unitsAtLocation.Where(n => n.UNITCATEGORY == "SURFACE").ToList())){
                                MainWindow.Alert("Stacking Violation:  Surface Ships");
                                errorGO = unitsAtLocation.First();
                                validSetup = false;
                                break;
                            }
                            if(!FS.CANSTACKAIR(unitsAtLocation.Where(n => n.UNITCATEGORY == "AIR").ToList())){
                                MainWindow.Alert("Stacking Violation:  Air");
                                errorGO = unitsAtLocation.Where(GS.InteractionMap.ContainsKey).FirstOrDefault();
                                validSetup = false;
                                break;
                            }
                            /*if(unitsAtLocation.Select(n => n.SIDE).Distinct().Count() > 1){
                                MainWindow.Alert("Stacking Violation:  Sides");
                                errorGO = unitsAtLocation.First();
                                validSetup = false;
                                break;
                            }*/
                        }
                    }
                    //enforce rules
                    if(validSetup){
                        FS.CREATE_TF_PHASE = false;
                        foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.GRPTYPE == "TFTGGRP")){
                            FS.UPDATEGROUP(obj);
                        }
                        if (SWITCHSIDEVIEW){
                            FS.SIDE_NAMES.ForEach(n => SetBoolean("DEPLOYMENT." + n, false));
                            GS.advanced = true;
                            Set("ACTIVE.SIDE", FS.ENEMY(side));
                            Set("ACTIVE.SIDE1", Get("ACTIVE.SIDE"));
                            GS.ResetBetweenUpdates();
                            GS.ResetBetweenPhases();
                            Start(true);
                        } else {
                            SetBoolean("DEPLOYMENT." + side, true);
                            //any deployment links to units that are not enroute can be removed
                            List<GO> unneededLinks = [.. FS.TYPESIDE(GS, "AI.LOGICLINK", FS.SIDE_MODE).Where(n => n.LOGIC.TYPE == "DEPLOYMENTLOGIC" && n.UNIT.ENROUTEDELAY == 0)];
                            unneededLinks.ForEach(FS.DISCARDLOGIC);
                            FS.DEPLOYMENT = false;
                            GS.Done(this);
                        }
                    } else {
                        GS.SelectedMarker = errorGO;
                        SWITCHSIDEVIEW = false;
                        Start(false);
                    }
                    break;
                case "LOAD MINES (EXCHANGE 3 TORP)":
                    gp.MINEPTS = 1;
                    gp.TORPPTS -= 3;
                    Start(false);
                    break;
                case "REMOVE MINES":
                    gp.MINEPTS = 0;
                    gp.TORPPTS += 3;
                    Start(false);
                    break;
                case "LOAD COMMANDOS (EXCHANGE 1 TORP)":
                    gp.COMMANDOPTS = 1;
                    gp.TORPPTS -= 1;
                    Start(false);
                    break;
                case "REMOVE COMMANDOS":
                    gp.COMMANDOPTS = 0;
                    gp.TORPPTS += 1;
                    Start(false);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GO newloc = GS.LOCATION(gp.TEMPLOCATIONID);
                        if(DROPTARGETS(gp).Contains(newloc)){
                            GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                            /*if(oldloc.TYPE != "TRAYLOCATION" && newloc.TYPE == "TRAYLOCATION"){
                                GO newsheet = newloc.PARENTSHEET;
                                GO newgroup = newsheet.SHEETPARENTPIECE;
                                FS.ADDTOGROUP(gp, newgroup);
                            } else if(oldloc.TYPE == "TRAYLOCATION" && newloc.TYPE != "TRAYLOCATION"){
                                gp.PARENTSHEETID = null;
                                GO oldsheet = oldloc.PARENTSHEET;
                                GO oldgroup = oldsheet.SHEETPARENTPIECE;
                                FS.REMOVEFROMGROUP(gp, oldgroup);
                            } else if(oldloc.TYPE == "TRAYLOCATION" && newloc.TYPE == "TRAYLOCATION" && newloc.PARENTSHEET == FS.GRPSHEET){
                                GO newsheet = newloc.PARENTSHEET;
                                List<GO> grouptraylocations = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", newsheet.ID);
                                int oldindex = grouptraylocations.IndexOf(oldloc);
                                int newindex = grouptraylocations.IndexOf(newloc);
                                for(int i = 0; i < Math.Abs(oldindex - newindex); i++){
                                    if(oldindex < newindex){
                                        FS.MOVEDOWNINGROUP(GS, gp, gp.GROUP);
                                    } else {
                                        FS.MOVEUPINGROUP(GS, gp, gp.GROUP);
                                    }
                                }
                            }*/
                            if(FS.PARENTGROUPLOCATION(gp) != gp.GAMELOCATION)
                            {
                                FS.REMOVEFROMGROUP(gp, FS.LOGICALPARENT(gp));
                            }
                        } else {
                            GS.CHANGELOCATION(gp, oldloc);
                        }
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    if(pData.StartsWith("JOIN : "))
                    {
                        string label = pData.Replace("JOIN : ", "");
                        GO parent = GS.InteractionMap.Keys.Where(n => n.GAMELOCATION == gp.GAMELOCATION && label == FS.INFOLINE1(n)).First();
                        FS.ADDTOGROUP(gp, parent);
                        GS.SelectedMarker = parent;
                    }
                    Start(false);
                    break;
            }            
        }
    }
    public class AIReview : GamePhaseInteractive
    {
        List<GO> LOGICALLOWED = new();
        public AIReview(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario)
        {
            DragDrop = true;
            ManualAdvance = true;
            NoShowLocationIndicators = true;
            RequiresMapUpdate = false;
        }
        public override void Execute(Boolean init)
        {
            int round = GetInt("ACTION.ROUNDS");
            int cycle = GetInt("ACTION.CYCLES");
            if (init)
            {
                if (GS.AI_Sides.Count < 2)
                {
                    Update("NEXT");
                    return;
                }
                BANNER = ID + " - Round " + (round + 1) + " - Cycle " + (cycle + 1);
                FS.AI_REVIEW = true;
                FS.SIDE_MODE = "ALLIESSOVNEUT";
                string OLDSITUATION = Get("AI.SITUATION") ?? "";
                LOGICALLOWED = [.. GS.TYPE("HEX")];
                FS.SETINSTRUCTIONS(GS, new() { "REVIEW AI FORCES" });
                GS.HELPTEXT =
                "*This Phase only appears if both sides are set to AI\n\n" +
                "It is an opportunity to review the AI forces and positions to understand how the AI logic is flowing\n\n" +
                "Each time you end this phase, the game will start processing the AI logic and will pause when a new combat or detection happens.  If you want to pause the action to see whats " +
                "going on, hit the green NEXT PHASE button in the top menu, the game will pause at the next Review Phase.";

                List<string> SITUATION = [];
                List<GO> UNITS = [];
                int situationParameters = -1;
                List<GO> units = [];
                foreach(string typ in FS.UNITTYPES)
                {
                    units.AddRange(FS.TYPELOCATION(GS, typ, "ALLDESTROYED"));
                    foreach (string s in FS.SIDE_NAMES)
                    {
                        units.AddRange(FS.TYPESIDE(GS, typ, s));
                    }
                }
                foreach (GO unit in units.OrderBy(n => n.ID))
                {
                    if (FS.LOGICALPARENT(unit) == unit && !unit.DESTROYED)
                    {
                        GS.InteractionMap.Add(unit, []);
                    }
                    if (!FS.ISGROUP(unit))
                    {
                        SITUATION.Add("ACTIVATED:" + (unit.ACTIVATED ? "Y" : "N"));
                        SITUATION.Add("DETECTED:" + (unit.LOCALDETECTED || unit.STRATDETECTED || unit.ADMINDETECTED ? "Y" : "N"));
                        SITUATION.Add("DESTROYED:" + (unit.DESTROYED ? "Y" : "N"));
                        SITUATION.Add("DAMAGED:" + (unit.DAMAGED ? "Y" : "N"));
                        SITUATION.Add("LOADING:" + (unit.LOADING ? "Y" : "N"));
                        SITUATION.Add("REPLENISHING:" + (unit.REPLENISHING ? "Y" : "N"));
                        SITUATION.Add("DONE:" + (unit.DONE ? "Y" : "N"));
                        UNITS.Add(unit);
                        if (situationParameters == -1)
                        {
                            situationParameters = SITUATION.Count;
                        }
                    }
                }
                string NEWSITUATION = string.Join('|', SITUATION);
                Set("AI.SITUATION", NEWSITUATION);
                bool turnStart = round == 0 && cycle == 0;
                GO interruptCombat = GS.TYPE("LOGIC").Where(n => FS.COMBATMISSIONTYPES.Contains(n.TYPE)).FirstOrDefault();
                bool combats = interruptCombat != null;
                bool forced = turnStart || Window().INIT || Window().InterruptAIProcessing;// || cycle == 0;
                GO interruptedGO = null;
                HashSet<string> reasonForInterruption = [];
                if (combats)
                {
                    reasonForInterruption.Add("NEW COMBAT");
                    interruptedGO =
                        GS.InteractionMap.Keys.Where(n => FS.UNITTYPES.Contains(n.TYPE) && n.GAMELOCATION == interruptCombat.DEFENDERLOCATION && FS.LOGICALPARENT(n) == n).FirstOrDefault() ??
                        GS.InteractionMap.Keys.Where(n => FS.UNITTYPES.Contains(n.TYPE) && n.GAMELOCATION == interruptCombat.ATTACKER.GAMELOCATION && FS.LOGICALPARENT(n) == n).FirstOrDefault();
                }
                List<string> oldSituation = [.. OLDSITUATION.Split('|')];
                List<string> newSituation = [.. NEWSITUATION.Split('|')];
                int count = Math.Max(oldSituation.Count, newSituation.Count);
                for (int i = 0; i < count; i++)
                {
                    int unitIndex = i / situationParameters;
                    GO unit = unitIndex < UNITS.Count ? UNITS[unitIndex] : null;
                    string o = oldSituation.Count > i ? oldSituation[i] : "";
                    string n = newSituation.Count > i ? newSituation[i] : "";
                    if (o != n)
                    {
                        string key = o.Contains(':') ? o.Split(':').First() : n.Contains(':') ? n.Split(':').First() : "";
                        switch (key)
                        {
                            case "DESTROYED":
                                if (n == "DESTROYED:Y")
                                {
                                    reasonForInterruption.Add("UNIT REMOVED FROM PLAY");
                                }
                                break;
                            case "DETECTED":
                                if (n == "DETECTED:Y")
                                {
                                    reasonForInterruption.Add("NEW DETECTION");
                                    if (unit != null && interruptedGO == null)
                                    {
                                        interruptedGO = FS.LOGICALPARENT(unit);
                                    }
                                }
                                break;
                            case "DAMAGED":
                                if (n == "DAMAGED:Y")
                                {
                                    reasonForInterruption.Add("UNIT DAMAGED");
                                    if (unit != null && interruptedGO == null)
                                    {
                                        interruptedGO = FS.LOGICALPARENT(unit);
                                    }
                                }
                                break;
                            case "LOADING":
                            case "REPLENISHING":
                                reasonForInterruption.Add("OTHER STATUS CHANGE");
                                if (unit != null && interruptedGO == null)
                                {
                                    interruptedGO = FS.LOGICALPARENT(unit);
                                }
                                break;
                            case "ACTIVATED":
                                /*if (n == "ACTIVATED:Y")
                                {
                                    reasonForInterruption.Add("NEW ACTIVATION");
                                    if (unit != null && interruptedGO == null)
                                    {
                                        interruptedGO = FS.LOGICALPARENT(unit);
                                    }
                                }*/
                                break;
                            case "DONE":
                                /*if (n == "DONE:Y")
                                {
                                    reasonForInterruption.Add("MISSION COMPLETED");
                                    if (unit != null && interruptedGO == null)
                                    {
                                        interruptedGO = FS.LOGICALPARENT(unit);
                                    }
                                }*/
                                break;
                            default:
                                break;
                        }
                    }
                }
                bool reasons = reasonForInterruption.Count > 0;
                if (reasonForInterruption.Count > 0)
                {
                    BANNER = BANNER + " - " + string.Join('|', reasonForInterruption);
                }
                if (!(combats || reasons || forced))
                {
                    GS.SHOWINSTRUCTIONS();
                    GS.Done(this);
                    return;
                }
                Window().InterruptAIProcessing = false;
                foreach (GO logic in GS.TYPE("OBJECTIVELOGIC"))
                {
                    GS.InteractionMap.Add(logic, LOGICALLOWED);
                }
                GS.SelectedMarker = interruptedGO;
            }
            else
            {
                BANNER = ID + " - Round " + (round + 1) + " - Cycle " + (cycle + 1);
            }
            if (GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker))
            {
                if (GS.InteractionMap.Any())
                {
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if (GS.SelectedMarker != null)
            {
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "END PHASE");
            }
            if (!GS.InteractionMap.Keys.Any())
            {
                Update("NEXT");
                return;
            }
            if (init) { FS.SETVIEW(GS); }
        }
        public override void Update(string pData)
        {
            GO gp = GS.SelectedMarker;
            switch (pData)
            {
                case "NEXT":
                    FS.AI_REVIEW = false;
                    GS.Done(this);
                    break;
                case null:
                    GO loc = FS.PARENTGROUPLOCATION(gp);
                    if (gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != loc.ID)
                    {
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                    }
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
}