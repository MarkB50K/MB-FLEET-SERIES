using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using System.Runtime.InteropServices;
using System.Windows.Media.Animation;
using System.Diagnostics;
using System.Reflection.Metadata.Ecma335;
using System.Security.Policy;

namespace CWApp.FS
{
    public class TerminalCycle : GamePhaseGroupLogic
    {
        public TerminalCycle(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new Fuel("Fuel", this, GS));
            AddGamePhase(new Repair("Repair", this, GS));
            AddGamePhase(new StrategicAirTermination("Strategic Air RTB", this, GS));
            AddGamePhase(new RemoveStrategicDetection("Remove Strategic Detection", this, GS));
        }
        public override Boolean ProcessCheck(){return Get("TURN.TYPE") == "NIGHT";}
        public override void Init()
        {
            //throw new NotImplementedException();
            Set("ACTIVE.SIDE1", Get("ACTIVE.SIDE"));
        }
        public override void End()
        {
            //throw new NotImplementedException();
            foreach(string s in FS.SIDE_NAMES)
            {
                if (GS.AI_Sides.Contains(s))
                {
                    FS.AI_COMPLETELINKS(GS, s);
                }
            }
        }
    }
    public class Fuel : GamePhaseAutomated
    {
        public Fuel(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}
            
        public override void Execute(Boolean init){
            foreach(GO obj in GS.TYPE("SHIP").Where(n => n.USEDFUEL)){
                if(obj.TEMPLATE.FUELPTS > 0){obj.FUELPTS = Math.Max(0, obj.FUELPTS - 1);}
                obj.USEDFUEL = false;
            }
            //every even numbered night turn (every 2 days), every PC not docked in their own country is destroyed
            if(GetInt("TURN") % 2 == 0){
                foreach(string s in FS.SIDE_NAMES.Where(n => !GS.AI_Sides.Contains(n))){
                    foreach(GO obj in FS.TYPESIDE(GS, "SHIP", s).Where(n => n.UNITTYPE == "PC" && (!n.DOCKED || FS.PARENTGROUPLOCATION(n).COUNTRY != n.COUNTRY))){
                        MainWindow.Alert(obj.UNITTYPE + " " + obj.LABEL + " is not docked in its home country, and is destroyed!");
                        GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * (obj.DAMAGED ? 0.5 : 1)); 
                        FS.DESTROY(obj);
                    }
                }
            }
            GS.Done(this);           
        }
    }
    public class Repair : GamePhaseAutomated
    {
        public Repair(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}
            
        public override void Execute(Boolean init){
            List<GO> facilityLocations = [];
            foreach (string t in FS.BASETYPES)
            {
                facilityLocations.AddRange(GS.TYPE(t).Select(n => n.GAMELOCATION));
            }
            foreach (GO loc in facilityLocations.Distinct())
            {
                FS.REPAIR(loc);
            }
            GS.Done(this);           
        }
    }
    public class StrategicAirTermination : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, List<GO>> ELIGIBLEAIRBASESCOMBAT = new();
        List<GO> ELIGIBLEAIRBASES = new();
        public StrategicAirTermination(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"RETURN AIR UNITS TO BASE"});
                GS.HELPTEXT = 
                "Return air units on Strategic Missions to Home\n\n" +
                "- Carrier units will auto-return to their carrier.  If the carrier is destroyed, they are eliminated\n" +
                "- For air units from airbases, unit will position itself at its home airbase.  You can choose any airbase with room in the same zone, but will suffer a " + GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER") + " turn delay (configurable) if you don't choose its homebase\n\n" +
                "When done with your choices you can click the NEXT button\n\n" +
                "NOTE: When selecting a unit, available locations on the strategic display(s) will have an indicator.";
                List<string> ZONES = new();
                string report = "";       
                List<GO> sqnsNeedingToLand = new();         
                foreach(GO obj in FS.TYPESIDE(GS, "SQN", side).Where(n => n.AIRMISSION != null)){
                    if(obj.HOMEBASE.TYPE == "SHIP"){
                        FS.RETURNTOHOMEBASE(obj);
                        obj.AIRMISSION = null;
                        if(obj.DESTROYED){
                            report += obj.UNITTYPE + " " + obj.LABEL + " destroyed due to destroyed carrier\n";
                        }
                        continue;
                    }
                    GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", obj.GAMELOCATION.ZONE).Single();
                    GS.CHANGELOCATION(obj, RTBLocation);  
                    sqnsNeedingToLand.Add(obj); 
                    ZONES.Add(obj.HOMEBASE.ZONE);                 
                }
                ELIGIBLEAIRBASES.Clear();
                ELIGIBLEAIRBASESCOMBAT.Clear();
                foreach(GO obj in FS.TYPESIDE(GS, "FACILITY", side).Where(n => !n.AIRFIELDDESTROYED && ZONES.Contains(n.GAMELOCATION.ZONE))){
                    List<GO> sqns = [..FS.TYPESIDELOCATION(GS, "SQN", obj.SIDE, obj.GAMELOCATIONID).Where(n => FS.LOGICALPARENT(n) == n)];
                    ELIGIBLEAIRBASES.Add(obj);
                    ELIGIBLEAIRBASESCOMBAT.Add(obj, sqns.Where(n => FS.AIRCOMBATTYPES.Contains(n.UNITTYPE)).ToList());
                }
                foreach(GO obj in sqnsNeedingToLand){
                    if(FS.AIRCOMBATTYPES.Contains(obj.UNITTYPE)){
                        List<GO> airbases = ELIGIBLEAIRBASESCOMBAT.Keys.Where(n => n.GAMELOCATION.ZONE == obj.HOMEBASE.ZONE && ELIGIBLEAIRBASESCOMBAT[n].Count < 4).ToList();
                        airbases.RemoveAll(n => !FS.STRATEGICCOUNTRIES[n.GAMELOCATION.ORGLEVEL1].Contains(obj.COUNTRY) && n.GAMELOCATION.COUNTRY != obj.COUNTRY);
                        if(airbases.Count == 0){
                            report += obj.UNITTYPE + " " + obj.LABEL + " destroyed due to no available airbase in " + obj.HOMEBASE.ZONE + "\n";
                            GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * (obj.DAMAGED ? 0.5 : 1)); 
                            FS.DESTROY(obj);
                        } else if(airbases.Count == 1){
                            LAND(obj, airbases.First().GAMELOCATION);
                        } else {
                            GS.InteractionMap.Add(obj, new());
                        }
                    } else {
                        List<GO> airbases = ELIGIBLEAIRBASES.Where(n => n.GAMELOCATION.ZONE == obj.HOMEBASE.ZONE).ToList();
                        airbases.RemoveAll(n => !FS.STRATEGICCOUNTRIES[n.GAMELOCATION.ORGLEVEL1].Contains(obj.COUNTRY) && n.GAMELOCATION.COUNTRY != obj.COUNTRY);
                        if(airbases.Count == 0){
                            report += obj.UNITTYPE + " " + obj.LABEL + " destroyed due to no available airbase in " + obj.HOMEBASE.ZONE + "\n";
                            GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * (obj.DAMAGED ? 0.5 : 1)); 
                            FS.DESTROY(obj);
                        } else if(airbases.Count == 1){
                            LAND(obj, airbases.First().GAMELOCATION);
                        } else {
                            GS.InteractionMap.Add(obj, new());
                        }
                    }
                }
                if(report != ""){
                    MainWindow.Alert(report);
                }
            }

            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                List<GO> targets = GS.InteractionMap[obj];
                targets.Clear();
                if(FS.AIRCOMBATTYPES.Contains(obj.UNITTYPE)){
                    List<GO> airbases = ELIGIBLEAIRBASESCOMBAT.Keys.Where(n => n.SIDE == obj.SIDE && n.GAMELOCATION.ZONE == obj.HOMEBASE.ZONE && ELIGIBLEAIRBASESCOMBAT[n].Count < 4).ToList();
                    airbases.RemoveAll(n => !FS.STRATEGICCOUNTRIES[n.GAMELOCATION.ORGLEVEL1].Contains(obj.COUNTRY) && n.GAMELOCATION.COUNTRY != obj.COUNTRY);
                    targets.AddRange(airbases.Select(n => n.GAMELOCATION));
                    foreach(GO target in airbases){
                        GS.AddAction(obj, target.LABEL);
                    }                    
                } else {
                    List<GO> airbases = ELIGIBLEAIRBASES.Where(n => n.SIDE == obj.SIDE && n.GAMELOCATION.ZONE == obj.HOMEBASE.ZONE).ToList();
                    airbases.RemoveAll(n => !FS.STRATEGICCOUNTRIES[n.GAMELOCATION.ORGLEVEL1].Contains(obj.COUNTRY) && n.GAMELOCATION.COUNTRY != obj.COUNTRY);
                    targets.AddRange(airbases.Select(n => n.GAMELOCATION));
                    foreach(GO target in airbases){
                        GS.AddAction(obj, target.LABEL);
                    }                    
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        LAND(gp, gp.GAMELOCATION);
                        CHECKELIGIBILITY();
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    GO facility = ELIGIBLEAIRBASES.Where(n => n.GAMELOCATION.ZONE == gp.HOMEBASE.ZONE && n.LABEL == pData).Single();
                    LAND(gp, facility.GAMELOCATION);
                    CHECKELIGIBILITY();
                    Start(false);
                    break;
            }
        }
        
        private void LAND(GO obj, GO loc){
            GO airbaseHex = loc;
            GO airbase = airbaseHex.GAMEPIECE;
            if(airbaseHex != obj.HOMEBASE){
                //transfer, so add delay
                obj.ENROUTEDELAY = GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER");
            }
            GS.CHANGELOCATION(obj, airbaseHex);
            obj.HOMEBASEID = null;
            obj.AIRMISSION = null;
            if(FS.AIRCOMBATTYPES.Contains(obj.UNITTYPE)){
                ELIGIBLEAIRBASESCOMBAT[airbase].Add(obj);
            }
            GS.REMOVEINTERACTIVE(obj);                        
        }
        private void CHECKELIGIBILITY(){
            string report = "";
            bool unitLanded = false;
            foreach(GO obj in GS.InteractionMap.Keys.ToList()){
                if(FS.AIRCOMBATTYPES.Contains(obj.UNITTYPE)){
                    List<GO> airbases = ELIGIBLEAIRBASESCOMBAT.Keys.Where(n => n.SIDE == obj.SIDE && n.GAMELOCATION.ZONE == obj.HOMEBASE.ZONE && ELIGIBLEAIRBASESCOMBAT[n].Count < 4).ToList();
                    airbases.RemoveAll(n => !FS.STRATEGICCOUNTRIES[n.GAMELOCATION.ORGLEVEL1].Contains(obj.COUNTRY) && n.GAMELOCATION.COUNTRY != obj.COUNTRY);
                    if(airbases.Count == 0){
                        report += obj.UNITTYPE + " " + obj.LABEL + " destroyed due to no available airbase in " + obj.HOMEBASE.ZONE + "\n";
                        GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * (obj.DAMAGED ? 0.5 : 1)); 
                        FS.DESTROY(obj);
                    } else if(airbases.Count == 1){
                        LAND(obj, airbases.First().GAMELOCATION);
                        unitLanded = true;
                    }
                } else {
                    List<GO> airbases = ELIGIBLEAIRBASES.Where(n => n.SIDE == obj.SIDE && n.GAMELOCATION.ZONE == obj.HOMEBASE.ZONE).ToList();
                    airbases.RemoveAll(n => !FS.STRATEGICCOUNTRIES[n.GAMELOCATION.ORGLEVEL1].Contains(obj.COUNTRY) && n.GAMELOCATION.COUNTRY != obj.COUNTRY);
                    if(airbases.Count == 0){
                        report += obj.UNITTYPE + " " + obj.LABEL + " destroyed due to no available airbase in " + obj.HOMEBASE.ZONE + "\n";
                        GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * (obj.DAMAGED ? 0.5 : 1)); 
                        FS.DESTROY(obj);
                    } else if(airbases.Count == 1){
                        LAND(obj, airbases.First().GAMELOCATION);
                        unitLanded = true;
                    }
                }
            }
            if(report != ""){
                MainWindow.Alert(report);
            }
            if(unitLanded){
                CHECKELIGIBILITY();
            }
        }
    }
    public class RemoveStrategicDetection : GamePhaseAutomated
    {
        public RemoveStrategicDetection(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            List<GO> UNDESTROYEDBASES = [];
            List<GO> UNDESTROYEDCDS = [];
            foreach (string s in FS.SIDE_NAMES)
            {
                UNDESTROYEDBASES.AddRange(FS.TYPESIDE(GS, "FACILITY", s).Where(n => ((n.PORT && !n.PORTDESTROYED) || (n.AIRFIELD && !n.AIRFIELDDESTROYED))));
                UNDESTROYEDCDS.AddRange(FS.TYPESIDE(GS, "CLOSEDEFENSE", s).Where(n => !n.CLOSEDEFENSEDESTROYED));
            }
            Dictionary<GO, List<List<GO>>> DetectionRadius = FS.DETECTIONRADIUSTABLE(GS);
            foreach (string s in FS.SIDE_NAMES)
            {
                List<GO> BASES = [.. UNDESTROYEDBASES.Where(n => n.SIDE == FS.ENEMY(s)).Select(n => n.GAMELOCATION)];
                List<GO> CDS = [.. UNDESTROYEDCDS.Where(n => n.SIDE == FS.ENEMY(s)).Select(n => n.GAMELOCATION)];
                List<GO> DETECTORS = [.. DetectionRadius.Keys.Where(n => n.SIDE == FS.ENEMY(s))];
                Dictionary<GO, List<GO>> LOCATIONTABLE = [];
                foreach (GO obj in FS.TYPESIDE(GS, "SHIP", s))
                {
                    GO loc = FS.PARENTGROUPLOCATION(obj);
                    if (loc.TYPE != "HEX")
                    {
                        obj.STRATDETECTED = false;
                        obj.LOCALDETECTED = false;
                        continue;
                    }
                    if (!obj.STRATDETECTED) { continue; }
                    if (obj.UNITCATEGORY == "SUB")
                    {
                        FS.STRATDETECT([obj], false);
                        List<GO> detectors = DETECTORS.Where(n => DetectionRadius[n][2].Contains(loc)).ToList();
                        FS.LOCALDETECT([obj], detectors.Sum(n => n.TEMPLATE?.ASW ?? 0) >= 6);
                    }
                    else
                    {
                        if (!LOCATIONTABLE.TryGetValue(loc, out List<GO> value))
                        {
                            value = [];
                            LOCATIONTABLE.Add(loc, value);
                        }

                        value.Add(obj);
                    }
                }
                //surface done as groups by location
                foreach (GO loc in LOCATIONTABLE.Keys)
                {
                    bool adjacentToBase = FS.FINDAIRRADIUS(loc, 1).Intersect(BASES).Any() || CDS.Contains(loc);
                    bool inDetectionZone = DETECTORS.Where(n => DetectionRadius[n][1].Contains(loc)).Any();
                    FS.STRATDETECT(LOCATIONTABLE[loc], adjacentToBase);
                    FS.LOCALDETECT(LOCATIONTABLE[loc], adjacentToBase || inDetectionZone);
                }
            }
            GS.Done(this);
        }
    }
}