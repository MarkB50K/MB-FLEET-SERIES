using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;
using System.Windows.Documents;
using System.Diagnostics.Eventing.Reader;
using System.Runtime;
namespace CWApp.FS
{
    public class ActionAirINTRole : GamePhaseInteractive
    {
        string side = null;
        public ActionAirINTRole(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario)
        {
            RequiresMapUpdate = false;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"SELECT ROLE"});

                GS.HELPTEXT = 
                "INT unit Role Designation.\n" + 
                "- Fighter.  Bombing and SSM values go to 0\n" +
                "- Bomber.  Anti-Air value goes to 1\n" + 
                "- Fighter/Bomber.  All values are halved";
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATING").Where(n => n.UNITTYPE == "INT" && n.ROLE == null)){
                    if(obj.TEMPLATE.SPECIAL == 0 && obj.TEMPLATE.SSM == 0){
                        obj.ROLE = "FIGHTER";
                        continue;
                    }
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.AIRMISSION == null){GS.AddAction(obj, "FIGHTER");}
                GS.AddAction(obj, "BOMBER");
                GS.AddAction(obj, "FIGHTER-BOMBER");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "FIGHTER":
                    gp.ROLE = pData;
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "BOMBER":
                case "FIGHTER-BOMBER":
                    gp.ROLE = pData;
                    switch(gp.AIRMISSION){
                        case "SSM":
                            gp.SSM = FS.GETAIRSSM(gp);
                            break;
                        case "BOMBING":
                            gp.SPECIAL = FS.GETAIRBOMB(gp);
                            break;
                        default:
                            break;
                    }
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "NEXT":
                    GS.Done(this);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirAmmoSelection : GamePhaseInteractive
    {
        string side = null;
        public ActionAirAmmoSelection(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            RequiresMapUpdate = false;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"SELECT AMMO"});

                GS.HELPTEXT = 
                "Ammo Selection\n\nThe physical game allows Air units to have all ammo on hand until the point at which you declare a combat.  In this game, especially since Carrier Ammo supplies are tracked, when launching you will select the Ammo type carried by the air unit";
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATING").Where(n => n.UNITCATEGORY == "AIR" && n.AIRMISSION == null && (FS.GETAIRSSM(n) > 0 || FS.GETAIRBOMB(n) > 0 || n.CMPTS > 0 || n.TEMPLATE.ASW > 0))){
                    //if this is a reload skip
                    if(obj.CM > 0 || obj.SPECIAL > 0 || obj.SSM > 0 || obj.TORPPTS > 0){continue;}
                    bool canBMB = FS.GETAIRBOMB(obj) > 0 && (obj.HOMEBASE.AIRFIELD || obj.HOMEBASE.BOMBPTS >= 1);
                    bool canCM = obj.CMPTS > 0;
                    bool canSSM = FS.GETAIRSSM(obj) > 0 && ((obj.HOMEBASE.AIRFIELD && !obj.TEMPLATE.LIMITEDSSM) || obj.HOMEBASE.AIRSSMPTS >= obj.TEMPLATE.AIRSSMCOST);
                    bool canTORP = obj.TEMPLATE.ASW > 0;
                    
                    bool needToChoose = (canBMB ? 1 : 0) + (canCM ? 1 : 0) + (canSSM ? 1 : 0) + (canTORP ? 1 : 0) > 1;
                    
                    if(needToChoose){
                        GS.InteractionMap.Add(obj, new());
                    } else if(canBMB){
                        obj.SPECIAL = FS.GETAIRBOMB(obj);
                        int availableBOMBPTS = obj.HOMEBASE.AIRFIELD ? 2 : obj.HOMEBASE.BOMBPTS;
                        int usedBOMBPTS = Math.Min(obj.REDUCEDRANGE ? 2 : 1, availableBOMBPTS);
                        obj.BOMBPTS = usedBOMBPTS;
                        if(!obj.HOMEBASE.AIRFIELD){
                            obj.HOMEBASE.BOMBPTS -= obj.BOMBPTS;
                        }
                    } else if(canCM){
                        obj.CM = obj.TEMPLATE.CM;
                    } else if(canSSM){
                        obj.SSM = FS.GETAIRSSM(obj);
                        obj.SSMPTS = Math.Max(1, obj.TEMPLATE.AIRSSMCOST);
                        if(!obj.HOMEBASE.AIRFIELD){
                            obj.HOMEBASE.AIRSSMPTS -= obj.SSMPTS;
                        }
                    } else if(canTORP){
                        obj.TORPPTS = 1;
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Count != 0)
                {
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(FS.GETAIRBOMB(obj) > 0 && (obj.HOMEBASE.AIRFIELD || obj.HOMEBASE.BOMBPTS >= 1)){GS.AddAction(obj, "LOAD BOMB");}
                if(obj.CMPTS > 0){GS.AddAction(obj, "LOAD CM");}
                if(FS.GETAIRSSM(obj) > 0 && ((obj.HOMEBASE.AIRFIELD && !obj.TEMPLATE.LIMITEDSSM) || obj.HOMEBASE.AIRSSMPTS >= obj.TEMPLATE.AIRSSMCOST)){GS.AddAction(obj, "LOAD SSM");}
                if(obj.TEMPLATE.ASW > 0){GS.AddAction(obj, "LOAD TORP");}
            }
            if(GS.InteractionMap.Keys.Count == 0)
            {
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "LOAD BOMB":
                    gp.SPECIAL = FS.GETAIRBOMB(gp);
                    int availableBOMBPTS = gp.HOMEBASE.AIRFIELD ? 2 : gp.HOMEBASE.BOMBPTS;
                    int usedBOMBPTS = Math.Min(gp.REDUCEDRANGE ? 2 : 1, availableBOMBPTS);
                    gp.BOMBPTS = usedBOMBPTS;
                    if(!gp.HOMEBASE.AIRFIELD){
                        gp.HOMEBASE.BOMBPTS -= gp.BOMBPTS;
                    }
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "LOAD CM":
                    gp.CM = gp.TEMPLATE.CM;
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "LOAD SSM":
                    gp.SSM = FS.GETAIRSSM(gp);
                    gp.SSMPTS = Math.Max(1, gp.TEMPLATE.AIRSSMCOST);
                    if(!gp.HOMEBASE.AIRFIELD){
                        gp.HOMEBASE.AIRSSMPTS -= gp.SSMPTS;
                    }
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "LOAD TORP":
                    gp.TORPPTS = 1;
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "NEXT":
                    GS.Done(this);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirMidAirRefueling : GamePhaseInteractive
    {
        GO tanker = null;
        string side = null;
        public ActionAirMidAirRefueling(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario)
        {
            RequiresMapUpdate = false;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"SELECT ROLE"});
                tanker = null;
                GS.HELPTEXT = 
                "Assign Mid-Air Refueling to this mission\n\n" + 
                "Adds 50% range to air unit.  this bonus will be revoked if, during the first 10 hexes of travel, the air unit flies within 4 hexes of ANY enemy INT on CAP, so be careful!";
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATING").Where(n => n.UNITTYPE == "INT" || n.UNITTYPE == "ATK" || n.UNITTYPE == "BMB")){
                    GO homebase = obj.HOMEBASE;
                    if(homebase.TYPE == "SHIP"){
                        tanker = FS.TYPESIDE(GS, "SQN", side).Where(n => n.CARRIER == homebase && n.UNITTYPE == "AR" && !n.AERIALREFUELING).FirstOrDefault();
                    } else {
                        tanker = FS.TYPESIDE(GS, "SQN", side).Where(n => n.GAMELOCATION == homebase && n.UNITTYPE == "AR" && !n.AERIALREFUELING).FirstOrDefault();
                    }
                    if(tanker != null){
                        GS.InteractionMap.Add(obj, new());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "ASSIGN TANKER TO MISSION");
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "ASSIGN TANKER TO MISSION":
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.AERIALREFUELING = true);
                    tanker.AERIALREFUELING = true;
                    Update("NEXT");
                    break;
                case "NEXT":
                    GS.Done(this);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirFlightOptions : GamePhaseInteractive
    {
        string side = null;
        public ActionAirFlightOptions(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            RequiresMapUpdate = false;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"ADJUST AIR UNIT RANGE VIA OPTIONS"});

                GS.HELPTEXT = 
                "There are some options available to adjust AIR UNIT mission ranges\n\n" + 
                "- EXTENDED RANGE: INT, ATK, BMB increase range 25%, ordinance halved\n" +
                "- HIGH MISSION PROFILE: INT, ATK, BMB, EW increase range 25%, enemy gets +modifiers in combat\n" + 
                "- REDUCED RANGE (cannot be combined with other options): INT, ATK, BMB range halved, Bomb value increased";
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATING")
                    .Where(n => n.UNITTYPE == "INT" || n.UNITTYPE == "ATK" || n.UNITTYPE == "BMB" || n.UNITTYPE == "EW")){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                switch(obj.UNITTYPE){
                    case "INT":
                    case "ATK":
                    case "BMB":
                        if(!obj.EXTENDEDRANGE){GS.AddAction(obj, "EXTENDED RANGE");}
                        if(!obj.EXTENDEDRANGE && !obj.HIGHMISSIONPROFILE && 
                        ((FS.GETAIRBOMB(obj) > 0 && obj.AIRMISSION == null) || obj.AIRMISSION == "BOMBING")){
                            int neededBOMBPTS = 2 - obj.BOMBPTS;
                            int availableBOMBPTS = obj.HOMEBASE.AIRFIELD ? 2 : obj.HOMEBASE.BOMBPTS;
                            if(availableBOMBPTS >= neededBOMBPTS){
                                GS.AddAction(obj, "REDUCED RANGE");
                            }
                        }
                        break;
                    default:
                        break;
                }
                if(!obj.HIGHMISSIONPROFILE){GS.AddAction(obj, "HIGH MISSION PROFILE");}
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "EXTENDED RANGE":
                    gp.EXTENDEDRANGE = true;
                    switch(gp.AIRMISSION){
                        case "SSM":
                            gp.SSM = FS.GETAIRSSM(gp);
                            break;
                        case "BOMBING":
                            gp.SPECIAL = FS.GETAIRBOMB(gp);
                            break;
                        default:
                            break;
                    }
                    Start(false);
                    break;
                case "REDUCED RANGE":
                    gp.REDUCEDRANGE = true;
                    switch(gp.AIRMISSION){
                        case "BOMBING":
                            gp.SPECIAL = FS.GETAIRBOMB(gp);
                            int neededBOMBPTS = 2 - gp.BOMBPTS;
                            gp.BOMBPTS = 2;
                            if(!gp.HOMEBASE.AIRFIELD){
                                gp.HOMEBASE.BOMBPTS -= neededBOMBPTS;
                            }
                            break;
                        default:
                            break;
                    }
                    Update("NEXT");
                    break;
                case "HIGH MISSION PROFILE":
                    gp.HIGHMISSIONPROFILE = true;
                    Start(false);
                    break;
                case "NEXT":
                    GS.Done(this);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirEnemyCAPLoop : GamePhaseLoopLogic
    {
        public ActionAirEnemyCAPLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionAirEnemyCAP("Intercept", this, GS));
            AddGamePhase(new ActionAirFriendlyAssistance("Friendly Assist", this, GS));
            AddGamePhase(new ActionAirCAPCombat("Air To Air Combat Resolution", this, GS));
            AddGamePhase(new ActionAirCAPPickCasualties("Air To Air Casualties", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTNEEDED").Any();}
        public override void Init()
        {
            List<GO> objs = FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTNEEDED");
            GO obj = GS.RANDOMGAMEOBJECT(objs);
            List<GO> intercepted = objs.Where(n => n.GAMELOCATION == obj.GAMELOCATION && n.SIDE == obj.SIDE).ToList();
            FS.SETSCENARIOOBJECTS(GS, "ACTION.INTERCEPTED", intercepted);
            objs.RemoveAll(intercepted.Contains);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.INTERCEPTNEEDED", objs);
        }
        public override void End()
        {
            //RTB
            foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.RTB")){
                switch(obj.ACTIVATED){
                    case true:
                        List<GO> groupMembers = FS.GROUPMEMBERS(obj);
                        foreach(GO sqn in groupMembers){
                            FS.REMOVEFROMGROUP(sqn, obj);
                            FS.RETURNTOHOMEBASE(sqn);
                            FS.REMOVESCENARIOOBJECT(GS, sqn, true);
                            sqn.DONE = !sqn.DESTROYED;
                            sqn.SEARCHMODE = false;
                            sqn.INTERCEPTMODE = false;
                            sqn.SEARCHDELAY = 0;
                            sqn.LOITERMODE = false;
                        }                        
                        break;
                    case false:
                        obj.DONE = true;
                        FS.REMOVESCENARIOOBJECT(GS, obj, true);
                        break;
                }
            }
            if(!ProcessCheck()){
                FS.AIRDETECTION(GS, new(), true);
            }
        }
    }
    public class ActionAirEnemyCAP : GamePhaseInteractive
    {
        List<GO> interceptedUnits = new();
        List<GO> INTERCEPTINGUNITS = new();
        List<GO> ALERTS = new();
        string side = null;
        public ActionAirEnemyCAP(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            RequiresMapUpdate = false;
        }
        public override void Execute(Boolean init){
            if(init){
                interceptedUnits = FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTED");
                GO interceptedUnit = interceptedUnits.First();
                side = FS.ENEMY(interceptedUnits.First().SIDE);
                INTERCEPTINGUNITS.Clear();
                ALERTS.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE CAP UNIT(s) TO INTERCEPT"});

                GS.HELPTEXT = 
                "Intercept Air Group.  Select all CAP units you'd like to intercept at this location\n\n" +
                "NOTE: To skip, hit NEXT Button";
                List<GO> priorInterceptions = GS.TYPE("INTERCEPTION").Where(n => interceptedUnits.Contains(n.INTERCEPTEDGRP)).ToList();
                List<GO> friendlyRadius = FS.FINDAIRRADIUS(interceptedUnit.GAMELOCATION, 4);
                friendlyRadius.Remove(interceptedUnit.GAMELOCATION);
                List<GO> CAPMISSIONS = FS.CAPSQNS(GS, side).Where(n => !n.DONE && friendlyRadius.Contains(n.GAMELOCATION)).ToList();
                foreach(GO obj in CAPMISSIONS.ToList()){
                    //if the CAP has already intercepted all units in the defense, skip
                    if(!interceptedUnits.Where(n => !priorInterceptions.Where(n2 => n2.INTERCEPTEDGRP == n && n2.CAP == obj).Any()).Any()){
                        CAPMISSIONS.Remove(obj);
                    }
                }
                ALERTS.AddRange(FS.TYPESIDE(GS, "ALERT", side).Where(n => n.INTERCEPTEDGRP == interceptedUnit && CAPMISSIONS.Contains(n.ATTACKER)));
                foreach (GO obj in CAPMISSIONS){
                    if(CAPMISSIONS.Where(n => n.GAMELOCATION == obj.GAMELOCATION && n.UNITTYPE == "INT").Any()){
                        GS.InteractionMap.Add(obj, new());
                        if (!ALERTS.Where(n => n.ATTACKER == obj).Any()) {
                            ALERTS.Add(FS.CREATEALERT(interceptedUnit, obj, obj.SIDE));
                        }
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Count != 0)
                {
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "ASSIGN ALL CAP IN THIS HEX TO INTERCEPT");
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                GO interceptedUnit = interceptedUnits.First();
                int aggressionfactor = GS.Get("AI." + side) switch
                {
                    "CAUTIOUS" => 50,
                    "AGGRESSIVE" => 90,
                    _ => 70
                };
                List<GO> INTERCEPTLOCATIONS = [.. GS.InteractionMap.Keys.Select(n => n.GAMELOCATION).Distinct()];
                foreach(GO loc in INTERCEPTLOCATIONS) {
                    List<GO> interceptors = [.. GS.InteractionMap.Keys.Where(n => n.AIRMISSION == "CAP" && n.SIDE == side && n.GAMELOCATION == loc)];
                    bool fromAirfield = interceptors.Where(n => n.HOMEBASE.AIRFIELD).Any();
                    bool USAEW = interceptors.Where(n => n.COUNTRY == "USA" && n.UNITTYPE == "AEW").Any();
                    bool AEW = interceptors.Where(n => n.UNITTYPE == "AEW").Any();
                    double capmodifier = 0;
                    if (fromAirfield)
                    {
                        capmodifier = 1;
                    }
                    else
                    {
                        int distance = FS.FINDAIRMOVEMENTPATH(loc, interceptedUnit.GAMELOCATION).Sum(n => n.DISTANCE);
                        if (distance <= 1)
                        {
                            capmodifier = 1;
                        }
                        else if (distance <= 2)
                        {
                            capmodifier = AEW ? 1 : 0.5;
                        }
                        else if (distance <= 3)
                        {
                            capmodifier = USAEW ? 0.5 : 0.25;
                        }
                        else if (distance <= 4)
                        {
                            capmodifier = USAEW ? 0.25 : 0.125;
                        }
                    }
                    int random = GS.RANDOMINT(100);
                    if (random < aggressionfactor * capmodifier)
                    {
                        INTERCEPTINGUNITS.AddRange(interceptors);
                    }
                }
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.SETSCENARIOOBJECTS(GS, "ACTION.INTERCEPTING", INTERCEPTINGUNITS);                        
                    if(INTERCEPTINGUNITS.Any()){
                        foreach(GO sqn in interceptedUnits){
                            foreach(GO obj in INTERCEPTINGUNITS){
                                Dictionary<string, string> clonedData = new()
                                {
                                    ["ID"] = obj.ID + GO.DELIM + sqn.ID + GO.DELIM + FS.GENERATETIMESTAMP(),
                                    ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                    ["TYPE"] = "INTERCEPTION"
                                };
                                GO interception = new(GS, clonedData, null, null)
                                {
                                    CAPID = obj.ID,
                                    CAP = obj,
                                    INTERCEPTEDGRPID = sqn.ID,
                                    INTERCEPTEDGRP = sqn
                                };
                            }
                        }
                    } else {
                        FS.CLEARSCENARIOVAR(GS, "ACTION.INTERCEPTED");
                    }
                    ALERTS.ForEach(FS.DISCARDLOGIC);
                    GS.Done(this);
                    break;
                case "ASSIGN ALL CAP IN THIS HEX TO INTERCEPT":
                    foreach(GO obj in GS.InteractionMap.Keys.ToList().Where(n => n.AIRMISSION == "CAP" && n.SIDE == gp.SIDE && n.GAMELOCATION == gp.GAMELOCATION && n != gp)){
                        INTERCEPTINGUNITS.Add(obj);
                        GS.REMOVEINTERACTIVE(obj);
                    }
                    INTERCEPTINGUNITS.Add(gp);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirFriendlyAssistance : GamePhaseInteractive
    {
        List<GO> interceptedUnits = new();
        List<GO> INTERCEPTINGUNITS = new();
        List<GO> ALERTS = new();
        string side = null;
        public ActionAirFriendlyAssistance(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            RequiresMapUpdate = false;
        }
        public override void Execute(Boolean init){
            if(init){
                INTERCEPTINGUNITS.Clear();
                ALERTS.Clear();
                interceptedUnits = FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTED");
                if(interceptedUnits.Any()){
                    GO interceptedUnit = interceptedUnits.First();
                    side = interceptedUnit.SIDE;
                    FS.SIDE_MODE = side;
                    FS.SETINSTRUCTIONS(GS, new(){"CHOOSE CAP MISSION(S) TO DEFEND"});

                    GS.HELPTEXT = 
                    "Defend active air unit at its current location.  Select all CAP units you'd like to assist at this location\n\n" +
                    "NOTE: To skip, hit NEXT Button";
                    List<GO> friendlyRadius = FS.FINDAIRRADIUS(interceptedUnit.GAMELOCATION, 4);
                    List<GO> CAPMISSIONS = [..FS.CAPSQNS(GS, side).Where(n => n.NUMCOMBATS == 0 && !n.DONE && friendlyRadius.Contains(n.GAMELOCATION))];
                    ALERTS.AddRange(FS.TYPESIDE(GS, "ALERT", side).Where(n => n.INTERCEPTEDGRP == interceptedUnit && CAPMISSIONS.Contains(n.ATTACKER)));
                    foreach (GO obj in CAPMISSIONS){
                        if(!FS.UNDERCOMMANDFAILURE(obj.GAMELOCATION, side, false)){
                            GS.InteractionMap.Add(obj, new());
                            if (!ALERTS.Where(n => n.ATTACKER == obj).Any())
                            {
                                ALERTS.Add(FS.CREATEALERT(interceptedUnit, obj, obj.SIDE));
                            }
                        }
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "ASSIGN ALL CAP IN THIS HEX TO DEFEND");
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                GO interceptedUnit = interceptedUnits.First();
                int aggressionfactor = GS.Get("AI." + side) switch
                {
                    "CAUTIOUS" => 50,
                    "AGGRESSIVE" => 90,
                    _ => 70
                };
                List<GO> INTERCEPTLOCATIONS = [.. GS.InteractionMap.Keys.Select(n => n.GAMELOCATION).Distinct()];
                foreach (GO loc in INTERCEPTLOCATIONS)
                {
                    List<GO> interceptors = [.. GS.InteractionMap.Keys.Where(n => n.SIDE == side && n.GAMELOCATION == loc && !interceptedUnits.Contains(n))];
                    bool fromAirfield = interceptors.Where(n => n.HOMEBASE.AIRFIELD).Any();
                    bool USAEW = interceptors.Where(n => n.COUNTRY == "USA" && n.UNITTYPE == "AEW").Any();
                    bool AEW = interceptors.Where(n => n.UNITTYPE == "AEW").Any();
                    double capmodifier = 0;
                    if (fromAirfield)
                    {
                        capmodifier = 1;
                    }
                    else
                    {
                        int distance = FS.FINDAIRMOVEMENTPATH(loc, interceptedUnit.GAMELOCATION).Sum(n => n.DISTANCE);
                        if (distance <= 1)
                        {
                            capmodifier = 1;
                        }
                        else if (distance <= 2)
                        {
                            capmodifier = AEW ? 1 : 0.5;
                        }
                        else if (distance <= 3)
                        {
                            capmodifier = USAEW ? 0.5 : 0.25;
                        }
                        else if (distance <= 4)
                        {
                            capmodifier = USAEW ? 0.25 : 0.125;
                        }
                    }
                    int random = GS.RANDOMINT(100);
                    if (random < aggressionfactor * capmodifier)
                    {
                        INTERCEPTINGUNITS.AddRange(interceptors);
                    }
                }
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDING", INTERCEPTINGUNITS);
                    GS.Done(this);
                    ALERTS.ForEach(FS.DISCARDLOGIC);
                    break;
                case "ASSIGN ALL CAP IN THIS HEX TO DEFEND":
                    foreach(GO obj in GS.InteractionMap.Keys.ToList().Where(n => n.SIDE == gp.SIDE && n.GAMELOCATION == gp.GAMELOCATION && n != gp && !interceptedUnits.Contains(n))){
                        INTERCEPTINGUNITS.Add(obj);
                        GS.REMOVEINTERACTIVE(obj);
                    }
                    INTERCEPTINGUNITS.Add(gp);
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirCAPCombat : GamePhaseAutomated
    {
        public ActionAirCAPCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            SetInt("ACTION.ATTACKERLOSSES", 0);
            SetInt("ACTION.DEFENDERLOSSES", 0);
            FS.CLEARSCENARIOVAR(GS, "ACTION.RTB");
            List<GO> interceptedGroups = FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTED");
            RequiresMapUpdate = interceptedGroups.Count > 0;
            if (interceptedGroups.Count > 0)
            {
                GO interceptedUnit = interceptedGroups.First();
                GO combatLocation = interceptedUnit.GAMELOCATION;
                string defendingSide = interceptedUnit.SIDE;
                string attackingSide = FS.ENEMY(defendingSide);
                List<GO> interceptedUnits = FS.GROUPSANDMEMBERS(interceptedGroups).Where(n => !FS.ISGROUP(n)).ToList();
                List<GO> combatants = new(interceptedUnits);
                Dictionary<GO, double> CAPModifiers = new();
                interceptedUnits.ForEach(n => CAPModifiers.Add(n, 1));
                List<GO> interceptors = FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTING");
                bool atkEW = interceptors.Where(n => n.UNITTYPE == "EW").Any() || FS.EWSQNS(attackingSide, combatLocation).Count != 0;
                bool fromAirfield = interceptors.Where(n => n.HOMEBASE.AIRFIELD).Any();
                bool USAEW = interceptors.Where(n => n.COUNTRY == "USA" && n.UNITTYPE == "AEW").Any();
                bool AEW = interceptors.Where(n => n.UNITTYPE == "AEW").Any();
                foreach (GO obj in interceptors)
                {
                    obj.ADMINDETECTED = true;
                    FS.CREATEALERT(obj, null, FS.ENEMY(obj.SIDE));
                    combatants.Add(obj);
                    double modifier = 0;
                    if (fromAirfield)
                    {
                        modifier = 1;
                    }
                    else
                    {
                        int distance = FS.FINDAIRMOVEMENTPATH(obj.GAMELOCATION, interceptedUnit.GAMELOCATION).Sum(n => n.DISTANCE);
                        if (distance <= 1)
                        {
                            modifier = 1;
                        }
                        else if (distance <= 2)
                        {
                            modifier = AEW ? 1 : 0.5;
                        }
                        else if (distance <= 3)
                        {
                            modifier = USAEW ? 0.5 : 0.25;
                        }
                        else if (distance <= 4)
                        {
                            modifier = USAEW ? 0.25 : 0.125;
                        }
                    }
                    CAPModifiers.Add(obj, modifier);
                }
                List<GO> defendCaps = FS.SCENARIOUNITS(GS, "ACTION.DEFENDING");
                bool defEW = FS.EWSQNS(defendingSide, combatLocation).Count != 0 || defendCaps.Where(n => n.UNITTYPE == "EW").Any();
                fromAirfield = defendCaps.Where(n => n.HOMEBASE.AIRFIELD).Any();
                USAEW = defendCaps.Where(n => n.COUNTRY == "USA" && n.UNITTYPE == "AEW").Any();
                AEW = defendCaps.Where(n => n.UNITTYPE == "AEW").Any();
                foreach (GO obj in defendCaps)
                {
                    obj.ADMINDETECTED = true;
                    FS.CREATEALERT(obj, null, FS.ENEMY(obj.SIDE));
                    combatants.Add(obj);
                    double modifier = 0;
                    if (fromAirfield)
                    {
                        modifier = 1;
                    }
                    else
                    {
                        int distance = FS.FINDAIRMOVEMENTPATH(obj.GAMELOCATION, interceptedUnit.GAMELOCATION).Sum(n => n.DISTANCE);
                        if (distance <= 1)
                        {
                            modifier = 1;
                        }
                        else if (distance <= 2)
                        {
                            modifier = AEW ? 1 : 0.5;
                        }
                        else if (distance <= 3)
                        {
                            modifier = USAEW ? 0.5 : 0.25;
                        }
                        else if (distance <= 4)
                        {
                            modifier = USAEW ? 0.25 : 0.125;
                        }
                    }
                    CAPModifiers.Add(obj, modifier);
                }
                List<GO> attackers = combatants.Where(n => n.SIDE == attackingSide).ToList();
                List<GO> defenders = combatants.Where(n => n.SIDE == defendingSide).ToList();
                string report = "CAP COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                //if (GS.AI_Sides.Count == 2)
                //{
                report += "ATTACKERS\n";
                foreach (GO attacker in attackers)
                {
                    report += attacker.UNITTYPE + " " + attacker.LABEL + "\n";
                }
                report += "\n";
                report += "DEFENDERS\n";
                foreach (GO defender in defenders)
                {
                    report += defender.UNITTYPE + " " + defender.LABEL + "\n";
                }
                report += "\n";
                //}
                double atkAArating = 0;
                foreach (GO obj in attackers)
                {
                    double rating = FS.GETAIRCAA(obj);
                    if (rating == 0) { continue; }
                    double modifier = CAPModifiers[obj];
                    atkAArating += Math.Max(Math.Floor(rating * modifier), 1);
                }
                double defAArating = 0;
                foreach (GO obj in defenders)
                {
                    double rating = FS.GETAIRCAA(obj);
                    if (rating == 0) { continue; }
                    double modifier = CAPModifiers[obj];
                    defAArating += Math.Max(Math.Floor(rating * modifier), 1);
                }
                bool NOATTACKERLOSSES = defAArating == 0;
                if (GS.AI_Sides.Contains(defendingSide))
                {
                    //AI side not penalized for having 0 ATA rating
                    defAArating = Math.Max(defAArating, 1);
                }
                if (defAArating == 0)
                {
                    SetInt("ACTION.DEFENDERLOSSES", 99999);
                    report += "RESULTS: Defender has 0 ATA rating.  DEFENDER ELIMINATED";
                    MainWindow.Alert(report);
                }
                else
                {
                    double ratio = atkAArating / defAArating;
                    double columnRatio = FS.INTERCEPTIONCOLUMNS.Keys.Where(n => n <= ratio).Any() ? FS.INTERCEPTIONCOLUMNS.Keys.Where(n => n <= ratio).Last() : FS.INTERCEPTIONCOLUMNS.Keys.Order().First();
                    string columnHeader = FS.INTERCEPTIONCOLUMNHEADER(columnRatio);
                    report += "COLUMN: " + columnHeader + " (" + Math.Round(atkAArating, 1) + "/" + Math.Round(defAArating, 1) + ")\n";
                    int rollmodifier = 0;
                    List<int> attacksperhex = interceptors.Select(n => n.GAMELOCATION).Distinct().Select(n => interceptors.Where(n2 => n2.GAMELOCATION == n).Max(n => n.NUMCOMBATS)).ToList();
                    int sumPriorAttacks = Math.Min(attacksperhex.Sum(), 2);
                    if (sumPriorAttacks > 0)
                    {
                        rollmodifier -= sumPriorAttacks;
                        report += "PRIOR ATTACKS: Roll -" + sumPriorAttacks + "\n";
                    }
                    if (atkEW)
                    {
                        rollmodifier += 2;
                        report += "ATK EW: Roll +2\n";
                    }
                    if (defEW)
                    {
                        rollmodifier -= 2;
                        report += "DEF EW: Roll -2\n";
                    }
                    if (interceptedUnits.Where(n => n.HIGHMISSIONPROFILE).Any())
                    {
                        rollmodifier += 2;
                        report += "DEF HIGH MISSION PROFILE: Roll +2\n";
                    }
                    report += "ROLL modifier: " + rollmodifier + "\n";
                    int dieRoll = Math.Min(9, Math.Max(0, FS.DIEROLL() + rollmodifier));
                    report += "ROLL: " + dieRoll + "\n";
                    List<string> results = FS.INTERCEPTIONRESULTS(columnHeader, dieRoll);
                    if (NOATTACKERLOSSES)
                    {
                        results[0] = "0";
                    }
                    report += "RESULTS: " + results[0] + "/" + results[1];
                    MainWindow.Alert(report);
                    string atkResult = results[0];
                    List<GO> RTB = new();
                    if (atkResult.Contains("R"))
                    {
                        atkResult = atkResult.Replace("R", "");
                        RTB.AddRange(interceptors);
                    }
                    Set("ACTION.ATTACKERLOSSES", atkResult);

                    string defResult = results[1];
                    if (defResult.Contains("R"))
                    {
                        defResult = defResult.Replace("R", "");
                        RTB.AddRange(interceptedGroups);
                        RTB.AddRange(defendCaps);
                    }
                    Set("ACTION.DEFENDERLOSSES", defResult);
                    FS.SETSCENARIOOBJECTS(GS, "ACTION.RTB", RTB);
                }
                //increment
                foreach (GO obj in interceptors)
                {
                    FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.NUMCOMBATS++);
                }
                foreach (GO obj in defendCaps)
                {
                    FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.NUMCOMBATS++);
                }
            }
            GS.Done(this);           
        }
    }
    public class ActionAirCAPPickCasualties : GamePhaseInteractive
    {
        List<GO> interceptedGroups = new();
        int stepLosses = 0;
        string side = null;
        bool attacker = false;
        public ActionAirCAPPickCasualties(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                interceptedGroups = FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTED");
                List<GO> attackers = new();
                List<GO> defenders = new();
                interceptedGroups.ForEach(n => defenders.AddRange(FS.GROUPMEMBERS(n)));
                FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTING").ForEach(attackers.Add);
                FS.SCENARIOUNITS(GS, "ACTION.DEFENDING").ForEach(defenders.Add);
                int attackerLosses = GetInt("ACTION.ATTACKERLOSSES");
                int defenderLosses = GetInt("ACTION.DEFENDERLOSSES");
                List<GO> combatants = new();
                if(attackerLosses > 0 && attackers.Any()){
                    side = FS.ENEMY(attackers.First().SIDE);
                    stepLosses = attackerLosses;
                    attacker = true;
                    combatants.AddRange(attackers);
                } else if(defenderLosses > 0 && defenders.Any()){
                    side = FS.ENEMY(defenders.First().SIDE);
                    stepLosses = defenderLosses;
                    attacker = false;
                    combatants.AddRange(defenders);
                } else {
                    RequiresMapUpdate = side != null;
                    Update("NEXT");
                    return;
                }
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "Choose the ENEMY squadrons to apply losses to. You must choose INTs first before other types.\n\n" +
                "When all step losses have been applied, the phase will end.  Any retreats will be carried out automatically at the end of this phase"; 
                foreach(GO obj in combatants){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(stepLosses == 0 || !GS.InteractionMap.Keys.Any()){
                if(attacker){
                    GS.advanced = true;
                    SetInt("ACTION.ATTACKERLOSSES", 0);
                    GS.ResetBetweenUpdates();
                    GS.ResetBetweenPhases();
                    Start(true);
                } else {
                    SetInt("ACTION.DEFENDERLOSSES", 0);
                    Update("NEXT");
                }
                return;
            }
            FS.SETINSTRUCTIONS(GS, new(){"APPLY LOSSES: STEPS REMAINING TO SELECT = " + stepLosses});
            BANNER = "Pick Casualties - Steps: " + stepLosses;
            bool INTPRESENT = GS.InteractionMap.Keys.Where(n => n.UNITTYPE == "INT").Any();
            foreach(GO obj in GS.InteractionMap.Keys){
                if(obj.UNITTYPE == "INT" || !INTPRESENT){GS.AddAction(obj, "APPLY LOSS");}
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.Where(n => n.UNITTYPE == "INT").FirstOrDefault() ?? GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){}
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                GS.SelectedMarker = GS.RANDOMGAMEOBJECT([.. GS.InteractionMap.Keys.Where(n => n.UNITTYPE == "INT" || !INTPRESENT)]);
                Update("APPLY LOSS");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    SetInt("ACTION.ATTACKERLOSSES", 0);
                    SetInt("ACTION.DEFENDERLOSSES", 0);                    
                    FS.CLEARSCENARIOVAR(GS, "ACTION.INTERCEPTED");
                    FS.CLEARSCENARIOVAR(GS, "ACTION.INTERCEPTING");
                    FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDING");
                    side = null;
                    GS.Done(this);
                    RequiresMapUpdate = true;
                    break;
                case "APPLY LOSS":
                    GS.IncrementDouble("VP." + FS.ENEMY(gp.SIDE), FS.VPVALUE(gp) * 0.5); 
                    FS.DAMAGE(gp);
                    stepLosses--;
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirEnemyMobileCAPLoop : GamePhaseLoopLogic
    {
        public ActionAirEnemyMobileCAPLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionAirEnemyMobileCAP("Intercept", this, GS));
            AddGamePhase(new ActionAirMobileCAPCombat("Air To Air Combat Resolution", this, GS));
            AddGamePhase(new ActionAirMobileCAPPickCasualties("Air To Air Casualties", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOUNITS(GS, "ACTION.MOBILEINTERCEPTNEEDED").Any();}
        public override void Init()
        {
            List<GO> objs = FS.SCENARIOUNITS(GS, "ACTION.MOBILEINTERCEPTNEEDED");
            GO obj = GS.RANDOMGAMEOBJECT(objs);
            List<GO> intercepted = objs.Where(n => n.GAMELOCATION == obj.GAMELOCATION && n.SIDE == obj.SIDE).ToList();
            FS.SETSCENARIOOBJECTS(GS, "ACTION.INTERCEPTED", intercepted);
            objs.RemoveAll(intercepted.Contains);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.MOBILEINTERCEPTNEEDED", objs);
        }
        public override void End()
        {
            //RTB
            foreach (GO obj in FS.SCENARIOUNITS(GS, "ACTION.RTB"))
            {
                switch (obj.ACTIVATED)
                {
                    case true:
                        List<GO> groupMembers = FS.GROUPMEMBERS(obj);
                        foreach (GO sqn in groupMembers)
                        {
                            FS.REMOVEFROMGROUP(sqn, obj);
                            FS.RETURNTOHOMEBASE(sqn);
                            FS.REMOVESCENARIOOBJECT(GS, sqn, true);
                            sqn.DONE = !sqn.DESTROYED;
                            sqn.SEARCHMODE = false;
                            sqn.INTERCEPTMODE = false;
                            sqn.SEARCHDELAY = 0;
                            sqn.LOITERMODE = false;
                        }
                        break;
                    case false:
                        obj.DONE = true;
                        FS.REMOVESCENARIOOBJECT(GS, obj, true);
                        break;
                }
            }
            if (!ProcessCheck()){
                FS.AIRDETECTION(GS, new(), true);
            }
        }
    }
    public class ActionAirEnemyMobileCAP : GamePhaseInteractive
    {
        List<GO> INTERCEPTED = new();
        List<GO> INTERCEPTING = new();
        string side = null;
        public ActionAirEnemyMobileCAP(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            RequiresMapUpdate = false;            
        }
        public override void Execute(Boolean init){
            if(init){
                INTERCEPTED = FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTED");
                GO interceptedUnit = INTERCEPTED.First();
                side = FS.ENEMY(INTERCEPTED.First().SIDE);
                INTERCEPTING.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE CAP UNIT(s) TO INTERCEPT"});

                GS.HELPTEXT = 
                "Intercept Air Group.  Select all CAP units you'd like to intercept at this location\n\n" +
                "NOTE: To skip, hit NEXT Button";
                List<GO> MOBILECAP = [..FS.TYPESIDE(GS, "SQN", side).Where(n => n.ACTIVATED && !n.DONE && FS.LOGICALPARENT(n) == n && n.NUMCOMBATS == 0 && n.INTERCEPTMODE)];
                List<GO> MOBILECAPF14 = [..MOBILECAP.Where(n => n.MAA)];
                MOBILECAP.RemoveAll(MOBILECAPF14.Contains);
                //MOBILE CAP F14
                List<GO> friendlyRadius = FS.FINDAIRRADIUS(interceptedUnit.GAMELOCATION, 1);
                List<GO> CAPMISSIONS = [..MOBILECAPF14.Where(n => friendlyRadius.Contains(n.GAMELOCATION))];
                foreach (GO obj in CAPMISSIONS){
                    GS.InteractionMap.Add(obj, new());
                }
                //MOBILE CAP
                friendlyRadius = [interceptedUnit.GAMELOCATION];
                CAPMISSIONS = [..MOBILECAP.Where(n => friendlyRadius.Contains(n.GAMELOCATION))];
                foreach (GO obj in CAPMISSIONS){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Count != 0)
                {
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                Update("ASSIGN");
                return;
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(INTERCEPTING.Any()){
                        List<GO> interceptingSqns = new();
                        foreach(GO obj in INTERCEPTING){
                            FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.INTERCEPTMODE = false);
                            FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.NUMCOMBATS++);
                            interceptingSqns.AddRange(FS.GROUPMEMBERS(obj));
                            interceptingSqns.AddRange(FS.EWSQNS(side, obj.GAMELOCATION));
                        }
                        //add any friendly EW in hexes involved
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.INTERCEPTING", interceptingSqns);                        
                    } else {
                        FS.CLEARSCENARIOVAR(GS, "ACTION.INTERCEPTING");
                        FS.CLEARSCENARIOVAR(GS, "ACTION.INTERCEPTED");
                    }
                    GS.Done(this);
                    break;
                case "ASSIGN":
                    INTERCEPTING.Add(gp);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirMobileCAPCombat : GamePhaseAutomated
    {
        public ActionAirMobileCAPCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            SetInt("ACTION.ATTACKERLOSSES", 0);
            SetInt("ACTION.DEFENDERLOSSES", 0);
            FS.CLEARSCENARIOVAR(GS, "ACTION.RTB");
            List<GO> interceptedGroups = FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTED");
            RequiresMapUpdate = interceptedGroups.Count > 0;
            if (interceptedGroups.Count > 0)
            {
                GO TMP = interceptedGroups.First();
                GO combatLocation = TMP.GAMELOCATION;
                string defendingSide = TMP.SIDE;
                string attackingSide = FS.ENEMY(defendingSide);
                List<GO> interceptedUnits = [.. FS.GROUPSANDMEMBERS(interceptedGroups).Where(n => !FS.ISGROUP(n))];
                List<GO> combatants = new(interceptedUnits);
                List<GO> interceptors = [.. FS.GROUPSANDMEMBERS(FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTING")).Where(n => !FS.ISGROUP(n))];
                combatants.AddRange(interceptors);
                foreach (GO obj in interceptors.Where(n => n.ACTIVATIONGRP != null).Select(n => n.ACTIVATIONGRP))
                {
                    obj.ADMINDETECTED = true;
                    FS.CREATEALERT(obj, null, FS.ENEMY(obj.SIDE));
                }
                bool atkEW = interceptors.Where(n => n.UNITTYPE == "EW").Any();
                bool defEW = interceptedUnits.Where(n => n.UNITTYPE == "EW").Any();
                List<GO> attackers = combatants.Where(n => n.SIDE == attackingSide).ToList();
                List<GO> defenders = combatants.Where(n => n.SIDE == defendingSide).ToList();
                string report = "INTERCEPTION COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                //if (GS.AI_Sides.Count == 2)
                //{
                report += "ATTACKERS\n";
                foreach (GO attacker in attackers)
                {
                    report += attacker.UNITTYPE + " " + attacker.LABEL + "\n";
                }
                report += "\n";
                report += "DEFENDERS\n";
                foreach (GO defender in defenders)
                {
                    report += defender.UNITTYPE + " " + defender.LABEL + "\n";
                }
                report += "\n";
                //}
                double atkAArating = 0;
                foreach (GO obj in attackers)
                {
                    double rating = FS.GETAIRCAA(obj);
                    if (rating == 0) { continue; }
                    atkAArating += Math.Max(rating, 1);
                }
                double defAArating = 0;
                foreach (GO obj in defenders)
                {
                    double rating = FS.GETAIRCAA(obj);
                    if (rating == 0) { continue; }
                    defAArating += Math.Max(rating, 1);
                }
                bool NOATTACKERLOSSES = defAArating == 0;
                defAArating = Math.Max(defAArating, 1);
                if (defAArating == 0)
                {
                    SetInt("ACTION.DEFENDERLOSSES", 99999);
                    report += "RESULTS: Defender has 0 ATA rating.  DEFENDER ELIMINATED";
                    MainWindow.Alert(report);
                }
                else
                {
                    double ratio = atkAArating / defAArating;
                    double columnRatio = FS.INTERCEPTIONCOLUMNS.Keys.Where(n => n <= ratio).Any() ? FS.INTERCEPTIONCOLUMNS.Keys.Where(n => n <= ratio).Last() : FS.INTERCEPTIONCOLUMNS.Keys.Order().First();
                    string columnHeader = FS.INTERCEPTIONCOLUMNHEADER(columnRatio);
                    report += "COLUMN: " + columnHeader + " (" + Math.Round(atkAArating, 1) + "/" + Math.Round(defAArating, 1) + ")\n";
                    int rollmodifier = 0;
                    if (atkEW)
                    {
                        rollmodifier += 2;
                        report += "ATK EW: Roll +2\n";
                    }
                    if (defEW)
                    {
                        rollmodifier -= 2;
                        report += "DEF EW: Roll -2\n";
                    }
                    if (interceptors.Where(n => n.HIGHMISSIONPROFILE).Any())
                    {
                        rollmodifier -= 2;
                        report += "ATK HIGH MISSION PROFILE: Roll -2\n";
                    }
                    if (interceptedUnits.Where(n => n.HIGHMISSIONPROFILE).Any())
                    {
                        rollmodifier += 2;
                        report += "DEF HIGH MISSION PROFILE: Roll +2\n";
                    }
                    report += "ROLL modifier: " + rollmodifier + "\n";
                    int dieRoll = Math.Min(9, Math.Max(0, FS.DIEROLL() + rollmodifier));
                    report += "ROLL: " + dieRoll + "\n";
                    List<string> results = FS.INTERCEPTIONRESULTS(columnHeader, dieRoll);
                    if (NOATTACKERLOSSES)
                    {
                        results[0] = "0";
                    }
                    report += "RESULTS: " + results[0] + "/" + results[1];
                    MainWindow.Alert(report);
                    string atkResult = results[0];
                    List<GO> RTB = new();
                    if (atkResult.Contains("R"))
                    {
                        atkResult = atkResult.Replace("R", "");
                        RTB.AddRange(interceptors.Where(n => FS.PARENTGROUPLOCATION(n) == TMP.GAMELOCATION));
                    }
                    Set("ACTION.ATTACKERLOSSES", atkResult);

                    string defResult = results[1];
                    if (defResult.Contains("R"))
                    {
                        defResult = defResult.Replace("R", "");
                        RTB.AddRange(interceptedGroups);
                    }
                    Set("ACTION.DEFENDERLOSSES", defResult);
                    FS.SETSCENARIOOBJECTS(GS, "ACTION.RTB", RTB);
                }
            }
            GS.Done(this);           
        }
    }
    public class ActionAirMobileCAPPickCasualties : GamePhaseInteractive
    {
        List<GO> interceptedGroups = new();
        int stepLosses = 0;
        string side = null;
        bool attacker = false;
        public ActionAirMobileCAPPickCasualties(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                interceptedGroups = FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTED");
                List<GO> attackers = [];
                List<GO> defenders = [];
                interceptedGroups.ForEach(n => defenders.AddRange(FS.GROUPMEMBERS(n)));
                FS.SCENARIOUNITS(GS, "ACTION.INTERCEPTING").ForEach(n => attackers.AddRange(FS.GROUPMEMBERS(n)));
                //remove any attackers not in the target square
                if(defenders.Count != 0){
                    attackers.RemoveAll(n => FS.PARENTGROUPLOCATION(n) != FS.PARENTGROUPLOCATION(defenders.First()));
                }
                int attackerLosses = GetInt("ACTION.ATTACKERLOSSES");
                int defenderLosses = GetInt("ACTION.DEFENDERLOSSES");
                List<GO> combatants = [];
                if(attackerLosses > 0 && attackers.Any()){
                    side = FS.ENEMY(attackers.First().SIDE);
                    stepLosses = attackerLosses;
                    attacker = true;
                    combatants.AddRange(attackers);
                } else if(defenderLosses > 0 && defenders.Any()){
                    side = FS.ENEMY(defenders.First().SIDE);
                    stepLosses = defenderLosses;
                    attacker = false;
                    combatants.AddRange(defenders);
                } else {
                    RequiresMapUpdate = side != null;
                    Update("NEXT");
                    return;
                }
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "Choose the ENEMY squadrons to apply losses to. You must choose INTs first before other types.\n\n" +
                "When all step losses have been applied, the phase will end.  Any retreats will be carried out automatically at the end of this phase"; 
                foreach(GO obj in combatants){
                    GS.InteractionMap.Add(obj, []);
                }
            }
            if(stepLosses == 0 || !GS.InteractionMap.Keys.Any()){
                if(attacker){
                    GS.advanced = true;
                    SetInt("ACTION.ATTACKERLOSSES", 0);
                    GS.ResetBetweenUpdates();
                    GS.ResetBetweenPhases();
                    Start(true);
                } else {
                    SetInt("ACTION.DEFENDERLOSSES", 0);
                    Update("NEXT");
                }
                return;
            }
            FS.SETINSTRUCTIONS(GS, new(){"APPLY LOSSES: STEPS REMAINING TO SELECT = " + stepLosses});
            BANNER = "Pick Casualties - Steps: " + stepLosses;
            bool INTPRESENT = GS.InteractionMap.Keys.Where(n => n.UNITTYPE == "INT").Any();
            foreach(GO obj in GS.InteractionMap.Keys){
                if(obj.UNITTYPE == "INT" || !INTPRESENT){GS.AddAction(obj, "APPLY LOSS");}
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.Where(n => n.UNITTYPE == "INT").FirstOrDefault() ?? GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){}
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                GS.SelectedMarker = GS.RANDOMGAMEOBJECT([.. GS.InteractionMap.Keys.Where(n => n.UNITTYPE == "INT" || !INTPRESENT)]);
                Update("APPLY LOSS");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    SetInt("ACTION.ATTACKERLOSSES", 0);
                    SetInt("ACTION.DEFENDERLOSSES", 0);                    
                    FS.CLEARSCENARIOVAR(GS, "ACTION.INTERCEPTED");
                    FS.CLEARSCENARIOVAR(GS, "ACTION.INTERCEPTING");
                    side = null;
                    GS.Done(this);
                    RequiresMapUpdate = true;
                    break;
                case "APPLY LOSS":
                    GS.IncrementDouble("VP." + FS.ENEMY(gp.SIDE), FS.VPVALUE(gp) * 0.5); 
                    FS.DAMAGE(gp);
                    stepLosses--;
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirMovement : GamePhaseGroupLogic
    {
        public ActionAirMovement(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionAirMove("Movement", this, GS));
            AddGamePhase(new ActionAirEnemyCAPLoop("CAP INTERCEPT", this, GS));
            AddGamePhase(new ActionAirEnemyMobileCAPLoop("MOBILE CAP INTERCEPT", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init()
        {
        }
        public override void End()
        {
        }
    }
    public class ActionAirMove : GamePhaseAutomated
    {
        public ActionAirMove(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            //find all activated air units with movements to do
            //move all one hex
            //auto land if needed
            //destroy if out of fuel
            //designate intercepts
            int RECONMODEMULTIPLIER = (int)Math.Floor(Math.Max(1, GetDouble("_CONFIG_AIR_RECON_MODE_MOVE_COST_MULTIPLIER")));
            List<GO> checkInterception = new();
            foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED").Where(n => n.UNITCATEGORY == "AIR")){
                bool SIDE_IS_AI = GS.AI_Sides.Contains(obj.SIDE);
                //remove any TACCOORDS
                foreach(GO tc in FS.TYPESIDE(GS, "SURFACE TACCOORD", obj.SIDE).Where(n => n.ATTACKER == obj)){
                    FS.DISCARDLOGIC(tc);
                }
                //remove any TACCOORDS
                foreach(GO tc in FS.TYPESIDE(GS, "SUB TACCOORD", obj.SIDE).Where(n => n.ATTACKER == obj)){
                    FS.DISCARDLOGIC(tc);
                }
                List<GO> groupMembers = FS.GROUPMEMBERS(obj);
                List<string> past_locations = obj.LOCATIONHISTORY.Split('|').ToList();
                List<string> future_locations = obj.LOCATIONFUTURE.Split('|').ToList();
                if(obj.ENROUTEDELAY > 0){
                    FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.ENROUTEDELAY--);
                    FS.UPDATEGROUP(obj);
                } else if(obj.SEARCHDELAY > 0){
                    FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.SEARCHDELAY--);
                }
                else if (obj.LOITERMODE)
                {
                   
                }
                else if(future_locations.Count > 1){
                    //get next connector
                    string oldLocId = future_locations[0];
                    GO newLocation = GS.LOCATION(future_locations[1]);
                    GS.CHANGELOCATION(obj, newLocation);
                    foreach (GO gm in FS.GROUPMEMBERS(obj))
                    {
                        gm.GAMELOCATIONID = obj.GAMELOCATIONID;
                        gm.GAMELOCATION = obj.GAMELOCATION;
                    }
                    past_locations.Add(newLocation.ID);
                    future_locations.Remove(oldLocId);
                    GO connector = GS.TYPE("UNITMOVEMENT" , "CONNECTORLOCATIONID", oldLocId).Where(n => n.CONNECTORLOCATION2ID == newLocation.ID).First();
                    int movementCost = Math.Max(connector.DISTANCE, 1);
                    if(movementCost > 1){
                        FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.ENROUTEDELAY = movementCost - 1);
                        FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.LOITERMODE = false);
                        FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.SEARCHMODE = false);
                        FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.SEARCHDELAY = 0);
                        FS.UPDATEGROUP(obj);
                    }
                    obj.LOCATIONHISTORY = string.Join('|', past_locations);
                    obj.LOCATIONFUTURE = string.Join('|', future_locations);
                }
                IncrementInt("ACTION.MOVES." + obj.SIDE, 1);
                FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.MOVEMENTALLOWANCE = Math.Max(0, n.MOVEMENTALLOWANCE - 1));
                bool oofuel = obj.MOVEMENTALLOWANCE == 0;
                //drop off any groupmembers that are over their homebase
                if(obj.ENROUTEDELAY == 0){
                    foreach(GO sqn in groupMembers){
                        bool READYTORTB = obj.AIRMISSION == "RTB" || sqn.MOVEMENTALLOWANCE == 0;
                        if(!READYTORTB) { continue; }
                        GO homebase = sqn.HOMEBASE;
                        if(homebase == obj.GAMELOCATION || FS.PARENTGROUPLOCATION(homebase) == obj.GAMELOCATION){
                            FS.REMOVEFROMGROUP(sqn, obj);
                            FS.RETURNTOHOMEBASE(sqn);
                            FS.REMOVESCENARIOOBJECT(GS, sqn, true);
                            sqn.DONE = !sqn.DESTROYED;
                            sqn.SEARCHMODE = false;
                            sqn.INTERCEPTMODE = false;
                            sqn.SEARCHDELAY = 0;
                            sqn.LOITERMODE = false;
                        }
                    }
                }
                if(oofuel && !SIDE_IS_AI){
                    List<GO> destroyGOs = FS.GROUPMEMBERS(obj).Where(n => n.MOVEMENTALLOWANCE == 0).ToList();
                    if(destroyGOs.Any()){
                        MainWindow.Alert("Air Groups running out of fuel have been eliminated: " + string.Join(',', destroyGOs.Select(n => n.UNITTYPE + " " + n.LABEL)));
                    }
                    foreach(GO groupMember in destroyGOs){
                        FS.REMOVEFROMGROUP(groupMember, obj);
                        GS.IncrementDouble("VP." + FS.ENEMY(groupMember.SIDE), FS.VPVALUE(groupMember) * (groupMember.DAMAGED ? 0.5 : 1)); 
                        FS.DESTROY(groupMember);
                    }
                }
                if(obj.RECYCLED || obj.DESTROYED){continue;}
                //check interception
                if (obj.ENROUTEDELAY == 0)
                {
                    checkInterception.Add(obj);
                }
            }
            FS.AIRDETECTION(GS, checkInterception, true);
            FS.SURFACEVSAIRTARGETING(GS);
            //only check air vs sub on non ship cycles
            if((GetInt("ACTION.CYCLES")) + 1 != 5){FS.AIRVSSUBDETECTION(GS);}
            GS.Done(this);
        }
    }
    public class ActionAirTacCoordReassignmentLoop : GamePhaseLoopLogic
    {
        public ActionAirTacCoordReassignmentLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionAirTacCoordReassignment("Reassignment", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOUNITS(GS, "ACTION.TACCOORDREASSIGN.NEEDED").Any();}
        public override void Init()
        {
            List<GO> objs = FS.SCENARIOUNITS(GS, "ACTION.TACCOORDREASSIGN.NEEDED");
            GO obj = objs.First();
            FS.SETSCENARIOOBJECTS(GS, "ACTION.TACCOORDREASSIGN", new List<GO>{obj});
            objs.Remove(obj);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.TACCOORDREASSIGN.NEEDED", objs);
        }
        public override void End()
        {
        }
    }
    public class ActionAirTacCoordReassignment : GamePhaseInteractive
    {
        GO activatedUnit = null;
        List<GO> TRACKEDSHIPS = new();
        string side = null;
        public ActionAirTacCoordReassignment(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                activatedUnit = FS.SCENARIOUNITS(GS, "ACTION.TACCOORDREASSIGN").First();    
                side = activatedUnit.SIDE;       
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"REASSIGN AFTER SPLIT"});

                GS.HELPTEXT = 
                "The units designated by a Tac Coordination air unit have split up.  Choose which surface stack to follow";  
                TRACKEDSHIPS = FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => n.TACCOORDPIECE == activatedUnit).ToList();
                foreach(GO obj in TRACKEDSHIPS){
                    obj.ADMINDETECTED = true;
                    GO parent = FS.LOGICALPARENT(obj);
                    parent.ADMINDETECTED = true;
                    if(!GS.InteractionMap.ContainsKey(obj)){
                        GS.InteractionMap.Add(obj, new());
                    }
                    if(!GS.InteractionMap.ContainsKey(parent)){
                        GS.InteractionMap.Add(parent, new());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "FOLLOW UNITS IN THIS HEX");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    foreach(GO obj in GS.InteractionMap.Keys){
                        obj.ADMINDETECTED = false;
                    }
                    GS.Done(this);
                    break;
                case "FOLLOW UNITS IN THIS HEX":
                    GO followLocation = FS.PARENTGROUPLOCATION(gp);
                    foreach(GO ship in GS.InteractionMap.Keys.Where(n => FS.PARENTGROUPLOCATION(n) == followLocation)){
                        ship.TACCOORDPIECEID = activatedUnit.ID;
                        ship.TACCOORDPIECE = activatedUnit;
                    }
                    foreach(GO ship in TRACKEDSHIPS.Where(n => FS.PARENTGROUPLOCATION(n) != followLocation)){
                        ship.TACCOORDPIECEID = null;
                    }
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
}