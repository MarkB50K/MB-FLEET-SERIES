using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Controls;
using System.Reflection.Metadata.Ecma335;
using System.Windows.Documents;
namespace CWApp.FS
{
    public class ActionCycle : GamePhaseGroupLogic
    {
        public ActionCycle(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new CAPAir("Allocate CAP", this, GS));
            AddGamePhase(new ReplenishmentBASE("At-Base Replenishment", this, GS));
            AddGamePhase(new ReplenishmentSEA("At-Sea Replenishment", this, GS));
            AddGamePhase(new Loading("Load Troops/Supplies", this, GS));
            AddGamePhase(new Unloading("UnLoad Troops/Supplies", this, GS));
            AddGamePhase(new LocalDetection("Local Detection", this, GS));
            AddGamePhase(new StrategicAirTacCoordinationLoop("Tactical Coordination", this, GS));
            AddGamePhase(new ActionGroupUnGroup("Pre-Action Phase Group Management", this, GS));
            AddGamePhase(new ActionSurfaceFullSpeed("High Speed", this, GS));
            AddGamePhase(new ActionRound("Loop", this, GS));
            AddGamePhase(new ActionSurfaceOverstacking("Overstacking", this, GS));
            AddGamePhase(new RemoveLocalDetection("Remove Local Detection", this, GS));
            AddGamePhase(new ActionGroupUnGroup("Post-Action Phase Group Management", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init()
        {
            Set("ACTIVE.SIDE1", Get("ACTIVE.SIDE"));
            FS.SIDE_NAMES.ForEach(n => SetBoolean("ACTION." + n, false));
            SetBoolean("ACTION.TACCOORD", false);
            SetInt("ACTION.ROUNDS", 0);
        }
        public override void End()
        {
            string report = "";
            foreach(GO obj in FS.CAPSQNS(GS, null)){
                obj.AIRMISSION = null;
                FS.RETURNTOHOMEBASE(obj);
                if(obj.DESTROYED){
                    report += obj.UNITTYPE + " " + obj.LABEL + " destroyed due to destroyed carrier or airfield\n";
                }
            }
            if(report != ""){
                MainWindow.Alert(report);
            }
        }
    }
    public class CAPAir : GamePhaseInteractive
    {
        string side = null;
        List<GO> ELIGIBLELIST = new();
        List<GO> CAPMISSIONS = new();
        public CAPAir(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                CAPMISSIONS.Clear();
                ELIGIBLELIST.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"ASSIGN AIR UNITS TO CAP"});
                GS.HELPTEXT = 
                "Allocate Air Units to CAP to the current Hex.  The game will enforce max 4 INT per airfield or carrier.\n\n" +
                "When done with your setup you can click the NEXT button.\n\n" +
                "NOTE: Due to complexity issues, this game will not use CAP markers.  The game will track all the units on CAP and consider all units in the same hex as on the same mission.  " + 
                "The physical game, using a marker to keep track of attacks left alot of loopholes when carriers are on the move and markers are breaking up and combining, so attacks are tracked per squadron, " + 
                "and the max number of attacks for a squadron in a stack is considered the stacks number.  Carrier based CAP squadrons will follow the ships as they move in the automated cycles";                
                foreach(GO obj in FS.TYPESIDE(GS, "SQN", side)){
                    if(!FS.CANLAUNCHCAP(obj)){continue;}
                    GS.InteractionMap.Add(obj, new());
                    ELIGIBLELIST.Add(obj);
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "ASSIGN TO CAP");
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                AI();
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        private void AI()
        {
            Dictionary<string, double> BEHAVIORFACTOR = new()
            {
                { "CAUTIOUS", 0.90},
                { "NORMAL", 0.80 },
                { "AGGRESSIVE", 0.40 }
            };
            Dictionary<string, double> UNITTYPEFACTOR = new()
            {
                { "INT", 0.70},
                { "AEW", 0.95 },
                { "EW", 0.50 }
            };
            List<GO> ASSIGNED = [];
            foreach (string ut in UNITTYPEFACTOR.Keys)
            {
                foreach (GO obj in GS.InteractionMap.Keys.Where(n => n.UNITTYPE == ut).OrderByDescending(n => n.TEMPLATE.CAA))
                {
                    if (GS.InteractionMap.ContainsKey(obj))
                    {
                        List<GO> possibleObjectives = [.. GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == obj)];
                        bool noObjectives = possibleObjectives.Count == 0;
                        double ESCORTFACTOR = 1;
                        switch (obj.UNITTYPE)
                        {
                            case "INT":
                                //look for BMB, ATK, and RCN in same hex
                                List<string> strings = new() { "BMB", "ATK", "RCN" }; //TODO: add more types
                                if (FS.TYPESIDELOCATION(GS, "SQN", side, obj.GAMELOCATIONID).Where(n => strings.Contains(n.UNITTYPE)).Any())
                                {
                                    ESCORTFACTOR *= 0.5;
                                }
                                if(ASSIGNED.Where(n => n.UNITTYPE == ut && n.GAMELOCATION == FS.PARENTGROUPLOCATION(obj)).Any())
                                {
                                    ESCORTFACTOR *= 0.5;
                                }
                                break;
                            case "AEW":
                                if (ASSIGNED.Where(n => n.UNITTYPE == ut && n.GAMELOCATION == FS.PARENTGROUPLOCATION(obj)).Any())
                                {
                                    ESCORTFACTOR *= 0.5;
                                }
                                break;
                            case "EW":
                                if (ASSIGNED.Where(n => n.UNITTYPE == ut && n.GAMELOCATION == FS.PARENTGROUPLOCATION(obj)).Any())
                                {
                                    ESCORTFACTOR *= 0.5;
                                }
                                if (!ASSIGNED.Where(n => n.GAMELOCATION == FS.PARENTGROUPLOCATION(obj)).Any())
                                {
                                    ESCORTFACTOR *= 0;
                                }
                                break;
                            default:
                                break;
                        }
                        double ASSIGN = ESCORTFACTOR * UNITTYPEFACTOR[obj.UNITTYPE] * BEHAVIORFACTOR[GS.AI_Behavior[FS.SIDE_MODE]];
                        if(obj.AIPRIMARYROLE == "CAP")
                        {
                            ASSIGN *= 1.25; //if primary role is CAP, increase chance
                        }
                        if (GS.RANDOMINT(100) <= ASSIGN * 100 || noObjectives)
                        {
                            ADDTOCAP(obj, FS.PARENTGROUPLOCATION(obj));
                            ASSIGNED.Add(obj);
                        }
                    }
                }
            }
        }
        private void ADDTOCAP(GO gp, GO presentLoc){
            if(gp.CARRIERID != null){
                //if homebase is carrier, and carrier is damaged, move all other air units out of IM
                if(gp.CARRIER.DAMAGED){
                    foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.CARRIER)){
                        GS.REMOVEINTERACTIVE(obj);
                    }
                }
                gp.HOMEBASEID = gp.CARRIERID;
                gp.HOMEBASE = gp.CARRIER;
                FS.REMOVEFROMGROUP(gp, gp.CARRIER);
            } else if(gp.HOMEBASEID == null){
                gp.HOMEBASEID = gp.GAMELOCATIONID;
                gp.HOMEBASE = gp.GAMELOCATION;
            }
            GS.CHANGELOCATION(gp, presentLoc);
            CAPMISSIONS.Add(gp);
            gp.AIRMISSION = "CAP";
            //if 4 INT from homebase are in this group, move all other air units out of IM
            if(CAPMISSIONS.Where(n => n.UNITTYPE == "INT" && n.HOMEBASE == gp.HOMEBASE).Count() == 4){
                foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.HOMEBASE && n.UNITTYPE == "INT")){
                    GS.REMOVEINTERACTIVE(obj);
                }
            }
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    //do detections on assigned CAP
                    if(side != Get("ACTIVE.SIDE1")){
                        FS.AIRDETECTION(GS, [], true);
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case "UNDO":
                    CAPMISSIONS.Remove(gp);
                    GO homeBase = gp.HOMEBASE;
                    if(homeBase != gp.GAMELOCATION){
                        //if homebase is carrier, and carrier is damaged, move all other air units back to interaction map
                        if(gp.HOMEBASE.DAMAGED){
                            foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.HOMEBASE)){
                                GS.InteractionMap.Add(obj, new());
                            }
                        //if now 3 INT from homebase are in this group, move all other air units back to IM
                        } else if(gp.UNITTYPE == "INT" && CAPMISSIONS.Where(n => n.UNITTYPE == "INT" && n.HOMEBASE == gp.HOMEBASE).Count() == 3){
                            foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.HOMEBASE && n.UNITTYPE == "INT")){
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                        FS.ADDTOGROUP(gp, homeBase);
                    }                    
                    gp.HOMEBASEID = null;
                    gp.AIRMISSION = null;
                    Start(false);
                    break;
                case "ASSIGN TO CAP":
                    ADDTOCAP(gp, FS.PARENTGROUPLOCATION(gp));
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ReplenishmentBASE : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, List<GO>> PORTREPLENISHMENTASSIGNMENTS = new();
        Dictionary<GO, List<GO>> AIRFIELDREPLENISHMENTASSIGNMENTS = new();
        bool SIDE_IS_AI = false;
        public ReplenishmentBASE(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                PORTREPLENISHMENTASSIGNMENTS.Clear();
                AIRFIELDREPLENISHMENTASSIGNMENTS.Clear();
                FS.SIDE_MODE = side;
                SIDE_IS_AI = GS.AI_Sides.Contains(FS.SIDE_MODE);
                FS.SETINSTRUCTIONS(GS, new(){"REPLENISH AT BASE"});
                GS.HELPTEXT = 
                "Replenishment, in-port.  The game enforces rules below:\n" + 
                "- Only docked ships can replenish\n" +
                "- Weather impacts.  No at-base replenishment in storm\n" +
                "- Max 4 ships can replenish at base per turn (max 1 CV or replenishment ship)\n" +
                "- CVs can replenish AIR SSM pts from port\n" +
                "- Damaged bases cannot replenish\n\n" +
                "NOTE: A configuration variable in the scenario file can be used to set when Cruise Missile reloads are available.  Every n turns, etc.\n\n" +
                "NOTE: Units giving or receiving replenishment will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Bases.                
                foreach(GO loc in FS.TYPESIDE(GS, "LOCATION", side).Where(n => (n.PORT || n.LOGSEA) && n.PORTDAMAGELEVEL == 0 && !FS.STORM(n))){
                    PORTREPLENISHMENTASSIGNMENTS.Add(loc, new());
                }
                //add airfields if CM reloads
                if(GetInt("CMRELOADS") > 0){
                    foreach(GO loc in FS.TYPESIDE(GS, "LOCATION", side).Where(n => (n.AIRFIELD || n.LOGAIR) && n.AIRFIELDDAMAGELEVEL == 0 && !FS.STORM(n))){
                        AIRFIELDREPLENISHMENTASSIGNMENTS.Add(loc, new());
                    }                
                    foreach(GO obj in FS.TYPESIDE(GS, "SQN", side).Where(n => n.ENROUTEDELAY == 0 &&
                        n.AIRMISSION == null &&
                        n.CMPTS < n.TEMPLATE.CMPTS)){
                        GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                        if(AIRFIELDREPLENISHMENTASSIGNMENTS.ContainsKey(locationToCheck)){
                            AIRFIELDREPLENISHMENTASSIGNMENTS[locationToCheck].Add(obj);
                            GS.InteractionMap.Add(obj, new());
                        }
                    }
                }                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => !FS.ISGROUP(n) && (n.DOCKED || SIDE_IS_AI) && n.ENROUTEDELAY == 0)){
                    if(obj.UNITCATEGORY == "SUB"){
                        if(PORTREPLENISHMENTASSIGNMENTS.ContainsKey(obj.GAMELOCATION)){
                            if( obj.SSMPTS < obj.TEMPLATE.SSMPTS ||
                                obj.SSM2PTS < obj.TEMPLATE.SSM2PTS ||
                                obj.TORPPTS < obj.TEMPLATE.TORPPTS ||
                                (obj.CMPTS < obj.TEMPLATE.CMPTS && obj.CMRELOADS < GetInt("CMRELOADS"))){

                                PORTREPLENISHMENTASSIGNMENTS[obj.GAMELOCATION].Add(obj);
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    } else { 
                        GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                        if(PORTREPLENISHMENTASSIGNMENTS.ContainsKey(locationToCheck)){
                            if( obj.FUELPTS < obj.TEMPLATE.FUELPTS ||
                                obj.SSMPTS < obj.TEMPLATE.SSMPTS ||
                                obj.SSM2PTS < obj.TEMPLATE.SSM2PTS ||
                                obj.ASWPTS < obj.TEMPLATE.ASWPTS ||
                                obj.AAPTS < obj.TEMPLATE.AAPTS ||
                                obj.BOMBPTS < obj.TEMPLATE.BOMBPTS ||
                                obj.AIRSSMPTS < obj.TEMPLATE.AIRSSMPTS ||
                                obj.APTS < obj.TEMPLATE.APTS ||
                                obj.FPTS < obj.TEMPLATE.FPTS ||
                                (obj.CMPTS < obj.TEMPLATE.CMPTS && obj.CMRELOADS < GetInt("CMRELOADS"))){
                                
                                PORTREPLENISHMENTASSIGNMENTS[locationToCheck].Add(obj);
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    }
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys.ToList()){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "REPLENISH");
                if(obj.SIDE == "SOV")
                {
                    if(obj.TEMPLATE.TORPPTS >= 3)
                    {
                        GS.AddAction(obj, "REPLENISH AND LOAD MINES");
                    }
                    if (obj.TEMPLATE.TORPPTS >= 1)
                    {
                        GS.AddAction(obj, "REPLENISH AND LOAD COMMANDOS");
                    }
                    if (obj.TEMPLATE.TORPPTS >= 4)
                    {
                        GS.AddAction(obj, "REPLENISH AND LOAD MINES AND COMMANDOS");
                    }
                }
                else
                {
                    if (obj.TEMPLATE.TORPPTS >= 1)
                    {
                        GS.AddAction(obj, "REPLENISH AND LOAD COMMANDOS");
                    }
                }
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                AI();
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        private void AI()
        {
            foreach(GO gp in GS.InteractionMap.Keys)
            {
                GO replenishmentBase = FS.PARENTGROUPLOCATION(gp);
                GO actualUnit = FS.LOGICALPARENT(gp);
                GO LOGICLINK = GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == actualUnit && n.ACTIVE).FirstOrDefault();
                if(LOGICLINK == null){
                    continue;
                }
                bool ATFOCUS = actualUnit.GAMELOCATION == LOGICLINK.AIFOCUSLOCATION;
                if (LOGICLINK.LOGIC.OBJECTIVETYPE != "REPLENISH" || !ATFOCUS)
                {
                    continue;
                }
                if(replenishmentBase.REPLENISHMENTPTSUSED == 4){
                    continue;
                }
                if(gp.UNITCATEGORY == "SHIP" && (gp.TEMPLATE.APTS > 0 || gp.TEMPLATE.FPTS > 0) && replenishmentBase.LARGEUNITREPLENISHED){
                    continue;
                }
                replenishmentBase.REPLENISHMENTPTSUSED++;
                gp.REPLENISHING = true;
                if(gp.UNITCATEGORY == "AIR"){
                    int numCM = Math.Min(GetInt("CMRELOADS") - gp.CMRELOADS, gp.TEMPLATE.CMPTS - gp.CMPTS);
                    gp.CMPTS += numCM;
                    gp.CMRELOADS += numCM;
                } else {
                    FS.GROUPSANDMEMBERS([FS.LOGICALPARENT(gp)]).ForEach(n => n.DOCKED = true);
                    bool mines = false;
                    bool commandos = false;
                    if (gp.TEMPLATE.APTS > 0 || gp.TEMPLATE.FPTS > 0){replenishmentBase.LARGEUNITREPLENISHED = true;}
                    int numCM = Math.Min(GetInt("CMRELOADS") - gp.CMRELOADS, gp.TEMPLATE.CMPTS - gp.CMPTS);
                    gp.CMPTS += numCM;
                    gp.CMRELOADS += numCM;
                    gp.FUELPTS = gp.TEMPLATE.FUELPTS;
                    gp.SSMPTS = gp.TEMPLATE.SSMPTS;
                    gp.SSM2PTS = gp.TEMPLATE.SSM2PTS;
                    gp.ASWPTS = gp.TEMPLATE.ASWPTS;
                    gp.AAPTS = gp.TEMPLATE.AAPTS;
                    gp.TORPPTS = gp.TEMPLATE.TORPPTS;
                    gp.BOMBPTS = gp.TEMPLATE.BOMBPTS;
                    gp.AIRSSMPTS = gp.TEMPLATE.AIRSSMPTS;
                    gp.APTS = gp.TEMPLATE.APTS;
                    gp.FPTS = gp.TEMPLATE.FPTS;
                    if(mines){
                        gp.MINEPTS = 1;
                        gp.TORPPTS -= 3;
                    }
                    if (commandos)
                    {
                        gp.COMMANDOPTS = 1;
                        gp.TORPPTS -= 1;
                    }
                }
            }
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    foreach(GO loc in AIRFIELDREPLENISHMENTASSIGNMENTS.Keys){
                        loc.REPLENISHMENTPTSUSED = 0;
                        loc.LARGEUNITREPLENISHED = false;
                    }
                    foreach(GO loc in PORTREPLENISHMENTASSIGNMENTS.Keys){
                        loc.REPLENISHMENTPTSUSED = 0;
                        loc.LARGEUNITREPLENISHED = false;
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case "REPLENISH":
                case "REPLENISH AND LOAD MINES":
                case "REPLENISH AND LOAD COMMANDOS":
                case "REPLENISH AND LOAD MINES AND COMMANDOS":
                    GO replenishmentBase = FS.PARENTGROUPLOCATION(gp);
                    replenishmentBase.REPLENISHMENTPTSUSED++;
                    gp.REPLENISHING = true;
                    if(gp.UNITCATEGORY == "AIR"){
                        int numCM = Math.Min(GetInt("CMRELOADS") - gp.CMRELOADS, gp.TEMPLATE.CMPTS - gp.CMPTS);
                        gp.CMPTS += numCM;
                        gp.CMRELOADS += numCM;
                        //once we reach 4 no more from this base
                        if(replenishmentBase.REPLENISHMENTPTSUSED == 4){
                            foreach(GO obj in AIRFIELDREPLENISHMENTASSIGNMENTS[replenishmentBase].Where(n => n != gp)){
                                GS.REMOVEINTERACTIVE(obj);
                            }
                        }
                        GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    } else {
                        bool mines = pData.Contains("MINES");
                        bool commandos = pData.Contains("COMMANDOS");
                        if (gp.TEMPLATE.APTS > 0 || gp.TEMPLATE.FPTS > 0){replenishmentBase.LARGEUNITREPLENISHED = true;}
                        int numCM = Math.Min(GetInt("CMRELOADS") - gp.CMRELOADS, gp.TEMPLATE.CMPTS - gp.CMPTS);
                        gp.CMPTS += numCM;
                        gp.CMRELOADS += numCM;
                        gp.FUELPTS = gp.TEMPLATE.FUELPTS;
                        gp.SSMPTS = gp.TEMPLATE.SSMPTS;
                        gp.SSM2PTS = gp.TEMPLATE.SSM2PTS;
                        gp.ASWPTS = gp.TEMPLATE.ASWPTS;
                        gp.AAPTS = gp.TEMPLATE.AAPTS;
                        gp.TORPPTS = gp.TEMPLATE.TORPPTS;
                        gp.BOMBPTS = gp.TEMPLATE.BOMBPTS;
                        gp.AIRSSMPTS = gp.TEMPLATE.AIRSSMPTS;
                        gp.APTS = gp.TEMPLATE.APTS;
                        gp.FPTS = gp.TEMPLATE.FPTS;
                        if(mines){
                            gp.MINEPTS = 1;
                            gp.TORPPTS -= 3;
                        }
                        if (commandos)
                        {
                            gp.COMMANDOPTS = 1;
                            gp.TORPPTS -= 1;
                        }
                        //once we do a large no more large from this base
                        if(replenishmentBase.LARGEUNITREPLENISHED){
                            foreach(GO obj in PORTREPLENISHMENTASSIGNMENTS[replenishmentBase].Where(n => n != gp && (n.TEMPLATE.APTS > 0 || n.TEMPLATE.FPTS > 0))){
                                GS.REMOVEINTERACTIVE(obj);
                            }
                        }
                        //once we reach 4 no more from this base
                        if(replenishmentBase.REPLENISHMENTPTSUSED == 4){
                            foreach(GO obj in PORTREPLENISHMENTASSIGNMENTS[replenishmentBase].Where(n => n != gp)){
                                GS.REMOVEINTERACTIVE(obj);
                            }
                        }
                        GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    }
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ReplenishmentSEA : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, List<GO>> FUELREPLENISHMENTASSIGNMENTS = new();
        Dictionary<GO, List<GO>> AMMOREPLENISHMENTASSIGNMENTS = new();
        public ReplenishmentSEA(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FUELREPLENISHMENTASSIGNMENTS.Clear();
                AMMOREPLENISHMENTASSIGNMENTS.Clear();
                FS.SIDE_MODE = side;
                if (GS.AI_Sides.Contains(FS.SIDE_MODE))
                {
                    AI();
                    Update("NEXT");
                    return;
                }
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE REPLENISHMENT OPTIONS"});
                GS.HELPTEXT = 
                "Replenishment, at-sea.  The game enforces rules below:\n" + 
                "- If a ship can replenish a certain type of ammo at-sea\n" +
                "- Weather impacts.  No at-sea in squall.\n" +
                "- Max total of 6 AP/FP pts a replenishment ship can provide in one phase.\n" +
                "- Use of BBs and US CVs as oilers\n" +
                "- Subs cannot replenish at sea.\n\n" +
                "NOTE: Units giving or receiving replenishment will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Ships.                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.ENROUTEDELAY == 0 && !n.DOCKED && !n.REPLENISHING && Get(n.GAMELOCATION.ZONE + ".WEATHER") == "CLEAR" &&
                    (n.FPTS > 0 || n.APTS > 0))){
                        
                    if(obj.FPTS > 0){
                        FUELREPLENISHMENTASSIGNMENTS.Add(obj, new());
                    }
                    if(obj.APTS > 0){
                        AMMOREPLENISHMENTASSIGNMENTS.Add(obj, new());
                    }
                }
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.UNITCATEGORY == "SURFACE" && n.ENROUTEDELAY == 0 && !n.DOCKED && !n.REPLENISHING)){
                    GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                    foreach(GO replenishment in FUELREPLENISHMENTASSIGNMENTS.Keys.Where(n => FS.PARENTGROUPLOCATION(n) == locationToCheck)){                                
                        if( (obj.FUELPTS < obj.TEMPLATE.FUELPTS && replenishment.FPTS > 0) ||
                            (obj.FPTS < obj.TEMPLATE.FPTS && replenishment.FPTS > 0)){
                            
                            FUELREPLENISHMENTASSIGNMENTS[replenishment].Add(obj);
                            if(!GS.InteractionMap.ContainsKey(obj)){
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    }
                    foreach(GO replenishment in AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => FS.PARENTGROUPLOCATION(n) == locationToCheck)){                                
                        if( (!obj.TEMPLATE.SSMPORTONLY && obj.SSMPTS < obj.TEMPLATE.SSMPTS && replenishment.APTS > 0) ||
                            (!obj.TEMPLATE.SSM2PORTONLY && obj.SSM2PTS < obj.TEMPLATE.SSM2PTS && replenishment.APTS > 0) ||
                            (obj.ASWPTS < obj.TEMPLATE.ASWPTS && replenishment.APTS > 0) ||
                            (obj.AAPTS < obj.TEMPLATE.AAPTS && replenishment.APTS > 0) ||
                            (obj.BOMBPTS < obj.TEMPLATE.BOMBPTS && replenishment.APTS > 0) ||
                            (obj.AIRSSMPTS < obj.TEMPLATE.AIRSSMPTS && replenishment.APTS > 0) ||
                            (obj.APTS < obj.TEMPLATE.APTS && replenishment.APTS > 0)){
                            
                            AMMOREPLENISHMENTASSIGNMENTS[replenishment].Add(obj);
                            if(!GS.InteractionMap.ContainsKey(obj)){
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    }
                }
            }
            //for FP, can replenish all FUELPTS on a single ship
            //for FP, can replenish one FPT on a single ship
            //for AP, can replenish all non BOMB ammo
            //for AP, can replenish 1 BOMB pt
            //for AP, can replenish 1 AP pt 
            foreach(GO obj in GS.InteractionMap.Keys.ToList()){
                //check if obj is still in any assignment group
                Boolean presentInGroup = false;
                foreach(GO replenishment in FUELREPLENISHMENTASSIGNMENTS.Keys.Where(n => FUELREPLENISHMENTASSIGNMENTS[n].Contains(obj))){
                    presentInGroup = true;

                    GS.AddAction(obj, "FUEL/FP FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                }                    
                foreach(GO replenishment in AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => AMMOREPLENISHMENTASSIGNMENTS[n].Contains(obj))){
                    presentInGroup = true;
                    if( (!obj.TEMPLATE.SSMPORTONLY && obj.SSMPTS < obj.TEMPLATE.SSMPTS && replenishment.APTS > 0) ||
                        (!obj.TEMPLATE.SSM2PORTONLY && obj.SSM2PTS < obj.TEMPLATE.SSM2PTS && replenishment.APTS > 0) ||
                        (obj.ASWPTS < obj.TEMPLATE.ASWPTS && replenishment.APTS > 0) ||
                        (obj.AAPTS < obj.TEMPLATE.AAPTS && replenishment.APTS > 0) ||
                        (obj.AIRSSMPTS < obj.TEMPLATE.AIRSSMPTS && replenishment.APTS > 0)){

                        GS.AddAction(obj, "AMMO FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                    }

                    if( obj.BOMBPTS < obj.TEMPLATE.BOMBPTS && replenishment.APTS > 0){
                        GS.AddAction(obj, "1 BOMB PT FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                    }
                    if( obj.APTS < obj.TEMPLATE.APTS && replenishment.APTS > 0){
                        GS.AddAction(obj, "1 AP FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                    }
                }
                GS.AddAction(obj, "END PHASE");
                if (!presentInGroup){
                    GS.InteractionMap.Remove(obj);
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        private void AI()
        {
            List<GO> GROUPSWITHREPLENISHERS = [.. FS.TYPESIDE(GS, "SHIP", side).Where(n =>
                n.GROUPID != null &&
                n.ENROUTEDELAY == 0 &&
                !n.DOCKED &&
                !n.REPLENISHING &&
                Get(n.GAMELOCATION.ZONE + ".WEATHER") == "CLEAR" &&
                (n.FPTS > 0 || n.APTS > 0)).Select(n => n.GROUP).Distinct()];

            foreach (GO group in GROUPSWITHREPLENISHERS)
            {
                GO replenishmentBase = group.GAMELOCATION;
                GO LOGICLINK = GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == group && n.ACTIVE).FirstOrDefault();
                bool ATFOCUS = LOGICLINK == null ? false : group.GAMELOCATION == LOGICLINK.AIFOCUSLOCATION;
                if (ATFOCUS)
                {
                    continue;
                }
                List<GO> gms = FS.GROUPMEMBERS(group);
                List<GO> APTS = [.. gms.Where(n => n.APTS > 0)];
                List<GO> FPTS = [.. gms.Where(n => n.FPTS > 0)];
                foreach (GO gp in gms)
                {
                    bool APTSAVAILABLE = APTS.Where(n => n != gp).Any();
                    bool FPTSAVAILABLE = FPTS.Where(n => n != gp).Any();
                    List<string> OPTIONS = [];
                    if(gp.TEMPLATE.FUELPTS > 0 && gp.FUELPTS == 0 && FPTSAVAILABLE)
                    {
                        OPTIONS.Add("FUEL");
                    }
                    if (gp.TEMPLATE.FPTS > 0 && gp.FPTS == 0 && FPTSAVAILABLE)
                    {
                        OPTIONS.Add("FP");
                    }
                    if (APTSAVAILABLE) {
                        bool ZEROAMMO = false;
                        int NEEDAMMOCOUNT = 0;
                        if(!gp.TEMPLATE.SSMPORTONLY && gp.SSMPTS < gp.TEMPLATE.SSMPTS)
                        {
                            NEEDAMMOCOUNT++;
                            if(gp.SSMPTS == 0)
                            {
                                ZEROAMMO = true;
                            }
                        }
                        if(!gp.TEMPLATE.SSM2PORTONLY && gp.SSM2PTS < gp.TEMPLATE.SSM2PTS)
                        {
                            NEEDAMMOCOUNT++;
                            if (gp.SSM2PTS == 0)
                            {
                                ZEROAMMO = true;
                            }
                        }
                        if(gp.ASWPTS < gp.TEMPLATE.ASWPTS)
                        {
                            NEEDAMMOCOUNT++;
                            if (gp.ASWPTS == 0)
                            {
                                ZEROAMMO = true;
                            }
                        }
                        if(gp.AAPTS < gp.TEMPLATE.AAPTS)
                        {
                            NEEDAMMOCOUNT++;
                            if (gp.AAPTS == 0)
                            {
                                ZEROAMMO = true;
                            }
                        }
                        if(gp.AIRSSMPTS < gp.TEMPLATE.AIRSSMPTS)
                        {
                            NEEDAMMOCOUNT++;
                            if (gp.AIRSSMPTS == 0)
                            {
                                ZEROAMMO = true;
                            }
                        }
                        if (ZEROAMMO)
                        {
                            for (int i = 0; i < NEEDAMMOCOUNT; i++)
                            {
                                OPTIONS.Add("AMMO");
                            }
                        }
                        if (gp.BOMBPTS < gp.TEMPLATE.BOMBPTS && gp.BOMBPTS == 0)
                        {
                            OPTIONS.Add("BOMB");
                        }
                        if (gp.APTS < gp.TEMPLATE.APTS && gp.APTS == 0)
                        {
                            OPTIONS.Add("AP");
                        }
                    }
                    if(OPTIONS.Count > 0)
                    {
                        gp.REPLENISHING = true;
                        string OPTION = OPTIONS[GS.RANDOMINT(OPTIONS.Count)];
                        switch (OPTION)
                        {
                            case "FUEL":
                                GO replenishmentShip = FPTS.Where(n => n.FPTS > 0 && n.REPLENISHMENTPTSUSED < 6 && n != gp).FirstOrDefault();
                                if(replenishmentShip != null)
                                {
                                    replenishmentShip.REPLENISHMENTPTSUSED++;
                                    replenishmentShip.REPLENISHING = true;
                                    gp.FUELPTS = gp.TEMPLATE.FUELPTS;
                                    replenishmentShip.FPTS--;
                                }
                                break;
                            case "FP":
                                replenishmentShip = FPTS.Where(n => n.FPTS > 0 && n.REPLENISHMENTPTSUSED < 6 && n != gp).FirstOrDefault();
                                if (replenishmentShip != null)
                                {
                                    replenishmentShip.REPLENISHMENTPTSUSED++;
                                    replenishmentShip.REPLENISHING = true;
                                    gp.FPTS++;
                                    replenishmentShip.FPTS--;
                                }
                                break;
                            case "AMMO":
                                replenishmentShip = APTS.Where(n => n.APTS > 0 && n.REPLENISHMENTPTSUSED < 6 && n != gp).FirstOrDefault();
                                if (replenishmentShip != null)
                                {
                                    replenishmentShip.REPLENISHMENTPTSUSED++;
                                    replenishmentShip.REPLENISHING = true;
                                    if (!gp.TEMPLATE.SSMPORTONLY)
                                    {
                                        gp.SSMPTS = gp.TEMPLATE.SSMPTS;
                                    }
                                    if (!gp.TEMPLATE.SSM2PORTONLY)
                                    {
                                        gp.SSM2PTS = gp.TEMPLATE.SSM2PTS;
                                    }
                                    gp.ASWPTS = gp.TEMPLATE.ASWPTS;
                                    gp.AAPTS = gp.TEMPLATE.AAPTS;
                                    gp.AIRSSMPTS = gp.TEMPLATE.AIRSSMPTS;
                                    replenishmentShip.APTS--;
                                }
                                break;
                            case "AP":
                                replenishmentShip = APTS.Where(n => n.APTS > 0 && n.REPLENISHMENTPTSUSED < 6 && n != gp).FirstOrDefault();
                                if (replenishmentShip != null)
                                {
                                    replenishmentShip.REPLENISHMENTPTSUSED++;
                                    replenishmentShip.REPLENISHING = true;
                                    gp.APTS++;
                                    replenishmentShip.APTS--;
                                }
                                break;
                            case "BOMB":
                                replenishmentShip = APTS.Where(n => n.APTS > 0 && n.REPLENISHMENTPTSUSED < 6 && n != gp).FirstOrDefault();
                                if (replenishmentShip != null)
                                {
                                    replenishmentShip.REPLENISHMENTPTSUSED++;
                                    replenishmentShip.REPLENISHING = true;
                                    gp.BOMBPTS++;
                                    replenishmentShip.APTS--;
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case null:
                    Start(false);
                    break;
                case "NEXT":
                    foreach(GO obj in FUELREPLENISHMENTASSIGNMENTS.Keys){
                        obj.REPLENISHMENTPTSUSED = 0;
                    }
                    foreach(GO obj in AMMOREPLENISHMENTASSIGNMENTS.Keys){
                        obj.REPLENISHMENTPTSUSED = 0;
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                default:
                    gp.REPLENISHING = true;
                    string rID = null;
                    GO replenishmentShip = null;
                    if(pData.StartsWith("FUEL/FP FROM : ")){
                        rID = pData.Replace("FUEL/FP FROM : ", "");
                        replenishmentShip = FUELREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            FUELREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        if(gp.TEMPLATE.FPTS > 0){
                            gp.FPTS++;
                        } else {
                            gp.FUELPTS = gp.TEMPLATE.FUELPTS;
                        }
                        replenishmentShip.FPTS--;
                    } else if(pData.StartsWith("AMMO FROM : ")){
                        rID = pData.Replace("AMMO FROM : ", "");
                        replenishmentShip = AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            AMMOREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        if(!gp.TEMPLATE.SSMPORTONLY){
                            gp.SSMPTS = gp.TEMPLATE.SSMPTS;
                        }
                        if(!gp.TEMPLATE.SSM2PORTONLY){
                            gp.SSM2PTS = gp.TEMPLATE.SSM2PTS;
                        }
                        gp.ASWPTS = gp.TEMPLATE.ASWPTS;
                        gp.AAPTS = gp.TEMPLATE.AAPTS;
                        gp.AIRSSMPTS = gp.TEMPLATE.AIRSSMPTS;
                        replenishmentShip.APTS--;
                    } else if(pData.StartsWith("1 BOMB PT FROM : ")){
                        rID = pData.Replace("1 BOMB PT FROM : ", "");
                        replenishmentShip = AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            AMMOREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        gp.BOMBPTS++;
                        replenishmentShip.APTS--;
                    } else if(pData.StartsWith("1 AP FROM : ")){
                        rID = pData.Replace("1 AP FROM : ", "");
                        replenishmentShip = AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            AMMOREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        gp.APTS++;
                        replenishmentShip.APTS--;
                    }
                    if(AMMOREPLENISHMENTASSIGNMENTS.ContainsKey(replenishmentShip) && (replenishmentShip.APTS == 0 || replenishmentShip.REPLENISHMENTPTSUSED == 6)){
                        AMMOREPLENISHMENTASSIGNMENTS[replenishmentShip].Clear();
                    }
                    if(FUELREPLENISHMENTASSIGNMENTS.ContainsKey(replenishmentShip) && (replenishmentShip.FPTS == 0 || replenishmentShip.REPLENISHMENTPTSUSED == 6)){
                        FUELREPLENISHMENTASSIGNMENTS[replenishmentShip].Clear();
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);               
                    Start(false);
                    break;
            }
        }
    }
    public class Loading : GamePhaseInteractive
    {
        string side = null;
        public Loading(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"LOAD SHIPS"});
                GS.HELPTEXT = 
                "LOADING TROOPS/CARGO\n\n" + 
                "- Only docked ships can load\n" +
                "- Troops can be loaded in storms.  Supplies cannot\n" +
                "- Troops can be loaded from damaged bases.  Supplies cannot\n\n" +
                "NOTE: A configuration variable in the scenario file can be used to track troops/supplies at bases.  Currently it is set to FALSE and the logic to establish starting levels at locations is not built yet, so leave FALSE for now\n\n" +
                "NOTE: Units loading/unloading will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Bases.                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(FS.CANSHIPLOAD)){                            
                    GS.InteractionMap.Add(obj, new());
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys.ToList()){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "LOAD");
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case "LOAD":
                    gp.LOADING = true;
                    gp.EMPTY = false;                    
                    GO replenishmentBase = FS.PARENTGROUPLOCATION(gp);
                    bool cargo = FS.SURFACECARGOTYPES.Contains(gp.UNITTYPE);
                    if (FS.LANDWAR){
                        GO logisticalZone = GS.TYPE("POSSESSIONFLAG").Where(n => n.LOGISTICALZONE == replenishmentBase.LOGISTICALZONE).Single();
                        if(cargo){
                            logisticalZone.SUPPLIES -= gp.TEMPLATE.SPECIAL;
                        } else {
                            logisticalZone.STRENGTH -= gp.TEMPLATE.SPECIAL;
                        }                        
                    }
                    else if (FS.GARRISONWAR)
                    {
                        //find facility
                        GO facility = FS.TYPESIDELOCATION(GS, "FACILITY", gp.SIDE, replenishmentBase.ID).Where(n => n.PORT).First();
                        facility.STRENGTH -= gp.TEMPLATE.SPECIAL;
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class Unloading : GamePhaseInteractive
    {
        string side = null;
        public Unloading(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"UNLOAD SHIPS"});
                GS.HELPTEXT = 
                "UNLOADING TROOPS/CARGO\n\n" + 
                "- Troops can be unloaded in storms.  Supplies cannot\n\n" +
                "*Units loading/unloading will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Bases.                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(FS.CANSHIPUNLOAD)){                            
                    GS.InteractionMap.Add(obj, new());                    
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys.ToList()){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "UNLOAD");
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case "UNLOAD":
                    GO unloadingPort = FS.PARENTGROUPLOCATION(gp);
                    gp.LOADING = true;
                    gp.EMPTY = true;
                    if (FS.LANDWAR)
                    {
                        //find logistical zone marker
                        GO logisticalZone = FS.TYPESIDE(GS, "POSSESSIONFLAG", unloadingPort.SIDE).Where(n => n.LOGISTICALZONE == unloadingPort.LOGISTICALZONE).Single();
                        if (FS.SURFACECARGOTYPES.Contains(gp.UNITTYPE))
                        {
                            logisticalZone.SUPPLIES += gp.TEMPLATE.SPECIAL;
                        }
                        else
                        {
                            logisticalZone.STRENGTH += gp.TEMPLATE.SPECIAL;
                        }
                    }
                    else if (FS.GARRISONWAR)
                    {
                        //find facility
                        GO facility = FS.TYPESIDELOCATION(GS, "FACILITY", gp.SIDE, unloadingPort.ID).Where(n => n.PORT).First();
                        facility.STRENGTH += gp.TEMPLATE.SPECIAL;
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class LocalDetection : GamePhaseAutomated
    {
        public LocalDetection(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            List<GO> UNDESTROYEDBASES = [];
            List<GO> UNDESTROYEDCDS = [];
            foreach (string s in FS.SIDE_NAMES)
            {
                UNDESTROYEDBASES.AddRange(FS.TYPESIDE(GS, "FACILITY", s).Where(n => ((n.PORT && !n.PORTDESTROYED) || (n.AIRFIELD && !n.AIRFIELDDESTROYED))));
                UNDESTROYEDCDS.AddRange(FS.TYPESIDE(GS, "CLOSEDEFENSE", s).Where(n => !n.CLOSEDEFENSEDESTROYED));
            }
            Dictionary<GO, List<List<GO>>> DetectionRadius = FS.DETECTIONRADIUSTABLE(GS);
            Dictionary<string, List<GO>> BASETABLE = [];
            Dictionary<string, List<GO>> CDTABLE = [];
            Dictionary<string, List<GO>> DETECTORTABLE = [];
            foreach(string s in FS.SIDE_NAMES)
            {
                BASETABLE.Add(s, [..UNDESTROYEDBASES.Where(n => n.SIDE == FS.ENEMY(s)).Select(n => n.GAMELOCATION)]);
                CDTABLE.Add(s, [.. UNDESTROYEDCDS.Where(n => n.SIDE == FS.ENEMY(s)).Select(n => n.GAMELOCATION)]);
                DETECTORTABLE.Add(s, [..DetectionRadius.Keys.Where(n => n.SIDE == FS.ENEMY(s))]);
            }
            //now detect
            foreach(GO obj in DetectionRadius.Keys){
                GO loc = FS.PARENTGROUPLOCATION(obj);
                bool adjacentToBase = FS.FINDAIRRADIUS(loc, 1).Intersect(BASETABLE[obj.SIDE]).Any() || CDTABLE[obj.SIDE].Contains(loc);
                if(adjacentToBase){
                    List<GO> detected = FS.ALLSHIPSINHEX(obj.SIDE, loc, true, false);
                    FS.STRATDETECT(detected, true);
                }
                if(obj.LOCALDETECTED){continue;}
                if(obj.UNITCATEGORY == "SURFACE"){
                    if (DETECTORTABLE[obj.SIDE].Where(n => DetectionRadius[n][1].Contains(loc)).Any()){
                        List<GO> detected = FS.ALLSHIPSINHEX(obj.SIDE, loc, true, false);
                        FS.LOCALDETECT(detected, true);
                        FS.CREATEALERT(detected.Where(n => n.GAMELOCATION == loc).First(), null, FS.ENEMY(obj.SIDE));
                    }
                } else {
                    List<GO> detectors = DETECTORTABLE[obj.SIDE].Where(n => DetectionRadius[n][2].Contains(loc)).ToList();
                    if(detectors.Sum(n => n.TEMPLATE?.ASW ?? 0) >= 6){
                        if(FS.SUBDETECTIONRESULT(obj, "LOCALDETECT", null, detectors) == "D"){
                            FS.LOCALDETECT(new(){obj}, true);
                            FS.CREATEALERT(obj, null, FS.ENEMY(obj.SIDE));
                        }
                    }
                }
            }
            GS.Done(this);
        }
    }
    public class StrategicAirTacCoordinationLoop : GamePhaseLoop
    {
        public StrategicAirTacCoordinationLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new StrategicAirTacCoordination("Assignment", this, GS));
            AddGamePhase(new StrategicAirTacCoordinationChoice("Choose Target", this, GS));
            
        }
        public override Boolean ProcessCheck(){return !GetBoolean("ACTION.TACCOORD");}
    }
    public class StrategicAirTacCoordination : GamePhaseInteractive
    {
        string side = null;
        public StrategicAirTacCoordination(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            DragDrop = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG AIR UNIT TO TARGET HEX"});

                GS.HELPTEXT = 
                "Perform tactical coordination missions.  In this phase, drag eligible air units to detected enemy surface stacks or individual submarines in the aircraft's zone.\n\n" + 
                "For subs, the mission will be limited to a single sub, and the game will ask you to choose which sub, if there are multiple in the hex.\n" + 
                "-To assign to a submarine, the aircraft to have an ASW factor > 0\n" + 
                "-Enemy units within 4 hexes of friendly INT on non-damaged airfield will not be selectable\n\n" +
                "NOTE: After assigning the aircraft to a mission, instead of the air unit following the enemy around, the enemy units will have a black indicator on the left side of the marker to show the unit is the target of a tac coord mission.\n" +
                "NOTE: When selecting a unit, available locations on the map will have an indicator."; 
                List<GO> missionSQNs = FS.TYPESIDE(GS, "SQN", side).Where(n => n.GAMELOCATION.AIRMISSION == "STRATTACCOORD").ToList();
                List<string> missionZones = missionSQNs.Select(n => n.GAMELOCATION.ZONE).Distinct().ToList();
                //detected enemy
                List<GO> detectedEnemy = FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => (n.STRATDETECTED || n.LOCALDETECTED) && n.TACCOORDPIECEID == null).ToList();
                List<GO> missionLocs = detectedEnemy.Select(n => n.GAMELOCATION).Where(n => missionZones.Contains(n.ZONE)).Distinct().ToList();
                List<GO> missionLocsNoASW = detectedEnemy.Where(n => n.UNITCATEGORY == "SURFACE").Select(n => n.GAMELOCATION).Where(n => missionZones.Contains(n.ZONE)).Distinct().ToList();
                //find INTs on non-damaged airfields 
                List<GO> enemyINTLocations = new(); 
                foreach(GO obj in FS.TYPESIDE(GS, "SQN", FS.ENEMY(side)).Where(n =>
                n.UNITTYPE == "INT" && 
                n.ENROUTEDELAY == 0 &&
                (n.GAMELOCATION.AIRFIELD || n.HOMEBASE?.AIRFIELD == true) &&
                !(n.GAMELOCATION.AIRFIELDDAMAGELEVEL > 0 || n.HOMEBASE?.AIRFIELDDAMAGELEVEL > 0))){
                    enemyINTLocations.Add(FS.PARENTGROUPLOCATION(obj));
                }
                enemyINTLocations = enemyINTLocations.Distinct().ToList();
                foreach(GO loc in missionLocs.ToList()){
                    if(FS.FINDAIRRADIUS(loc, 4).Intersect(enemyINTLocations).Any()){
                        missionLocs.Remove(loc);
                        missionLocsNoASW.Remove(loc);
                    }
                }
                foreach(GO obj in missionSQNs){
                    if(obj.TEMPLATE.ASW > 0){
                        GS.InteractionMap.Add(obj, missionLocs.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList());
                    } else {
                        GS.InteractionMap.Add(obj, missionLocsNoASW.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if (side != Get("ACTIVE.SIDE1")) 
                    { 
                        SetBoolean("ACTION.TACCOORD", true); 
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, GS.TYPE("STRATRTBLOCATION", "ZONE", oldloc.ZONE).Single());
                        GO newloc = GS.LOCATION(gp.TEMPLOCATIONID);
                        Set("ACTION.TACCOORD.LOCATION", newloc.ID);
                        Set("ACTION.TACCOORD.UNIT", gp.ID);
                        GS.Done(this);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class StrategicAirTacCoordinationChoice : GamePhaseInteractive
    {
        GO activatedUnit = null;
        string side = null;
        public StrategicAirTacCoordinationChoice(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                string activatedUnitId = Get("ACTION.TACCOORD.UNIT");
                if(activatedUnitId == null){
                    Update("NEXT");
                    return;
                }
                activatedUnit = GS.PIECE(activatedUnitId);              
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE TARGET"});

                GS.HELPTEXT = 
                "Choose which marker to assign the Tac Coordination air unit to.  Submarines are tracked individually.  Surface are tracked per hex, so all will be assigned.";  
                //detected enemy
                List<GO> detectedEnemy = FS.TYPESIDELOCATION(GS, "SHIP", FS.ENEMY(side), Get("ACTION.TACCOORD.LOCATION")).Where(n => (n.STRATDETECTED || n.LOCALDETECTED) && n.TACCOORDPIECE == null).ToList();
                List<GO> surfaceChoices = detectedEnemy.Where(n => n.UNITCATEGORY == "SURFACE").ToList();
                List<GO> subChoices = activatedUnit.TEMPLATE.ASW > 0 ? detectedEnemy.Where(n => n.UNITCATEGORY == "SUB").ToList() : new();

                if(surfaceChoices.Any() && !subChoices.Any()){
                    foreach(GO ship in surfaceChoices){
                        ship.TACCOORDPIECEID = activatedUnit.ID;
                        ship.TACCOORDPIECE = activatedUnit;
                    }
                } else if(!surfaceChoices.Any() && subChoices.Count == 1){
                    GO ship = subChoices.First();
                    ship.TACCOORDPIECEID = activatedUnit.ID;
                    ship.TACCOORDPIECE = activatedUnit;
                } else {
                    foreach(GO ship in surfaceChoices){
                        GS.InteractionMap.Add(ship, new());
                    }
                    foreach(GO ship in subChoices){
                        GS.InteractionMap.Add(ship, new());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.UNITCATEGORY == "SUB"){
                    GS.AddAction(obj, "ASSIGN TO THIS SUB");
                } else {
                    GS.AddAction(obj, "ASSIGN TO ALL SURFACE UNITS IN THIS HEX");
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    Set("ACTION.TACCOORD.UNIT", null);
                    Set("ACTION.TACCOORD.LOCATION", null);
                    if(activatedUnit != null){
                        GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", activatedUnit.GAMELOCATION.ZONE).Single();
                        GS.CHANGELOCATION(activatedUnit, RTBLocation);
                    }
                    GS.Done(this);
                    break;
                case "ASSIGN TO THIS SUB":
                    gp.TACCOORDPIECEID = activatedUnit.ID;
                    gp.TACCOORDPIECE = activatedUnit;
                    Update("NEXT");
                    break;
                case "ASSIGN TO ALL SURFACE UNITS IN THIS HEX":
                    foreach(GO ship in GS.InteractionMap.Keys.Where(n => n.UNITCATEGORY == "SURFACE")){
                        ship.TACCOORDPIECEID = activatedUnit.ID;
                        ship.TACCOORDPIECE = activatedUnit;
                    }
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionGroupUnGroup : GamePhaseInteractive
    {
        string side = null;
        public ActionGroupUnGroup(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                FS.CREATE_TF_PHASE = true;
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"MANAGE TF/TGs"});
                GS.HELPTEXT = 
                "This phase is your opportunity to combine, disband, and create TF/TGs\n\n" + 
                "- Units cannot be moved outside of their hex.\n" +
                "- Docked units cannot be merged with Un-docked units.\n" +
                "When done with your setup you can click the NEXT button";                
                foreach(GO unit in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.UNITCATEGORY == "SURFACE" && FS.CANSHIPGROUPUP(n))){
                    GS.InteractionMap.Add(unit, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                List<GO> targets = GS.InteractionMap[obj];
                targets.Clear();
                if(FS.ISGROUP(obj)){
                    GS.AddAction(obj, "DISBAND");
                } else {
                    if(obj.GROUPID != null){
                        List<GO> groupMembers = FS.GROUPMEMBERS(FS.LOGICALPARENT(obj));
                        int count = groupMembers.Count;
                        if (obj.GROUPINDEX > 0)
                        {
                            GS.AddAction(obj, "MOVE UP IN GROUP");
                        }
                        if (obj.GROUPINDEX < count - 1)
                        {
                            GS.AddAction(obj, "MOVE DOWN IN GROUP");
                        }
                        GS.AddAction(obj, "LEAVE TF/TG");
                    } else {
                        GS.AddAction(obj, "CREATE TF/TG");
                        foreach(GO parent in GS.InteractionMap.Keys.Where(n => FS.ISGROUP(n) && n.GAMELOCATION == obj.GAMELOCATION && n.DOCKED == obj.DOCKED))
                        {
                            GS.AddAction(obj, "JOIN : " + FS.INFOLINE1(parent));
                        }
                    }
                }
                GS.AddAction(obj, "END PHASE");
            }
            if (!GS.InteractionMap.Keys.Any())
            {
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "CREATE TF/TG":
                    GO createdTG = FS.CREATEGROUP(GS, gp, gp.GAMELOCATIONID);
                    GS.InteractionMap.Add(createdTG, new());
                    createdTG.DOCKED = gp.DOCKED;
                    GS.SelectedMarker = createdTG;
                    Start(false);
                    break;
                case "DISBAND":
                    GO firstMember = GS.TYPE(gp.TYPE, "GROUPID", gp.ID).FirstOrDefault();
                    //FS.GROUPMEMBERS(gp).ForEach(n => GS.CHANGELOCATION(n, gp.GAMELOCATION));
                    FS.GROUPMEMBERS(gp).ForEach(n => FS.REMOVEFROMGROUP(n, gp));
                    FS.DISCARDTAGGED(gp);
                    if(firstMember != null){GS.SelectedMarker = firstMember;}
                    Start(false);
                    break;
                case "MOVE UP IN GROUP":
                    FS.MOVEUPINGROUP(GS, gp, FS.LOGICALPARENT(gp));
                    Start(false);
                    break;
                case "MOVE DOWN IN GROUP":
                    FS.MOVEDOWNINGROUP(GS, gp, FS.LOGICALPARENT(gp));
                    Start(false);
                    break;
                case "LEAVE TF/TG":
                    FS.REMOVEFROMGROUP(gp, gp.GROUP);
                    Start(false);
                    break;
                case "NEXT":
                    FS.CREATE_TF_PHASE = false;
                    foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.GRPTYPE == "TFTGGRP")){
                        FS.UPDATEGROUP(obj);
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    if(pData.StartsWith("JOIN : "))
                    {
                        string label = pData.Replace("JOIN : ", "");
                        GO parent = GS.InteractionMap.Keys.Where(n => n.GAMELOCATION == gp.GAMELOCATION && n.DOCKED == gp.DOCKED && label == FS.INFOLINE1(n)).First();
                        FS.ADDTOGROUP(gp, parent);
                        GS.SelectedMarker = parent;
                    }
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionRound : GamePhaseLoopLogic
    {
        public ActionRound(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionActivation("ACTIVATION", this, GS));
            AddGamePhase(new ActionAirEnemyCAPLoop("CAP INTERCEPT", this, GS));
            AddGamePhase(new ActionAirEnemyMobileCAPLoop("MOBILE CAP INTERCEPT", this, GS));
            AddGamePhase(new ActionImpulse("SEGMENT", this, GS));         
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION." + n)).Any();}
        public override void Init()
        {
            SetBoolean("AI.ACTIVATIONGROUPS", true);
            foreach(string s in FS.SIDE_NAMES){
                SetBoolean("ACTION.ACTIVATION." + s, false);
                SetInt("ACTION.MOVES." + s, 0);
                SetInt("ACTION.COMBATS." + s, 0);
                if (GS.AI_Sides.Contains(s))
                {
                    List<GO> invalid = [];
                    foreach(GO obj in FS.TYPESIDE(GS, "OBJECTIVELOGIC", s))
                    {
                        if(FS.VALIDCOVERAGE(obj).Count == 0)
                        {
                            invalid.Add(obj);
                            continue;
                        }
                    }
                    FS.AI_GENERATESHIPLINKS(GS.TYPE("SHIP", "SIDE", s), invalid);
                    FS.AI_GENERATESQNLINKS(GS.TYPE("SQN", "SIDE", s), invalid);
                }
            }
            SetInt("ACTION.CYCLES", 0);
        }
        public override void End()
        {
            foreach(string s in FS.SIDE_NAMES){
                int numMoves = GetInt("ACTION.MOVES." + s);
                int numCombats = GetInt("ACTION.COMBATS." + s);
                GS.SetBoolean("ACTION." + s, numMoves == 0 && numCombats == 0);
            }
            if(!ProcessCheck()){
                SetBoolean("AI.ACTIVATIONGROUPS", false);
                //remove any activation groups that may remain
                foreach(string s in FS.SIDE_NAMES.Where(n => !GS.AI_Sides.Contains(n))){
                    foreach(GO group in FS.TYPESIDE(GS, "SHIP", s).Where(n => n.GRPTYPE == "ACTIVATIONGRP")){
                        //FS.GROUPMEMBERS(group).ForEach(n => GS.CHANGELOCATION(n, group.GAMELOCATION));
                        FS.GROUPMEMBERS(group).ForEach(n => FS.REMOVEFROMGROUP(n, group));
                        FS.DISCARDTAGGED(group);
                    }
                }
                List<GO> PROCESS = [];
                foreach (string s in FS.SIDE_NAMES)
                {
                    foreach (string typ in FS.UNITTYPES)
                    {
                        PROCESS.AddRange(FS.TYPESIDE(GS, typ, s));
                    }
                }
                foreach (GO obj in PROCESS)
                {
                    FS.REMOVESCENARIOOBJECT(GS, obj, false);
                    obj.ACTIVATED = false;
                    obj.DONE = false;
                    obj.REPLENISHING = false;
                    obj.LOADING = false;
                    obj.ACTIVATEDAIRUNITS = 0;
                    obj.LOCATIONHISTORY = null;
                    if (FS.LOGICALPARENT(obj) != obj)
                    {
                        obj.LOCATIONFUTURE = null;
                    }
                    obj.NUMCOMBATS = 0;
                    obj.DONEASW = false;
                    obj.DONESSM = false;
                    obj.DONECM = false;
                    obj.DONECC = false;
                    obj.ADMINDETECTED = false;
                    //reset movement allowance
                    obj.USEDFUEL = obj.USEDFUEL || obj.HEXESTRAVELLED > 2;
                    obj.HEXESTRAVELLED = 0;
                    obj.ATTACKEDBYAIR = false;
                    obj.ATTACKEDBYSURFACE = false;
                    obj.DETECTIONATTEMPTED = false;
                    obj.TACCOORDPIECEID = null;
                    obj.EXTENDEDRANGE = false;
                    obj.REDUCEDRANGE = false;
                    obj.HIGHMISSIONPROFILE = false;
                    obj.AERIALREFUELING = false;
                    obj.ASWPATROLMODE = false;
                    obj.LOITERMODE = false;
                    obj.ROLE = null;
                    //reset air unit ammo
                    if (obj.UNITCATEGORY == "AIR")
                    {
                        obj.MINEPTS = 0;
                        obj.SSMPTS = 0;
                        obj.BOMBPTS = 0;
                        obj.CM = 0;
                        obj.SSM = 0;
                        obj.SPECIAL = 0;
                        obj.TORPPTS = 0;
                        obj.MAA = false;
                    }
                    obj.SEARCHMODE = false;
                    obj.INTERCEPTMODE = false;
                    obj.SEARCHDELAY = 0;
                    if (obj.AIRMISSION != "CAP" && obj.AIRMISSION?.StartsWith("STRAT") == false)
                    {
                        obj.AIRMISSION = null;
                    }
                    if (obj.UNITCATEGORY == "SUB" || Get("TURN.TYPE") == "NIGHT")
                    {
                        obj.FULLSPEED = false;
                    }
                    obj.NOORDERS = false;
                }
                foreach(GO logic in GS.LOGICS())
                {
                    switch (logic.TYPE)
                    {
                        case "AI.LOGICLINK":
                            if(logic.UNIT?.UNITCATEGORY == "AIR" && logic.ACTIVE)
                            {
                                logic.ACTIVE = false;
                                logic.LINKCYCLES = 0;
                            }
                            logic.INTERRUPTED = false;
                            break;
                        case "LANDCOMBAT":
                        case "GROUPINGLOGIC":
                            break;
                        default:
                            FS.DISCARDLOGIC(logic);
                            break;
                    }
                }
                FS.SIDE_NAMES.ForEach(n => FS.CLEARSCENARIOVAR(GS, "ACTION.COMBATLOCATIONS." + n));
                MainWindow.Alert("No units with orders or movement points remaining.  Action Segment is over.");
            }
            IncrementInt("ACTION.ROUNDS", 1);
            foreach (string s in FS.SIDE_NAMES)
            {
                if (GS.AI_Sides.Contains(s))
                {
                    FS.AI_COMPLETELINKS(GS, s);
                }
            }
        }
    }
    public class ActionActivation : GamePhaseLoopLogic
    {
        public ActionActivation(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionActivationLoop("Loop", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION.ACTIVATION." + n)).Any();}
        public override void Init(){}
        public override void End()
        {
            string side = Get("ACTIVE.SIDE");
            if(side == GS.Get("ACTIVE.SIDE1")){
                Set("ACTIVE.SIDE", FS.ENEMY(side));
            } else {
                Set("ACTIVE.SIDE1", side);
                List<GO> alreadyActivated = FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED");
                List<GO> activated = [];
                foreach (string s in FS.SIDE_NAMES)
                {
                    foreach (string typ in FS.UNITTYPES)
                    {
                        activated.AddRange(FS.TYPESIDE(GS, typ, s).Where(n => n.ACTIVATED && !n.DONE && FS.LOGICALPARENT(n) == n));
                    }
                }
                FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIVATED", activated);
                List<GO> checkInterception = activated.Where(n => !alreadyActivated.Contains(n) && n.TYPE == "SQN").ToList();
                FS.AIRDETECTION(GS, checkInterception, true);
                FS.SURFACEVSAIRTARGETING(GS);
            }
        }
    }  

    public class ActionActivationLoop : GamePhaseLoopLogic
    {
        public ActionActivationLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionActivateStack("Activate Stack", this, GS)); 
            AddGamePhase(new ActionAirINTRole("AIR INT Role", this, GS));
            AddGamePhase(new ActionAirMidAirRefueling("AIR Assign Mid-Air Refueling", this, GS));
            AddGamePhase(new ActionAirFlightOptions("AIR Range Options", this, GS));
            AddGamePhase(new ActionAirAmmoSelection("AIR Ammo Selection", this, GS));
            AddGamePhase(new ActionSubFullSpeed("SUB Full Speed", this, GS));
        }
        public override Boolean ProcessCheck(){return !GetBoolean("ACTION.ACTIVATION." + Get("ACTIVE.SIDE"));}
        public override void Init(){}
        public override void End(){
            List<GO> FULLSPEEDDETECTORS = [];
            foreach (string s in FS.SIDE_NAMES)
            {
                FULLSPEEDDETECTORS.AddRange(FS.TYPESIDE(GS, "SHIP", s).Where(n => n.ENROUTEDELAY == 0 && n.GAMELOCATION.TYPE == "HEX"));
            }
            foreach (GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATING")){
                obj.ACTIVATED = true;
                obj.MOVEMENTALLOWANCE = FS.RESETMOVEMENTALLOWANCE(obj);
                if(FS.LOGICALPARENT(obj) == obj){
                    obj.LOCATIONHISTORY = obj.GAMELOCATIONID;
                    obj.LOCATIONFUTURE ??= obj.GAMELOCATIONID;
                    obj.DOCKED = false;
                    if(FS.ISGROUP(obj)){
                        FS.UPDATEGROUP(obj);
                    }
                    if(obj.UNITCATEGORY == "SUB" && obj.FULLSPEED && !obj.STRATDETECTED){
                        if(FS.FINDAIRRADIUS(obj.GAMELOCATION, 5).Intersect(FULLSPEEDDETECTORS.Where(n => n.SIDE == FS.ENEMY(obj.SIDE))).Any()){
                            FS.STRATDETECT(new(){obj}, true);
                            FS.CREATEALERT(obj, null, FS.ENEMY(obj.SIDE));
                        }
                    }
                    if(obj.DESTINATIONPIECEID == null){
                        //create destination marker
                        //add attempt marker
                        GO template = GS.PIECE("ACTION.DESTINATION");
                        Dictionary<string, string> clonedData = new(template._data);
                        clonedData["ID"] = obj.ID + GO.DELIM + "DESTINATION" + GO.DELIM + FS.GENERATETIMESTAMP();
                        clonedData["LABEL"] = template.LABEL;
                        GO clone = new(GS, clonedData, null, null);
                        GS.CHANGELOCATION(clone, obj.GAMELOCATIONID);
                        clone.SIDE = obj.SIDE;
                        obj.DESTINATIONPIECEID = clone.ID;
                        obj.DESTINATIONPIECE = clone;
                        clone.GAMEPIECEID = obj.ID;
                        clone.GAMEPIECE = obj;
                        GS.ShuffleMarkerToBottom(clone);
                    }
                } else {
                    FS.UPDATEGROUP(FS.LOGICALPARENT(obj));
                }
            }
            FS.CLEARSCENARIOVAR(GS, "ACTION.ACTIVATING");
        }
    }            
    public class ActionActivateStack : GamePhaseInteractive
    {
        List<GO> CANACTIVATE = new();
        GO activatingUnit = null;
        GO ACTIVATIONGROUP = null;
        List<GO> UNITSINSAMELOCATION = [];
        GO LASTACTIVATED = null;
        string side = null;
        public ActionActivateStack(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                FS.CREATE_ACTGRP_PHASE = true;
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                activatingUnit = null;
                ACTIVATIONGROUP = null;
                FS.SETINSTRUCTIONS(GS, new(){"ACTIVATE UNITS", "CREATE ACTIVATION GROUPS"});
                int round = GetInt("ACTION.ROUNDS") + 1;
                int cycle = GetInt("ACTION.CYCLES") + 1;
                BANNER = ID + " - Round " + round + " - Cycle " + cycle;

                GS.HELPTEXT = 
                "Activation.  In this phase, you will select the unit(s) that you want to activate.  Options:\n\n" + 
                "- TF/TGs and SUBS:  ACTIVATE it\n" +
                "- Ungrouped Ships and Air:  Game will continue to allow you to add units from the same hex, max 12 combat units (ships), Max 4 INT/ATK/BMB (air), then ACTIVATE the group\n" +
                "- AIR MISSIONS:  Depending on what options you have enabled, you can create air missions for specific purposes. These missions are limited to groups of one air unit\n" +
                "*You do NOT have to do all activations at this time.  the Game will allow you to activate more groups after these groups being moving/attacking\n\n" +
                "*To skip or whenever finished activating, hit NEXT Button";
                CANACTIVATE = [];
                CANACTIVATE.AddRange(FS.TYPESIDE(GS, "SHIP", side).Where(n => FS.CANSHIPACTIVATE(n)));
                CANACTIVATE.AddRange(FS.TYPESIDE(GS, "SQN", side).Where(n => FS.CANLAUNCHACTIVATE(n)));
                List<GO> activationGrps = CANACTIVATE.Where(n => n.GRPTYPE == "ACTIVATIONGRP" && !n.ACTIVATED).ToList();
                if(activationGrps.Any()){
                    GO group = activationGrps.First();
                    GS.InteractionMap.Add(group, new());
                    ACTIVATIONGROUP = group;
                    UNITSINSAMELOCATION = [..CANACTIVATE.Where(n => group.AIRMISSION == null && !n.ACTIVATED && n.GROUPID == null && n.UNITCATEGORY == group.UNITCATEGORY && !FS.ISGROUP(n) && FS.PARENTGROUPLOCATION(n) == group.GAMELOCATION)];
                } else {
                    ACTIVATIONGROUP = null;
                    UNITSINSAMELOCATION.Clear();
                    foreach(GO obj in CANACTIVATE.Where(n => !n.ACTIVATED && n.GROUPID == null)){
                        GS.InteractionMap.Add(obj, new());
                    }
                }
            }
            if(LASTACTIVATED != null)
            {
                if (GS.InteractionMap.ContainsKey(LASTACTIVATED))
                {
                    GS.SelectedMarker = LASTACTIVATED;
                } else {
                    List<GO> selectable = [.. CANACTIVATE.Where(n => GS.InteractionMap.ContainsKey(n) || n == LASTACTIVATED)];
                    GS.SelectedMarker = GS.NEXT(selectable, LASTACTIVATED);
                    if (!GS.InteractionMap.ContainsKey(GS.SelectedMarker))
                    {
                        GS.SelectedMarker = null;
                    }
                }
            }
            LASTACTIVATED = null;
            if (GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker))
            {
                if (GS.InteractionMap.Count != 0)
                {
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if (GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj == ACTIVATIONGROUP)
                {
                    if(UNITSINSAMELOCATION.Count != 0 && GS.InteractionMap.Count == 1)
                    {
                        GS.AddAction(obj, "ADD MORE TO GROUP");
                    }
                    GS.AddAction(obj, "ACTIVATE");
                }
                else if(ACTIVATIONGROUP == null)
                {
                    if(FS.ISGROUP(obj) || obj.UNITCATEGORY == "SUB")
                    {
                        GS.AddAction(obj, "ACTIVATE");
                    }
                    else
                    {
                        if (obj.UNITCATEGORY == "AIR")
                        {
                            bool CANBOMB = FS.GETAIRBOMB(obj) > 0 && (obj.CARRIERID == null || obj.CARRIER.BOMBPTS > 0);
                            bool CANSSM = FS.GETAIRSSM(obj) > 0 && ((obj.CARRIERID == null && !obj.TEMPLATE.LIMITEDSSM) || obj.CARRIER?.AIRSSMPTS >= obj.TEMPLATE.AIRSSMCOST);
                            bool CANCM = obj.CMPTS > 0;
                            bool CANMINE = FS.GETAIRMINE(obj) > 0 && !FS.STRATEGICMINING;
                            bool CANTORP = obj.TEMPLATE.ASW > 0;
                            bool CANCARGOTRANSPORT = FS.CANATR(obj, true, false);
                            bool CANTROOPTRANSPORT = FS.CANATR(obj, false, false);
                            switch(obj.UNITTYPE){
                                case "INT":
                                    GS.AddAction(obj, "AIR SUPERIORITY MISSION"); 
                                    break;
                                case "RCN":
                                    if (CANTORP) { GS.AddAction(obj, "ASW PATROL MISSION"); }
                                    break;
                                case "ATR":
                                    if (CANTROOPTRANSPORT) { GS.AddAction(obj, "TROOP TRANSPORT MISSION"); }
                                    if (CANCARGOTRANSPORT) { GS.AddAction(obj, "CARGO TRANSPORT MISSION"); }
                                    break;
                                default:
                                    break;
                            }
                            if (CANBOMB){GS.AddAction(obj, "BOMBING MISSION");}
                            if (CANSSM){GS.AddAction(obj, "ANTI-SHIP MISSILE MISSION");}
                            if (CANCM) { GS.AddAction(obj, "CRUISE MISSILE MISSION"); }
                            if (CANMINE) { GS.AddAction(obj, "MINING MISSION"); }
                            if (FS.GETAIRSURFACESEARCH(obj) > 0 && FS.AIRSURFACEINTERACTION && !FS.STRATEGICTACCOORD) { GS.AddAction(obj, "TAC-COORD MISSION"); }
                        }
                        else
                        {
                            GS.AddAction(obj, "ACTIVATE");
                        }
                        GS.AddAction(obj, "CREATE " + obj.UNITCATEGORY + " GROUP");
                    }
                    GS.AddAction(obj, "END PHASE");
                }
                else if(UNITSINSAMELOCATION.Contains(obj)){
                    GS.AddAction(obj, "ADD");
                    GS.AddAction(obj, "DONE");
                }
                if(obj.GRPTYPE == "ACTIVATIONGRP" && UNITSINSAMELOCATION.Count == 0){
                    Update("ACTIVATE");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                FS.AI_GENERATESHIPACTIVATIONS(GS, [.. GS.InteractionMap.Keys.Where(n => n.TYPE == "SHIP")], FS.SIDE_MODE);
                FS.AI_GENERATESQNACTIVATIONS(GS, [.. GS.InteractionMap.Keys.Where(n => n.TYPE == "SQN")], FS.SIDE_MODE);
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    bool valid = true;
                    if(activatingUnit != null){
                        //check validity of units
                        if(activatingUnit.UNITCATEGORY == "AIR"){
                            if(activatingUnit.CARRIER?.DAMAGED == true && activatingUnit.CARRIER?.ACTIVATEDAIRUNITS == 1){
                                MainWindow.Alert("Exceeding max number of air units activated from damaged Carrier.");
                                valid = false;
                            }
                        }
                        if(valid){
                            GO obj = activatingUnit;
                            GO loc = FS.PARENTGROUPLOCATION(obj);
                            List<GO> activatingUnits = new();
                            if(FS.ISGROUP(obj)){
                                activatingUnits.Add(obj);
                                foreach(GO obj2 in FS.GROUPMEMBERS(obj).Where(n => !n.ACTIVATED)){
                                    activatingUnits.Add(obj2);
                                }
                            } else if(obj.UNITCATEGORY == "SUB"){
                                activatingUnits.Add(obj);
                            } else {
                                if(obj.UNITCATEGORY == "AIR"){
                                    GO homebase = obj.CARRIER ?? obj.GAMELOCATION;
                                    obj.HOMEBASEID = homebase.ID;
                                    obj.HOMEBASE = homebase;
                                    if(obj.CARRIER != null){
                                        obj.HOMEBASE.ACTIVATEDAIRUNITS++;
                                        FS.REMOVEFROMGROUP(obj, obj.CARRIER);
                                    }
                                    switch (obj.AIRMISSION)
                                    {
                                        case "CRUISE MISSILE":
                                            obj.CM = obj.TEMPLATE.CM;
                                            break;
                                        case "SSM":
                                            obj.SSM = FS.GETAIRSSM(obj);
                                            obj.SSMPTS = Math.Max(1, obj.TEMPLATE.AIRSSMCOST);
                                            if(!obj.HOMEBASE.AIRFIELD){
                                                obj.HOMEBASE.AIRSSMPTS -= obj.SSMPTS;
                                            }
                                            break;
                                        case "AIR SUPERIORITY":
                                            if (obj.COUNTRY == "USA" && obj.LABEL.StartsWith("F-14"))
                                            {
                                                obj.MAA = true;
                                            }
                                            obj.ROLE = "FIGHTER";
                                            break;
                                        case "MINING":
                                            obj.MINEPTS = 1;
                                            break;
                                        case "ASW":
                                            obj.TORPPTS = 1;
                                            break;
                                        case "BOMBING":
                                            obj.SPECIAL = FS.GETAIRBOMB(obj);
                                            obj.BOMBPTS = 1;
                                            if(!obj.HOMEBASE.AIRFIELD){
                                                obj.HOMEBASE.BOMBPTS -= obj.BOMBPTS;
                                            }
                                            break;
                                        case "TROOPS":
                                        case "CARGO":
                                            FS.CANATR(obj, obj.AIRMISSION == "CARGO", true);
                                            break;
                                        default:
                                            break;
                                    }
                                }
                                if (ACTIVATIONGROUP != null)
                                {
                                    if (!FS.ISGROUP(ACTIVATIONGROUP))
                                    {
                                        ACTIVATIONGROUP = FS.CREATEACTIVATIONGROUP(obj, loc.ID);
                                    }
                                    else
                                    {
                                        FS.ADDTOGROUP(obj, ACTIVATIONGROUP);
                                    }
                                }
                                activatingUnits.Add(obj);
                            }
                            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIVATING", activatingUnits);
                            SetBoolean("ACTION.ACTIVATION." + side, false);
                            LASTACTIVATED = activatingUnit.GRPTYPE == "ACTIVATIONGRP" ? FS.GROUPMEMBERS(obj).Last() : activatingUnit;
                            FS.CREATE_ACTGRP_PHASE = false;
                            GS.Done(this);
                        } else {
                            activatingUnit.AIRMISSION = null;
                            GS.SelectedMarker = GS.REMOVEINTERACTIVE(activatingUnit);
                            activatingUnit = null;
                            Start(false);
                        }
                    } else if(ACTIVATIONGROUP != null){
                        activatingUnit = ACTIVATIONGROUP;
                        Update("NEXT");
                    } else {
                        //pass
                        SetBoolean("ACTION.ACTIVATION." + side, true);
                        LASTACTIVATED = null;
                        FS.CREATE_ACTGRP_PHASE = false;
                        GS.Done(this);
                    }
                    break;
                case "ACTIVATE":
                    activatingUnit = gp;
                    Update("NEXT");
                    break;
                case "CREATE SURFACE GROUP":
                case "CREATE AIR GROUP":
                    ACTIVATIONGROUP = gp;
                    activatingUnit = gp;
                    Update("NEXT");
                    break;
                case "ADD":
                    activatingUnit = gp;
                    Update("NEXT");
                    break;
                case "DONE":
                    activatingUnit = ACTIVATIONGROUP;
                    Update("NEXT");
                    break;
                case "ADD MORE TO GROUP":
                    UNITSINSAMELOCATION.ForEach(n => GS.InteractionMap.Add(n, []));
                    GS.SelectedMarker = UNITSINSAMELOCATION.First();
                    Start(false);
                    break;
                case "AIR SUPERIORITY MISSION":
                    activatingUnit = gp;
                    gp.AIRMISSION = "AIR SUPERIORITY";
                    Update("NEXT");
                    break;
                case "MINING MISSION":
                    activatingUnit = gp;
                    gp.AIRMISSION = "MINING";
                    Update("NEXT");
                    break;
                case "TAC-COORD MISSION":
                    activatingUnit = gp;
                    gp.AIRMISSION = "RECON";
                    Update("NEXT");
                    break;
                case "BOMBING MISSION":
                    activatingUnit = gp;
                    gp.AIRMISSION = "BOMBING";
                    Update("NEXT");
                    break;
                case "CRUISE MISSILE MISSION":
                    activatingUnit = gp;
                    gp.AIRMISSION = "CRUISE MISSILE";
                    Update("NEXT");
                    break;
                case "ANTI-SHIP MISSILE MISSION":
                    activatingUnit = gp;
                    gp.AIRMISSION = "SSM";
                    Update("NEXT");
                    break;
                case "ASW PATROL MISSION":
                    activatingUnit = gp;
                    gp.AIRMISSION = "ASW";
                    Update("NEXT");
                    break;
                case "TROOP TRANSPORT MISSION":
                    activatingUnit = gp;
                    gp.AIRMISSION = "TROOPS";
                    Update("NEXT");
                    break;
                case "CARGO TRANSPORT MISSION":
                    activatingUnit = gp;
                    gp.AIRMISSION = "CARGO";
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionImpulse : GamePhaseLoopLogic
    {
        public ActionImpulse(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionOrdersLoop("Loop", this, GS));
            AddGamePhase(new AIReview("AI Situation Review", this, GS));
            AddGamePhase(new ActionCombat("COMBAT MISSIONS", this, GS));
            AddGamePhase(new ActionAirMovement("AIR", this, GS));
            AddGamePhase(new ActionShipMovement("SHIP", this, GS));
            
        }
        public override Boolean ProcessCheck(){return GetInt("ACTION.CYCLES") < 10;}
        public override void Init(){
            FS.SIDE_NAMES.ForEach(n => SetBoolean("ACTION.ORDERS." + n, false));
            foreach (string s in GS.AI_Sides)
            {
                FS.AI_UPDATEPATROLLINKS(GS, s);
                FS.AI_UPDATEGROUPINGLINKS(GS, s);
            }
        }
        public override void End()
        {
            foreach (string s in GS.AI_Sides)
            {
                List<GO> ALLLINKS = [.. GS.TYPE("AI.LOGICLINK", "SIDE", s).Where(n => n.UNIT?.SIDE == s && n.LOGIC?.SIDE == s && n.LOGIC.TYPE == "OBJECTIVELOGIC")];
                List<GO> ACTIVELINKS = [.. ALLLINKS.Where(n => n.ACTIVE)];
                //any units in this side not linked to an active link, reset
                List<GO> UNITSWITHACTIVELINK = FS.GROUPSANDMEMBERS([.. ACTIVELINKS.Select(n => n.UNIT)]);
                List<GO> UNITSWITHOUTACTIVELINK = [.. ALLLINKS.Select(n => n.UNIT).Where(n => !UNITSWITHACTIVELINK.Contains(n)).Distinct()];
                foreach (GO unit in UNITSWITHOUTACTIVELINK)
                {
                    unit.SEARCHMODE = false;
                    unit.SEARCHDELAY = 0;
                    unit.AIROLE = null;
                }
            }
            IncrementInt("ACTION.CYCLES", 1);
        }
    }  
    public class ActionOrdersLoop : GamePhaseLoopLogic
    {
        public ActionOrdersLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionOrders("Orders", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION.ORDERS." + n)).Any();}
        public override void Init()
        {
            //throw new NotImplementedException();
        }
        public override void End()
        {
            string side = Get("ACTIVE.SIDE");
            if(side == GS.Get("ACTIVE.SIDE1")){
                Set("ACTIVE.SIDE", FS.ENEMY(side));
            } else {
                Set("ACTIVE.SIDE1", side);
            }
            SetBoolean("ACTION.ORDERS." + side, true);
        }
    }
    public class ActionOrders : GamePhaseInteractive
    {
        List<GO> ACTIONABLE = new();
        List<GO> DESTINATIONS = new();
        List<GO> ENEMYUNITS = new();
        Dictionary<GO, Dictionary<string, List<GO>>> TARGETS = new();
        List<GO> SSMSCOPE = new();
        List<GO> BOMBSCOPE = new();
        List<GO> CMSCOPE = new();
        List<GO> ASWSCOPE = new();
        List<GO> TORPSCOPE = new();
        List<GO> AAASCOPE = new();
        List<GO> CCSCOPE = new();
        List<GO> TACCOORDSCOPE = new();
        List<GO> COMBATS = new();
        List<GO> SURFACETOAIRS = new();
        string COMBATMODE = null;
        GO attackingUnit = null;
        Dictionary<GO, List<FSMovement>> MOVEMENTFUTURES = new();
        Dictionary<GO, List<FSMovement>> MOVEMENTCHOICES = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> ATTACKDATA = new();                                    
        string side = null;
        bool firstCycle = false;
        bool shipMoveCycle = false;
        bool shipCombatCycle = false;
        bool SIDE_IS_AI = false;
        List<GO> NOORDERSALERTS = [];
        List<GO> DEPLOYEDMINES = [];
        List<GO> MINEDEPLOYMENTLOCATIONS = [];
        List<GO> MOVABLELOGICS = [];
        Dictionary<GO, List<string>> VPOBJECTIVELOCATIONIDS = [];
        public ActionOrders(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            DragOver = true;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            int round = GetInt("ACTION.ROUNDS") + 1;
            int cycle = GetInt("ACTION.CYCLES") + 1;
            FS.SETINSTRUCTIONS(GS, new() { "ROUND:" + round, "CYCLE:" + cycle, "DRAG UNIT TO GIVE MOVEMENT ORDERS", "GIVE OTHER ORDERS FROM UNIT CURRENT LOCATION" });
            BANNER = ID + " - Round " + round + " - Cycle " + cycle;
            GS.SHOWINSTRUCTIONS(); 
            if (init){
                FS.ORDERS = true;
                side = Get("ACTIVE.SIDE");
                ACTIONABLE.Clear();
                DESTINATIONS.Clear();
                ENEMYUNITS.Clear();
                TARGETS.Clear();
                ATTACKDATA.Clear();
                COMBATMODE = null;
                attackingUnit = null;
                MOVEMENTFUTURES.Clear();
                MOVEMENTCHOICES.Clear();
                NOORDERSALERTS.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG UNIT TO GIVE MOVEMENT ORDERS", "DESIGNATE ATTACKS ALONG THE WAY"});
                GS.HELPTEXT = 
                "ORDERS\n\n" + 
                "Give orders to units, which will be EXECUTED AFTERWARDS by automation. A total of 10 automated cycles will run after this phase.  During those, the automation will move air units a hex at a time.  Halfway through those, the surface/sub units will move.  The automation will automatically interrupt if a new enemy detection occurs (RED circle) or an unit has no pathing (YELLOW circle)\n\n" + 
                "PATHING: Trace the path that will be followed by the unit. You can make it as long as you like. A DESTINATION Marker will indicate the path. TF/TG/Sub Units will remember this path and you'll have opportunities to adjust it after the automation runs.  If not interrupted as described above, up to 10 air hexes and/or 1 surface/sub hex will be processed\n\n" + 
                "ATTACKS: The game will allow you to designate attacks. Actual execution of attack happens after orders phase has ended\n\n" + 
                "LANDING AIR:  during the automation, if the unit flies over it's homebase, it will automatically land. You CAN choose to land the air unit at another base, if the air unit is actually over the base currently.  Only non-carrier units can do this and after landing they have to go through " +
                "a delay of " + GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER") + " turns (configurable)\n\n" +
                "DOCKING: You can tell the unit to dock if it is in a port and all units have enough movement points. Docking will end its actions for the turn\n\n" +
                "STACKING: AIR rules are enforced at real-time. SURFACE is handled slightly differently. Since ships are constantly moving, stacking will be enforced after all movements are completed in the turn. " + 
                "The automation will interrupt to warn you of hexes that are overstacked. Ensure that by the end of all activations and movements, no hexes are in violation.  " +
                "IF surface ships violate the Stacking Limit (max of 12 combat units per hex), you will have to destroy units to get under the limit\n\n" +
                "SEARCH: for air units, will lock air unit in a hex for 5 air cycles, BUT you get increased surface detection range (if enabled), TAC-COORD is available for squadrons equipped (if enabled), and ASW equipped air can look for SUBs in same hex (if enabled)\n\n" +
                "LOITER: for air units, air unit will remain in its current location, and prevent the out-of-orders alert. Can come out of this mode anytime, but doesn't gain the advantages of SEARCH mode\n\n" +
                "AUTO-INTERCEPT: for air units on AIR SUPERIORITY missions, will engage nearby air during automation cycle.  US F-14s can engage 1 hex away, all other require being in same hex as enemy\n\n" +
                "ASW-PATROL (enabled by REAL TIME SUB DETECTION option): for surface/subs, will use a movement point to stay in same hex, but enable SUB detection attempts\n\n" +
                "MINING/TACCOORD (if enabled): Normally done in the Strategic Cycle, you can enable an option to do this during Action. Mine equipped subs and aircraft can lay mines.  Subs must use their entire action phase to do this.  Drag the sub's destination marker to the hex you want to lay mines in then select the option.  Air can deploy in flight.  Tactical Coordination is available in LOITER/RECON mode for air units designated as RECON missions. Surface targets in sensor range of the air unit, or Sub targets in same hex can be designated.  The Air unit can perform as many of these missions as they like during their activation\n\n" +
                "ENDING THE ACTION PHASE:  The open-ended Action Phase this game uses now has no distinct end.  You aren't forced to activate all your units at the beginning, and you could intentionally pause orders to wait to see what the enemy does.  " + 
                "So, the Action Phase will AUTOMATICALLY END when no movements or combats are performed during a 10 cycle round. So if you are waiting to activate units, the Action Phase may end, so keep that in mind";  
                List<GO> objs = FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED").Where(n => 
                    n.SIDE == side).ToList();
                ENEMYUNITS.AddRange(FS.TYPESIDE(GS, "PIECE", FS.ENEMY(side)).Where(n => n.ENROUTEDELAY == 0 && (n.STRATDETECTED || n.LOCALDETECTED || (FS.BASETYPES.Contains(n.TYPE) && !FS.STORM(n.GAMELOCATION) && !(n.PORTDESTROYED && n.AIRFIELDDESTROYED && n.CLOSEDEFENSEDESTROYED)))));
                AAASCOPE = FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED").Where(n => 
                    n.SIDE == FS.ENEMY(side) && n.UNITCATEGORY == "AIR" && n.ADMINDETECTED).ToList();
                SURFACETOAIRS = GS.TYPE("SURFACETOAIR").Where(n => n.ATTACKER.SIDE == side).ToList();                
                foreach(GO obj in objs){
                    ACTIONABLE.Add(obj);
                    GS.InteractionMap.Add(obj, new());
                    MOVEMENTCHOICES.Add(obj, new());
                    DESTINATIONS.Add(obj.DESTINATIONPIECE);
                    GS.InteractionMap.Add(obj.DESTINATIONPIECE, new());
                    MOVEMENTCHOICES.Add(obj.DESTINATIONPIECE, new());
                    GENERATEFUTURES(obj);                        
                }
                TACCOORDSCOPE = [..ENEMYUNITS.Where(n => n.UNITCATEGORY == "SURFACE" || n.UNITCATEGORY == "SUB")];
                SSMSCOPE = ENEMYUNITS.Where(n => !n.DOCKED && n.UNITCATEGORY == "SURFACE").ToList();
                BOMBSCOPE = ENEMYUNITS.Where(n => n.UNITCATEGORY == "SURFACE" || (FS.BASETYPES.Contains(n.TYPE) && n.GAMELOCATION.TYPE == "HEX")).ToList();
                CMSCOPE = ENEMYUNITS.Where(n => n.UNITTYPE == "BASE").ToList();
                CCSCOPE = ENEMYUNITS.Where(n => n.UNITCATEGORY == "SURFACE" || FS.BASETYPES.Contains(n.TYPE)).ToList();
                ASWSCOPE = ENEMYUNITS.Where(n => (n.UNITCATEGORY == "SURFACE" && n.TEMPLATE.AAA > 0) || n.UNITCATEGORY == "SUB").ToList();
                TORPSCOPE = ENEMYUNITS.Where(n => !n.DOCKED && n.UNITCATEGORY == "SURFACE").ToList();
                COMBATS = [..FS.TYPESIDE(GS, "LOGIC", side).Where(n => FS.COMBATMISSIONTYPES.Contains(n.TYPE))];
                COMBATS.AddRange(FS.TYPESIDE(GS, "SURFACE TACCOORD", side));
                COMBATS.AddRange(FS.TYPESIDE(GS, "SUB TACCOORD", side));
                firstCycle = GetInt("ACTION.CYCLES") == 0;
                shipMoveCycle = firstCycle;
                shipCombatCycle = firstCycle;
                SIDE_IS_AI = GS.AI_Sides.Contains(FS.SIDE_MODE);
                if (SIDE_IS_AI)
                {
                    AI();
                    FS.ORDERS = false;
                    FS.TYPESIDE(GS, "ALERT", side).ForEach(FS.DISCARDLOGIC);
                    GS.Done(this);
                    return;
                }
                NOORDERSALERTS.AddRange(FS.TYPESIDE(GS, "ALERT", side).Where(n => n.INTERCEPTEDGRP.SIDE == side));
                DEPLOYEDMINES = [..GS.TYPE("MINEMARKER").Where(n => n.GAMELOCATIONID != null)];
                MINEDEPLOYMENTLOCATIONS = [..GS.TYPE("HEX").Where(n => FS.THEATERS.ContainsKey(n.ORGLEVEL1) &&
                n.TERRAIN == "SEA" && (n.COUNTRY != null || n.RESTRICTED || n.FJORD || n.SHALLOW))];
                
                bool interrupt = FS.TYPESIDE(GS, "ALERT", side).Count != 0;
                GO errorGO = CANADVANCE();
                if(!firstCycle){
                    //attempt to auto through
                    GS.SelectedMarker = errorGO;
                    bool moveOn = GS.SelectedMarker == null && !interrupt;
                    if(moveOn){
                        FS.ORDERS = false;
                        GS.Done(this);
                        return;
                    }
                }
                if(firstCycle || interrupt){
                    //add alerts to show where both sides are in same hex
                    Dictionary<GO, GO> ENEMYPOSITIONS = [];
                    foreach(string s in new List<string>{FS.ENEMY(side), side}){
                        bool enemy = s == FS.ENEMY(side);
                        List<GO> UNITS = [];
                        foreach (string typ in FS.UNITTYPES)
                        {
                            UNITS.AddRange(FS.TYPESIDE(GS, typ, s).Where(n => FS.LOGICALPARENT(n) == n));
                        }
                        foreach (GO obj in UNITS)
                        {
                            if (enemy && !obj.STRATDETECTED && !obj.LOCALDETECTED && !obj.ADMINDETECTED) { continue; }
                            GO loc = obj.GAMELOCATION;
                            if (loc.TYPE == "HEX")
                            {
                                if (enemy)
                                {
                                    ENEMYPOSITIONS[loc] = obj;
                                }
                                else if (ENEMYPOSITIONS.TryGetValue(loc, out GO e))
                                {
                                    ENEMYPOSITIONS.Remove(loc);
                                    FS.CREATEALERT(e, null, side);
                                }
                            }
                        }
                    }
                }
                MOVABLELOGICS = [];
                foreach (string typ in FS.SELECTABLELOGICTYPES) {
                    MOVABLELOGICS.AddRange(GS.TYPE(typ).Where(n => n.SIDE == side || n.OBJECTIVE));
                }
                VPOBJECTIVELOCATIONIDS.Clear();
                foreach(GO logic in MOVABLELOGICS.Where(n => n.TYPE == "OBJECTIVELOGIC" && n.VP_AWARD && n.VP_MULTIPLE > 0))
                {
                    VPOBJECTIVELOCATIONIDS[logic] = logic.LOCATIONCOVERAGE != null ? [.. logic.LOCATIONCOVERAGE.Split('|')] : [logic.GAMELOCATIONID];
                }
            }
            ACTIONABLE.RemoveAll(n => n.RECYCLED || n.DESTROYED || n.DONE);
            DESTINATIONS.RemoveAll(n => n.GAMEPIECE == null || n.GAMEPIECE.RECYCLED || n.GAMEPIECE.DESTROYED || n.GAMEPIECE.DONE);
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if (GS.SelectedMarker != null) {
                GO obj = GS.SelectedMarker;
                bool logicType = obj.TYPE == "OBJECTIVELOGIC" || obj.TYPE == "DEPLOYMENTLOGIC";
                if (logicType)
                {
                    GS.InteractionMap[obj] = FS.FINDAIRRADIUS(obj.GAMELOCATION, 1);
                }
                else
                {
                    if (obj.SIDE == side)
                    {
                        bool attackMode = obj == attackingUnit;
                        GO actualUnit = obj.TYPE == "DESTINATION" ? obj.GAMEPIECE : obj;
                        GO destinationMarker = obj.TYPE == "DESTINATION" ? obj : obj.DESTINATIONPIECE;
                        List<FSMovement> movements = MOVEMENTFUTURES[actualUnit];
                        if (!attackMode)
                        {
                            if (actualUnit.GAMELOCATION == destinationMarker.GAMELOCATION && movements.Count <= 1)
                            {
                                obj = actualUnit;
                                GS.SelectedMarker = actualUnit;
                                GS.InteractionMap[destinationMarker] = [];
                            }
                            else
                            {
                                GS.AddAction(obj, obj == actualUnit ? ">>DESTINATION" : ">>ACTUAL");
                            }
                            RESHUFFLEINTERACTIVES();
                            foreach (GO a in ACTIONABLE)
                            {
                                GS.InteractionMap[a].Clear();
                                if (!a.SEARCHMODE && !a.ASWPATROLMODE && !a.LOITERMODE)
                                {
                                    if ((a.GAMELOCATION == a.DESTINATIONPIECE.GAMELOCATION && MOVEMENTFUTURES[a].Count == 1) || a.DRAGGING)
                                    {
                                        List<FSMovement> choices = actualUnit.UNITCATEGORY switch
                                        {
                                            "AIR" => FS.FINDAIRMOVEMENTS(a.GAMELOCATION),
                                            "SUB" => FS.FINDSUBMOVEMENTS(a, a.GAMELOCATION, false),
                                            "SURFACE" => FS.FINDSURFACEMOVEMENTS(a, a.GAMELOCATION, false),
                                            _ => new()
                                        };
                                        MOVEMENTCHOICES[a] = choices;
                                        GS.InteractionMap[a].AddRange(choices.Select(n => n.MOVEMENTLOCATION));
                                    }
                                }
                            }
                            if (obj == destinationMarker)
                            {
                                GS.InteractionMap[obj].Clear();
                                List<FSMovement> choices = actualUnit.UNITCATEGORY switch
                                {
                                    "AIR" => FS.FINDAIRMOVEMENTS(obj.GAMELOCATION),
                                    "SUB" => FS.FINDSUBMOVEMENTS(obj, obj.GAMELOCATION, false),
                                    "SURFACE" => FS.FINDSURFACEMOVEMENTS(obj, obj.GAMELOCATION, false),
                                    _ => new()
                                };
                                MOVEMENTCHOICES[obj] = choices;
                                GS.InteractionMap[obj].AddRange(choices.Select(n => n.MOVEMENTLOCATION));
                            }
                        }
                        List<GO> combats = [.. COMBATS.Where(n => n.ATTACKER == actualUnit)];
                        int numCombats = combats.Where(n => FS.COMBATMISSIONTYPES.Contains(n.TYPE) && n.TYPE != "AAA").Count() + actualUnit.NUMCOMBATS;
                        bool qualifiesForDone = obj.UNITCATEGORY switch
                        {
                            "AIR" => false,
                            "SUB" => actualUnit.NUMCOMBATS > 0 && actualUnit.MOVEMENTALLOWANCE == 0,
                            "SURFACE" => actualUnit.NUMCOMBATS > 1 && actualUnit.MOVEMENTALLOWANCE == 0,
                            _ => false
                        };
                        double plannedDistance = movements.Where(n => n.MOVEMENTCONNECTOR != null).Sum(n => n.DISTANCE);
                        double delay = actualUnit.ENROUTEDELAY + actualUnit.SEARCHDELAY;

                        double remaining = actualUnit.MOVEMENTALLOWANCE - plannedDistance - delay;
                        remaining = actualUnit.UNITCATEGORY switch
                        {
                            "AIR" => remaining,
                            _ => Math.Max(0, remaining)
                        };
                        actualUnit.REMAININGMOVEMENT = actualUnit.DRAGGING ? remaining : actualUnit.MOVEMENTALLOWANCE;
                        destinationMarker.REMAININGMOVEMENT = remaining;
                        //show future moves as they are being added
                        if (movements.Count > 1)
                        {
                            string color = destinationMarker.REMAININGMOVEMENT < 0 ? "RED" : "WHITE";
                            for (int i = 1; i < movements.Count; i++)
                            {
                                FSMovement movement = movements[i];
                                movement.MOVEMENTCONNECTOR.MakeLineVisible(color);
                                if (movement == movements.Last())
                                {
                                    movement.MOVEMENTLOCATION.MakeEllipseVisible(color, true, 20);
                                }
                            }
                        }
                        if (!init)
                        {
                            bool HASMOVEMENTS = movements.Count > 1 || actualUnit.MOVEMENTALLOWANCE == 0;
                            actualUnit.NOORDERS = !(HASMOVEMENTS || actualUnit.SEARCHMODE || actualUnit.LOITERMODE || actualUnit.ASWPATROLMODE) && !SIDE_IS_AI;
                            if (!actualUnit.NOORDERS)
                            {
                                foreach (GO logic in NOORDERSALERTS.Where(n => n.INTERCEPTEDGRP == actualUnit).ToList())
                                {
                                    FS.DISCARDLOGIC(logic);
                                    NOORDERSALERTS.Remove(logic);
                                }
                            }
                            else
                            {
                                if (!NOORDERSALERTS.Where(n => n.INTERCEPTEDGRP == actualUnit).Any())
                                {
                                    NOORDERSALERTS.Add(FS.CREATEALERT(actualUnit, null, side));
                                }
                            }
                        }
                        GO actualLocation = movements.First().MOVEMENTLOCATION;
                        if (attackingUnit == obj)
                        {
                            switch (COMBATMODE)
                            {
                                case "BOMB":
                                case "CC":
                                    if (TARGETS[obj][COMBATMODE].Where(n => n.UNITCATEGORY == "SURFACE").Any()) { GS.AddAction(obj, "TARGET SHIPS"); }
                                    if (TARGETS[obj][COMBATMODE].Where(n => n.AIRFIELD && !n.AIRFIELDDESTROYED).Any()) { GS.AddAction(obj, "TARGET AIRFIELD"); }
                                    if (TARGETS[obj][COMBATMODE].Where(n => n.PORT && !n.PORTDESTROYED).Any()) { GS.AddAction(obj, "TARGET PORT"); }
                                    if (TARGETS[obj][COMBATMODE].Where(n => n.CLOSEDEFENSE && !n.CLOSEDEFENSEDESTROYED).Any()) { GS.AddAction(obj, "TARGET CLOSEDEFENSE"); }
                                    break;
                                default:
                                    break;
                            }
                            GS.AddAction(obj, "CANCEL ATTACK");
                        }
                        else
                        {
                            List<GO> groupMembers = FS.GROUPMEMBERS(actualUnit);
                            if (actualUnit.SEARCHMODE && actualUnit.SEARCHDELAY == 0)
                            {
                                FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.SEARCHDELAY = (int)GetDouble("_CONFIG_AIR_RECON_MODE_MOVE_COST_MULTIPLIER"));
                            }
                            if (GS.InteractionMap[obj].Count != 0)
                            {
                                foreach (FSMovement m in MOVEMENTCHOICES[obj])
                                {
                                    if (m.MOVEMENTLOCATION.TYPE == "OM")
                                    {
                                        m.LABEL = "To Off Map Airfield";
                                        GS.AddAction(obj, m.LABEL);
                                    }
                                    if (m.MOVEMENTLOCATION.TERRAIN == "OMAF")
                                    {
                                        m.LABEL = "To " + m.MOVEMENTLOCATION.ZONE + " ZONE";
                                        GS.AddAction(obj, m.LABEL);
                                    }
                                }
                            }
                            if (!obj.DRAGGING)
                            {
                                if (obj.GAMELOCATION == actualLocation && obj == actualUnit)
                                {
                                    if (actualUnit.UNITCATEGORY == "AIR")
                                    {
                                        bool landAtHomebase = false;
                                        if (groupMembers.Where(n => n.HOMEBASE?.AIRFIELD == true).Any())
                                        {
                                            if (actualLocation.SIDE == actualUnit.SIDE && actualLocation.AIRFIELD)
                                            {
                                                if (actualLocation != actualUnit.HOMEBASE && actualLocation.AIRFIELDDAMAGELEVEL == 0)
                                                {
                                                    GS.AddAction(obj, "TRANSFER NON-CARRIER UNITS TO THIS AIRFIELD");
                                                }
                                                if(actualLocation == actualUnit.HOMEBASE)
                                                {
                                                    landAtHomebase = true;
                                                }
                                            }
                                        }
                                        if(groupMembers.Where(n => n.HOMEBASE?.DOMAIN == GO.DOMAIN_PIECE && n.HOMEBASE.GAMELOCATION == actualLocation).Any())
                                        {
                                            landAtHomebase = true;
                                        }
                                        if (landAtHomebase)
                                        {
                                            GS.AddAction(obj, "LAND AT HOMEBASE");
                                        }
                                        if (actualUnit.GAMELOCATION.TYPE == "HEX")
                                        {
                                            if (!actualUnit.SEARCHMODE || actualUnit.SEARCHDELAY == 5)
                                            {
                                                if (FS.AIRSURFACEINTERACTION)
                                                {
                                                    bool surfaceSearch = groupMembers.Where(n => FS.GETAIRSURFACESEARCH(n) >= 1).Any();
                                                    bool subSearch = groupMembers.Where(n => n.TEMPLATE.ASW > 0).Any();
                                                    if (surfaceSearch && subSearch)
                                                    {
                                                        GS.AddAction(obj, "SURFACE/SUB SEARCH|" + (obj.SEARCHMODE ? "TRUE" : "FALSE"));
                                                    }
                                                    else if (surfaceSearch || subSearch)
                                                    {
                                                        GS.AddAction(obj, (surfaceSearch ? "SURFACE" : "SUB") + " SEARCH|" + (obj.SEARCHMODE ? "TRUE" : "FALSE"));
                                                    }
                                                }
                                                GS.AddAction(obj, "LOITER|" + (obj.LOITERMODE ? "TRUE" : "FALSE"));
                                            }
                                        }
                                        if (actualUnit.AIRMISSION == "AIR SUPERIORITY" && actualUnit.NUMCOMBATS == 0)
                                        {
                                            GS.AddAction(obj, "AUTO-INTERCEPT|" + (obj.INTERCEPTMODE ? "TRUE" : "FALSE"));
                                        }
                                    }
                                    else
                                    {
                                        if (actualLocation.PORT)
                                        {
                                            if (actualLocation.SIDE == actualUnit.SIDE)
                                            {
                                                if (!groupMembers.Where(n => !FS.CANDOCK(n)).Any())
                                                {

                                                    GS.AddAction(obj, "DOCK");
                                                }
                                            }
                                        }
                                        if (groupMembers.Where(n => n.VP_REMOVABLE).Any())
                                        {
                                            List<GO> LOGICS = [.. VPOBJECTIVELOCATIONIDS.Keys.Where(n => VPOBJECTIVELOCATIONIDS[n].Contains(actualLocation.ID))];
                                            if (LOGICS.Count > 0)
                                            {
                                                foreach (GO LOGIC in LOGICS)
                                                {
                                                    double vp = LOGIC.VP_MULTIPLE * groupMembers.Where(n => n.VP_REMOVABLE).Sum(n => FS.VPVALUE(n) * (n.DAMAGED ? 0.5 : 1));
                                                    GS.AddAction(obj, "AWARD VP: " + vp + " (" + LOGIC.OBJECTIVETYPE + ")");
                                                }
                                            }
                                            GS.AddAction(obj, "REMOVE OBJECTIVE SHIPS FROM GAME");
                                        }
                                        if (actualUnit.MOVEMENTALLOWANCE > 0 && actualUnit.GAMELOCATION.TYPE == "HEX")
                                        {
                                            if (FS.SUBREALTIMEDETECTION)
                                            {
                                                GS.AddAction(obj, "LOITER/PATROL|" + (obj.ASWPATROLMODE ? "TRUE" : "FALSE"));
                                            }
                                        }
                                    }
                                    if (!TARGETS.ContainsKey(actualUnit))
                                    {
                                        TARGETS.Add(actualUnit, new());
                                        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers);
                                        attackData.Keys.ToList().ForEach(n => ATTACKDATA.Add(n, attackData[n]));
                                    }
                                    Dictionary<string, bool> allowable = combats.Any() ? new() : new()
                                    {
                                        {
                                            "SSM",
                                            actualUnit.UNITCATEGORY switch
                                            {
                                                "SURFACE" => !(actualUnit.DONESSM || numCombats >= 2),
                                                _ => numCombats == 0 && (actualUnit.AIRMISSION == null || actualUnit.AIRMISSION == "SSM")
                                            }
                                        },
                                        {
                                            "CC",
                                            actualUnit.UNITCATEGORY switch
                                            {
                                                "SURFACE" => !actualUnit.DONECC,
                                                _ => false
                                            }
                                        },
                                        {
                                            "CM",
                                            actualUnit.UNITCATEGORY switch
                                            {
                                                "SURFACE" => !(actualUnit.DONECM || numCombats >= 2),
                                                _ => numCombats == 0 && (actualUnit.AIRMISSION == null || actualUnit.AIRMISSION == "CRUISE MISSILE")
                                            }
                                        },
                                        {
                                            "ASW",
                                            actualUnit.UNITCATEGORY switch
                                            {
                                                "SURFACE" => !(actualUnit.DONEASW || numCombats >= 2),
                                                _ => numCombats == 0 && (actualUnit.AIRMISSION == null || actualUnit.AIRMISSION == "ASW")
                                            }
                                        },
                                        {
                                            "BOMB",
                                            actualUnit.UNITCATEGORY switch
                                            {
                                                "AIR" => numCombats == 0 && (actualUnit.AIRMISSION == null || actualUnit.AIRMISSION == "BOMBING"),
                                                _ => false
                                            }
                                        },
                                        {
                                            "TORP",
                                            actualUnit.UNITCATEGORY switch
                                            {
                                                "SUB" => numCombats == 0,
                                                _ => false
                                            }
                                        },
                                        {
                                            "AAA",
                                            actualUnit.UNITCATEGORY switch
                                            {
                                                "SURFACE" => FS.AIRSURFACEINTERACTION,
                                                _ => false
                                            }
                                        },
                                        {
                                            "TACCOORD",
                                            actualUnit.UNITCATEGORY switch
                                            {
                                                "AIR" => !FS.STRATEGICTACCOORD && actualUnit.SEARCHMODE && actualUnit.AIRMISSION == "RECON",
                                                _ => false
                                            }
                                        }

                                    };
                                    if (allowable.Values.Where(n => n).Any() && !FS.STORM(obj.GAMELOCATION))
                                    {
                                        foreach (string ct in FS.COMBATMISSIONTYPES.Where(n => allowable[n]))
                                        {
                                            if (!TARGETS[actualUnit].ContainsKey(ct))
                                            {
                                                TARGETS[actualUnit].Add(ct, new());
                                                foreach (GO gm in groupMembers)
                                                {
                                                    if (ATTACKDATA.TryGetValue(gm, out Dictionary<string, Dictionary<string, Dictionary<string, double>>> dict))
                                                    {
                                                        if (dict.ContainsKey(ct))
                                                        {
                                                            TARGETS[actualUnit][ct].AddRange(GETTARGETS(actualUnit, ct));
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            if (TARGETS[actualUnit][ct].Any())
                                            {
                                                GS.AddAction(obj, ct + " ATTACK");
                                            }
                                        }
                                        if (allowable["TACCOORD"])
                                        {
                                            string ct = "TACCOORD";
                                            if (!TARGETS[actualUnit].ContainsKey(ct))
                                            {
                                                TARGETS[actualUnit].Add(ct, new());
                                                TARGETS[actualUnit][ct].AddRange(GETTARGETS(actualUnit, ct));
                                            }

                                            if (TARGETS[actualUnit][ct].Any())
                                            {
                                                List<GO> targets = TARGETS[actualUnit][ct];
                                                if (targets.Where(n => n.UNITCATEGORY == "SUB").Any())
                                                {
                                                    GS.AddAction(obj, "SUB TACCOORD DESIGNATE");
                                                }
                                                if (targets.Where(n => n.UNITCATEGORY == "SURFACE").Any())
                                                {
                                                    GS.AddAction(obj, "SURFACE TACCOORD DESIGNATE");
                                                }
                                            }
                                        }
                                    }
                                    if (!FS.STRATEGICMINING)
                                    {
                                        GO MINELOCATION = actualUnit.UNITCATEGORY == "AIR" ? actualUnit.GAMELOCATION : actualUnit.DESTINATIONPIECE.GAMELOCATION;
                                        if (MINEOPTIONS(actualUnit).Contains(MINELOCATION))
                                        {
                                            GS.AddAction(actualUnit, "LAY MINES");
                                        }
                                    }
                                    if (!FS.STORM(actualLocation) && !FS.SQUALL(actualLocation))
                                    {
                                        if (actualUnit.LOCATIONHISTORY.Split('|').Length == 1)
                                        {
                                            if (actualUnit.COMMANDOPTS > 0 && actualUnit.GAMELOCATION.COUNTRY != null)
                                            {
                                                GS.AddAction(actualUnit, "INSERT COMMANDOS");
                                            }
                                            if ((FS.LANDWAR || FS.GARRISONWAR) && (actualUnit.GAMELOCATION.PORT || actualUnit.GAMELOCATION.AIRFIELD))
                                            {
                                                if (FS.GROUPMEMBERS(actualUnit).Where(n => FS.SURFACELADENTYPES.Contains(n.UNITTYPE) && !n.EMPTY).Any())
                                                {
                                                    if (actualUnit.GAMELOCATION.SIDE == FS.ENEMY(actualUnit.SIDE))
                                                    {
                                                        GS.AddAction(actualUnit, "UNLOAD TO ENEMY BASE");
                                                    }
                                                    else if (actualUnit.GAMELOCATION.SIDE == actualUnit.SIDE)
                                                    {
                                                        GS.AddAction(actualUnit, "UNLOAD TO FRIENDLY BASE");
                                                    }
                                                }
                                            }
                                        }
                                        if ((FS.LANDWAR || FS.GARRISONWAR) && (actualUnit.GAMELOCATION.PORT || actualUnit.GAMELOCATION.AIRFIELD))
                                        {
                                            if (FS.GROUPMEMBERS(actualUnit).Where(n => n.UNITTYPE == "ATR" && !n.EMPTY).Any())
                                            {
                                                if (actualUnit.GAMELOCATION.SIDE == FS.ENEMY(actualUnit.SIDE))
                                                {
                                                    GS.AddAction(actualUnit, "DROP TO ENEMY BASE");
                                                }
                                                else if (actualUnit.GAMELOCATION.SIDE == actualUnit.SIDE)
                                                {
                                                    GS.AddAction(actualUnit, "DROP TO FRIENDLY BASE");
                                                }
                                            }
                                        }
                                    }
                                }
                                if (movements.Count > 1)
                                {
                                    GS.AddAction(obj, "RESET MOVEMENT");
                                }
                                if (combats.Count != 0)
                                {
                                    GS.AddAction(obj, "RESET ATTACK");
                                }
                                if (qualifiesForDone)
                                {
                                    GS.AddAction(obj, "DESIGNATE AS DONE");
                                }
                            }
                            GS.AddAction(obj, "END PHASE");
                        }
                    }
                    else
                    {
                        switch (COMBATMODE)
                        {
                            case "SSM":
                            case "TORP":
                            case "AAA":
                            case "SURFACE TACCOORD":
                                GS.AddAction(obj, "TARGET THIS LOCATION");
                                GS.AddAction(obj, "CANCEL ATTACK");
                                break;
                            case "CM":
                                if (obj.AIRFIELD && !obj.AIRFIELDDESTROYED) { GS.AddAction(obj, "TARGET AIRFIELD"); }
                                if (obj.PORT && !obj.PORTDESTROYED) { GS.AddAction(obj, "TARGET PORT"); }
                                if (obj.CLOSEDEFENSE && !obj.CLOSEDEFENSEDESTROYED) { GS.AddAction(obj, "TARGET CLOSEDEFENSE"); }
                                GS.AddAction(obj, "CANCEL ATTACK");
                                break;
                            case "ASW":
                            case "SUB TACCOORD":
                                GS.AddAction(obj, "TARGET");
                                GS.AddAction(obj, "CANCEL ATTACK");
                                break;
                            default:
                                break;
                        }
                    }
                }            
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (init){
                FS.SETVIEW(GS);
            }
            foreach(GO obj in DESTINATIONS)
            {
                bool hidden = (obj.GAMELOCATION == obj.GAMEPIECE.GAMELOCATION && MOVEMENTFUTURES[obj.GAMEPIECE].Count <= 1) ||
                (obj.GAMEPIECE != GS.SelectedMarker && obj != GS.SelectedMarker);

                if(hidden != obj.HIDDEN)
                {
                    Window().DrawMarkerStack(obj.GAMELOCATION);
                }
                obj.HIDDEN = hidden;
                if (obj.HIDDEN)
                {
                    GS.InteractionMap.Remove(obj);
                }
                else if(!GS.InteractionMap.ContainsKey(obj))
                {
                    List<FSMovement> choices = obj.GAMEPIECE.UNITCATEGORY switch
                    {
                        "AIR" => FS.FINDAIRMOVEMENTS(obj.GAMELOCATION),
                        "SUB" => FS.FINDSUBMOVEMENTS(obj, obj.GAMELOCATION, false),
                        "SURFACE" => FS.FINDSURFACEMOVEMENTS(obj, obj.GAMELOCATION, false),
                        _ => new()
                    };
                    MOVEMENTCHOICES[obj] = choices;
                    GS.InteractionMap[obj] = [..choices.Select(n => n.MOVEMENTLOCATION)];
                }
            }                
        }
        private void AI()
        {
            List<GO> PROCESSED = [];
            List<GO> ACTIVELOGICLINKS = [.. GS.TYPE("AI.LOGICLINK").Where(n => n.ACTIVE)];
            List<GO> GROUPINGSHIPS = [.. ACTIVELOGICLINKS.Where(n => n.LOGIC.OBJECTIVETYPE == "GROUPING").Select(n => n.UNIT)];
            double aggressionfactor = GS.Get("AI." + side) switch
            {
                "CAUTIOUS" => 1,
                "AGGRESSIVE" => 3,
                _ => 2
            };
            //put units in groups
            List<List<GO>> ACTIONGROUPS = [];
            List<GO> ACTIONSHIPS = GS.InteractionMap.Keys.Where(n => n.TYPE == "SHIP" && n.SIDE == side && !GROUPINGSHIPS.Contains(n)).ToList();
            ACTIONGROUPS.Add(ACTIONSHIPS);
            List<GO> ACTIONSHIPSGROUPING = GS.InteractionMap.Keys.Where(n => n.TYPE == "SHIP" && n.SIDE == side && GROUPINGSHIPS.Contains(n)).ToList();
            ACTIONGROUPS.Add(ACTIONSHIPSGROUPING);
            List<GO> ACTIONSQNS = GS.InteractionMap.Keys.Where(n => n.TYPE == "SQN" && n.SIDE == side && n.AIRMISSION != "ESCORT").ToList();
            ACTIONGROUPS.Add(ACTIONSQNS);
            List<GO> ACTIONSQNESCORTS = GS.InteractionMap.Keys.Where(n => n.TYPE == "SQN" && n.SIDE == side && n.AIRMISSION == "ESCORT").ToList();
            ACTIONGROUPS.Add(ACTIONSQNESCORTS);
            foreach (List<GO> actionGroup in ACTIONGROUPS)
            {
                foreach (GO obj in actionGroup)
                {
                    PROCESSED.Add(obj);
                    GO actualUnit = obj;
                    GO escortedUnit = null;
                    List<GO> groupMembers = FS.GROUPMEMBERS(actualUnit);
                    //if nothing left to do skip
                    List<GO> combats = [.. COMBATS.Where(n => n.ATTACKER == actualUnit)];
                    int numCombats = combats.Where(n => FS.COMBATMISSIONTYPES.Contains(n.TYPE) && n.TYPE != "AAA").Count() + actualUnit.NUMCOMBATS;
                    bool qualifiesForDone = obj.UNITCATEGORY switch
                    {
                        "AIR" => false,
                        "SUB" => actualUnit.NUMCOMBATS > 0 && actualUnit.MOVEMENTALLOWANCE == 0,
                        "SURFACE" => actualUnit.NUMCOMBATS > 1 && actualUnit.MOVEMENTALLOWANCE == 0,
                        _ => false
                    };
                    if (qualifiesForDone)
                    {
                        continue;
                    }
                    GO destinationMarker = obj.DESTINATIONPIECE;
                    GO LOGICLINK = ACTIVELOGICLINKS.Where(n => n.UNIT == obj).FirstOrDefault();
                    if (LOGICLINK != null)
                    {
                        List<string> ACTIONLIST = [];
                        bool ATFOCUS = actualUnit.GAMELOCATION == LOGICLINK.AIFOCUSLOCATION;
                        bool SEARCHING = actualUnit.SEARCHMODE && actualUnit.SEARCHDELAY > 0 && actualUnit.SEARCHDELAY < 5;
                        bool INCOVERAGE = LOGICLINK.LOGIC.LOCATIONCOVERAGE.Contains(actualUnit.GAMELOCATIONID);
                        if (LOGICLINK.LOGIC.OBJECTIVETYPE == "PATROL" && INCOVERAGE)
                        {
                            ACTIONLIST.Add("SEARCH");
                        }
                        if (actualUnit.UNITCATEGORY == "AIR")
                        {
                            double RANGE = actualUnit.TEMPLATE.MOVEMENTALLOWANCE * 0.5;
                            //give some wiggle room for carrier based aircraft
                            if (actualUnit.MOVEMENTALLOWANCE <= RANGE || actualUnit.AIRMISSION == "RTB")
                            {
                                if (!FS.VALIDHOMEBASE(actualUnit))
                                {
                                    GS.IncrementDouble("VP." + FS.ENEMY(actualUnit.SIDE), FS.VPVALUE(actualUnit) * (actualUnit.DAMAGED ? 0.5 : 1));
                                    FS.DESTROY(actualUnit);
                                    continue;
                                }
                                else
                                {
                                    GO homebaseLocation = actualUnit.HOMEBASE.AIRFIELD ? actualUnit.HOMEBASE : actualUnit.HOMEBASE.GAMELOCATION;
                                    List<FSMovement> newPath = FS.FINDAIRMOVEMENTPATH(actualUnit.GAMELOCATION, homebaseLocation);
                                    if (actualUnit.AIRMISSION == "RTB" || actualUnit.MOVEMENTALLOWANCE <= newPath.Sum(n => n.DISTANCE))
                                    {
                                        GS.CHANGELOCATION(destinationMarker, newPath.Last().MOVEMENTLOCATION);
                                        actualUnit.LOCATIONFUTURE = string.Join('|', newPath.Select(n => n.MOVEMENTLOCATIONID));
                                        actualUnit.AIRMISSION = "RTB";
                                        FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.SEARCHMODE = false);
                                        FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.SEARCHDELAY = 0);
                                        FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.LOITERMODE = false);
                                        ACTIONLIST.Clear();
                                        ACTIONLIST.Add("RTB");
                                    }
                                }
                            }
                            if(actualUnit.AIRMISSION != "RTB")
                            {
                                if(actualUnit.AIRMISSION == "ESCORT" && 
                                    actualUnit.NUMCOMBATS == 0)
                                {
                                    List<GO> ESCORTEDUNITS = [.. ACTIONSQNS.Where(n => n != actualUnit && n.AIRMISSION != "RTB" && n.GAMELOCATION == actualUnit.GAMELOCATION)];
                                    if (ESCORTEDUNITS.Count > 0)
                                    {
                                        List<GO> SAMEOBJECTIVE = [.. ACTIVELOGICLINKS.Where(n => n.UNIT != actualUnit && n.LOGIC == LOGICLINK.LOGIC).Select(n => n.UNIT).Intersect(ESCORTEDUNITS)];
                                        if (SAMEOBJECTIVE.Count > 0)
                                        {
                                            escortedUnit = GS.RANDOMGAMEOBJECT(SAMEOBJECTIVE);
                                        }
                                        else
                                        {
                                            escortedUnit = GS.RANDOMGAMEOBJECT(ESCORTEDUNITS);
                                        }
                                        ACTIONLIST.Add("ESCORT");
                                    }
                                }
                            }
                        }
                        else if(actualUnit.UNITCATEGORY == "SURFACE")
                        {
                            if(LOGICLINK.LOGIC.OBJECTIVETYPE == "GROUPING")
                            {
                                List<GO> ESCORTEDUNITS = [.. GS.InteractionMap.Keys.Where(n => 
                                n != actualUnit && 
                                n.UNITCATEGORY == "SURFACE" && 
                                PROCESSED.Contains(n) && 
                                n.GAMELOCATION == LOGICLINK.AIFOCUSLOCATION)];

                                if (ESCORTEDUNITS.Count > 0)
                                {
                                    escortedUnit = GS.RANDOMGAMEOBJECT(ESCORTEDUNITS);
                                    ACTIONLIST.Add("ESCORT");
                                }
                            }
                        }
                        if (!ATFOCUS && !SEARCHING)
                        {
                            ACTIONLIST.Add("MOVE");
                        }
                        GO actualLocation = actualUnit.GAMELOCATION;
                        if (actualUnit.UNITCATEGORY == "AIR")
                        {
                            if (actualUnit.GAMELOCATION.TYPE == "HEX")
                            {
                                if (!SEARCHING)
                                {
                                    if (FS.AIRSURFACEINTERACTION && ACTIONLIST.Contains("SEARCH"))
                                    {
                                        if (groupMembers.Where(n => FS.GETAIRSURFACESEARCH(n) >= 1).Any())
                                        {
                                            ACTIONLIST.Add("SURFACESEARCH");
                                        }
                                        if (groupMembers.Where(n => n.TEMPLATE.ASW > 0).Any())
                                        {
                                            ACTIONLIST.Add("SUBSEARCH");
                                        }
                                    }
                                }
                            }
                            FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.INTERCEPTMODE = (actualUnit.AIRMISSION == "AIR SUPERIORITY" || actualUnit.AIRMISSION == "ESCORT") && actualUnit.UNITTYPE == "INT" && actualUnit.NUMCOMBATS == 0);
                        }
                        else
                        {
                            if (actualLocation.PORT)
                            {
                                if (actualLocation.SIDE == actualUnit.SIDE)
                                {
                                    if (!groupMembers.Where(n => !FS.CANDOCK(n)).Any() && ATFOCUS)
                                    {
                                        ACTIONLIST.Add("DOCK");
                                    }
                                }
                            }
                            if (actualUnit.MOVEMENTALLOWANCE > 0 && actualUnit.GAMELOCATION.TYPE == "HEX")
                            {
                                if (FS.SUBREALTIMEDETECTION && ACTIONLIST.Contains("SEARCH") && groupMembers.Where(n => n.TEMPLATE.ASW > 0).Any())
                                {
                                    ACTIONLIST.Add("SUBSEARCH");
                                }
                            }
                        }
                        if (ATFOCUS)
                        {
                            if (actualUnit.LOCATIONHISTORY.Split('|').Length == 1)
                            {
                                if (actualUnit.MINEPTS > 0 && LOGICLINK.LOGIC.OBJECTIVETYPE == "LAY MINES")
                                {
                                    ACTIONLIST.Add("LAY MINES");
                                }
                            }
                            if (!FS.STORM(actualLocation) && !FS.SQUALL(actualLocation))
                            {
                                if (actualUnit.LOCATIONHISTORY.Split('|').Length == 1)
                                {
                                    if (actualUnit.COMMANDOPTS > 0 && LOGICLINK.LOGIC.OBJECTIVETYPE == "INSERT COMMANDOS")
                                    {
                                        ACTIONLIST.Add("INSERT COMMANDOS");
                                    }
                                    if ((FS.LANDWAR || FS.GARRISONWAR) && (actualUnit.GAMELOCATION.PORT || actualUnit.GAMELOCATION.AIRFIELD))
                                    {
                                        if (FS.GROUPMEMBERS(actualUnit).Where(n => FS.SURFACELADENTYPES.Contains(n.UNITTYPE) && !n.EMPTY).Any() && LOGICLINK.LOGIC.OBJECTIVETYPE == "UNLOAD")
                                        {
                                            ACTIONLIST.Add("UNLOAD");
                                        }
                                        if (FS.GROUPMEMBERS(actualUnit).Where(FS.CANSHIPLOAD).Any() && LOGICLINK.LOGIC.OBJECTIVETYPE == "LOAD")
                                        {
                                            ACTIONLIST.Add("LOAD");
                                        }
                                        if (LOGICLINK.LOGIC.OBJECTIVETYPE == "REPLENISH")
                                        {
                                            if (!actualLocation.PORTDESTROYED && groupMembers.Where(n => n.FUELPTS < n.TEMPLATE.FUELPTS).Any())
                                            {
                                                ACTIONLIST.Add("REPLENISH");
                                            }
                                        }
                                    }
                                }
                                if ((FS.LANDWAR || FS.GARRISONWAR) && (actualUnit.GAMELOCATION.PORT || actualUnit.GAMELOCATION.AIRFIELD))
                                {
                                    if (FS.GROUPMEMBERS(actualUnit).Where(n => n.UNITTYPE == "ATR" && !n.EMPTY).Any() && LOGICLINK.LOGIC.OBJECTIVETYPE == "AIRDROP")
                                    {
                                        ACTIONLIST.Add("AIRDROP");
                                    }
                                }
                            }
                        }
                        //first do movement type orders
                        //MOVE
                        //RTB
                        //SEARCH
                        //AIRINTERCEPT
                        //COMMANDOS
                        //LOAD
                        //UNLOAD
                        if (actualUnit.UNITCATEGORY == "AIR" || shipMoveCycle)
                        {
                            if (ACTIONLIST.Contains("INSERT COMMANDOS"))
                            {
                                GO commandoTemplate = GS.PIECE("COMMANDO");
                                actualUnit.COMMANDOPTS -= 1;
                                GO cmndo = FS.CLONE(GS, commandoTemplate, actualUnit.GAMELOCATIONID);
                                cmndo.SIDE = actualUnit.SIDE;
                                DESIGNATEASDONE(actualUnit, destinationMarker);
                                continue;
                            }
                            else if (ACTIONLIST.Contains("LAY MINES"))
                            {
                                GO mineTemplate = GS.PIECE("MINE");
                                actualUnit.MINEPTS -= 1;
                                GO mine = FS.CLONE(GS, mineTemplate, destinationMarker.GAMELOCATIONID);
                                mine.SIDE = side;
                                DESIGNATEASDONE(actualUnit, destinationMarker);
                                actualUnit.ADMINPROTECTED = true;
                                continue;
                            }
                            else if (ACTIONLIST.Contains("UNLOAD"))
                            {
                                if (actualUnit.GAMELOCATION.SIDE == actualUnit.SIDE && actualUnit.GAMELOCATION.PORT)
                                {
                                    FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.DOCKED = true);
                                }
                                FS.AMPHIBIOUSDROP(actualUnit);
                                DESIGNATEASDONE(actualUnit, destinationMarker);
                                continue;
                            }
                            else if (ACTIONLIST.Contains("LOAD"))
                            {
                                if (actualUnit.GAMELOCATION.SIDE == actualUnit.SIDE && actualUnit.GAMELOCATION.PORT)
                                {
                                    FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.DOCKED = true);
                                }
                                foreach (GO ship in FS.GROUPMEMBERS(actualUnit).Where(n => FS.SURFACELADENTYPES.Contains(n.UNITTYPE)))
                                {
                                    ship.LOADING = true;
                                    ship.EMPTY = false;
                                    GO replenishmentBase = FS.PARENTGROUPLOCATION(ship);
                                    bool cargo = FS.SURFACECARGOTYPES.Contains(ship.UNITTYPE);
                                    if (FS.LANDWAR)
                                    {
                                        GO logisticalZone = GS.TYPE("POSSESSIONFLAG").Where(n => n.LOGISTICALZONE == replenishmentBase.LOGISTICALZONE).Single();
                                        if (cargo)
                                        {
                                            logisticalZone.SUPPLIES -= ship.TEMPLATE.SPECIAL;
                                        }
                                        else
                                        {
                                            logisticalZone.STRENGTH -= ship.TEMPLATE.SPECIAL;
                                        }
                                    }
                                    else if (FS.GARRISONWAR)
                                    {
                                        //find facility
                                        GO facility = FS.TYPESIDELOCATION(GS, "FACILITY", ship.SIDE, replenishmentBase.ID).Where(n => n.PORT).First();
                                        facility.STRENGTH -= ship.TEMPLATE.SPECIAL;
                                    }
                                }
                                DESIGNATEASDONE(actualUnit, destinationMarker);
                                continue;
                            }
                            else if (ACTIONLIST.Contains("AIRDROP"))
                            {
                                if (actualUnit.GAMELOCATION.SIDE == actualUnit.SIDE && actualUnit.GAMELOCATION.PORT)
                                {
                                    FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.DOCKED = true);
                                }
                                FS.AMPHIBIOUSDROP(actualUnit);
                                DESIGNATEASDONE(actualUnit, destinationMarker);
                                continue;
                            }
                            else if (ACTIONLIST.Contains("RTB"))
                            {
                                
                            }
                            else if (ACTIONLIST.Contains("ESCORT"))
                            {
                                switch(actualUnit.UNITCATEGORY){
                                    case "AIR":
                                        if (escortedUnit.SEARCHMODE)
                                        {
                                            FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.LOITERMODE = true);
                                            GS.CHANGELOCATION(destinationMarker, actualUnit.GAMELOCATIONID);
                                            actualUnit.LOCATIONFUTURE = actualUnit.GAMELOCATIONID;
                                        }
                                        else
                                        {
                                            string[] sqnlocs = escortedUnit.LOCATIONFUTURE.Split('|');
                                            FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.LOITERMODE = false); 
                                            FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.SEARCHMODE = false);
                                            FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.SEARCHDELAY = 0);

                                            GS.CHANGELOCATION(destinationMarker, sqnlocs.Last());
                                            actualUnit.LOCATIONFUTURE = escortedUnit.LOCATIONFUTURE;
                                        }
                                        break;
                                    case "SURFACE":
                                        string[] locations = escortedUnit.LOCATIONFUTURE.Split('|');
                                        if (escortedUnit.GAMELOCATION == actualUnit.GAMELOCATION)
                                        {
                                            FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.ASWPATROLMODE = escortedUnit.ASWPATROLMODE);
                                        }
                                        //get the first destination in the escorted units path
                                        string escortedNextMove = locations[Math.Min(locations.Length - 1, escortedUnit.MOVEMENTALLOWANCE == 0 ? 0 : 1)];
                                        List<FSMovement> newPath = FS.FINDAUTOSEAMOVEMENTPATH(actualUnit, actualUnit.GAMELOCATION, GS.LOCATION(escortedNextMove));
                                        GS.CHANGELOCATION(destinationMarker, newPath.Last().MOVEMENTLOCATION);
                                        actualUnit.LOCATIONFUTURE = string.Join('|', newPath.Select(n => n.MOVEMENTLOCATIONID));
                                        break;
                                    default:
                                        break;
                                }
                                LOGICLINK.AIFOCUSLOCATIONID = destinationMarker.GAMELOCATIONID;
                                LOGICLINK.AIFOCUSLOCATION = destinationMarker.GAMELOCATION;
                            }
                            else
                            {
                                bool DOMOVE = false;
                                bool DOSEARCH = false;
                                bool CANMOVE = ACTIONLIST.Contains("MOVE");
                                bool CANSEARCH = ACTIONLIST.Contains("SURFACESEARCH") || ACTIONLIST.Contains("SUBSEARCH");
                                if (CANMOVE && CANSEARCH)
                                {
                                    double moveChance = 25 * aggressionfactor;
                                    if (LOGICLINK.INTERCEPTMODE)
                                    {
                                        moveChance *= 1.5;
                                    }
                                    if (GS.RANDOMINT(100) < moveChance)
                                    {
                                        DOMOVE = true;
                                        DOSEARCH = false;
                                    }
                                    else
                                    {
                                        DOMOVE = false;
                                        DOSEARCH = true;
                                    }
                                }
                                else
                                {
                                    DOMOVE = CANMOVE;
                                    DOSEARCH = CANSEARCH;
                                }
                                if (DOSEARCH)
                                {
                                    FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.LOITERMODE = false);
                                    if (actualUnit.UNITCATEGORY == "AIR")
                                    {
                                        FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.SEARCHMODE = true);
                                        FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.SEARCHDELAY = 5);
                                    }
                                    else
                                    {
                                        FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.ASWPATROLMODE = true);
                                    }
                                    GS.CHANGELOCATION(destinationMarker, actualUnit.GAMELOCATIONID);
                                    actualUnit.LOCATIONFUTURE = actualUnit.GAMELOCATIONID;
                                }
                                else if (!SEARCHING)
                                {
                                    FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.LOITERMODE = false); 
                                    FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.SEARCHMODE = false);
                                    FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.ASWPATROLMODE = false);
                                }
                                if (DOMOVE)
                                {
                                    if (destinationMarker.GAMELOCATION != LOGICLINK.AIFOCUSLOCATION)
                                    {
                                        List<FSMovement> newPath = actualUnit.UNITCATEGORY == "AIR" ?
                                            FS.FINDAIRMOVEMENTPATH(actualUnit.GAMELOCATION, LOGICLINK.AIFOCUSLOCATION) :
                                            FS.FINDAUTOSEAMOVEMENTPATH(actualUnit, actualUnit.GAMELOCATION, LOGICLINK.AIFOCUSLOCATION);
                                        GS.CHANGELOCATION(destinationMarker, newPath.Last().MOVEMENTLOCATION);
                                        actualUnit.LOCATIONFUTURE = string.Join('|', newPath.Select(n => n.MOVEMENTLOCATIONID));
                                    }
                                }
                            }
                        }
                    }
                    //COMBAT
                    List<string> ATTACKLIST = [];
                    if (!TARGETS.ContainsKey(actualUnit))
                    {
                        TARGETS.Add(actualUnit, new());
                        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers);
                        attackData.Keys.ToList().ForEach(n => ATTACKDATA.Add(n, attackData[n]));
                    }
                    Dictionary<string, bool> allowable = combats.Any() ? new() : new()
                    {
                        {
                            "SSM",
                            actualUnit.UNITCATEGORY switch
                            {
                                "SURFACE" => !(actualUnit.DONESSM || numCombats >= 2),
                                "SUB" => numCombats == 0,
                                _ => numCombats == 0 && actualUnit.SSM > 0
                            }
                        },
                        {
                            "CC",
                            actualUnit.UNITCATEGORY switch
                            {
                                "SURFACE" => !actualUnit.DONECC,
                                _ => false
                            }
                        },
                        {
                            "CM",
                            actualUnit.UNITCATEGORY switch
                            {
                                "SURFACE" => !(actualUnit.DONECM || numCombats >= 2),
                                "SUB" => numCombats == 0,
                                _ => numCombats == 0 && actualUnit.CM > 0
                            }
                        },
                        {
                            "ASW",
                            actualUnit.UNITCATEGORY switch
                            {
                                "SURFACE" => !(actualUnit.DONEASW || numCombats >= 2),
                                "SUB" => numCombats == 0,
                                _ => numCombats == 0 && actualUnit.TORPPTS > 0
                            }
                        },
                        {
                            "BOMB",
                            actualUnit.UNITCATEGORY switch
                            {
                                "AIR" => numCombats == 0 && actualUnit.SPECIAL > 0,
                                _ => false
                            }
                        },
                        {
                            "TORP",
                            actualUnit.UNITCATEGORY switch
                            {
                                "SUB" => numCombats == 0,
                                _ => false
                            }
                        },
                        {
                            "AAA",
                            actualUnit.UNITCATEGORY switch
                            {
                                "SURFACE" => FS.AIRSURFACEINTERACTION,
                                _ => false
                            }
                        },
                        {
                            "TACCOORD",
                            actualUnit.UNITCATEGORY switch
                            {
                                "AIR" => !FS.STRATEGICTACCOORD && actualUnit.SEARCHMODE && actualUnit.AIRMISSION == "RECON",
                                _ => false
                            }
                        }

                    };
                    if (allowable.Values.Where(n => n).Any() && !FS.STORM(obj.GAMELOCATION))
                    {
                        //allow AAA and ASW to happen at any time, since planes move so much, and subs get detected and undetected often
                        foreach (string ct in FS.COMBATMISSIONTYPES.Where(n => allowable[n] && (actualUnit.UNITCATEGORY == "AIR" || shipCombatCycle || n == "AAA" || n == "ASW")))
                        {
                            if (!TARGETS[actualUnit].TryGetValue(ct, out List<GO> value))
                            {
                                value = new();
                                TARGETS[actualUnit].Add(ct, value);
                                foreach (GO gm in groupMembers)
                                {
                                    if (ATTACKDATA.TryGetValue(gm, out Dictionary<string, Dictionary<string, Dictionary<string, double>>> dict))
                                    {
                                        if (dict.ContainsKey(ct))
                                        {
                                            TARGETS[actualUnit][ct].AddRange(GETTARGETS(actualUnit, ct));
                                            break;
                                        }
                                    }
                                }
                            }
                            if (value.Any())
                            {
                                double attackChance = ct switch
                                {
                                    "TORP" => 20 * aggressionfactor,
                                    "ASW" => actualUnit.UNITCATEGORY == "SUB" ? 25 * aggressionfactor : 100,
                                    "SSM" => actualUnit.AIRMISSION == "RTB" ? 100 : FS.FINDSSMDIRECTPATH(actualUnit.GAMELOCATION, TARGETS[actualUnit][ct].OrderBy(n => GS.GetDistance(n.GAMELOCATION, actualUnit.GAMELOCATION.x, actualUnit.GAMELOCATION.y)).First().GAMELOCATION).Sum(n => n.DISTANCE) 
                                        switch
                                        { 
                                            0 => 100,
                                            1 => 100,
                                            2 => 30 * aggressionfactor,
                                            _ => 20 * aggressionfactor
                                        },
                                    _ => 100
                                };
                                if (GS.RANDOMINT(100) < attackChance) {
                                    ATTACKLIST.Add(ct);
                                }
                            }
                        }
                    }
                    List<string> facilityObjectiveTypes = ["DESTROY BASE", "DESTROY AIRFIELD", "DESTROY PORT", "DESTROY CLOSEDEFENSE"];
                    bool baseAttack = facilityObjectiveTypes.Contains(LOGICLINK.LOGIC.OBJECTIVETYPE);
                    bool airfieldAttack = LOGICLINK.LOGIC.OBJECTIVETYPE == "DESTROY BASE" || LOGICLINK.LOGIC.OBJECTIVETYPE == "DESTROY AIRFIELD";
                    bool portAttack = LOGICLINK.LOGIC.OBJECTIVETYPE == "DESTROY BASE" || LOGICLINK.LOGIC.OBJECTIVETYPE == "DESTROY PORT";
                    bool cdAttack = LOGICLINK.LOGIC.OBJECTIVETYPE == "DESTROY BASE" || LOGICLINK.LOGIC.OBJECTIVETYPE == "DESTROY CLOSEDEFENSE";
                    if (ATTACKLIST.Contains("CM") && baseAttack)
                    {
                        ATTACKLIST.Remove("CM");
                        List<GO> baseTargets = [.. TARGETS[actualUnit]["CM"].Where(n => n.GAMELOCATION == LOGICLINK.AIFOCUSLOCATION)];
                        Dictionary<string, GO> TGTS = [];
                        if (airfieldAttack && baseTargets.Where(n => n.AIRFIELD && !n.AIRFIELDDESTROYED).Any()) { TGTS.Add("AIRFIELD", baseTargets.Where(n => n.AIRFIELD && !n.AIRFIELDDESTROYED).First()); }
                        if (portAttack && baseTargets.Where(n => n.PORT && !n.PORTDESTROYED).Any()) { TGTS.Add("PORT", baseTargets.Where(n => n.PORT && !n.PORTDESTROYED).First()); }
                        if (cdAttack && baseTargets.Where(n => n.CLOSEDEFENSE && !n.CLOSEDEFENSEDESTROYED).Any()) { TGTS.Add("CLOSEDEFENSE", baseTargets.Where(n => n.CLOSEDEFENSE && !n.CLOSEDEFENSEDESTROYED).First()); }
                        if (TGTS.Count > 0)
                        {
                            string TGT = TGTS.Keys.ToList()[GS.RANDOMINT(TGTS.Count)];
                            ADDCOMBAT_CCBOMBCM("CM", actualUnit, TGTS[TGT], TGT);
                            continue;
                        }
                    }
                    if (ATTACKLIST.Contains("CC"))
                    {
                        ATTACKLIST.Remove("CC");
                        if (baseAttack)
                        {
                            List<GO> baseTargets = [.. TARGETS[actualUnit]["CC"].Where(n => n.GAMELOCATION == LOGICLINK.AIFOCUSLOCATION)];
                            Dictionary<string, GO> TGTS = [];
                            if (airfieldAttack && baseTargets.Where(n => n.AIRFIELD && !n.AIRFIELDDESTROYED).Any()) { TGTS.Add("AIRFIELD", baseTargets.Where(n => n.AIRFIELD && !n.AIRFIELDDESTROYED).First()); }
                            if (portAttack && baseTargets.Where(n => n.PORT && !n.PORTDESTROYED).Any()) { TGTS.Add("PORT", baseTargets.Where(n => n.PORT && !n.PORTDESTROYED).First()); }
                            if (cdAttack && baseTargets.Where(n => n.CLOSEDEFENSE && !n.CLOSEDEFENSEDESTROYED).Any()) { TGTS.Add("CLOSEDEFENSE", baseTargets.Where(n => n.CLOSEDEFENSE && !n.CLOSEDEFENSEDESTROYED).First()); }
                            if (TGTS.Count > 0)
                            {
                                string TGT = TGTS.Keys.ToList()[GS.RANDOMINT(TGTS.Count)];
                                ADDCOMBAT_CCBOMBCM("CC", actualUnit, TGTS[TGT], TGT);
                                continue;
                            }
                        }
                        else
                        {
                            List<GO> baseTargets = [.. TARGETS[actualUnit]["CC"]];
                            Dictionary<string, GO> TGTS = [];
                            if (baseTargets.Where(n => n.UNITCATEGORY == "SURFACE").Any()) { TGTS.Add("SHIPS", baseTargets.Where(n => n.UNITCATEGORY == "SURFACE").First()); }
                            if (TGTS.Count > 0)
                            {
                                string TGT = TGTS.Keys.ToList()[GS.RANDOMINT(TGTS.Count)];
                                ADDCOMBAT_CCBOMBCM("CC", actualUnit, TGTS[TGT], TGT);
                                continue;
                            }
                        }
                    }
                    if (ATTACKLIST.Contains("BOMB"))
                    {
                        ATTACKLIST.Remove("BOMB");
                        if (baseAttack)
                        {
                            List<GO> baseTargets = [.. TARGETS[actualUnit]["BOMB"].Where(n => n.GAMELOCATION == LOGICLINK.AIFOCUSLOCATION)];
                            Dictionary<string, GO> TGTS = [];
                            if (airfieldAttack && baseTargets.Where(n => n.AIRFIELD && !n.AIRFIELDDESTROYED).Any()) { TGTS.Add("AIRFIELD", baseTargets.Where(n => n.AIRFIELD && !n.AIRFIELDDESTROYED).First()); }
                            if (portAttack && baseTargets.Where(n => n.PORT && !n.PORTDESTROYED).Any()) { TGTS.Add("PORT", baseTargets.Where(n => n.PORT && !n.PORTDESTROYED).First()); }
                            if (cdAttack && baseTargets.Where(n => n.CLOSEDEFENSE && !n.CLOSEDEFENSEDESTROYED).Any()) { TGTS.Add("CLOSEDEFENSE", baseTargets.Where(n => n.CLOSEDEFENSE && !n.CLOSEDEFENSEDESTROYED).First()); }
                            if (TGTS.Count > 0)
                            {
                                string TGT = TGTS.Keys.ToList()[GS.RANDOMINT(TGTS.Count)];
                                ADDCOMBAT_CCBOMBCM("BOMB", actualUnit, TGTS[TGT], TGT);
                                continue;
                            }
                        }
                        else
                        {
                            List<GO> baseTargets = [.. TARGETS[actualUnit]["BOMB"]];
                            Dictionary<string, GO> TGTS = [];
                            if (baseTargets.Where(n => n.UNITCATEGORY == "SURFACE").Any()) { TGTS.Add("SHIPS", baseTargets.Where(n => n.UNITCATEGORY == "SURFACE").First()); }
                            if (TGTS.Count > 0)
                            {
                                string TGT = TGTS.Keys.ToList()[GS.RANDOMINT(TGTS.Count)];
                                ADDCOMBAT_CCBOMBCM("BOMB", actualUnit, TGTS[TGT], TGT);
                                continue;
                            }
                        }
                    }
                    if(ATTACKLIST.Count > 0)
                    {                        
                        int antiSurface = groupMembers.Where(n => n.AIPRIMARYROLE == "ANTI-SURFACE" || n.AIPRIMARYROLE == "WARSHIP").Count();
                        int antiSub = groupMembers.Where(n => n.AIPRIMARYROLE == "ANTI-SUB" || n.AIPRIMARYROLE == "WARSHIP").Count();
                        bool ANTISURFACE = antiSurface > antiSub;
                        bool ANTISUB = antiSub > antiSurface;
                        List<string> COMBATMODES = ["SSM", "TORP", "ASW", "AAA"];
                        if (ANTISUB)
                        {
                            COMBATMODES = ["ASW", "SSM", "TORP", "AAA"];
                        }
                        else if (!ANTISURFACE)
                        {
                            List<string> TMP = [.. COMBATMODES];
                            COMBATMODES.Clear();
                            for (int i = 0; i < (TMP.Count + COMBATMODES.Count); i++)
                            {
                                string m = TMP[GS.RANDOMINT(TMP.Count)];
                                COMBATMODES.Add(m);
                                TMP.Remove(m);
                            }
                        }
                        foreach (string ct in COMBATMODES)
                        {
                            if (ATTACKLIST.Contains(ct))
                            {
                                switch (ct)
                                {
                                    case "SSM":
                                    case "TORP":
                                    case "AAA":
                                        GO LOCTGT = TARGETS[actualUnit][ct].OrderBy(n => GS.GetDistance(n.GAMELOCATION, actualUnit.GAMELOCATION.x, actualUnit.GAMELOCATION.y)).FirstOrDefault();
                                        ADDCOMBAT_LOCATION(ct, actualUnit, LOCTGT);
                                        break;
                                    case "ASW":
                                        GO SINGLETGT = TARGETS[actualUnit][ct].OrderBy(n => GS.GetDistance(n.GAMELOCATION, actualUnit.GAMELOCATION.x, actualUnit.GAMELOCATION.y)).FirstOrDefault();
                                        ADDCOMBAT_SINGLEGO(ct, actualUnit, SINGLETGT);
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            GO actualUnit = null;
            GO destinationMarker = null;
            if(gp != null){
                actualUnit = gp.TYPE == "DESTINATION" ? gp.GAMEPIECE : gp;
                destinationMarker = gp.TYPE == "DESTINATION" ? gp : gp.DESTINATIONPIECE;
                if(attackingUnit != null){
                    actualUnit = attackingUnit.TYPE == "DESTINATION" ? attackingUnit.GAMEPIECE : attackingUnit;
                    destinationMarker = attackingUnit.TYPE == "DESTINATION" ? attackingUnit : attackingUnit.DESTINATIONPIECE;
                }
            }
            switch(pData){
                case ">>DESTINATION":
                case ">>ACTUAL":
                    GS.SelectedMarker = gp == actualUnit ? destinationMarker : actualUnit;
                    Start(false);
                    break;
                case "NEXT":
                    if(attackingUnit != null){
                        MainWindow.Alert("You must either choose your attack or cancel first");
                        Start(false);
                    } else {
                        GO errorGO = CANADVANCE();
                        if(errorGO == null){
                            FS.ORDERS = false;
                            FS.TYPESIDE(GS, "ALERT", side).ForEach(FS.DISCARDLOGIC);
                            GS.Done(this);
                        } else {
                            GS.SelectedMarker = errorGO;
                            Start(false);
                        }
                    }
                    break;
                case "SURFACE SEARCH":
                case "SURFACE SEARCH?":
                case "SURFACE/SUB SEARCH":
                case "SURFACE/SUB SEARCH?":
                    bool sm = !gp.SEARCHMODE;
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.SEARCHMODE = sm);
                    GENERATEFUTURES(gp);
                    if (gp.SEARCHMODE)
                    {
                        FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.LOITERMODE = false);
                        FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.SEARCHDELAY = 5);
                        RESETMOVEMENT(gp);
                    }
                    else
                    {
                        FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.SEARCHDELAY = 0);
                        foreach (GO obj in COMBATS.Where(n => (n.TYPE == "SUB TACCOORD" || n.TYPE == "SURFACE TACCOORD") && n.ATTACKER == gp).ToList())
                        {
                            FS.DISCARDLOGIC(obj);
                            COMBATS.Remove(obj);
                        }   
                    }
                    Start(false);
                    break;
                case "LOITER":
                case "LOITER?":
                    bool lm = !gp.LOITERMODE;
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.LOITERMODE = lm);
                    if (gp.LOITERMODE)
                    {
                        FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.SEARCHMODE = false);
                        FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.SEARCHDELAY = 0);
                        RESETMOVEMENT(gp);
                    }
                    Start(false);
                    break;
                case "AUTO-INTERCEPT":
                case "AUTO-INTERCEPT?":
                    bool im = !gp.INTERCEPTMODE;
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.INTERCEPTMODE = im);
                    Start(false);
                    break;
                case "LOITER/PATROL":
                case "LOITER/PATROL?":
                    bool am = !gp.ASWPATROLMODE;
                    FS.GROUPSANDMEMBERS([gp]).ForEach(n => n.ASWPATROLMODE = am);
                    if(gp.ASWPATROLMODE){
                        RESETMOVEMENT(gp);
                    }
                    Start(false);
                    break;
                case "DOCK":
                    FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.DOCKED = true);
                    Update("DESIGNATE AS DONE");
                    break;
                case "DESIGNATE AS DONE":
                    DESIGNATEASDONE(actualUnit, destinationMarker);
                    Start(false);
                    break;
                case "TARGET SHIPS":
                case "TARGET AIRFIELD":
                case "TARGET PORT":
                case "TARGET CLOSEDEFENSE":
                    COMBATS.Add(ADDCOMBAT_CCBOMBCM(COMBATMODE, actualUnit, gp, pData.Replace("TARGET ", "")));
                    Update("RETURN TO MOVE MODE");
                    break;
                case "TARGET THIS LOCATION":
                    COMBATS.Add(ADDCOMBAT_LOCATION(COMBATMODE, actualUnit, gp));
                    Update("RETURN TO MOVE MODE");
                    break;
                case "TARGET":                    
                    COMBATS.Add(ADDCOMBAT_SINGLEGO(COMBATMODE, actualUnit, gp));
                    Update("RETURN TO MOVE MODE");
                    break;
                case "LAY MINES":
                    GO mineTemplate = GS.PIECE("MINE");
                    if(gp.UNITCATEGORY == "AIR"){
                        GO mine = FS.CLONE(GS, mineTemplate, gp.GAMELOCATIONID);
                        mine.SIDE = side;
                        DEPLOYEDMINES.Add(mine);
                        FS.GROUPMEMBERS(gp).Where(n => n.MINEPTS > 0).First().MINEPTS -= 1;
                        Start(false);
                    } else if(gp.UNITCATEGORY == "SUB"){
                        gp.MINEPTS -= 1;
                        GO mine = FS.CLONE(GS, mineTemplate, destinationMarker.GAMELOCATIONID);
                        mine.SIDE = side;
                        DEPLOYEDMINES.Add(mine);
                        Update("DESIGNATE AS DONE");
                    }
                    break;
                case "INSERT COMMANDOS":
                    GO commandoTemplate = GS.PIECE("COMMANDO");                    
                    gp.COMMANDOPTS -= 1;
                    GO cmndo = FS.CLONE(GS, commandoTemplate, destinationMarker.GAMELOCATIONID);
                    cmndo.SIDE = side;
                    Update("DESIGNATE AS DONE");                    
                    break;
                case "UNLOAD TO FRIENDLY BASE":
                case "UNLOAD TO ENEMY BASE":
                    if(actualUnit.GAMELOCATION.SIDE == actualUnit.SIDE && actualUnit.GAMELOCATION.PORT)
                    {
                        FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.DOCKED = true);
                    }
                    FS.AMPHIBIOUSDROP(actualUnit);
                    Update("DESIGNATE AS DONE");
                    break;
                case "DROP TO FRIENDLY BASE":
                case "DROP TO ENEMY BASE":
                    FS.AIRDROP(gp);
                    Start(false);
                    break;
                case "RESET MOVEMENT":
                    RESETMOVEMENT(actualUnit);
                    Start(false);
                    break;
                case "RESET ATTACK":
                    RESETCOMBAT(actualUnit);
                    Start(false);
                    break;
                case "CANCEL ATTACK":
                case "RETURN TO MOVE MODE":
                    GS.InteractionMap.Clear();
                    ACTIONABLE.ForEach(n => GS.InteractionMap.Add(n, []));
                    DESTINATIONS.ForEach(n => GS.InteractionMap.Add(n, []));
                    GS.SelectedMarker = attackingUnit;
                    COMBATMODE = null;
                    attackingUnit = null;
                    Start(false);
                    break;
                case "SSM ATTACK":
                case "CM ATTACK":
                case "TORP ATTACK":
                case "ASW ATTACK":
                case "AAA ATTACK":
                    COMBATMODE = pData.Replace(" ATTACK","");
                    attackingUnit = gp;
                    GS.InteractionMap.Clear();
                    TARGETS[actualUnit][COMBATMODE].ForEach(n => GS.InteractionMap.Add(n, new()));
                    GS.InteractionMap.Add(gp, new());
                    GS.SelectedMarker = TARGETS[actualUnit][COMBATMODE].Where(n => FS.LOGICALPARENT(n) == n).FirstOrDefault() ?? TARGETS[actualUnit][COMBATMODE].First();
                    Start(false);
                    break;
                case "BOMB ATTACK":
                case "CC ATTACK":
                    COMBATMODE = pData.Replace(" ATTACK","");
                    attackingUnit = gp;
                    GS.InteractionMap.Clear();
                    GS.InteractionMap.Add(gp, new());
                    Start(false);
                    break;
                case "SURFACE TACCOORD DESIGNATE":
                case "SUB TACCOORD DESIGNATE":
                    COMBATMODE = pData.Replace(" DESIGNATE","");
                    attackingUnit = gp;
                    GS.InteractionMap.Clear();
                    string unitCategory = pData.Split(' ').First().Trim();
                    List<GO> specificTargets = [..TARGETS[actualUnit]["TACCOORD"].Where(n => n.UNITCATEGORY == unitCategory)];
                    specificTargets.ForEach(n => GS.InteractionMap.Add(n, []));
                    GS.InteractionMap.Add(gp, []);
                    GS.SelectedMarker = specificTargets.First();
                    Start(false);
                    break;
                case "TRANSFER NON-CARRIER UNITS TO THIS AIRFIELD":
                    List<GO> landingAir = [.. FS.GROUPMEMBERS(actualUnit).Where(n => n.HOMEBASE.AIRFIELD)];
                    //attempt to land, if no room throw error
                    GO airfield = actualUnit.GAMELOCATION;
                    if(landingAir.Where(n => !FS.STRATEGICCOUNTRIES[airfield.ORGLEVEL1].Contains(n.COUNTRY) && n.COUNTRY != airfield.COUNTRY).Any()){
                        MainWindow.Alert("Air Units are not able to land in this country");
                        Start(false);
                        break;
                    }
                    List<GO> airUnits = [..FS.TYPESIDELOCATION(GS, "SQN", actualUnit.SIDE, airfield.ID).Where(n => !FS.ISGROUP(n) && FS.LOGICALPARENT(n) == n && n.HOMEBASEID == null)];
                    airUnits.AddRange(FS.TYPESIDE(GS, "SQN", actualUnit.SIDE).Where(n => n.HOMEBASE == airfield));
                    airUnits.AddRange(landingAir);
                    if(FS.CANSTACKAIR(airUnits)){
                        foreach(GO sqn in landingAir){
                            if(airfield != sqn.HOMEBASE){
                                //transfer, so add delay
                                sqn.ENROUTEDELAY = GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER");
                                sqn.HOMEBASEID = airfield.ID;
                                sqn.HOMEBASE = airfield;
                            }
                            FS.REMOVEFROMGROUP(sqn, actualUnit);
                            FS.RETURNTOHOMEBASE(sqn);
                            FS.REMOVESCENARIOOBJECT(GS, sqn, true);
                            sqn.DONE = !sqn.DESTROYED;
                            sqn.SEARCHMODE = false;
                            sqn.INTERCEPTMODE = false;
                            sqn.SEARCHDELAY = 0;
                            sqn.LOITERMODE = false;
                            sqn.NOORDERS = false;
                        }
                        if(gp.DONE || gp.DESTROYED || gp.RECYCLED){
                            Update("DESIGNATE AS DONE");
                        } else {
                            Start(false);
                        }
                    } else {
                        MainWindow.Alert("Airbase does not have enough capacity");
                        Start(false);
                    }
                    break;
                case "LAND AT HOMEBASE":
                    landingAir = [.. FS.GROUPMEMBERS(actualUnit).Where(n => n.HOMEBASE?.AIRFIELD == true && n.HOMEBASE == actualUnit.GAMELOCATION)];
                    landingAir.AddRange(FS.GROUPMEMBERS(actualUnit).Where(n => n.HOMEBASE?.AIRFIELD == false && n.HOMEBASE.GAMELOCATION == actualUnit.GAMELOCATION));
                    foreach (GO sqn in landingAir)
                    {
                        FS.REMOVEFROMGROUP(sqn, actualUnit);
                        FS.RETURNTOHOMEBASE(sqn);
                        FS.REMOVESCENARIOOBJECT(GS, sqn, true);
                        sqn.DONE = !sqn.DESTROYED;
                        sqn.SEARCHMODE = false;
                        sqn.INTERCEPTMODE = false;
                        sqn.SEARCHDELAY = 0;
                        sqn.LOITERMODE = false;
                        sqn.NOORDERS = false;
                    }
                    if (gp.DONE || gp.DESTROYED || gp.RECYCLED)
                    {
                        Update("DESIGNATE AS DONE");
                    }
                    else
                    {
                        Start(false);
                    }                    
                    break;
                case "REMOVE OBJECTIVE SHIPS FROM GAME":
                    List<GO> objectiveShips = FS.GROUPMEMBERS(actualUnit).Where(n => n.VP_REMOVABLE).ToList();
                    string removeReport = "";
                    foreach(GO ship in objectiveShips){
                        removeReport += FS.INFOLINE1(ship) + " Removed from Gameplay\n";
                        FS.DESTROY(ship);
                    }
                    if(removeReport != ""){
                        MainWindow.Alert(removeReport);
                        //GS.ScenarioButtonClick(1,1);
                    }
                    if(gp.DONE || gp.DESTROYED || gp.RECYCLED){
                        Update("DESIGNATE AS DONE");
                    } else {
                        Start(false);
                    }
                    break;
                case null:
                    if (gp.DRAGGING)
                    {
                        if (gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID)
                        {
                            GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                            GO newloc = gp.GAMELOCATION;
                            if (actualUnit.TYPE != "OBJECTIVELOGIC")
                            {
                                List<FSMovement> movementPath = MOVEMENTFUTURES[actualUnit];
                                movementPath.Add(MOVEMENTCHOICES[gp].Where(n => n.MOVEMENTLOCATION == newloc).Single());
                                if (actualUnit?.ASWPATROLMODE == true)
                                {
                                    FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.ASWPATROLMODE = false);
                                }
                            }
                        }
                        Start(false);
                    }
                    else if (actualUnit.TYPE == "OBJECTIVELOGIC") { }
                    else if(actualUnit.SIDE == side){
                        FSMovement firstMovement = MOVEMENTFUTURES[actualUnit].First();
                        GO initialLocation = firstMovement.MOVEMENTLOCATION;
                        if(gp.GAMELOCATION != initialLocation && gp == actualUnit){
                            GS.CHANGELOCATION(destinationMarker, gp.GAMELOCATION);
                            GS.CHANGELOCATION(actualUnit, initialLocation);
                        }
                        actualUnit.LOCATIONFUTURE = string.Join('|', MOVEMENTFUTURES[actualUnit].Select(n => n.MOVEMENTLOCATIONID));
                        Start(false);
                    }
                    break;
                default:
                    if (pData.StartsWith("AWARD VP"))
                    {
                        string[] data = pData.Split(' ');
                        double vp = double.Parse(data[2]);
                        GS.IncrementDouble("VP." + side, vp);
                    }
                    else
                    {
                        FSMovement immediateMovement = MOVEMENTCHOICES[gp].Where(n => n.LABEL == pData).SingleOrDefault();
                        if (immediateMovement != null)
                        {
                            if (gp == actualUnit)
                            {
                                FSMovement firstMovement = MOVEMENTFUTURES[actualUnit].First();
                                GO initialLocation = firstMovement.MOVEMENTLOCATION;
                                GS.CHANGELOCATION(destinationMarker, immediateMovement.MOVEMENTLOCATION);
                                GS.CHANGELOCATION(actualUnit, initialLocation);
                            }
                            else
                            {
                                GS.CHANGELOCATION(gp, immediateMovement.MOVEMENTLOCATION);
                            }
                            //construct tmp array until you hit the new loc
                            List<FSMovement> movementPath = MOVEMENTFUTURES[actualUnit];
                            movementPath.Add(immediateMovement);
                            actualUnit.LOCATIONFUTURE = string.Join('|', MOVEMENTFUTURES[actualUnit].Select(n => n.MOVEMENTLOCATIONID));
                        }
                    }
                    Start(false);
                    break;
            }            
        }
        private void DESIGNATEASDONE(GO actualUnit, GO destinationMarker)
        {
            RESETMOVEMENT(actualUnit);
            RESETCOMBAT(actualUnit);
            FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.DONE = true);
            FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.ASWPATROLMODE = false);
            FS.GROUPSANDMEMBERS([actualUnit]).ForEach(n => n.LOITERMODE = false);
            bool isActivationGrp = actualUnit.GRPTYPE == "ACTIVATIONGRP";
            bool isAir = actualUnit.UNITCATEGORY == "AIR";
            foreach (GO obj in FS.GROUPMEMBERS(actualUnit))
            {
                FS.REMOVESCENARIOOBJECT(GS, obj, isAir);
                if (isActivationGrp)
                {
                    FS.REMOVEFROMGROUP(obj, actualUnit);
                }
            }
            FS.REMOVESCENARIOOBJECT(GS, actualUnit, isActivationGrp || isAir);
            if (destinationMarker != null)
            {
                GS.REMOVEINTERACTIVE(destinationMarker);
            }
            GS.SelectedMarker = GS.REMOVEINTERACTIVE(actualUnit);
        }
        private GO ADDCOMBAT_CCBOMBCM(string COMBATMODE, GO actualUnit, GO gp, string label)
        {
            Dictionary<string, string> objData = new()
            {
                ["ID"] = actualUnit.ID + GO.DELIM + COMBATMODE + GO.DELIM + FS.GENERATETIMESTAMP(),
                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                ["TYPE"] = COMBATMODE
            };
            GO combat = new(GS, objData, null, null)
            {
                ATTACKERID = actualUnit.ID,
                ATTACKER = actualUnit,
                ATTACKERLOCATIONID = actualUnit.GAMELOCATIONID,
                ATTACKERLOCATION = actualUnit.GAMELOCATION,
                DEFENDERLOCATIONID = COMBATMODE == "CM" ? gp.GAMELOCATIONID : actualUnit.GAMELOCATIONID,
                DEFENDERLOCATION = COMBATMODE == "CM" ? gp.GAMELOCATION : actualUnit.GAMELOCATION,
                LABEL = label,
                SIDE = actualUnit.SIDE
            };
            if(COMBATMODE == "BOMB" || COMBATMODE == "CC"){
                if(combat.LABEL != "SHIPS"){
                    GO target = combat.LABEL switch {
                        "CLOSEDEFENSE" => TARGETS[actualUnit][COMBATMODE].Where(n => n.TYPE == "CLOSEDEFENSE").Single(),
                        _ => TARGETS[actualUnit][COMBATMODE].Where(n => n.UNITTYPE == "BASE").Single(),
                    };
                    combat.DEFENDERID = target.ID;
                    combat.DEFENDER = target;
                }
            } else {
                GO target = gp;
                combat.DEFENDERID = target.ID;
                combat.DEFENDER = target;
            }
            GO template = GS.PIECE("ACTION.TARGET");
            GO clone = FS.CLONE(GS, template, COMBATMODE == "CM" ? gp.GAMELOCATIONID : actualUnit.GAMELOCATIONID);
            clone.LABEL = COMBATMODE;
            clone.SIDE = side;
            combat.GAMEPIECEID = clone.ID;
            combat.GAMEPIECE = clone;
            clone.GAMEPIECEID = combat.ID;
            clone.GAMEPIECE = combat;
            GS.ShuffleMarkerToBottom(clone);
            return combat;
        }
        private GO ADDCOMBAT_LOCATION(string COMBATMODE, GO actualUnit, GO gp)
        {
            Dictionary<string, string> objData = new()
            {
                ["ID"] = actualUnit.ID + GO.DELIM + COMBATMODE + GO.DELIM + FS.GENERATETIMESTAMP(),
                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                ["TYPE"] = COMBATMODE
            };
            GO combat = new(GS, objData, null, null)
            {
                ATTACKERID = actualUnit.ID,
                ATTACKER = actualUnit,
                ATTACKERLOCATIONID = actualUnit.GAMELOCATIONID,
                ATTACKERLOCATION = actualUnit.GAMELOCATION,
                DEFENDERLOCATIONID = gp.GAMELOCATIONID,
                DEFENDERLOCATION = gp.GAMELOCATION,
                DISTANCE = FS.FINDAIRMOVEMENTPATH(actualUnit.GAMELOCATION, gp.GAMELOCATION).Sum(n => n.DISTANCE),
                SIDE = actualUnit.SIDE
            };
            GO template = GS.PIECE("ACTION.TARGET");
            GO clone = FS.CLONE(GS, template, gp.GAMELOCATIONID);
            clone.LABEL = COMBATMODE;
            clone.SIDE = side;
            combat.GAMEPIECEID = clone.ID;
            combat.GAMEPIECE = clone;
            clone.GAMEPIECEID = combat.ID;
            clone.GAMEPIECE = combat;
            GS.ShuffleMarkerToBottom(clone);
            return combat;
        }
        private GO ADDCOMBAT_SINGLEGO(string COMBATMODE, GO actualUnit, GO gp)
        {
            Dictionary<string, string> objData = new()
            {
                ["ID"] = actualUnit.ID + GO.DELIM + COMBATMODE + GO.DELIM + FS.GENERATETIMESTAMP(),
                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                ["TYPE"] = COMBATMODE
            };
            GO combat = new(GS, objData, null, null)
            {
                ATTACKERID = actualUnit.ID,
                ATTACKER = actualUnit,
                ATTACKERLOCATIONID = actualUnit.GAMELOCATIONID,
                ATTACKERLOCATION = actualUnit.GAMELOCATION,
                DEFENDERLOCATIONID = gp.GAMELOCATIONID,
                DEFENDERLOCATION = gp.GAMELOCATION,
                DEFENDERID = gp.ID,
                DEFENDER = gp,
                DISTANCE = FS.FINDAIRMOVEMENTPATH(actualUnit.GAMELOCATION, gp.GAMELOCATION).Sum(n => n.DISTANCE),
                SIDE = actualUnit.SIDE
            };
            GO template = GS.PIECE("ACTION.TARGET");
            GO clone = FS.CLONE(GS, template, gp.GAMELOCATIONID);
            clone.LABEL = COMBATMODE;
            clone.SIDE = side;
            combat.GAMEPIECEID = clone.ID;
            combat.GAMEPIECE = clone;
            clone.GAMEPIECEID = combat.ID;
            clone.GAMEPIECE = combat;
            GS.ShuffleMarkerToBottom(clone);
            return combat;
        }
        private void RESHUFFLEINTERACTIVES()
        {
            if (ACTIONABLE.Count > 1 && GS.SelectedMarker?.TYPE != "OBJECTIVELOGIC")
            {
                GS.InteractionMap.Clear();
                bool isActionable = ACTIONABLE.Contains(GS.SelectedMarker);
                GO destinationMarker = isActionable ? null : GS.SelectedMarker;
                GO actualUnit = isActionable ? GS.SelectedMarker : GS.SelectedMarker.GAMEPIECE;

                int indexA = ACTIONABLE.IndexOf(actualUnit);
                List<GO> actionable = new(ACTIONABLE);
                if (indexA == 0)
                {
                    GO tmp = ACTIONABLE[ACTIONABLE.Count - 1];
                    actionable.Remove(tmp);
                    actionable.Insert(0, tmp);
                }
                else if (indexA == ACTIONABLE.Count - 1)
                {
                    GO tmp = ACTIONABLE[0];
                    actionable.Remove(tmp);
                    actionable.Add(tmp);
                }
                for (int i = 0; i < actionable.Count; i++)
                {
                    bool inSameHex = actionable[i].GAMELOCATION == actionable[i].DESTINATIONPIECE.GAMELOCATION;
                    GS.InteractionMap.Add(actionable[i], inSameHex ? [actionable[i].GAMELOCATION] : []);
                    if (destinationMarker != null && actionable[i] == actualUnit)
                    {
                        GS.InteractionMap.Add(destinationMarker, [destinationMarker.GAMELOCATION]);
                    }
                }
                DESTINATIONS.Where(n => n != destinationMarker).ToList().ForEach(n => GS.InteractionMap.Add(n, [n.GAMELOCATION]));
            }
            foreach(GO logic in MOVABLELOGICS)
            {
                GS.InteractionMap.Remove(logic);
                GS.InteractionMap.Add(logic, []);
            }
        }
        private List<GO> GETTARGETS(GO actualUnit, string combatType){
            return combatType switch{
                "SSM" => FS.SSMTARGETS(actualUnit, SSMSCOPE, ATTACKDATA),
                "CM" => FS.CMTARGETS(actualUnit, CMSCOPE, ATTACKDATA),
                "BOMB" => FS.BOMBTARGETS(actualUnit, BOMBSCOPE, ATTACKDATA),
                "TORP" => FS.TORPTARGETS(actualUnit, TORPSCOPE),
                "ASW" => FS.ASWTARGETS(actualUnit, ASWSCOPE),
                "AAA" => FS.AAATARGETS(actualUnit, AAASCOPE, SURFACETOAIRS.Where(n => FS.LOGICALPARENT(n.ATTACKER) == actualUnit).ToList(), ATTACKDATA),
                "CC" => FS.CCTARGETS(actualUnit, CCSCOPE, ATTACKDATA),
                "TACCOORD" => FS.TACCOORDTARGETS(actualUnit, TACCOORDSCOPE),
                _ => new()
            };
        }
        private void RESETMOVEMENT(GO actualUnit){
            FSMovement firstMovement = MOVEMENTFUTURES[actualUnit].First();
            if(actualUnit.DESTINATIONPIECE != null){
                GS.CHANGELOCATION(actualUnit.DESTINATIONPIECE, firstMovement.MOVEMENTLOCATION);
            }
            actualUnit.LOCATIONFUTURE = firstMovement.MOVEMENTLOCATIONID;
            MOVEMENTFUTURES[actualUnit] = [firstMovement];
        }
        private void RESETCOMBAT(GO actualUnit)
        {
            foreach (GO obj in COMBATS.Where(n => n.ATTACKER == actualUnit).ToList())
            {
                FS.DISCARDLOGIC(obj);
                COMBATS.Remove(obj);
            }
        }
        private GO CANADVANCE(){
            GO returnGO = null;
           //confirm all active air units have a planned path
            List<GO> INACTIVE = [..GS.InteractionMap.Keys
                .Where(n => (n.TYPE == "SHIP" || n.TYPE == "SQN") && n.ENROUTEDELAY == 0 && n.SEARCHDELAY == 0 && !n.LOITERMODE && !n.ASWPATROLMODE)
                .Where(n => n.MOVEMENTALLOWANCE > 0 && (!MOVEMENTFUTURES.ContainsKey(n) || MOVEMENTFUTURES[n].Count == 1))];

            if(INACTIVE.Count != 0)
            {
                foreach (GO obj in INACTIVE) {
                    obj.NOORDERS = !SIDE_IS_AI;
                    bool existingAlert = NOORDERSALERTS.Where(n => n.INTERCEPTEDGRP == obj).Any();
                    if (!existingAlert) {
                        NOORDERSALERTS.Add(FS.CREATEALERT(obj, null, side));
                    }
                }
                returnGO = INACTIVE.First();
            }
            return returnGO;
        }
        private void GENERATEFUTURES(GO obj){
            string[] locations = obj.LOCATIONFUTURE.Split('|');
            MOVEMENTFUTURES.Remove(obj);
            //generate futures
            List<FSMovement> ms = new(){
                new(){
                    MOVEMENTLOCATIONID = locations[0],
                    MOVEMENTLOCATION = GS.LOCATION(locations[0])
                }
            };
            for(int i = 1; i < locations.Length; i++){
                string f = locations[i - 1];
                string t = locations[i];
                GO connector = GS.TYPE("UNITMOVEMENT" , "CONNECTORLOCATIONID", f).Where(n => n.CONNECTORLOCATION2ID == t).FirstOrDefault();
                ms.Add(
                    new(){
                        MOVEMENTLOCATIONID = locations[i],
                        MOVEMENTLOCATION = GS.LOCATION(locations[i]),
                        MOVEMENTCONNECTORID = connector.ID,
                        MOVEMENTCONNECTOR = connector,
                        DISTANCE = Math.Max(1, connector.DISTANCE) * (obj.SEARCHMODE && connector.DISTANCE <= 1 ? (int)Math.Floor(Math.Max(1, GetDouble("_CONFIG_AIR_RECON_MODE_MOVE_COST_MULTIPLIER"))) : 1)
                    }
                );
            }
            MOVEMENTFUTURES.Add(obj, ms);
        }
        private List<GO> MINEOPTIONS(GO obj){
            if(obj.UNITCATEGORY == "SURFACE" || FS.GROUPMEMBERS(obj).Max(n => n.MINEPTS) < 1){return [];}
            //subs must be SOV and not have moved yet
            if(obj.UNITCATEGORY == "SUB" && (obj.SIDE != "SOV" || obj.LOCATIONHISTORY.Split('|').Length > 1)){return [];}
            List<string> MAXEDOUTTHEATERS = [..FS.THEATERS.Keys.Where(n => DEPLOYEDMINES.Where(n2 => n2.SIDE == side && n2.GAMELOCATION.ORGLEVEL1 == n).Count() >= GS.GetInt("_CONFIG_MINES_PER_SIDE_PER_THEATER"))];
            MINEDEPLOYMENTLOCATIONS.RemoveAll(n => MAXEDOUTTHEATERS.Contains(n.ORGLEVEL1));
            List<GO> MAXEDOUTLOCATIONS = DEPLOYEDMINES.Where(n => GS.TYPE("MINEMARKER", "GAMELOCATIONID", n.GAMELOCATIONID).Count == 4).ToList();
            MINEDEPLOYMENTLOCATIONS.RemoveAll(MAXEDOUTLOCATIONS.Contains);
            List<GO> MOVES = obj.UNITCATEGORY == "AIR" ? [obj.GAMELOCATION] : [..FS.FINDSUBMOVEMENTS(obj, obj.GAMELOCATION, false).Select(n => n.MOVEMENTLOCATION)];
            return [..MOVES.Intersect(MINEDEPLOYMENTLOCATIONS)];
        }
    }
    public class ActionCombat : GamePhaseGroupLogic
    {
        public ActionCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionCCCombat("CC", this, GS));
            AddGamePhase(new ActionAAACombat("AAA", this, GS));
            AddGamePhase(new ActionBOMBCombat("BOMB", this, GS));
            AddGamePhase(new ActionTORPCombat("TORP", this, GS));
            AddGamePhase(new ActionASWCombat("ASW", this, GS));
            AddGamePhase(new ActionSSMCombat("SSM", this, GS));
            AddGamePhase(new ActionCMCombat("CM", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init()
        {
            List<GO> combats = new();
            foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED")){
                List<GO> unitcombats = [.. GS.LOGICS().Where(n => FS.COMBATMISSIONTYPES.Contains(n.TYPE)).Where(n => n.ATTACKER == obj && n.ATTACKERLOCATION == obj.GAMELOCATION)];
                foreach (GO combat in unitcombats)
                {
                    if (combat == unitcombats.First())
                    {
                        combats.Add(combat);
                        IncrementInt("ACTION.COMBATS." + obj.SIDE, 1);
                    }
                    else
                    {
                        FS.DISCARDLOGIC(combat);
                    }
                }
            }
            FS.COMBATMISSIONTYPES.ForEach(n => FS.SETSCENARIOOBJECTS(GS, "ACTION." + n + "COMBAT", combats.Where(n2 => n2.TYPE == n).ToList()));
            //remove invalid TAC COORDS
            foreach(GO obj in GS.TYPE("SUB TACCOORD").Where(n => n.ATTACKER?.GAMELOCATION != n.DEFENDER?.GAMELOCATION)){
                FS.DISCARDLOGIC(obj);
            }
            Dictionary<string, List<GO>> COMBATLOCATIONS = [];
            FS.SIDE_NAMES.ForEach(n => COMBATLOCATIONS.Add(n, FS.SCENARIOLOCATIONS(GS, "ACTION.COMBATLOCATIONS." + n)));
            foreach (string s in FS.SIDE_NAMES)
            {
                foreach (GO combat in combats.Where(n => n.SIDE == s))
                {
                    switch (combat.TYPE)
                    {
                        case "ASW":
                        case "TORP":
                        case "SSM":
                            COMBATLOCATIONS[s].Add(combat.DEFENDERLOCATION);
                            if (combat.ATTACKER.UNITCATEGORY != "AIR")
                            {
                                COMBATLOCATIONS[FS.ENEMY(s)].Add(combat.DEFENDERLOCATION);
                            }
                            break;
                        case "BOMB":
                            if(combat.LABEL == "SHIPS")
                            {
                                COMBATLOCATIONS[s].Add(combat.DEFENDERLOCATION);
                            }
                            break;
                        case "CC":
                            if (combat.LABEL == "SHIPS")
                            {
                                COMBATLOCATIONS[s].Add(combat.DEFENDERLOCATION);
                            }
                            COMBATLOCATIONS[FS.ENEMY(s)].Add(combat.DEFENDERLOCATION);
                            break;
                        case "AAA":
                            COMBATLOCATIONS[FS.ENEMY(s)].Add(combat.ATTACKER.GAMELOCATION);
                            break;
                        default:
                            break;
                    }
                }
            }
            FS.SIDE_NAMES.ForEach(n => FS.SETSCENARIOOBJECTS(GS, "ACTION.COMBATLOCATIONS." + n, [.. COMBATLOCATIONS[n].Where(n => n != null)]));
        }
        public override void End()
        {
            //apply damages
            foreach(GO obj in GS.PIECES().Where(n => n.UNAPPLIEDDAMAGE > 0)){
                int unapplied = obj.UNAPPLIEDDAMAGE;
                obj.UNAPPLIEDDAMAGE = 0;
                for(int i = 0; i < unapplied && !obj.DESTROYED; i++){
                    GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * 0.5);
                    FS.DAMAGE(obj);
                }
            }
            foreach(GO obj in GS.LOCATIONS().Where(n => n.UNAPPLIEDPORTDAMAGE > 0)){
                int unapplied = obj.UNAPPLIEDPORTDAMAGE;
                obj.UNAPPLIEDPORTDAMAGE = 0;
                for(int i = 0; i < unapplied && !obj.PORTDESTROYED; i++){
                    string side = obj.SIDE;
                    FS.DAMAGEBASE(obj, "PORT");
                    if (obj.PORTDESTROYED)
                    {
                        GS.IncrementDouble("VP." + FS.ENEMY(side), 10);
                    }
                }
            }
            foreach(GO obj in GS.LOCATIONS().Where(n => n.UNAPPLIEDAIRFIELDDAMAGE > 0)){
                int unapplied = obj.UNAPPLIEDAIRFIELDDAMAGE;
                obj.UNAPPLIEDAIRFIELDDAMAGE = 0;
                for(int i = 0; i < unapplied && !obj.AIRFIELDDESTROYED; i++){
                    string side = obj.SIDE;
                    FS.DAMAGEBASE(obj, "AIRFIELD");
                    if (obj.AIRFIELDDESTROYED)
                    {
                        GS.IncrementDouble("VP." + FS.ENEMY(side), 10);
                    }
                }
            }
            foreach (GO obj in GS.LOCATIONS().Where(n => n.UNAPPLIEDCLOSEDEFENSEDAMAGE > 0))
            {
                int unapplied = obj.UNAPPLIEDCLOSEDEFENSEDAMAGE;
                obj.UNAPPLIEDCLOSEDEFENSEDAMAGE = 0;
                for (int i = 0; i < unapplied && !obj.CLOSEDEFENSEDESTROYED; i++)
                {
                    string side = obj.SIDE;
                    FS.DAMAGEBASE(obj, "CLOSEDEFENSE");
                    if (obj.CLOSEDEFENSEDESTROYED)
                    {
                        GS.IncrementDouble("VP." + FS.ENEMY(side), 10);
                    }
                }
            }
            //local detection
            foreach (GO detectionEvent in GS.TYPE("COMBATDETECTION").Where(n => FS.SIDE_NAMES.Contains(n.INTERCEPTEDGRP?.SIDE) && n.INTERCEPTEDGRP?.LOCALDETECTED == false))
            {
                string defendingSide = FS.ENEMY(detectionEvent.SIDE);
                GO actioningUnit = detectionEvent.INTERCEPTEDGRP;
                List<GO> actioningUnits = FS.GROUPMEMBERS(actioningUnit);
                List<GO> adjacent = new();
                switch (actioningUnit.UNITCATEGORY)
                {
                    case "SURFACE":
                        if (actioningUnits.Where(n => FS.STORM(n.GAMELOCATION)).Any()) { break; }
                        foreach (GO loc in FS.FINDAIRRADIUS(actioningUnit.GAMELOCATION, 1))
                        {
                            adjacent.AddRange(FS.ALLSHIPSINHEX(defendingSide, loc, true, true));
                            if(FS.AIRSURFACEINTERACTION){
                                adjacent.AddRange(FS.TYPESIDELOCATION(GS, "SQN", defendingSide, loc.ID));
                            }
                        }
                        adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)));
                        if (adjacent.Count != 0)
                        {
                            FS.CREATEALERT(actioningUnit, null, defendingSide);
                            FS.LOCALDETECT(actioningUnits, true);
                        }
                        break;
                    case "SUB":
                        bool belowSurface = detectionEvent.LABEL == "ASW" || detectionEvent.LABEL == "TORP";
                        foreach (GO loc in FS.FINDAIRRADIUS(actioningUnit.GAMELOCATION, 1))
                        {
                            adjacent.AddRange(FS.ALLSHIPSINHEX(defendingSide, loc, true, true));
                            if(FS.AIRSURFACEINTERACTION){
                                adjacent.AddRange(FS.TYPESIDELOCATION(GS, "SQN", defendingSide, loc.ID).Where(n => ((n.SEARCHMODE && n.TEMPLATE.ASWPTS > 0) || (loc == actioningUnit.GAMELOCATION && !belowSurface))));
                            }
                        }
                        adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)) && n.UNITCATEGORY == "SURFACE");
                        if (adjacent.Count != 0)
                        {
                            foreach (GO obj in actioningUnits)
                            {
                                if (FS.SUBDETECTIONRESULT(obj, "COMBAT", detectionEvent.LABEL, adjacent) == "D")
                                {
                                    FS.CREATEALERT(actioningUnit, null, defendingSide);
                                    FS.LOCALDETECT(new() { obj }, true);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
            GS.TYPE("COMBATDETECTION").ForEach(FS.DISCARDLOGIC);
            foreach(string TCTYPE in FS.TACCOORDMISSIONTYPES)
            {
                GS.TYPE(TCTYPE).ForEach(FS.DISCARDLOGIC);
            }
        }
    }
}