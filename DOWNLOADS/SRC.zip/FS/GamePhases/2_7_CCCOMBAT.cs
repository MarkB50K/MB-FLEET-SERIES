using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
namespace CWApp.FS
{    
    public class ActionCCCombat : GamePhaseLoopLogic
    {
        public ActionCCCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionCCCombatLoadTrays("Load Trays", this, GS));
            AddGamePhase(new ActionCCCombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionCCCombatDefenderSetup("Defender Setup", this, GS));
            AddGamePhase(new ActionCombatAllocation("Allocation", this, GS, "CC"));
            AddGamePhase(new ActionCCCombatResolution("Resolution", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOLOGICS(GS, "ACTION.CCCOMBAT").Any();}
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.CCCOMBAT");
            GO firstcombat = GS.RANDOMGAMEOBJECT(combats);
            List<GO> combined_combats = new(){firstcombat};
            if(FS.COMBINEDATTACKS){
                combined_combats = combats.Where(n => n.SIDE == firstcombat.SIDE && n.DEFENDERLOCATION == firstcombat.DEFENDERLOCATION && n.LABEL == firstcombat.LABEL).ToList();
            }
            List<GO> attackingUnits = combined_combats.Select(n => n.ATTACKER).ToList();
            Set("ACTIVE.SIDE", attackingUnits.First().SIDE);
            Set("ACTIVE.SIDE1", Get("ACTIVE.SIDE"));
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIONING", attackingUnits);
            combats.RemoveAll(n => combined_combats.Contains(n));
            FS.SETSCENARIOOBJECTS(GS, "ACTION.CCCOMBAT", combats);
            List<GO> defenders = new();
            if(firstcombat.DEFENDER != null){
                GO facility = firstcombat.DEFENDER;
                if((firstcombat.LABEL == "PORT" && facility.PORT && !facility.PORTDESTROYED) || 
                    (firstcombat.LABEL == "AIRFIELD" && facility.AIRFIELD && !facility.AIRFIELDDESTROYED) ||
                    (firstcombat.LABEL == "CLOSEDEFENSE" && facility.CLOSEDEFENSE && !facility.CLOSEDEFENSEDESTROYED)){
                    defenders.Add(facility);
                }
            } else {
                defenders.AddRange(FS.TYPESIDELOCATION(GS, "SHIP", FS.ENEMY(firstcombat.SIDE), firstcombat.DEFENDERLOCATIONID).Where(n => 
                    n.ENROUTEDELAY == 0 &&
                    n.UNITCATEGORY == "SURFACE" &&
                    FS.LOGICALPARENT(n) == n &&
                    (n.STRATDETECTED || n.LOCALDETECTED)));
            }
            List<GO> attackers = new();
            List<GO> gunsOnly = [];
            if(defenders.Any() && !FS.STORM(firstcombat.DEFENDERLOCATION)){
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", defenders);
                foreach(GO combat in combined_combats){
                    List<GO> atks = new();
                    GO attackingUnit = combat.ATTACKER;
                    //determine which attackers can reach this range
                    List<GO> groupMembers = FS.GROUPMEMBERS(attackingUnit);
                    Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers, "CC");
                    bool ships = combat.DEFENDER == null;
                    foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                        bool canAttackShips = false;
                        bool canAttackBase = false;
                        if(attackData[obj].ContainsKey("CC")){
                            canAttackShips = !attackingUnit.DONESSM;
                            if(attackData[obj]["CC"].ContainsKey("BASE CC")){
                                canAttackBase = true;
                                canAttackShips = true;
                            }
                        }
                        if((ships && canAttackShips) || (!ships && canAttackBase)){
                            atks.Add(obj);
                            if(obj.DONESSM || !attackData[obj]["CC"].ContainsKey("CC"))
                            {
                                gunsOnly.Add(obj);
                            }
                        }
                    }
                    if(atks.Any()){
                        if(!attackingUnit.DONESSM){
                            FS.GROUPSANDMEMBERS([attackingUnit]).ForEach(n => n.NUMCOMBATS++);
                            FS.GROUPSANDMEMBERS([attackingUnit]).ForEach(n => n.DONESSM = true); 
                        }
                        FS.GROUPSANDMEMBERS([attackingUnit]).ForEach(n => n.DONECC = true);
                    }
                    attackers.AddRange(atks);
                }
                Set("ACTION.TARGET", firstcombat.LABEL); 
            }
            string reason = "";
            if(!attackers.Any()){reason = "no units able to attack";}
            if(!defenders.Any()){reason = "no viable targets in target location";}
            if(reason != ""){
                MainWindow.Alert("Planned " + firstcombat.SIDE + " " + firstcombat.TYPE + " combat not possible: " + reason);
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", attackers);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.GUNSONLY", gunsOnly);
            combined_combats.ForEach(FS.DISCARDLOGIC);
        }
        public override void End()
        {
            FS.REMOVECOMBATSHEET();
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionCCCombatLoadTrays : GamePhaseAutomated
    {
        public ActionCCCombatLoadTrays(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            if(FS.SCENARIOUNITS(GS, "ACTION.ATTACKER").Any()){
                List<GO> tagged = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Where(n => !FS.BASETYPES.Contains(n.TYPE)).ToList();
                List<GO> defenders = tagged.Where(n => !FS.ISGROUP(n) && !n.DOCKED).ToList();
                defenders.AddRange(tagged.Where(n => !FS.ISGROUP(n) && n.DOCKED));
                defenders.AddRange(tagged.Where(n => FS.ISGROUP(n)));
                foreach(GO obj in defenders){
                    obj.HOMEBASEID = obj.GAMELOCATIONID;
                    obj.HOMEBASE = obj.GAMELOCATION;
                }
                if(defenders.Any()){
                    FS.DISPLAYCOMBATSHEET(GS, defenders);                        
                }
            }
            GS.Done(this);           
        }
    }
    public class ActionCCCombatDeclaration : GamePhaseInteractive
    {
        bool baseTarget = false;
        string side = null;
        List<GO> GUNSONLY = [];
        Dictionary<GO, Dictionary<string, double>> ATTACKS = [];
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = [];
        public ActionCCCombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                baseTarget = Get("ACTION.TARGET") != "SHIPS";
                ATTACKS.Clear();
                GUNSONLY = FS.SCENARIOUNITS(GS, "ACTION.GUNSONLY");
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE UNITS THAT WILL PARTICIPATE AND WHAT ATTACK TYPE"});
                GS.HELPTEXT = 
                "CC COMBAT.  Declare which units you will attack with\n\n" + 
                "- Choose which ammunition, game will only allow ones in range, and will only allow one choice\n\n" +
                "When done with your declaration(s) you can click the NEXT button.  The Defender will be given a chance to reposition forces in the target hex.";
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ATTACKER")){
                    GS.InteractionMap.Add(obj, []);
                }
            }
            FS.SETINSTRUCTIONS(GS, new(){"ALLOCATE CC POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"])});
            BANNER = "Close Combat " + ID + " - Allocated: " + ATTACKS.Values.Sum(n => n["PTS"]);
            attackData = FS.ATTACKDATA(GS.InteractionMap.Keys.ToList(), "CC");
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                bool gunsOnly = GUNSONLY.Contains(obj);
                if(attackData.ContainsKey(obj)){
                    if(attackData[obj].ContainsKey("CC")){
                        foreach(string attackType in attackData[obj]["CC"].Keys){
                            if((baseTarget || gunsOnly) && attackType != "BASE CC"){continue;}
                            if(!baseTarget && !gunsOnly && attackType == "BASE CC"){continue;}
                            GS.AddAction(obj, "USE " + (attackType == "BASE CC" ? "GUNS/HELOS" : attackType));                            
                        }
                    }
                }
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                List<string> standardAttackTypes = ["BASE CC", "CC"];
                int aggressionfactor = GS.Get("AI." + side) switch
                {
                    "CAUTIOUS" => 1,
                    "AGGRESSIVE" => 3,
                    _ => 2
                };
                List<GO> gps = [.. GS.InteractionMap.Keys.OrderByDescending(n => n.TEMPLATE.SPECIAL)];
                foreach (GO gp in gps)
                {
                    List<string> cts = [];
                    bool gunsOnly = GUNSONLY.Contains(gp);
                    if (attackData.ContainsKey(gp))
                    {
                        if (attackData[gp].ContainsKey("CC"))
                        {
                            foreach (string attackType in attackData[gp]["CC"].Keys.Intersect(standardAttackTypes))
                            {
                                if ((baseTarget || gunsOnly) && attackType != "BASE CC") { continue; }
                                if (!baseTarget && !gunsOnly && attackType == "BASE CC") { continue; }
                                cts.Add(attackType);
                            }
                        }
                    }
                    string ct = cts[GS.RANDOMINT(cts.Count)];
                    switch (ct)
                    {
                        case "CC":
                            gp.SSMPTS--;
                            ATTACKS.Add(gp, attackData[gp]["CC"][ct]);
                            break;
                        case "BASE CC":
                            ATTACKS.Add(gp, attackData[gp]["CC"][ct]);
                            break;
                        default:
                            break;
                    }
                    /* CC combats should not be piecemeal
                    double moreChance = 50 + (15 * aggressionfactor);
                    if (GS.RANDOMINT(100) >= moreChance)
                    {
                        break;
                    }*/
                }
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(ATTACKS.Any() || !GS.InteractionMap.Any()){
                        //collect attack data
                        int numattackers = ATTACKS.Keys.Count;
                        double numseaskimmer = ATTACKS.Values.Sum(n => n["SEASKIMMER"]);
                        double numfastCC  = ATTACKS.Values.Sum(n => n["FAST"]);
                        SetBoolean("ACTION.SEASKIMMER", numseaskimmer * 2 >= numattackers);
                        SetBoolean("ACTION.FAST", numfastCC * 2 >= numattackers);
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", ATTACKS.Keys.ToList());
                        GS.Done(this);
                    } else {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE GUNS/HELOS":
                    ATTACKS.Add(gp, attackData[gp]["CC"]["BASE CC"]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE CC":
                    gp.SSMPTS--;
                    ATTACKS.Add(gp, attackData[gp]["CC"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE INTENSIVE CC":
                    gp.SSMPTS -= 2;
                    ATTACKS.Add(gp, attackData[gp]["CC"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE MAXIMUM CC":
                    gp.SSMPTS -= 3;
                    ATTACKS.Add(gp, attackData[gp]["CC"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionCCCombatDefenderSetup : GamePhaseInteractive
    {
        string side = null;
        List<string> groupingOrder = new();
        List<GO> DOCKEDTRAYLOCATIONS = new();
        List<GO> UNDOCKEDTRAYLOCATIONS = new();
        public ActionCCCombatDefenderSetup(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            List<GO> DefendersOnDefenseSheet = GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID);
            if(init){
                side = FS.ENEMY(Get("ACTIVE.SIDE"));
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG OR USE MENU TO REARRANGE SHIP IN STACK"});
                GS.HELPTEXT =
                "Adjust Defender Positioning. This will determine which units provide Close AA assistance\n\n" +
                "- You can arrange units within a TF/TG\n" +
                "- You can arrange units within the hex by group and then within group\n" +
                "- All UNDOCKED ships not in TF/TG will always be grouped together.  All DOCKED ships not in TF/TG will always be grouped together. Use context menu options to move up/down the grouping as a whole\n" +
                "- Dragging ships within a group will only rearrange the ships within the group, the grouping will not move.  Grouping position is only determined with context menu options\n\n" +
                "When done with your setup you can click the NEXT button.  The attacking player will then be allowed to allocate pts prior to combat resolution.";
                foreach (GO obj in FS.SCENARIOUNITS(GS, "ACTION.DEFENDER")){
                    GS.InteractionMap.Add(obj, new());
                    if(FS.ISGROUP(obj)){
                        List<GO> groupmembers = FS.GROUPMEMBERS(obj);
                        if(groupmembers.Count <= 1){continue;}
                        foreach(GO obj2 in groupmembers){
                            GS.InteractionMap.Add(obj2, new());
                        }
                    }
                }
                if(DefendersOnDefenseSheet.Count == 1){
                    foreach(GO obj in GS.InteractionMap.Keys.Where(n => n.PARENTSHEET == FS.DEFENDSHEET).ToList()){
                        GS.InteractionMap.Remove(obj);
                    }
                }
                if(!(DefendersOnDefenseSheet.Count > 1 || DefendersOnDefenseSheet.Max(n => FS.GROUPMEMBERS(n).Count) > 1)){
                    Update("NEXT");
                    return;
                }
                //determine initial grouping
                HashSet<string> groupings = new();
                foreach (GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).OrderBy(n => n.GAMELOCATIONID))
                {
                    if (FS.ISGROUP(obj))
                    {
                        groupings.Add(obj.ID);
                    }
                    else if (obj.DOCKED)
                    {
                        groupings.Add("DOCKED");
                    }
                    else
                    {
                        groupings.Add("UNDOCKED");
                    }
                }
                groupingOrder = groupings.ToList();
            }
            DOCKEDTRAYLOCATIONS = DefendersOnDefenseSheet.Where(n => !FS.ISGROUP(n) && n.DOCKED).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).ToList();
            UNDOCKEDTRAYLOCATIONS = DefendersOnDefenseSheet.Where(n => !FS.ISGROUP(n) && !n.DOCKED).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).ToList(); 
            if (GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                List<GO> targets = GS.InteractionMap[obj];
                targets.Clear();
                if(obj.HOMEBASE != null){
                    if(!FS.ISGROUP(obj)){
                        targets.AddRange(obj.DOCKED ? DOCKEDTRAYLOCATIONS.Where(n => n != obj.GAMELOCATION) : UNDOCKEDTRAYLOCATIONS.Where(n => n != obj.GAMELOCATION));
                    }
                } else {
                    List<GO> groupMembers = FS.GROUPMEMBERS(FS.LOGICALPARENT(obj));
                    int count = groupMembers.Count;
                    if (obj.GROUPINDEX > 0)
                    {
                        GS.AddAction(obj, "MOVE UP IN GROUP");
                    }
                    if (obj.GROUPINDEX < count - 1)
                    {
                        GS.AddAction(obj, "MOVE DOWN IN GROUP");
                    }
                }
                if (obj.HOMEBASE != null)
                {
                    int index = groupingOrder.IndexOf(FS.ISGROUP(obj) ? obj.ID : obj.DOCKED ? "DOCKED" : "UNDOCKED");
                    if (index > 0) { GS.AddAction(obj, "MOVE GROUP UP"); }
                    if (index < groupingOrder.Count - 1) { GS.AddAction(obj, "MOVE GROUP DOWN"); }
                }
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if (GS.AI_Sides.Contains(FS.SIDE_MODE))
            {
                Update("NEXT");
                return;
            }
            if (init){FS.SETVIEW(GS);}
        }
        private void ARRANGEUNITS(GO gp, bool left)
        {
            //always keep non TF/TG grouped together
            GO newsheet = FS.DEFENDSHEET;
            List<GO> grouptraylocations = GS.TYPE("PIECE", "PARENTSHEETID", newsheet.ID).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).Distinct().ToList();
            List<GO> groupMembers = new();
            List<GO> tfs = new();
            List<GO> docked = new();
            List<GO> undocked = new();
            foreach (GO loc in grouptraylocations)
            {
                List<GO> unitsAtLoc = FS.TYPELOCATION(GS, "PIECE", loc.ID);
                if (unitsAtLoc.Any())
                {
                    if (unitsAtLoc.Count == 1)
                    {
                        GO u = unitsAtLoc.First();
                        if (FS.ISGROUP(u))
                        {
                            tfs.Add(u);
                        }
                        else if (u.DOCKED)
                        {
                            docked.Add(u);
                        }
                        else
                        {
                            undocked.Add(u);
                        }
                    }
                    else
                    {
                        if (left)
                        {
                            if (gp.DOCKED)
                            {
                                docked.Add(gp);
                            }
                            else
                            {
                                undocked.Add(gp);
                            }
                        }
                        GO u = unitsAtLoc.Where(n => n != gp).Single();
                        if (FS.ISGROUP(u))
                        {
                            tfs.Add(u);
                        }
                        else if (u.DOCKED)
                        {
                            docked.Add(u);
                        }
                        else
                        {
                            undocked.Add(u);
                        }
                        if (!left)
                        {
                            if (gp.DOCKED)
                            {
                                docked.Add(gp);
                            }
                            else
                            {
                                undocked.Add(gp);
                            }
                        }
                    }
                }
            }
            foreach (string grouping in groupingOrder)
            {
                switch (grouping)
                {
                    case "UNDOCKED":
                        groupMembers.AddRange(undocked);
                        break;
                    case "DOCKED":
                        groupMembers.AddRange(docked);
                        break;
                    default:
                        groupMembers.Add(tfs.Where(n => n.ID == grouping).Single());
                        break;
                }
            }
            FS.DISPLAYCOMBATSHEET(GS, groupMembers);
        }
        private void REORDERGROUPINGS(GO gp, bool up)
        {
            string key = FS.ISGROUP(gp) ? gp.ID : gp.DOCKED ? "DOCKED" : "UNDOCKED";
            int index = groupingOrder.IndexOf(key);
            groupingOrder.Remove(key);
            if (up)
            {
                groupingOrder.Insert(index - 1, key);
            }
            else
            {
                if (index >= groupingOrder.Count - 1)
                {
                    groupingOrder.Add(key);
                }
                else
                {
                    groupingOrder.Insert(index + 1, key);
                }
            }
            ARRANGEUNITS(gp, true);
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    GS.Done(this);
                    break;
                case "MOVE UP IN GROUP":
                    FS.MOVEUPINGROUP(GS, gp, FS.LOGICALPARENT(gp));
                    Start(false);
                    break;
                case "MOVE DOWN IN GROUP":
                    FS.MOVEDOWNINGROUP(GS, gp, FS.LOGICALPARENT(gp));
                    Start(false);
                    break;
                case "MOVE GROUP UP":
                    REORDERGROUPINGS(gp, true);
                    Start(false);
                    break;
                case "MOVE GROUP DOWN":
                    REORDERGROUPINGS(gp, false);
                    Start(false);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if (gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID)
                    {
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        GO newloc = gp.GAMELOCATION;
                        if (oldloc.PARENTSHEET == FS.DEFENDSHEET && newloc.PARENTSHEET == FS.DEFENDSHEET)
                        {
                            if (DOCKEDTRAYLOCATIONS.Contains(oldloc))
                            {
                                int oldindex = DOCKEDTRAYLOCATIONS.IndexOf(oldloc);
                                int newindex = DOCKEDTRAYLOCATIONS.IndexOf(newloc);
                                ARRANGEUNITS(gp, oldindex > newindex);
                            }
                            else
                            {
                                int oldindex = UNDOCKEDTRAYLOCATIONS.IndexOf(oldloc);
                                int newindex = UNDOCKEDTRAYLOCATIONS.IndexOf(newloc);
                                ARRANGEUNITS(gp, oldindex > newindex);
                            }
                        }
                        Start(false);
                    }
                    else
                    {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionCCCombatResolution : GamePhaseAutomated
    {
        public ActionCCCombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            List<GO> attackers = FS.SCENARIOUNITS(GS, "ACTION.ATTACKER");
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            string facilityBeingAttacked = Get("ACTION.TARGET");    
            if(defenders.Any()){
                List<GO> actioningGroups = FS.SCENARIOUNITS(GS, "ACTION.ACTIONING");
                bool baseTarget = FS.BASETYPES.Contains(defenders.First().TYPE);
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                bool seaskimmer = GetBoolean("ACTION.SEASKIMMER");
                bool fast = GetBoolean("ACTION.FAST");
                GO firstDefender = defenders.First();
                GO defenseLocation = baseTarget ? firstDefender.GAMELOCATION : firstDefender.HOMEBASE ?? FS.LOGICALPARENT(firstDefender).HOMEBASE;
                string report = "CC COMBAT : " + attackingSide + " vs " + defendingSide + (fast ? " FAST" : "") + (seaskimmer ? " SEASKIMMER" : "") + "\n\n";
                if(GS.AI_Sides.Count == 2){
                    report += "ATTACKERS\n";
                    foreach(GO attacker in attackers){
                        report += attacker.UNITTYPE + " " + attacker.LABEL + "\n";
                    }
                    report += "\n";
                }
                List<GO> dockedShips = new();
                List<GO> undockedShips = new();
                List<GO> DEFENDERSONSHEET = GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID);
                //put defenders in groups
                foreach(GO obj in DEFENDERSONSHEET.OrderBy(n => n.GAMELOCATIONID)){
                    if(!FS.ISGROUP(obj)){
                        if(obj.DOCKED){
                            dockedShips.Add(obj);
                        } else {
                            undockedShips.Add(obj);
                        }                            
                    }
                }
                //create Dict of targets to ships beneath them
                Dictionary<GO, GO> targetsAndBeneath = new();
                foreach(GO defender in defenders.Where(n => !FS.BASETYPES.Contains(n.TYPE))){
                    if(defender.HOMEBASE != null){
                        int position1 = defender.DOCKED ? dockedShips.IndexOf(defender) : undockedShips.IndexOf(defender);
                        int position2 = defender.DOCKED ? (position1 + 1) % dockedShips.Count : (position1 + 1) % undockedShips.Count;
                        GO beneath = defender.DOCKED ? dockedShips[position2] : undockedShips[position2];
                        if(beneath == defender || defenders.Contains(beneath)){
                            beneath = null;
                        }
                        targetsAndBeneath.Add(defender, beneath);
                    } else {
                        GO group = FS.LOCATIONPARENT(defender);
                        List<GO> groupMembers = FS.GROUPMEMBERS(group);
                        int position1 = groupMembers.IndexOf(defender);
                        int position2 = (position1 + 1) % groupMembers.Count;
                        GO beneath = groupMembers[position2];
                        if(beneath == defender || defenders.Contains(beneath)){
                            beneath = null;
                        }
                        targetsAndBeneath.Add(defender, beneath);
                    }
                }
                FS.REMOVECOMBATSHEET();   
                int rollModifier = 0;
                if(!baseTarget){
                    //combine AA values
                    int combinedAAValue = 0;
                    double sskim = seaskimmer ? 0.5 : 1;
                    double fst = fast ? 0.5 : 1;
            
                    //CAA of targets
                    double targetCAA = 0;
                    foreach(GO obj in defenders){
                        targetCAA += obj.TEMPLATE.CAA;
                        report += obj.UNITTYPE + " " + obj.LABEL + " CAA=" + obj.TEMPLATE.CAA + "\n";
                    }
                    //CAA of beneath
                    foreach(GO obj in targetsAndBeneath.Values.Where(n => n != null)){
                        targetCAA += obj.TEMPLATE.CAA;
                        report += obj.UNITTYPE + " " + obj.LABEL + " CAA=" + obj.TEMPLATE.CAA + "\n";
                    }
                    report += "contributes " + Math.Floor(targetCAA * fst) + "\n";
                    combinedAAValue += (int)Math.Floor(targetCAA * fst);  
                    report += "TOTAL AA = " + combinedAAValue + "\n\n";
                    int defenseModifier = 0;
                    if(combinedAAValue > 0){
                        if(defenders.Where(n => n.GROUP?.UNITTYPE == "TF").Any()){
                            rollModifier += 2;
                            report += "TF: Roll +2\n";
                        }
                        if(!defenders.Where(n => n.GROUP != null).Any()){
                            rollModifier -= 4;
                            report += "NO TG/TF: Roll -4\n";
                        }
                        report += "DEFENSE ROLL MODIFIER: " + rollModifier + "\n";
                        int dieRoll = FS.DIEROLL();
                        report += "ROLL: " + dieRoll + " => " + (dieRoll + rollModifier) + "\n";
                        dieRoll += rollModifier;
                        defenseModifier = FS.COMBATRESULTSTABLE(false, dieRoll, combinedAAValue);
                    }
                    report += "DEFENSE MODIFIER: " + defenseModifier + "\n\n";
                    rollModifier = -defenseModifier;
                }
                if(FS.STRATEGICTACCOORD){
                    if(FS.ALLSHIPSINHEX(defendingSide, defenseLocation, true, false).Where(n => n.TACCOORDPIECEID != null).Any()){
                        rollModifier += 2;
                        report += "TAC COORD: Roll +2\n";
                    } 
                }else {
                    if(FS.TYPESIDE(GS, "SURFACE TACCOORD", attackingSide).Where(n => n.DEFENDERLOCATION == defenseLocation).Any()){
                        rollModifier += 2;
                        report += "TAC COORD: Roll +2\n";
                    }
                }
                if(baseTarget){
                    rollModifier -= 3;
                    report += "BASE: Roll -3\n";
                    GO facility = defenders.First();
                    report += "\nATTACK ON " + facilityBeingAttacked + " " + facility.LABEL + " with " + facility.ATK + " pts:\n";
                    int objRollModifer = rollModifier;
                    report += "ATTACK ROLL MODIFIER: " + objRollModifer + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + objRollModifer) + "\n";
                    dieRoll += objRollModifer;
                    double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)facility.ATK);
                    facility.ATK = 0;
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    GO bombedBase = defenseLocation;
                    string increase = "";
                    if (attackResult >= 11)
                    {
                        switch (facilityBeingAttacked)
                        {
                            case "PORT":
                                bombedBase.UNAPPLIEDPORTDAMAGE += 4;
                                break;
                            case "AIRFIELD":
                                bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 4;
                                break;
                            case "CLOSEDEFENSE":
                                bombedBase.UNAPPLIEDCLOSEDEFENSEDAMAGE += 4;
                                break;
                            default:
                                break;
                        }
                        report += facilityBeingAttacked + " Destroyed\n";
                        increase = "4";
                    }
                    else if (attackResult >= 10)
                    {
                        switch (facilityBeingAttacked)
                        {
                            case "PORT":
                                bombedBase.UNAPPLIEDPORTDAMAGE += 3;
                                break;
                            case "AIRFIELD":
                                bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 3;
                                break;
                            case "CLOSEDEFENSE":
                                bombedBase.UNAPPLIEDCLOSEDEFENSEDAMAGE += 3;
                                break;
                            default:
                                break;
                        }
                        increase = "3";
                    }
                    else if (attackResult >= 8)
                    {
                        switch (facilityBeingAttacked)
                        {
                            case "PORT":
                                bombedBase.UNAPPLIEDPORTDAMAGE += 2;
                                break;
                            case "AIRFIELD":
                                bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 2;
                                break;
                            case "CLOSEDEFENSE":
                                bombedBase.UNAPPLIEDCLOSEDEFENSEDAMAGE += 2;
                                break;
                            default:
                                break;
                        }
                        increase = "2";
                    }
                    else if (attackResult >= 4)
                    {
                        switch (facilityBeingAttacked)
                        {
                            case "PORT":
                                bombedBase.UNAPPLIEDPORTDAMAGE += 1;
                                break;
                            case "AIRFIELD":
                                bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 1;
                                break;
                            case "CLOSEDEFENSE":
                                bombedBase.UNAPPLIEDCLOSEDEFENSEDAMAGE += 1;
                                break;
                            default:
                                break;
                        }
                        increase = "1";
                    }
                    else
                    {
                        report += "No effect\n";
                    }
                    if (increase != "")
                    {
                        switch (facilityBeingAttacked)
                        {
                            case "PORT":
                                if (bombedBase.PORTDAMAGELEVEL + bombedBase.UNAPPLIEDPORTDAMAGE >= 4)
                                {
                                    report += facilityBeingAttacked + " Destroyed\n";
                                }
                                else
                                {
                                    report += facilityBeingAttacked + " Damaged Level increases by " + increase + "\n";
                                }
                                break;
                            case "AIRFIELD":
                                if (bombedBase.AIRFIELDDAMAGELEVEL + bombedBase.UNAPPLIEDAIRFIELDDAMAGE >= 4)
                                {
                                    report += facilityBeingAttacked + " Destroyed\n";
                                }
                                else
                                {
                                    report += facilityBeingAttacked + " Damaged Level increases by " + increase + "\n";
                                }
                                break;
                            case "CLOSEDEFENSE":
                                if (bombedBase.CLOSEDEFENSEDAMAGELEVEL + bombedBase.UNAPPLIEDCLOSEDEFENSEDAMAGE >= 4)
                                {
                                    report += facilityBeingAttacked + " Destroyed\n";
                                }
                                else
                                {
                                    report += facilityBeingAttacked + " Damaged Level increases by " + increase + "\n";
                                }
                                break;
                            default:
                                break;
                        }
                    }
                } else {               
                    foreach(GO obj in defenders){
                        int objRollModifer = rollModifier;
                        report += "\nATTACK ON " + obj.UNITTYPE + " " + obj.LABEL + " with " + obj.ATK + " pts:\n";
                        report += "ATTACK ROLL MODIFIER: " + objRollModifer + "\n";
                        int dieRoll = FS.DIEROLL();
                        report += "ROLL: " + dieRoll + " => " + (dieRoll + objRollModifer) + "\n";
                        dieRoll += objRollModifer;
                        double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)obj.ATK);
                        obj.ATK = 0;
                        report += "ATTACK RESULT: " + attackResult + "\n";
                        //compare to ship defense
                        double defense = FS.GETDEFENSE(obj);
                        if(attackResult >= defense){
                            obj.UNAPPLIEDDAMAGE += 2;
                            report += "Target Destroyed\n";
                        } else if(attackResult >= defense * 0.5){
                            obj.UNAPPLIEDDAMAGE++;
                            if((obj.DAMAGED ? 1 : 0) + obj.UNAPPLIEDDAMAGE >= 2){
                                report += "Target Destroyed\n";
                            } else {
                                report += "Target Damaged\n";
                            }
                        } else {
                            report += "No effect\n";
                        }
                    }
                }
                //local detection
                actioningGroups.ForEach(n => FS.CREATECOMBATDETECTION(n, n.SIDE, "CC"));

                MainWindow.Alert(report);         
            }
            GS.Done(this);           
        }
    }
}
