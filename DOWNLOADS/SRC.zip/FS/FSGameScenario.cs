using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Data;
using System.Windows;
using System.DirectoryServices.ActiveDirectory;
using System.Windows.Markup;
using System.Windows.Navigation;
using System.Windows.Media;
using System.Dynamic;
using System.CodeDom;
using System.Reflection.Metadata.Ecma335;
//using CWApp.TWW;
using System.Configuration;
using System.Collections;
using System.Runtime;
using System.Windows.Documents;
using System.Net;
using System.Threading;
using System.Diagnostics.Eventing.Reader;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Diagnostics;

namespace CWApp.FS
{
    public class FSGeography : GOGeography {
        public FSGeography(GameScenario gs, Dictionary<string, string> pdata, Dictionary<string, string> odata, Dictionary<string, string> sdata) : base(gs, pdata, odata, sdata) { }
        public FSGeography() : base() { }
    }
    public class FSMovement : FSGeography {
        public FSMovement() : base() {DOMAIN = GO.DOMAIN_MOVEMENT;}
        public string MOVEMENTLOCATIONID { get{ return Get("MOVEMENTLOCATIONID");} set{ Set("MOVEMENTLOCATIONID", value); if(value == null){_MOVEMENTLOCATION = null;}} }
        private GO _MOVEMENTLOCATION { get; set; }
        public GO MOVEMENTLOCATION { 
            get {
                if(GS != null && _MOVEMENTLOCATION == null && MOVEMENTLOCATIONID != null){
                    _MOVEMENTLOCATION = GS.LOCATION(MOVEMENTLOCATIONID);
                }
                return _MOVEMENTLOCATION;
            } 
            set {
                _MOVEMENTLOCATION = value;
            }
        }
    }
    public abstract class FS : GameScenario
    {
        public static int DIEROLL()
        {
            return CWConstants._random.Next(10);
        }
        public static void SETINSTRUCTIONS(GameScenario GS, List<string> instructions)
        {
            string player = SIDE_MODE == "SOV" || SIDE_MODE == "ALLIES" ? SIDE_MODE : "ADMIN";
            List<string> i = new() { "**" + player + "**" };
            i.AddRange(instructions);
            GS.SetInstructions(i);
        }
        public static bool SETUP = false;
        public static bool DEPLOYMENT = false;
        public static bool CREATE_TF_PHASE = false;
        public static bool CREATE_ACTGRP_PHASE = false;
        public static bool AI_REVIEW = false;
        public static bool ORDERS = false;
        public static bool TRIGGER = false;
        public static GO GRPSHEET;
        public static GO CVSHEET;
        public static GO DETAILSHEET;
        public static GO ACTIVATIONGRPSHEET;
        public static GO SETUPSHEET;
        public static GO DEFENDSHEET;
        public static List<GO> TRAYSHEETS;
        public static List<GO> TMPSHEETS;
        public static List<GO> STRATAIRSHEETS;
        public static List<GO> FACILITYTEMPLATES = new();
        public static List<GO> CLOSEDEFENSETEMPLATES = new();
        public static List<string> BASETYPES = new() { "CLOSEDEFENSE", "FACILITY" };
        public static List<string> UNITTYPES = new() { "SHIP", "SQN" };
        public static List<string> SELECTABLELOGICTYPES = new() { "OBJECTIVELOGIC", "DEPLOYMENTLOGIC", "TRIGGERLOGIC" };
        public static List<GO> FAILURETEMPLATES = new();
        public static List<GO> FLAGTEMPLATES = new();
        public static List<GO> OBJECTIVETEMPLATES = new();
        public static List<GO> OBJECTIVELOGICTEMPLATES = new();
        public static List<GO> DEPLOYMENTLOGICTEMPLATES = new();
        public static List<GO> TRIGGERLOGICTEMPLATES = new();
        public static GO TEMPLOC;
        public static string SIDE_MODE = "ALLIESSOVNEUT";
        public static string OLD_SIDE_MODE = null;
        public static bool LANDWAR = false;
        public static bool GARRISONWAR = false;
        public static double LANDCOMBATSIZE = 0;
        public static double LANDSUPPLYSIZE = 0;
        public static double LANDTRANSFERSIZE = 0;
        public static bool COMBINEDATTACKS = false;
        public static bool AIRSURFACEINTERACTION = false;
        public static bool SURFACEREALTIMEDETECTION = false;
        public static bool SUBREALTIMEDETECTION = false;
        public static bool STRATEGICMINING = false;
        public static bool STRATEGICTACCOORD = false;
        public static bool SHOWAILOGIC = false;
        public static Dictionary<double, string> INTERCEPTIONCOLUMNS = new(){
            {1.0/5.0, "1:5"},
            {1.0/4.0, "1:4"},
            {1.0/3.0, "1:3"},
            {1.0/2.0, "1:2"},
            {1, "1:1"},
            {2, "2:1"},
            {3, "3:1"},
            {4, "4:1"}
        };
        public override void SHOWINSTRUCTIONS()
        {
            _Window.UpdateBanner(ExecutingGamePhase().BANNER ?? ExecutingGamePhase().ID, FS.SIDE_MODE);
        }

        public static string INTERCEPTIONCOLUMNHEADER(double odds)
        {
            return INTERCEPTIONCOLUMNS[odds];
        }
        public static List<string> INTERCEPTIONRESULTS(string column, int dieRoll)
        {
            return column switch
            {
                "1:5" => dieRoll switch
                {
                    0 => new() { "3R", "0" },
                    1 => new() { "3R", "0" },
                    2 => new() { "3R", "0" },
                    3 => new() { "3R", "0" },
                    4 => new() { "2R", "0" },
                    5 => new() { "2R", "0" },
                    6 => new() { "1R", "0" },
                    7 => new() { "1R", "0" },
                    8 => new() { "0R", "0" },
                    9 => new() { "0", "0R" },
                    _ => new() { "0", "0" },
                },
                "1:4" => dieRoll switch
                {
                    0 => new() { "3R", "0" },
                    1 => new() { "3R", "0" },
                    2 => new() { "3R", "0" },
                    3 => new() { "2R", "0" },
                    4 => new() { "2R", "0" },
                    5 => new() { "1R", "0" },
                    6 => new() { "1R", "0" },
                    7 => new() { "0R", "0" },
                    8 => new() { "0", "0R" },
                    9 => new() { "0", "0R" },
                    _ => new() { "0", "0" },
                },
                "1:3" => dieRoll switch
                {
                    0 => new() { "3R", "0" },
                    1 => new() { "2R", "0" },
                    2 => new() { "2R", "0" },
                    3 => new() { "1R", "0" },
                    4 => new() { "1R", "0" },
                    5 => new() { "0R", "0" },
                    6 => new() { "0R", "0R" },
                    7 => new() { "0", "0R" },
                    8 => new() { "0", "0R" },
                    9 => new() { "0", "1R" },
                    _ => new() { "0", "0" },
                },
                "1:2" => dieRoll switch
                {
                    0 => new() { "2R", "0" },
                    1 => new() { "2R", "0" },
                    2 => new() { "1R", "0" },
                    3 => new() { "1R", "0" },
                    4 => new() { "0R", "0" },
                    5 => new() { "0R", "0R" },
                    6 => new() { "0", "0R" },
                    7 => new() { "0", "1R" },
                    8 => new() { "0", "1R" },
                    9 => new() { "0", "2R" },
                    _ => new() { "0", "0" },
                },
                "1:1" => dieRoll switch
                {
                    0 => new() { "2R", "0" },
                    1 => new() { "1R", "0" },
                    2 => new() { "1R", "0" },
                    3 => new() { "0R", "0" },
                    4 => new() { "0R", "0R" },
                    5 => new() { "0", "0R" },
                    6 => new() { "0", "1R" },
                    7 => new() { "0", "1R" },
                    8 => new() { "0", "1R" },
                    9 => new() { "0", "2R" },
                    _ => new() { "0", "0" },
                },
                "2:1" => dieRoll switch
                {
                    0 => new() { "1R", "0" },
                    1 => new() { "0R", "0" },
                    2 => new() { "0R", "0R" },
                    3 => new() { "0", "0R" },
                    4 => new() { "0", "0R" },
                    5 => new() { "0", "1R" },
                    6 => new() { "0", "1R" },
                    7 => new() { "0", "1R" },
                    8 => new() { "0", "2R" },
                    9 => new() { "0", "2R" },
                    _ => new() { "0", "0" },
                },
                "3:1" => dieRoll switch
                {
                    0 => new() { "0R", "0" },
                    1 => new() { "0R", "0R" },
                    2 => new() { "0", "0R" },
                    3 => new() { "0", "1R" },
                    4 => new() { "0", "1R" },
                    5 => new() { "0", "1R" },
                    6 => new() { "0", "2R" },
                    7 => new() { "0", "2R" },
                    8 => new() { "0", "3R" },
                    9 => new() { "0", "3R" },
                    _ => new() { "0", "0" },
                },
                "4:1" => dieRoll switch
                {
                    0 => new() { "0R", "0R" },
                    1 => new() { "0", "1R" },
                    2 => new() { "0", "1R" },
                    3 => new() { "0", "1R" },
                    4 => new() { "0", "2R" },
                    5 => new() { "0", "2R" },
                    6 => new() { "0", "3R" },
                    7 => new() { "0", "3R" },
                    8 => new() { "0", "4R" },
                    9 => new() { "0", "4R" },
                    _ => new() { "0", "0" },
                },
                _ => new() { "0", "0" },
            };
        }
        public static List<string> BOUNCERESULTS(int dieRoll)
        {
            return dieRoll switch
            {
                0 => new() { "0", "0" },
                1 => new() { "0", "1" },
                2 => new() { "0", "0R" },
                3 => new() { "0", "0R" },
                4 => new() { "0", "1R" },
                5 => new() { "0", "1R" },
                6 => new() { "0", "1R" },
                7 => new() { "0", "2R" },
                8 => new() { "0", "2R" },
                9 => new() { "0", "3R" },
                _ => new() { "0", "0" },
            };
        }
        public static List<string> COMBATMISSIONTYPES = new() { "SSM", "ASW", "CM", "BOMB", "TORP", "AAA", "CC" };
        public static List<string> TACCOORDMISSIONTYPES = new() { "SURFACE TACCOORD", "SUB TACCOORD" };
        public const double HEXDISTANCE = 94;
        public const double MILESPERTURN = 100;
        public static Dictionary<string, string> THEATERS = new(){
            {"CARIBBEAN", "CARIBBEAN"},
            {"ATLANTIC", "EUROPEAN"},
            {"MEDITERRANEAN", "EUROPEAN"},
            {"INDIAN", "INDIAN"},
            {"PACIFIC", "PACIFIC"},
        };
        public static Dictionary<string, List<string>> STRATEGICCOUNTRIES = new();
        //15 hexes from OMAF to ZONE is 1 hop, 30 is 2, 45 is 3....
        public static Dictionary<string, List<string>> ZONECONNECTIONS = new(){
            {"ADRIATIC", new(){"BLACK SEA", "AEGEAN", "CENTRAL MEDITERRANEAN", "THYRRENIAN SEA"}},
            {"AEGEAN", new(){"ADRIATIC", "BLACK SEA", "CENTRAL MEDITERRANEAN", "EASTERN MEDITERRANEAN"}},
            {"ALEUTIAN", new(){"SEA OF OKHOTSK", "KAMCHATKA"}},
            {"ASHKHABAD", new(){"PERSIAN GULF"}},
            {"ATLANTIC", new(){"PUERTO RICO", "BAHAMAS"}},
            {"AZORES", new(){"NORTH ATLANTIC", "WESTERN APPROACHES", "IBERIAN"}},
            {"BAHAMAS", new(){"FLORIDA", "ATLANTIC", "PUERTO RICO", "WINDWARD PASSAGE"}},
            {"BAKU", new(){"BLACK SEA", "PERSIAN GULF"}},
            {"BALTIC SEA", new(){"BOTHNIA GULF", "NORTH SEA", "NORWEGIAN SEA"}},
            {"BARENTS SEA", new(){"BOTHNIA GULF", "NORWEGIAN SEA", "GREENLAND", "SVALBARD"}},
            {"BAY OF BENGAL", new(){"SUMATRA", "EAST INDIAN OCEAN", "SRI LANKA", "INDIA"}},
            {"BAY OF BISCAY", new(){"IBERIAN", "WESTERN MEDITERRANEAN", "WESTERN APPROACHES", "IRELAND", "NORTH SEA"}},
            {"BERMUDA", new(){"BERMUDA1", "BAHAMAS"}},
            {"BERMUDA1", new(){"BERMUDA2"}},
            {"BERMUDA2", new(){"AZORES"}},
            {"BLACK SEA", new(){"EASTERN MEDITERRANEAN", "ADRIATIC", "AEGEAN"}},
            {"BONIN ISLANDS", new(){"NORTHWEST PACIFIC", "NORTH PACIFIC", "MARIANAS", "CENTRAL PACIFIC", "JAPAN"}},
            {"BOTHNIA GULF", new(){"BARENTS SEA", "BALTIC SEA", "NORWEGIAN SEA"}},
            {"CAPE FAREWELL", new(){"LABRADOR SEA", "NORTH ATLANTIC", "WESTERN APPROACHES", "ICELAND SEA", "GREENLAND"}},
            {"CENTRAL MEDITERRANEAN", new(){"EASTERN MEDITERRANEAN", "AEGEAN", "ADRIATIC", "THYRRENIAN SEA"}},
            {"CENTRAL PACIFIC", new(){"JAPAN", "BONIN ISLANDS", "MARIANAS", "SOUTH PACIFIC", "PHILIPPINES", "FORMOSA", "EAST CHINA SEA", }},
            {"CHAGOS ARCHIPELAGO", new(){"MALDIVES", "EAST INDIAN OCEAN"}},
            {"EAST CHINA SEA", new(){"YELLOW SEA", "SEA OF JAPAN", "JAPAN", "CENTRAL PACIFIC", "FORMOSA"}},
            {"EAST INDIAN OCEAN", new(){"SUMATRA", "CHAGOS ARCHIPELAGO", "MALDIVES", "SRI LANKA", "BAY OF BENGAL"}},
            {"EASTERN MEDITERRANEAN", new(){"CENTRAL MEDITERRANEAN", "AEGEAN", "BLACK SEA"}},
            {"EGLIN", new(){"FLORIDA"}},
            {"ELMENDORF AFB", new(){"ALEUTIAN"}},
            {"FLORIDA", new(){"BAHAMAS", "WINDWARD PASSAGE", "WESTERN CARIBBEAN"}},
            {"FORMOSA", new(){"EAST CHINA SEA", "CENTRAL PACIFIC", "PHILIPPINES", "SOUTH CHINA SEA", "HAINAN"}},
            {"GALENA", new(){"ALEUTIAN"}},
            {"GEORGE TOWN", new(){"SUMATRA", "SOUTH CHINA SEA"}},
            {"GREENLAND", new(){"SVALBARD", "BARENTS SEA", "NORWEGIAN SEA", "ICELAND SEA", "CAPE FAREWELL"}},
            {"GULF OF ADEN", new(){"SAUDI ARABIA", "SOCOTRA"}},
            {"GULF OF OMAN", new(){"NORTH ARABIAN SEA", "SOUTH ARABIAN SEA", "SOCOTRA", "SAUDI ARABIA", "PERSIAN GULF"}},
            {"HAINAN", new(){"FORMOSA", "SOUTH CHINA SEA"}},
            {"HOKKAIDO", new(){"SEA OF OKHOTSK", "NORTHWEST PACIFIC", "JAPAN", "SEA OF JAPAN"}},
            {"IBERIAN", new(){"AZORES", "WESTERN APPROACHES", "BAY OF BISCAY", "WESTERN MEDITERRANEAN"}},
            {"ICELAND SEA", new(){"GREENLAND", "NORWEGIAN SEA", "NORTH SEA", "IRELAND", "WESTERN APPROACHES", "CAPE FAREWELL"}},
            {"INDIA", new(){"BAY OF BENGAL", "SRI LANKA", "LACCADIVES", "NORTH ARABIAN SEA"}},
            {"IRELAND", new(){"BAY OF BISCAY", "WESTERN APPROACHES", "ICELAND SEA", "NORTH SEA"}},
            {"JAPAN", new(){"HOKKAIDO", "NORTHWEST PACIFIC", "BONIN ISLANDS", "CENTRAL PACIFIC", "EAST CHINA SEA", "SEA OF JAPAN"}},
            {"KABUL", new(){"GULF OF OMAN"}},
            {"KAMCHATKA", new(){"ALEUTIAN", "SEA OF OKHOTSK"}},
            {"KING SALMON", new(){"ALEUTIAN"}},
            {"LABRADOR SEA", new(){"CAPE FAREWELL", "NORTH ATLANTIC"}},
            {"LACCADIVES", new(){"INDIA", "SRI LANKA", "MALDIVES", "WEST INDIAN OCEAN", "SOUTH ARABIAN SEA", "NORTH ARABIAN SEA"}},
            {"LESSER ANTILLES", new(){"PUERTO RICO", "VENEZUELA", }},
            {"LORING AFB", new(){"LABRADOR SEA"}},
            {"MAGADAN", new(){"KAMCHATKA"}},
            {"MALDIVES", new(){"SRI LANKA", "EAST INDIAN OCEAN", "CHAGOS ARCHIPELAGO", "WEST INDIAN OCEAN", "LACCADIVES"}},
            {"MARIANAS", new(){"SOUTH PACIFIC", "CENTRAL PACIFIC", "BONIN ISLANDS", "NORTH PACIFIC"}},
            {"MIDWAY ISLAND", new(){"MIDWAY1"}},
            {"MIDWAY1", new(){"NORTH PACIFIC", "ALEUTIAN", "MIDWAY2"}},
            {"MIDWAY2", new(){"MARIANAS"}},
            {"NORTH ARABIAN SEA", new(){"INDIA", "LACCADIVES", "SOUTH ARABIAN SEA", "GULF OF OMAN"}},
            {"NORTH ATLANTIC", new(){"LABRADOR SEA", "CAPE FAREWELL", "WESTERN APPROACHES", "AZORES"}},
            {"NORTH PACIFIC", new(){"NORTHWEST PACIFIC", "MARIANAS", "BONIN ISLANDS"}},
            {"NORTH SEA", new(){"NORWEGIAN SEA", "BALTIC SEA", "BAY OF BISCAY", "IRELAND", "ICELAND SEA"}},
            {"NORTHWEST PACIFIC", new(){"SEA OF OKHOTSK", "NORTH PACIFIC", "BONIN ISLANDS", "JAPAN", "HOKKAIDO"}},
            {"NORWEGIAN SEA", new(){"GREENLAND", "BARENTS SEA", "BOTHNIA GULF", "BALTIC SEA", "NORTH SEA", "ICELAND SEA"}},
            {"OKHOTSK", new(){"KAMCHATKA"}},
            {"PANAMA CANAL", new(){"WESTERN CARIBBEAN", "VENEZUELA"}},
            {"PEARL HARBOR", new(){"PEARL1"}},
            {"PEARL1", new(){"PEARL2"}},
            {"PEARL2", new(){"ALEUTIAN"}},
            {"PERSIAN GULF", new(){"GULF OF OMAN", "SAUDI ARABIA"}},
            {"PHILIPPINES", new(){"CENTRAL PACIFIC", "SOUTH PACIFIC", "SOUTH CHINA SEA", "FORMOSA"}},
            {"PRINCE RUPERT", new(){"PRINCERUPERT1"}},
            {"PRINCERUPERT1", new(){"ALEUTIAN"}},
            {"PUERTO RICO", new(){"ATLANTIC", "LESSER ANTILLES", "VENEZUELA", "WINDWARD PASSAGE", "BAHAMAS"}},
            {"SAUDI ARABIA", new(){"PERSIAN GULF", "GULF OF OMAN", "SOCOTRA", "GULF OF ADEN"}},
            {"SEA OF JAPAN", new(){"HOKKAIDO", "JAPAN", "EAST CHINA SEA", "YELLOW SEA"}},
            {"SEA OF OKHOTSK", new(){"KAMCHATKA", "ALEUTIAN", "NORTHWEST PACIFIC", "HOKKAIDO"}},
            {"SINGAPORE", new(){"SUMATRA", "SINGAPORE1"}},
            {"SINGAPORE1", new(){"SOUTH CHINA SEA"}},
            {"SOCOTRA", new(){"GULF OF OMAN", "SOUTH ARABIAN SEA", "WEST INDIAN OCEAN", "GULF OF ADEN", "SAUDI ARABIA"}},
            {"SOUTH ARABIAN SEA", new(){"NORTH ARABIAN SEA", "LACCADIVES", "WEST INDIAN OCEAN", "SOCOTRA", "GULF OF OMAN"}},
            {"SOUTH CHINA SEA", new(){"SCSSUMATRA", "HAINAN", "FORMOSA", "PHILIPPINES"}},
            {"SCSSUMATRA", new(){"SOUTH CHINA SEA", "SUMATRA"}},
            {"SOUTH PACIFIC", new(){"CENTRAL PACIFIC", "MARIANAS", "PHILIPPINES"}},
            {"SRI LANKA", new(){"INDIA", "BAY OF BENGAL", "EAST INDIAN OCEAN", "MALDIVES", "LACCADIVES"}},
            {"SUMATRA", new(){"SCSSUMATRA", "EAST INDIAN OCEAN", "BAY OF BENGAL"}},
            {"SVALBARD", new(){"GREENLAND", "BARENTS SEA"}},
            {"THYRRENIAN SEA", new(){"WESTERN MEDITERRANEAN", "CENTRAL MEDITERRANEAN", "ADRIATIC", }},
            {"VENEZUELA", new(){"WINDWARD PASSAGE", "PUERTO RICO", "LESSER ANTILLES", "PANAMA CANAL", "WESTERN CARIBBEAN"}},
            {"WEST INDIAN OCEAN", new(){"SOUTH ARABIAN SEA", "LACCADIVES", "MALDIVES", "SOCOTRA"}},
            {"WESTERN APPROACHES", new(){"CAPE FAREWELL", "NORTH ATLANTIC", "AZORES", "IBERIAN", "BAY OF BISCAY", "IRELAND", "ICELAND SEA"}},
            {"WESTERN CARIBBEAN", new(){"FLORIDA", "WINDWARD PASSAGE", "VENEZUELA", "PANAMA CANAL"}},
            {"WESTERN MEDITERRANEAN", new(){"THYRRENIAN SEA", "BAY OF BISCAY", "IBERIAN"}},
            {"WINDWARD PASSAGE", new(){"FLORIDA", "BAHAMAS", "PUERTO RICO", "VENEZUELA", "WESTERN CARIBBEAN"}},
            {"YELLOW SEA", new(){"SEA OF JAPAN", "EAST CHINA SEA"}}
        };
        public static Dictionary<string, List<string>> ALIGNEDCOUNTRIES = new(){
            {"ALLIES", new(){"USA", "UK", "CAN", "FRA", "SPN", "PRT", "FRG", "GRC", "NED", "DEN", "BEL", "NOR", "ITA", "TUR", "ICE",
                            "JPN", "SKOR", "TAI", "PHL", "AUS", "SGP", "MLY", "THA",
                            "BHR", "SAU", "OMN", "QTR", "UAE", "KUW",
                            "AAB", "GRN", "PAN", "MEX", "APW"}},
            {"SOV", new(){"USSR", "POL", "DDR", "CZE", "ROM", "BUL", "HUN",
                            "AFG", "CUB", "NIC", "SYM", "NYM", "ETH", "VNM", "NKOR",
                            "SYR", "LIB", "ALG", "MON",
                            "BEN", "ANG", "MOZ", "SPW"}},
            {"NEUT", new(){"NPW"}}
        };
        public static List<string> GENERICCOUNTRIES = new() { "APW", "SPW", "NPW" };
        public static bool ISGROUP(GO obj)
        {
            return obj.GRPTYPE != null;
        }
        public override string TURNTITLE()
        {
            return "TURN " + GetInt("TURN") + " : " + (Get("TURN.TYPE") ?? "-");
        }
        public override string TURNPHASE()
        {
            string fullName = "";
            GamePhase tmp = ExecutingGamePhase();
            string[] pathParts = tmp.UNIQUEPATH.Split('|');
            for (int p = 0; p < pathParts.Length; p++)
            {
                string pathPart = pathParts[p];
                if (!pathPart.Contains("*"))
                {
                    if (fullName == "")
                    {
                        fullName = pathPart;
                    }
                    else
                    {
                        fullName += " | " + pathPart;
                    }
                }
            }
            return fullName;
        }
        public override Run SHORTTURNPHASE()
        {
            return new Run(ExecutingGamePhase().ID)
            {
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.White,
                Background = SIDE_MODE switch
                {
                    "ALLIES" => Brushes.Blue,
                    "SOV" => Brushes.Red,
                    _ => Brushes.Black
                }
            };
        }
        public override List<GO> STACKSATLOCATION(string glid)
        {
            //List<GO> markers = new();
            List<GO> markers = TYPE("PIECE", "GAMELOCATIONID", glid);
            foreach (GO marker in markers)
            {
                GO loc = FS.PARENTGROUPLOCATION(marker);
                if (loc != marker.GAMELOCATION)
                {
                    marker.GAMELOCATIONID = loc.ID;
                    marker.GAMELOCATION = loc;
                }
            }
            return markers;
        }
        public override void GARBAGECOLLECT(GO obj)
        {
            foreach (UIElement uie in new List<UIElement> { obj.image, obj.lineIndicator, obj.lineIndicator2, obj.ellipseIndicator }.Where(n => n != null))
            {
                if (uie == obj.image)
                {
                    GOImageMap.Remove(obj.image);
                }
                _Window.WORLD_CANVAS.Children.Remove(uie);
            }
            _Window.IndicatorsToDraw.RemoveAll(n => n.GAMEPIECE == obj);
            _Window.IndicatorsDrawn.RemoveAll(n => n.GAMEPIECE == obj);
            if (TempParents.ContainsValue(obj))
            {
                foreach (GO k in TempParents.Keys.Where(n => TempParents[n] == obj).ToList())
                {
                    TempParents.Remove(k);
                }
            }
            _Objects.Remove(obj.ID);
            foreach (List<GO> objs in _TypeObjects.Values)
            {
                objs.Remove(obj);
            }
            _ChangedObjects.Remove(obj);
            _Window.combinedState.state.Remove(obj.ID);
            foreach (GO c in LOGICS().Where(n => n.LOGIC == obj))
            {
                DISCARDLOGIC(c);
            }
            foreach (GO c in TYPE("AI.LOGICLINK").Where(n => n.UNIT == obj))
            {
                DISCARDLOGIC(c);
            }
            obj.GS = null;
        }
        public static double VPVALUE(GO ship)
        {
            return ship.UNITTYPE switch
            {
                "AA" => ship.TEMPLATE.SPECIAL,
                "MP" => ship.TEMPLATE.SPECIAL,
                "SC" => ship.TEMPLATE.SPECIAL,
                "FC" => ship.TEMPLATE.SPECIAL,
                "TK" => ship.TEMPLATE.SPECIAL,
                "BB" => 12,
                "CV" => (ship.COUNTRY == "USA" ? 10 : 5) + ship.TEMPLATE.DEF,
                _ => ship.UNITCATEGORY == "AIR" ? 1 : Math.Max(ship.TEMPLATE.DEF, 2)
            };
        }
        public override void PreCallProcess()
        {
            if (SelectedMarker != null)
            {
                if (!InteractionMap.ContainsKey(SelectedMarker))
                {
                    _Window.ClearSelectedMarker();
                }
            }
            if (GetBoolean("_CONFIG_PROMPT_WHEN_SWITCHING_SIDE_VISIBILITY"))
            {
                TextBlock textBlock = (TextBlock)_Window.FindName("TXTINFO");
                textBlock.Text = "";
                textBlock.Background = Brushes.Black;
                textBlock.Foreground = Brushes.Black;
                /*
                GO anchorLocation = LOCATION(BLINDER.SHEETANCHORLOCATIONID);
                double viewportWidth = Math.Max(_Window.CANVAS_SCROLL_VIEWER.ViewportWidth, 1000);
                double viewportHeight = Math.Max(_Window.CANVAS_SCROLL_VIEWER.ViewportHeight, 500);
                double realX = _Window.CANVAS_SCROLL_VIEWER.HorizontalOffset + viewportWidth * 0.5;
                double realY = _Window.CANVAS_SCROLL_VIEWER.VerticalOffset + viewportHeight * 0.5;
                double gameX = realX / _Window.MapZoomLevel;
                double gameY = realY / _Window.MapZoomLevel;
                anchorLocation.x = gameX;
                anchorLocation.XCOORD = gameX;
                anchorLocation.y = gameY;
                anchorLocation.YCOORD = gameY;
                CHANGELOCATION(BLINDER, anchorLocation.ID);
                _Window.DrawMarkerStackImmediately(GO.DOMAIN_SHEET, anchorLocation);
                */
                _Window.BACKGROUND.Background = Brushes.Black;
                Canvas.SetZIndex(_Window.BACKGROUND, MainWindow.Z_BLINDER);
            }
            if (_Window.ActionContext.Contains("SAVE"))
            {
                if (FS.ORDERS)
                {
                    if (GetBoolean("ACTION.PAUSE." + SIDE_MODE))
                    {
                        SetBoolean("ACTION.PAUSE." + SIDE_MODE, false);
                    }
                }
            }
        }
        public override void PostCallProcess()
        {
            bool InProgress = AdvancingPhase != null;
            Boolean changingSideView = OLD_SIDE_MODE != SIDE_MODE && !FS.SETUP;
            //pop up blinder and message when switching side views
            if (changingSideView)
            {
                GO selectedGO = SelectedMarker;
                _Window.ClearSelectedMarker();
                if (FS.SIDE_NAMES.Contains(OLD_SIDE_MODE) && FS.SIDE_NAMES.Contains(SIDE_MODE) && AI_Sides.Count == 0)
                {
                    if (GetBoolean("_CONFIG_PROMPT_WHEN_SWITCHING_SIDE_VISIBILITY"))
                    {
                        MainWindow.Alert("The game is entering " + SIDE_MODE + " perspective.\n\nIf necessary, please switch players before continuing.");
                    }
                }
                OLD_SIDE_MODE = SIDE_MODE;
                SelectedMarker = selectedGO;
                _Window.SelectMarker(selectedGO);
                _Window.HideMenus();
            }
            if (changingSideView || advanced)
            {
                foreach (GO loc in InspectedLocations.ToList())
                {
                    REMOVEINSPECTION(loc);
                }
            }
            if (FS.ORDERS)
            {
                List<GO> interrupts = FS.TYPESIDE(this, "ALERT", SIDE_MODE);
                if (!GetBoolean("ACTION.PAUSE." + SIDE_MODE) && interrupts.Any())
                {
                    //MainWindow.Alert(string.Join("\n", interrupts));
                    SetBoolean("ACTION.PAUSE." + SIDE_MODE, true);
                }
            }
            //CHANGELOCATION(BLINDER, "TEMP");
            _Window.BACKGROUND.Background = Brushes.Gray;
            Canvas.SetZIndex(_Window.BACKGROUND, MainWindow.Z_BACKGROUND);
            //DISPLAYDETAILSHEET(this);
            //handle sheets
            //if selected unit or its move targets are on a sheet, show it
            List<GO> SelectedTargetLocations = new();
            HashSet<GO> SheetsThatMustBeVisible = new();
            HashSet<GO> LocationsThatMustBeInspected = new();
            if (SelectedMarker != null && InteractionMap.ContainsKey(SelectedMarker))
            {
                if (SelectedMarker.PARENTSHEETID != null)
                {
                    SheetsThatMustBeVisible.Add(SelectedMarker.PARENTSHEET);
                }
                SelectedTargetLocations.AddRange(InteractionMap[SelectedMarker]);
                foreach (GO sheet in SelectedTargetLocations.Where(n => n.PARENTSHEETID != null).Select(n => n.PARENTSHEET))
                {
                    SheetsThatMustBeVisible.Add(sheet);
                }
                if (LOGICALPARENT(SelectedMarker) != SelectedMarker)
                {
                    LocationsThatMustBeInspected.Add(PARENTGROUPLOCATION(SelectedMarker));
                }
                if (GetBoolean("ACTION.DEFENDTRAYACTIVE"))
                {
                    GO CARRIER = SelectedMarker.CARRIER;
                    GO GROUP = SelectedMarker.GROUP; // CARRIER?.GROUP ?? SelectedMarker.GROUP;
                    GO ACTIVATIONGRP = SelectedMarker.ACTIVATIONGRP; // CARRIER?.ACTIVATIONGRP ?? SelectedMarker.ACTIVATIONGRP;       
                    if (CARRIER?.PARENTSHEET == FS.DEFENDSHEET || GROUP?.PARENTSHEET == FS.DEFENDSHEET || ACTIVATIONGRP?.PARENTSHEET == FS.DEFENDSHEET)
                    {
                        SheetsThatMustBeVisible.Add(FS.DEFENDSHEET);
                    }
                }
                switch (SelectedMarker.TYPE)
                {
                    case "OBJECTIVELOGIC":
                    case "DEPLOYMENTLOGIC":
                    case "TRIGGERLOGIC":
                        SelectedTargetLocations.Clear();
                        break;
                    default:
                        break;
                }
            }
            //handle connecting lines from open trays
            List<GO> DRAWLINES = new();
            List<GO> tmpsheets = [FS.DEFENDSHEET];
            //any target for our selected marker, show indicator
            if (!ExecutingGamePhase().NoShowLocationIndicators && ExecutingGamePhase().DragDrop)
            {
                SelectedTargetLocations.RemoveAll(n => tmpsheets.Contains(n.PARENTSHEET) && (n.XCOORD >= n.PARENTSHEET.IMAGEWIDTH || n.YCOORD >= n.PARENTSHEET.IMAGEHEIGHT));
                SelectedTargetLocations.ForEach(n => n.MakeEllipseVisible("WHITE", false, 40));
            }
            foreach (GO grouptray in tmpsheets)
            {
                GO parentPiece = grouptray.SHEETPARENTPIECE;
                if (parentPiece == null || FS.PARENTGROUPLOCATION(parentPiece).LOCATIONHIDDEN || parentPiece.HIDDEN || parentPiece.DESTROYED)
                {
                    if (grouptray.GAMELOCATIONID != "TEMP")
                    {
                        REMOVEGROUPSHEET(grouptray);
                    }
                }
                else
                {
                    DRAWLINES.Add(grouptray);
                }
            }
            foreach (GO sheet in SHEETS())
            {
                if (SheetsThatMustBeVisible.Contains(sheet))
                {
                    if (!sheet.EXPANDED)
                    {
                        _Window.ExpandOrCollapseSheet(sheet, true);
                    }
                    if (tmpsheets.Contains(sheet))
                    {
                        sheet.MakeLineVisible("WHITE");
                    }
                }
                else
                {
                    if (changingSideView || advanced)
                    {
                        if (FS.TRAYSHEETS.Contains(sheet))
                        {
                            REMOVEGROUPSHEET(sheet);
                        }
                        else if (!tmpsheets.Contains(sheet) && sheet.EXPANDED)
                        {
                            _Window.ExpandOrCollapseSheet(sheet, false);
                        }
                    }
                    else if (DRAWLINES.Contains(sheet))
                    {
                        sheet.MakeLineVisible("WHITE");
                        if (!sheet.EXPANDED)
                        {
                            _Window.ExpandOrCollapseSheet(sheet, true);
                        }
                    }
                }
            }
            string humanSide = AI_Sides.Count switch
            {
                1 => FS.ENEMY(AI_Sides.First()),
                _ => null
            };
            //show trails of activated units
            if (AI_Sides.Count == 2)
            {
                foreach (GO obj in FS.SCENARIOUNITS(this, "ACTION.ACTIVATED").Where(n => n.LOCATIONHISTORY != null && !n.HIDDEN && n == SelectedMarker))
                {
                    string[] locations = obj.LOCATIONHISTORY.Split('|');
                    for (int i = 1; i < locations.Length; i++)
                    {
                        bool first = i == 1;
                        bool last = i == locations.Length - 1;
                        string f = locations[i - 1];
                        string t = locations[i];
                        if (first)
                        {
                            LOCATION(f).MakeEllipseVisible("GRAY", true, 20);
                        }
                        GO connector = TYPE("UNITMOVEMENT", "CONNECTORLOCATIONID", f).Where(n => n.CONNECTORLOCATION2ID == t).FirstOrDefault();
                        connector?.MakeLineVisible("GRAY");
                    }
                }
                foreach (string s in FS.SIDE_NAMES)
                {
                    foreach (string typ in FS.UNITTYPES)
                    {
                        foreach (GO obj in FS.TYPESIDE(this, typ, s).Where(n => n.LOCATIONFUTURE != null && !n.HIDDEN && LOGICALPARENT(n) == n))
                        {
                            string[] locations = obj.LOCATIONFUTURE.Split('|');
                            for (int i = 1; i < locations.Length; i++)
                            {
                                bool first = i == 1;
                                bool last = i == locations.Length - 1;
                                string f = locations[i - 1];
                                string t = locations[i];
                                GO connector = TYPE("UNITMOVEMENT", "CONNECTORLOCATIONID", f).Where(n => n.CONNECTORLOCATION2ID == t).FirstOrDefault();
                                string color = "BLACK";
                                if (obj == SelectedMarker || obj == SelectedMarker?.GAMEPIECE)
                                {
                                    GO movingUnit = obj.DESTINATIONPIECE ?? obj;
                                    color = movingUnit.REMAININGMOVEMENT < 0 ? "RED" : "WHITE";
                                }
                                connector?.MakeLineVisible(color);
                                if (last)
                                {
                                    LOCATION(t).MakeEllipseVisible(color, true, 20);
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                string SIDETOSHOW = humanSide ?? SIDE_MODE;
                //show transfers
                foreach (GO obj in FS.TYPESIDE(this, "LANDTRANSFER", SIDETOSHOW))
                {
                    obj.MOVEMENTCONNECTOR?.MakeLineVisible("WHITE");
                }
                foreach (GO obj in FS.SCENARIOUNITS(this, "ACTION.ACTIVATED").Where(n => n.LOCATIONHISTORY != null && !n.HIDDEN))
                {
                    string[] locations = obj.LOCATIONHISTORY.Split('|');
                    for (int i = 1; i < locations.Length; i++)
                    {
                        bool first = i == 1;
                        bool last = i == locations.Length - 1;
                        string f = locations[i - 1];
                        string t = locations[i];
                        if (first && obj.SIDE == SIDETOSHOW)
                        {
                            LOCATION(f).MakeEllipseVisible("GRAY", true, 20);
                        }
                        if (last || obj.SIDE == SIDETOSHOW)
                        {
                            GO connector = TYPE("UNITMOVEMENT", "CONNECTORLOCATIONID", f).Where(n => n.CONNECTORLOCATION2ID == t).FirstOrDefault();
                            connector?.MakeLineVisible("GRAY");
                        }
                    }
                }
                foreach (string typ in FS.UNITTYPES)
                {
                    foreach (GO obj in FS.TYPESIDE(this, typ, SIDETOSHOW).Where(n => n.LOCATIONFUTURE != null && !n.HIDDEN && LOGICALPARENT(n) == n))
                    {
                        string[] locations = obj.LOCATIONFUTURE.Split('|');
                        for (int i = 1; i < locations.Length; i++)
                        {
                            bool first = i == 1;
                            bool last = i == locations.Length - 1;
                            string f = locations[i - 1];
                            string t = locations[i];
                            GO connector = TYPE("UNITMOVEMENT", "CONNECTORLOCATIONID", f).Where(n => n.CONNECTORLOCATION2ID == t).FirstOrDefault();
                            string color = "BLACK";
                            if (obj == SelectedMarker || obj == SelectedMarker?.GAMEPIECE)
                            {
                                GO movingUnit = obj.DESTINATIONPIECE ?? obj;
                                color = movingUnit.REMAININGMOVEMENT < 0 ? "RED" : "WHITE";
                            }
                            connector?.MakeLineVisible(color);
                            if (last)
                            {
                                LOCATION(t).MakeEllipseVisible(color, true, 20);
                            }
                        }
                    }
                }
            }
            //show conflicts
            foreach (GO obj in TYPE("LANDCOMBAT"))
            {
                obj.MOVEMENTCONNECTOR?.MakeLineVisible("RED");
            }
            if (InProgress)
            {
                foreach (GO marker in TYPE("DESTINATION").Where(n => n.GAMELOCATIONID != null && !n.HIDDEN))
                {
                    marker.HIDDEN = true;
                    _Window.DrawMarkerStack(marker.GAMELOCATION, true);
                }
            }
            else
            {
                foreach (GO loc in LocationsThatMustBeInspected)
                {
                    if (!InspectedLocations.Contains(loc))
                    {
                        ADDINSPECTION(loc);
                    }
                }
                GO logicalParent = LOGICALPARENT(LOGICALPARENT(SelectedMarker));
                if (logicalParent != SelectedMarker && InspectedLocations.Contains(SelectedMarker.GAMELOCATION))
                {
                    ShuffleMarker(logicalParent);
                    _Window.DrawMarkerStack(logicalParent.GAMELOCATION);
                    TempParents[logicalParent.GAMELOCATION] = LOGICALPARENT(SelectedMarker);
                }
            }
        }
        public override void DrawGOs()
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            bool InProgress = AdvancingPhase != null;
            HashSet<GO> InspectionLocationsToRemove = [];
            Dictionary<GO, List<GO>> InspectionObjectsMap = [];
            foreach (GO loc in _Window.GOsToDraw)
            {
                List<GO> objs = _Window.DrawMarkerStackImmediately(loc);
                if (InspectedLocations.Contains(loc))
                {
                    if (objs.Count <= 1)
                    {
                        InspectionLocationsToRemove.Add(loc);
                    }
                    else
                    {
                        InspectionObjectsMap.Add(loc, objs);
                    }
                }
            }
            _Window.GOsToDraw.Clear();
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 0)
            {
                Debug.Print($"{stopwatch.Elapsed} : DrawGOs - DrawMarkerStacks {EXECUTINGPHASE}");
            }
            stopwatch = new Stopwatch();
            stopwatch.Start();
            //show interrupts
            foreach (GO obj in FS.TYPESIDE(this, "ALERT", SIDE_MODE))
            {
                obj.INTERCEPTEDGRP?.MakeEllipseVisible(obj.INTERCEPTEDGRP?.SIDE == SIDE_MODE ? "YELLOW" : "RED", false, 200);
                obj.MakeLineVisible(obj.ATTACKER?.SIDE == obj.INTERCEPTEDGRP?.SIDE ? "WHITE" : "RED");
            }
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 0)
            {
                Debug.Print($"{stopwatch.Elapsed} : DrawGOs - DrawInterrupts {EXECUTINGPHASE}");
            }
            stopwatch = new Stopwatch();
            stopwatch.Start();
            foreach (GO loc in InspectedLocations.ToList())
            {
                bool remove = true;
                if (!InspectionObjectsMap.TryGetValue(loc, out List<GO> objs))
                {
                    objs = _Window.DrawMarkerStackImmediately(loc);
                    InspectionObjectsMap[loc] = objs;
                }
                List<GO> inner = [.. objs.Where(n => n.z == 1)];
                List<GO> outer = [.. objs.Where(n => n.z == 2)];
                if (inner.Count != 0)
                {
                    GETINSPECTIONELLIPSE(loc, "INNERARC").MakeEllipseVisible("LIGHTGRAY", false, INSPECTIONDISPLAYRADIUS() * 2);
                    remove = false;
                }
                if (outer.Count != 0)
                {
                    GETINSPECTIONELLIPSE(loc, "OUTERARC").MakeEllipseVisible("LIGHTGRAY", false, INSPECTIONDISPLAYRADIUS() * 4);
                    remove = false;
                }
                foreach (GO obj in objs.Where(n => n != LOGICALPARENT(n) && objs.Contains(LOGICALPARENT(n))))
                {
                    GETINSPECTIONLINE(loc, obj, "PARENTCONNECTION").MakeLineVisible("LIGHTGRAY");
                }
                if (remove)
                {
                    InspectionLocationsToRemove.Add(loc);
                }
            }
            foreach (GO loc in InspectionLocationsToRemove)
            {
                REMOVEINSPECTION(loc);
            }
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 0)
            {
                Debug.Print($"{stopwatch.Elapsed} : DrawGOs - DrawInspections {EXECUTINGPHASE}");
            }
            stopwatch = new Stopwatch();
            stopwatch.Start();
            if (SelectedMarker?.TYPE == "OBJECTIVELOGIC" || SelectedMarker?.TYPE == "DEPLOYMENTLOGIC")
            {
                GO logic = SelectedMarker;
                string[] locations = logic.LOCATIONCOVERAGE != null ? [.. logic.LOCATIONCOVERAGE.Split('|')] : [logic.GAMELOCATIONID];
                for (int i = 0; i < locations.Length; i++)
                {
                    string f = locations[i];
                    LOCATION(f)?.MakeEllipseVisible("BLACK", true, 30);
                }
            }
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 0)
            {
                Debug.Print($"{stopwatch.Elapsed} : DrawGOs - DrawLogicCoverages {EXECUTINGPHASE}");
            }
            stopwatch = new Stopwatch();
            stopwatch.Start();
            //show AI logic links
            //if no longer valid discard
            List<GO> discarded = [];
            foreach (GO obj in TYPE("AI.LOGICLINK"))
            {
                if(obj.UNIT == null || obj.LOGIC == null || obj.UNIT.DESTROYED || obj.UNIT.RECYCLED || obj.UNIT.GAMELOCATION.HIDDEN || obj.LOGIC.DESTROYED || obj.LOGIC.RECYCLED)
                {
                    discarded.Add(obj);
                }
                else if(FS.SHOWAILOGIC && (FS.SETUP || FS.AI_REVIEW || obj.SIDE == SIDE_MODE))
                {
                    obj.MakeLineVisible(obj.ACTIVE? "RED" : "YELLOW");
                }
            }
            foreach (GO c in discarded)
            {
                DISCARDLOGIC(c);
            }
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 0)
            {
                Debug.Print($"{stopwatch.Elapsed} : DrawGOs - DrawLogicLines {EXECUTINGPHASE}");
            }
            stopwatch = new Stopwatch();
            stopwatch.Start();
            if (!InProgress && SelectedMarker != null)
            {
                //simulate mouse move
                _Window.MouseOverMarker = null;
                ProcessImageMouseMove(SelectedMarker);
                ProcessImageMouseMove(SelectedMarker);
            }
            stopwatch.Stop();
            if (stopwatch.ElapsedMilliseconds > 0)
            {
                Debug.Print($"{stopwatch.Elapsed} : DrawGOs - ProcessMouseMoves {EXECUTINGPHASE}");
            }
        }
        public override void ProcessImageMouseMove(GO marker)
        {
            bool processStackMenu = false;
            if (marker?.DOMAIN == GO.DOMAIN_PIECE)
            {
                if (marker != null && marker != _Window.MouseOverMarker)
                {
                    /*if (CANINTERACT(marker))
                    {
                        if (marker != SelectedMarker)
                        {
                            SelectedMarker = marker;
                            _Window.ActionContext.Clear();
                            _Window.RefreshScenario();
                        }
                        else if (marker.DOMAIN == GO.DOMAIN_PIECE)
                        {
                            _Window.ClickMarker(marker, false);
                        }
                    }
                    else if (marker.DOMAIN == GO.DOMAIN_PIECE)
                    {
                        _Window.ClickMarker(marker, false);
                    }*/
                    if (marker == SelectedMarker)
                    {
                        _Window.ChoiceMenuMarker = null;
                    }
                    else
                    {
                        _Window.ClickMarker(marker, false);
                        _Window.InfoMenuMarker = null;
                    }

                    processStackMenu = marker.GAMELOCATION != SelectedMarker?.GAMELOCATION;
                    if (FS.GROUPMEMBERS(marker).Where(n => n != marker).Any())
                    {
                        TempParents[marker.GAMELOCATION] = marker;
                    }
                }
                else
                {
                    bool overSelectedMarker = marker == SelectedMarker;
                    bool overSelectedTargetMarker = marker == SelectedMarker?.DESTINATIONPIECE;
                    bool overSelectedGamepieceMarker = SelectedMarker?.TYPE == "DESTINATION" && marker == SelectedMarker?.GAMEPIECE;
                    bool displayChoiceMenu = overSelectedMarker && marker != _Window.ChoiceMenuMarker;
                    bool displayInfoMenu = !overSelectedMarker && !overSelectedTargetMarker && !overSelectedGamepieceMarker && marker != _Window.InfoMenuMarker;
                    if (displayChoiceMenu)
                    {
                        ProcessMarkerChoiceMenu(marker);
                        if (marker.DESTINATIONPIECE != null && !marker.HIDDEN)
                        {
                            ProcessSelectedMarkerInfoMenu(marker);
                            ProcessSelectedMarkerTargetInfoMenu(marker.DESTINATIONPIECE);
                        }
                        else if (marker.TYPE == "DESTINATION")
                        {
                            ProcessSelectedMarkerInfoMenu(marker.GAMEPIECE);
                            ProcessSelectedMarkerTargetInfoMenu(marker);
                        }
                        else
                        {
                            ProcessSelectedMarkerInfoMenu(marker);
                            _Window.HideMenu(_Window.SelectedMarkerTargetInfoMenu);
                        }
                        _Window.ChoiceMenuMarker = marker;
                        bool xIsClose = Math.Abs(Canvas.GetLeft(_Window.MarkerInfoMenu) - Canvas.GetLeft(_Window.SelectedMarkerInfoMenu)) < 200;
                        bool yIsClose = Math.Abs(Canvas.GetBottom(_Window.MarkerInfoMenu) - Canvas.GetBottom(_Window.SelectedMarkerInfoMenu)) < 200;
                        bool otherMenuIsClose = xIsClose && yIsClose;
                        if (otherMenuIsClose || marker == _Window.InfoMenuMarker)
                        {
                            _Window.HideMenu(_Window.MarkerInfoMenu);
                            _Window.HideMenu(_Window.StackMenu);
                            _Window.InfoMenuMarker = null;
                        }

                    }
                    else if (displayInfoMenu)
                    {
                        ProcessMarkerInfoMenu(marker);
                        _Window.InfoMenuMarker = marker;
                        //_Window.ChoiceMenuMarker = null;
                        //_Window.HideMenu(_Window.MarkerChoiceMenu);
                    }
                }
                _Window.MouseOverMarker = marker;
            }
            if (advanced)
            {
                _Window.SHOWACTIONS = true;
            }
            if (!_Window.SHOWACTIONS)
            {
                _Window.ChoiceMenuMarker = null;
                _Window.HideMenu(_Window.MarkerChoiceMenu);
            }
            /*if((FS.SETUP || FS.AI_REVIEW) && FS.SHOW_AI_MENU)
            {
                PresentAISummary(marker);
            }
            else */
            if (processStackMenu)
            {
                ProcessStackMenu(marker);
            }
        }
        public override void ADDINSPECTION(GO location)
        {
            InspectedLocations.Add(location);
            _Window.DrawMarkerStack(location);
        }
        public override void REMOVEINSPECTION(GO location)
        {
            InspectedLocations.Remove(location);
            _Window.DrawMarkerStack(location);
            foreach (GO logic in TYPE("INNERARC").Where(n => n.GAMELOCATION == location))
            {
                logic.GAMELOCATIONID = null;
            }
            foreach (GO logic in TYPE("OUTERARC").Where(n => n.GAMELOCATION == location))
            {
                logic.GAMELOCATIONID = null;
            }
            foreach (GO logic in TYPE("PARENTCONNECTION").Where(n => n.GAMELOCATION == location))
            {
                logic.GAMELOCATIONID = null;
                logic.GAMEPIECEID = null;
            }
        }
        public GO GETINSPECTIONELLIPSE(GO location, string type)
        {
            GO logic = TYPE(type).Where(n => n.GAMELOCATION == location).FirstOrDefault() ??
                                TYPE(type).Where(n => n.GAMELOCATION == null).FirstOrDefault();
            if (logic == null)
            {
                Dictionary<string, string> clonedData = new()
                {
                    ["ID"] = "ELLIPSE." + type + GO.DELIM + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                    ["DOMAIN"] = GO.DOMAIN_LOGIC,
                    ["TYPE"] = type
                };
                logic = new(this, clonedData, null, null);
            }
            logic.GAMELOCATIONID = location.ID;
            logic.GAMELOCATION = location;
            return logic;
        }
        public GO GETINSPECTIONLINE(GO location, GO gp, string type)
        {
            GO logic = TYPE(type).Where(n => n.GAMEPIECE == gp).FirstOrDefault() ??
                        TYPE(type).Where(n => n.GAMEPIECE == null).FirstOrDefault();
            if (logic == null)
            {
                Dictionary<string, string> clonedData = new()
                {
                    ["ID"] = "LINE." + type + GO.DELIM + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                    ["DOMAIN"] = GO.DOMAIN_LOGIC,
                    ["TYPE"] = type
                };
                logic = new(this, clonedData, null, null);
            }
            logic.GAMELOCATIONID = location.ID;
            logic.GAMELOCATION = location;
            logic.GAMEPIECEID = gp.ID;
            logic.GAMEPIECE = gp;
            return logic;
        }
        public override Dictionary<GO, List<double>> INSPECTIONOFFSETS(List<GO> objects, bool inspecting)
        {
            Dictionary<GO, List<double>> returnList = [];
            if (!inspecting || objects.Count == 0)
            {
                foreach (GO obj in objects.Where(n => LOGICALPARENT(n) == n))
                {
                    if (obj.DOMAIN == GO.DOMAIN_PIECE)
                    {
                        obj.x = 0;
                        obj.y = 0;
                        obj.z = 0;
                    }
                    returnList.Add(obj, []);
                }
            }
            else if (objects[0].GAMELOCATIONID == "ALLDESTROYED")
            {
                List<GO> objs = [.. objects];
                int ring = 1;
                while(objs.Count > 1)
                {
                    double numObjects = Math.Min(objs.Count - 1, 10 * ring);
                    double radius = INSPECTIONDISPLAYRADIUS() * ring;
                    double angleIncrement = (360 / numObjects);
                    double x, y = 0;
                    for (int i = 0; i < numObjects; i++)
                    {
                        double angle = i * angleIncrement;
                        double angleRadians = angle / 57.2957795;
                        GO obj = objs[0];
                        double basex = radius * Math.Cos(angleRadians);
                        double basey = radius * Math.Sin(angleRadians);
                        //transform
                        y = -basex;
                        x = basey;
                        returnList.Add(obj, new() { x - obj.IMAGEWIDTHVALUE * MainWindow.MiniMarkerRatio * 0.5, y - obj.IMAGEHEIGHTVALUE * MainWindow.MiniMarkerRatio * 0.5 });
                        obj.x = x; obj.y = y; obj.z = 1;
                        objs.Remove(obj);
                    }
                    ring++;
                }
                GO last = objs.Last();
                //finally do last marker, center
                returnList.Add(last, new() { last.IMAGEWIDTHVALUE * -0.5, last.IMAGEHEIGHTVALUE * -0.5 });
                last.x = 0;
                last.y = 0;
                last.z = 0;
            }
            else
            {
                List<GO> NOPARENTS = [.. objects.Where(n => LOGICALPARENT(n) == n)];
                List<GO> HASPARENT = [.. objects.Where(n => !NOPARENTS.Contains(n) && NOPARENTS.Contains(LOGICALPARENT(n)))];
                List<GO> HAS2PARENTS = [.. objects.Where(n => !NOPARENTS.Contains(n) && !HASPARENT.Contains(n))];
                if (NOPARENTS.Count > 0)
                {
                    List<GO> objs = NOPARENTS;
                    double numObjects = objs.Count - 1;
                    double radius = INSPECTIONDISPLAYRADIUS();
                    double angleIncrement = (180 / numObjects) / 57.2957795;
                    double angle = -((numObjects - 1) * angleIncrement * 0.5);
                    double x, y = 0;
                    for (int i = 0; i < numObjects; i++)
                    {
                        double basex = radius * Math.Cos(angle);
                        double basey = radius * Math.Sin(angle);
                        //transform
                        y = basex;
                        x = basey;
                        returnList.Add(objs[i], new() { x - objs[i].IMAGEWIDTHVALUE * MainWindow.MiniMarkerRatio * 0.5, y - objs[i].IMAGEHEIGHTVALUE * MainWindow.MiniMarkerRatio * 0.5 });
                        angle += angleIncrement;
                        objs[i].x = x; objs[i].y = y; objs[i].z = 1;
                    }
                    GO last = objs.Last();
                    //do group members
                    List<GO> gms = GROUPMEMBERS(last);
                    gms.Remove(last);
                    numObjects = gms.Count;
                    if (numObjects > 0)
                    {
                        radius = INSPECTIONDISPLAYRADIUS();
                        angleIncrement = (180 / numObjects) / 57.2957795;
                        angle = -((numObjects - 1) * angleIncrement * 0.5);
                        for (int i = 0; i < numObjects; i++)
                        {
                            double basex = radius * Math.Cos(angle);
                            double basey = radius * Math.Sin(angle);
                            //transform
                            y = -basex;
                            x = basey;
                            returnList.Add(gms[i], new() { x - gms[i].IMAGEWIDTHVALUE * MainWindow.MiniMarkerRatio * 0.5, y - gms[i].IMAGEHEIGHTVALUE * MainWindow.MiniMarkerRatio * 0.5 });
                            angle += angleIncrement;
                            gms[i].x = x; gms[i].y = y; gms[i].z = 1;
                        }
                    }
                    //do any parent extensions
                    GO inspectedParent = TempParents.TryGetValue(last.GAMELOCATION, out GO value) ? value : null;
                    if (inspectedParent == null || inspectedParent == last)
                    {
                        inspectedParent = gms.Intersect(HAS2PARENTS.Select(LOGICALPARENT)).FirstOrDefault();
                        TempParents[last.GAMELOCATION] = inspectedParent;
                    }
                    else if (!gms.Contains(inspectedParent))
                    {
                        inspectedParent = null;
                        TempParents[last.GAMELOCATION] = null;
                    }
                    if (inspectedParent != null)
                    {
                        gms = GROUPMEMBERS(inspectedParent);
                        gms.Remove(inspectedParent);
                        numObjects = gms.Count;
                        if (numObjects > 0)
                        {
                            radius = INSPECTIONDISPLAYRADIUS() * 2;
                            angleIncrement = (180 / numObjects) / 57.2957795;
                            angle = -((numObjects - 1) * angleIncrement * 0.5);
                            for (int i = 0; i < numObjects; i++)
                            {
                                double basex = radius * Math.Cos(angle);
                                double basey = radius * Math.Sin(angle);
                                //transform
                                y = -basex;
                                x = basey;
                                returnList.Add(gms[i], new() { x - gms[i].IMAGEWIDTHVALUE * MainWindow.MiniMarkerRatio * 0.5, y - gms[i].IMAGEHEIGHTVALUE * MainWindow.MiniMarkerRatio * 0.5 });
                                angle += angleIncrement;
                                gms[i].x = x; gms[i].y = y; gms[i].z = 2;
                            }
                        }
                    }
                    //finally do last marker, center
                    returnList.Add(last, new() { last.IMAGEWIDTHVALUE * -0.5, last.IMAGEHEIGHTVALUE * -0.5 });
                    last.x = 0;
                    last.y = 0;
                    last.z = 0;
                }
            }
            return returnList;
        }
        public override List<GO> DYNAMICCONNECTORENDPOINTS(GO obj)
        {
            return obj.DOMAIN switch
            {
                GO.DOMAIN_SHEET => new()
                {
                    obj.GAMELOCATION,
                    obj.SHEETPARENTPIECE != null ?
                        obj.SHEETPARENTPIECE.GAMELOCATION.LOCATIONHIDDEN ?
                            FS.PARENTGROUPLOCATION(obj.SHEETPARENTPIECE) :
                            obj.SHEETPARENTPIECE.GAMELOCATION :
                        obj.GAMELOCATION
                },
                GO.DOMAIN_LOGIC => obj.TYPE switch
                {
                    "ALERT" => new()
                    {
                        obj.INTERCEPTEDGRP.GAMELOCATION ?? FS.TEMPLOC,
                        obj.ATTACKER?.GAMELOCATION ?? obj.INTERCEPTEDGRP.GAMELOCATION ?? FS.TEMPLOC
                    },
                    "PARENTCONNECTION" => new()
                    {
                        obj.GAMEPIECE != null ? new(){x = obj.GAMEPIECE.GAMELOCATION.x + obj.GAMEPIECE.x, y = obj.GAMEPIECE.GAMELOCATION.y + obj.GAMEPIECE.y} : FS.TEMPLOC,
                        obj.GAMEPIECE != null ? new(){x = obj.GAMEPIECE.GAMELOCATION.x + LOGICALPARENT(obj.GAMEPIECE).x, y = obj.GAMEPIECE.GAMELOCATION.y + LOGICALPARENT(obj.GAMEPIECE).y} : FS.TEMPLOC
                    },
                    "AI.LOGICLINK" => new()
                    {
                        obj.LOGIC?.GAMELOCATION ?? FS.TEMPLOC,
                        obj.UNIT?.GAMELOCATION ?? obj.LOGIC?.GAMELOCATION ?? FS.TEMPLOC
                    },
                    _ => new()
                },
                _ => new()
            };
        }
        public static List<GO> TYPELOCATION(GameScenario gs, string type, string p1)
        {
            return gs.TYPE(type, "GAMELOCATIONID", p1);
        }
        public static List<GO> TYPESIDE(GameScenario gs, string type, string p1)
        {
            return gs.TYPE(type, "SIDE", p1);
        }
        public static List<GO> TYPESIDELOCATION(GameScenario gs, string type, string p1, string p2)
        {
            return TYPESIDE(gs, type, p1).Intersect(TYPELOCATION(gs, type, p2)).ToList();
        }
        public static List<string> SIDE_NAMES = new(){
            "SOV",
            "ALLIES"
        };
        public static Dictionary<string, List<string>> ADJACENT_AIR_THEATERS = new(){
            {"NORTHERN", new(){"BALTIC"}},
            {"BALTIC", new(){"NORTHERN", "WESTERNEUROPE"}},
            {"WESTERNEUROPE", new(){"BALTIC", "SOUTHWESTERN"}},
            {"SOUTHWESTERN", new(){"WESTERNEUROPE", "BALKAN"}},
            {"BALKAN", new(){"SOUTHWESTERN", "WESTERNASIA", "PALESTINIAN"}},
            {"WESTERNASIA", new(){"BALKAN", "PERSIANGULF", "PALESTINIAN"}},
            {"PERSIANGULF", new(){"WESTERNASIA", "PALESTINIAN"}},
            {"PALESTINIAN", new(){"BALKAN", "WESTERNASIA", "PERSIANGULF"}}
        };
        public static List<string> AIR_THEATER_NAMES = ADJACENT_AIR_THEATERS.Keys.ToList();
        public static string ENEMY(string side)
        {
            return side == "ALLIES" ? "SOV" : side == "SOV" ? "ALLIES" : "";
        }
        public void SetTrackValue(string track, int value, int numTracks)
        {
            if (numTracks == 2)
            {
                int ones = value % 10;
                GO onesMarker = PIECE(track);
                CHANGELOCATION(onesMarker, track + GO.DELIM + ones + "");

                int tens = value - ones;
                GO tensMarker = PIECE(track + "10");
                CHANGELOCATION(tensMarker, track + "10" + GO.DELIM + tens + "");
            }
            else
            {
                GO onesMarker = PIECE(track);
                CHANGELOCATION(onesMarker, track + GO.DELIM + value + "");
            }
        }
        public override void ProcessCanvasRightClick(double x, double y)
        {
            List<GO> actions = ACTIONS(TYPE("MAP").First());
            if (actions.Any())
            {
                _Window.MapDynamicMenu.Items.Clear();
                foreach (GO action in actions)
                {
                    MenuItem mi = new() { Header = action.ACTION };
                    mi.Click += _Window.MapcmiImg_Click;
                    _Window.MapDynamicMenu.Items.Add(mi);
                }
                _Window.MapDynamicMenu.PlacementTarget = _Window.WORLD_CANVAS;
                _Window.MapDynamicMenu.IsOpen = true;
            }
        }
        public override void ProcessMapMouseMove(double realX, double realY)
        {
        }
        public override void ProcessControlClick(GO marker)
        {
            /*if(marker.GRPTYPE == "TFTGGRP"){
                TOGGLETRAY(marker, GRPSHEET);
            } else if(marker.GRPTYPE == "ACTIVATIONGRP"){
                TOGGLETRAY(marker, ACTIVATIONGRPSHEET);
            } else if(marker.TEMPLATE?.AIRUNITS != null){
                TOGGLETRAY(marker, CVSHEET);
            } else if(marker.PARENTSHEETID != null && TRAYSHEETS.Contains(marker.PARENTSHEET)){
                TOGGLETRAY(marker.PARENTSHEET.SHEETPARENTPIECE, marker.PARENTSHEET);
            } else if(TRAYSHEETS.Contains(marker)){
                TOGGLETRAY(marker.SHEETPARENTPIECE, marker);
            }  */
        }
        public void TOGGLETRAY(GO marker, GO tmpSheet)
        {
            GO DIRECTSHEET = SelectedMarker.PARENTSHEET;
            GO INDIRECTSHEET = null;// SelectedMarker.CARRIER?.PARENTSHEET;
            bool closing = tmpSheet.SHEETPARENTPIECE == marker;
            List<GO> doesNotNeedThisSheet = InteractionMap.Keys.Where(n => n.PARENTSHEET != tmpSheet).ToList();// && n.CARRIER?.PARENTSHEET != tmpSheet).ToList();
            bool markerIsEligible = doesNotNeedThisSheet.Contains(marker);
            List<GO> children = InteractionMap.Keys.Where(n => LOGICALPARENT(n) == marker || LOGICALPARENT(LOGICALPARENT(n)) == marker).ToList();
            if (DIRECTSHEET == tmpSheet || INDIRECTSHEET == tmpSheet)
            {
                if (closing)
                {
                    if (doesNotNeedThisSheet.Any())
                    {
                        SelectedMarker = markerIsEligible ? marker : doesNotNeedThisSheet.First();
                        REMOVEGROUPSHEET(tmpSheet);
                    }
                }
                else
                {
                    if (children.Any())
                    {
                        SelectedMarker = children.First();
                        DISPLAYGROUP(this, marker);
                    }
                    else if (doesNotNeedThisSheet.Any())
                    {
                        SelectedMarker = doesNotNeedThisSheet.First();
                        DISPLAYGROUP(this, marker);
                    }
                }
            }
            else
            {
                if (closing)
                {
                    REMOVEGROUPSHEET(tmpSheet);
                }
                else
                {
                    DISPLAYGROUP(this, marker);
                }
            }
        }
        public override void ProcessMarkerChoiceMenu(GO marker)
        {
            _Window.AIREVIEWMENUGOs.Clear();
            _Window.HideMenu(_Window.MainMenu);
            Menu m = _Window.MarkerChoiceMenu;
            if (marker != null && marker.image != null && CANACTION(marker))
            {
                Image img = marker.image;
                m.Items.Clear();
                MenuItem firstmi = new MenuItem()
                {
                    Header = INFOLINE1(marker),
                    FontWeight = FontWeights.UltraBold,
                    Foreground = Brushes.White,
                    Background = Brushes.Black
                };
                firstmi.Click += _Window.mnuSelectedMarkerInfo_Click;
                m.Items.Add(firstmi);
                if (FS.ORDERS && marker.SIDE == FS.SIDE_MODE)
                {
                    GO actualUnit = marker.TYPE == "DESTINATION" ? marker.GAMEPIECE : marker;
                    GO destinationMarker = marker.TYPE == "DESTINATION" ? marker : marker.DESTINATIONPIECE;
                    string r = actualUnit != null && destinationMarker != null && actualUnit.REMAININGMOVEMENT != destinationMarker.REMAININGMOVEMENT ?
                        actualUnit.REMAININGMOVEMENT + " -> " + destinationMarker.REMAININGMOVEMENT :
                        marker.REMAININGMOVEMENT + "";
                    string hdr = "MP: " + r;
                    if (m.Items.Count > 0)
                    {
                        //m.Items.Add(new Separator() { Foreground = Brushes.White, Background = Brushes.Black});
                    }
                    m.Items.Add(new MenuItem()
                    {
                        Header = hdr,
                        FontWeight = FontWeights.UltraBold,
                        Foreground = Brushes.White,
                        Background = Brushes.Black
                    });
                }
                MENU_MARKERAIINFO(marker, m, "");
                foreach (GO action in ACTIONS(marker))
                {
                    if (m.Items.Count > 0)
                    {
                        m.Items.Add(new Separator());
                    }
                    bool SHOWCHECKBOX = false;
                    bool ISCHECKED = false;
                    string a = action.ACTION;
                    if (a.Contains("|TRUE") || a.Contains("|FALSE"))
                    {
                        SHOWCHECKBOX = true;
                        ISCHECKED = a.Contains("|TRUE");
                        a = ISCHECKED ? a.Replace("|TRUE", "") : a.Replace("|FALSE", "?");
                    }
                    MenuItem mi = new() { Header = a };
                    mi.Click += _Window.MarkercmiImg_Click;
                    mi.IsCheckable = SHOWCHECKBOX;
                    if (SHOWCHECKBOX)
                    {
                        mi.IsChecked = ISCHECKED;
                    }
                    //mi.Foreground = Brushes.White;
                    //mi.Background = Brushes.Black;
                    mi.FontWeight = FontWeights.UltraBold;
                    m.Items.Add(mi);
                }

                _Window.CHOICEMENUGOs.Clear();
                string INDENT = "    ";
                List<GO> all = [.. TYPE("PIECE", "GAMELOCATIONID", marker.GAMELOCATIONID).Where(n => !n.HIDDEN && !marker.GAMELOCATION.HIDDEN && FS.LOGICALPARENT(n) == n)];
                if (all.Count > 0 && marker != null && marker.DOMAIN == GO.DOMAIN_PIECE)
                {
                    m.Items.Add(new MenuItem() { Header = INDENT });
                    m.Items.Add(new MenuItem() { Header = INDENT });
                    //split ships up by present, enroute
                    Dictionary<int, List<GO>> ENROUTETABLE = [];
                    foreach(GO obj in all)
                    {
                        int delay = !obj.DONE && obj.ACTIVATED && obj.UNITCATEGORY == "AIR" ? 0 : obj.ENROUTEDELAY;
                        if (!ENROUTETABLE.ContainsKey(delay))
                        {
                            ENROUTETABLE.Add(delay, []);
                        }
                        ENROUTETABLE[delay].Add(obj);
                    }
                    foreach (int d in ENROUTETABLE.Keys.Order())
                    {
                        List<GO> tmp = ENROUTETABLE[d];
                        m.Items.Add(new MenuItem()
                        {
                            Header = d == 0 ? "IN LOCATION" : "ENROUTE (" + d + " TURNS)",
                            FontWeight = FontWeights.UltraBold,
                            Foreground = Brushes.White,
                            Background = Brushes.Black
                        });
                        List<GO> stackedGOs = [];
                        stackedGOs.AddRange(tmp.Where(n => n.TYPE == "SQN" && n.AIRMISSION == "CAP"));
                        tmp.RemoveAll(stackedGOs.Contains);
                        stackedGOs.AddRange(tmp.Where(n => n.TYPE == "SQN"));
                        tmp.RemoveAll(stackedGOs.Contains);
                        stackedGOs.AddRange(tmp.Where(n => n.UNITCATEGORY == "SURFACE"));
                        tmp.RemoveAll(stackedGOs.Contains);
                        stackedGOs.AddRange(tmp.Where(n => n.UNITCATEGORY == "SUB"));
                        tmp.RemoveAll(stackedGOs.Contains);
                        stackedGOs.AddRange(tmp);
                        //Image img = marker.image;
                        for (int i = 0; i < stackedGOs.Count; i++)
                        {
                            GO obj = stackedGOs[i];
                            if (m.Items.Count > 0)
                            {
                                m.Items.Add(new Separator());
                            }
                            MenuItem mi = new() { Header = (obj.AIRMISSION == "CAP" ? "On CAP : " : "") + INFOLINE1(obj), FontWeight = FontWeights.UltraBold };
                            MENUITEM_SHOWALLEGIENCE(obj, mi);
                            _Window.CHOICEMENUGOs.Add(mi, obj);
                            mi.Click += _Window.StackcmiImg_Click;
                            m.Items.Add(mi);
                            MENU_MARKERAIINFO(obj, m, "");
                            foreach (GO gm in FS.GROUPMEMBERS(obj).Where(n => n != obj))
                            {
                                MenuItem gmi = new() { Header = INDENT + INFOLINE1(gm), FontWeight = FontWeights.UltraBold };
                                MENUITEM_SHOWALLEGIENCE(gm, gmi);
                                _Window.CHOICEMENUGOs.Add(gmi, gm);
                                gmi.Click += _Window.StackcmiImg_Click;
                                m.Items.Add(new Separator());
                                m.Items.Add(gmi);
                                MENU_MARKERAIINFO(gm, m, INDENT);
                                foreach (GO gm2 in FS.GROUPMEMBERS(gm).Where(n => n != gm))
                                {
                                    MenuItem gm2i = new() { Header = INDENT + INDENT + INFOLINE1(gm2), FontWeight = FontWeights.UltraBold };
                                    MENUITEM_SHOWALLEGIENCE(gm2, gm2i);
                                    _Window.CHOICEMENUGOs.Add(gm2i, gm2);
                                    gm2i.Click += _Window.StackcmiImg_Click;
                                    m.Items.Add(new Separator());
                                    m.Items.Add(gm2i);
                                    MENU_MARKERAIINFO(gm2, m, INDENT + INDENT);
                                }
                            }
                        }
                    }
                }
                Canvas.SetLeft(m, _Window.GetHorizontalOffset + 1);
                Canvas.SetTop(m, _Window.GetVerticalOffset + 1);
                _Window.SetDockedMenuZ(m);
            }
            else
            {
                _Window.HideMenu(m);
            }
        }
        public void MENUITEM_SHOWALLEGIENCE(GO obj, MenuItem mi)
        {
            if(FS.SIDE_NAMES.Contains(FS.SIDE_MODE) && obj.SIDE != FS.SIDE_MODE)
            {
                switch (obj.SIDE)
                {
                    case "ALLIES":
                        mi.Foreground = Brushes.White;
                        mi.Background = Brushes.DodgerBlue;
                        break;
                    case "SOV":
                        mi.Foreground = Brushes.White;
                        mi.Background = Brushes.PaleVioletRed;
                        break;
                    default:
                        break;
                }
            }
        }
        public void MENU_MARKERAIINFO(GO obj, Menu m, string INDENT)
        {
            if (FS.AI_REVIEW)
            {
                List<string> statuses = [];
                GO LOGICLINK = obj.GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == obj && n.ACTIVE).FirstOrDefault();
                if (LOGICLINK != null)
                {
                    if (obj.UNITCATEGORY != "AIR" || (obj.ACTIVATED && !obj.DONE))
                    {
                        //statuses.Add("MOV:" + obj.MOVEMENTALLOWANCE); 
                        statuses.Add("MOV:" + obj.MOVEMENTALLOWANCE + " " + FS.INFOLINE1(LOGICLINK.LOGIC));
                    }
                }
                if (obj.UNITCATEGORY == "AIR" && (obj.ACTIVATED || obj.AIRMISSION == "CAP") && !obj.DONE && obj.AIRMISSION != null)
                {
                    statuses.Add(obj.AIRMISSION);
                }
                List<GO> gms = FS.ISGROUP(obj) ? FS.GROUPMEMBERS(obj) : [obj];
                if (gms.Where(n => n.SEARCHMODE || n.ASWPATROLMODE).Any() && FS.LOGICALPARENT(obj) == obj) { statuses.Add("SEARCHING"); }
                if (gms.Where(n => n.LOADING).Any()) { statuses.Add("UN/LOADING"); }
                if (gms.Where(n => n.REPLENISHING).Any()) { statuses.Add("REPLENISHING"); }
                string h = "";
                foreach (string s in statuses)
                {
                    //m.Items.Add(new Separator());
                    h += (h != "" ? "\n" : "") + INDENT + s;
                }
                if (h != "")
                {
                    MenuItem mi = new()
                    {
                        Header = h,
                        FontWeight = FontWeights.UltraBold,
                        Foreground = Brushes.White,
                        Background = Brushes.Gray
                    };
                    m.Items.Add(mi);
                }
            }
            if (GetBoolean("AI.MENUINFO"))
            {
                if (FS.SETUP || FS.ORDERS)
                {
                    foreach (GO link in obj.GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == obj && n.LOGIC.TYPE == "OBJECTIVELOGIC"))
                    {
                        //m.Items.Add(new Separator());
                        MenuItem mi = new()
                        {
                            Header = INDENT + FS.INFOLINE1(link.LOGIC),
                            FontWeight = FontWeights.UltraBold,
                            Foreground = Brushes.White,
                            Background = Brushes.Gray
                        };
                        m.Items.Add(mi);
                        _Window.AIREVIEWMENUGOs.Add(mi, link.LOGIC);
                        mi.Click += _Window.StackcmiImg_Click;
                    }
                }
                if (FS.SETUP || FS.DEPLOYMENT)
                {
                    foreach (GO link in obj.GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == obj && n.LOGIC.TYPE == "DEPLOYMENTLOGIC"))
                    {
                        //m.Items.Add(new Separator());
                        MenuItem mi = new()
                        {
                            Header = INDENT + FS.INFOLINE1(link.LOGIC),
                            FontWeight = FontWeights.UltraBold,
                            Foreground = Brushes.White,
                            Background = Brushes.Gray
                        };
                        m.Items.Add(mi);
                        _Window.AIREVIEWMENUGOs.Add(mi, link.LOGIC);
                        mi.Click += _Window.StackcmiImg_Click;
                    }
                }
                if (FS.SETUP || FS.TRIGGER)
                {
                    foreach (GO link in obj.GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == obj && n.LOGIC.TYPE == "TRIGGERLOGIC"))
                    {
                        //m.Items.Add(new Separator());
                        MenuItem mi = new()
                        {
                            Header = INDENT + FS.INFOLINE1(link.LOGIC),
                            FontWeight = FontWeights.UltraBold,
                            Foreground = Brushes.White,
                            Background = Brushes.Gray
                        };
                        m.Items.Add(mi);
                        _Window.AIREVIEWMENUGOs.Add(mi, link.LOGIC);
                        mi.Click += _Window.StackcmiImg_Click;
                    }
                }
            }
        }
        public override void ProcessMarkerInfoMenu(GO marker)
        {
            Menu m = _Window.MarkerInfoMenu;
            if (marker != null && marker.image != null && marker.DOMAIN == GO.DOMAIN_PIECE)
            {
                Image img = marker.image;
                m.Items.Clear();
                MenuItem mi = new()
                {
                    Header = marker.TYPE switch
                    {
                        "TARGET" => marker.SIDE != null && marker.GAMEPIECE?.ATTACKER != null ? FS.INFOLINE1(marker.GAMEPIECE.ATTACKER, true) : "DEFENSE SHEET ANCHOR",
                        "DESTINATION" => FS.INFOLINE1(marker.GAMEPIECE, true),
                        _ => FS.INFOLINE1(marker, true)
                    },
                    FontWeight = FontWeights.UltraBold
                };
                m.Items.Add(mi);

                Canvas.SetLeft(m, Math.Max(Canvas.GetLeft(img), 1));
                Canvas.SetBottom(m, Math.Max(WorldSize * _Window.MapZoomLevel - Canvas.GetTop(img) + 1, 1));
                Canvas.SetZIndex(m, Canvas.GetZIndex(img) + 1000000);
            }
            else
            {
                _Window.HideMenu(m);
            }
        }
        public override void ProcessSelectedMarkerInfoMenu(GO marker)
        {
            Menu m = _Window.SelectedMarkerInfoMenu;
            if (marker != null && marker.image != null && marker.DOMAIN == GO.DOMAIN_PIECE)
            {
                Image img = marker.image;
                m.Items.Clear();
                MenuItem mi = new()
                {
                    Header = marker.TYPE switch
                    {
                        "TARGET" => marker.SIDE != null && marker.GAMEPIECE?.ATTACKER != null ? FS.INFOLINE1(marker.GAMEPIECE.ATTACKER, true) : "DEFENSE SHEET ANCHOR",
                        "DESTINATION" => FS.INFOLINE1(marker.GAMEPIECE, true),
                        _ => FS.INFOLINE1(marker, true)
                    },
                    FontWeight = FontWeights.UltraBold
                };
                mi.Foreground = Brushes.White;
                mi.Background = Brushes.Black;
                m.Items.Add(mi);

                Canvas.SetLeft(m, Math.Max(Canvas.GetLeft(img), 1));
                Canvas.SetBottom(m, Math.Max(WorldSize * _Window.MapZoomLevel - Canvas.GetTop(img) + 1, 1));
                Canvas.SetZIndex(m, Canvas.GetZIndex(img) + 1000001);
            }
            else
            {
                _Window.HideMenu(m);
            }
        }
        public override void ProcessSelectedMarkerTargetInfoMenu(GO marker)
        {
            Menu m = _Window.SelectedMarkerTargetInfoMenu;
            if (marker != null && marker.image != null && marker.DOMAIN == GO.DOMAIN_PIECE)
            {
                Image img = marker.image;
                m.Items.Clear();
                MenuItem mi = new()
                {
                    Header = marker.TYPE switch
                    {
                        "TARGET" => "*",
                        "DESTINATION" => ">>",
                        _ => FS.INFOLINE1(marker, true)
                    }
                };
                mi.Foreground = Brushes.White;
                mi.Background = Brushes.Black;
                m.Items.Add(mi);

                Canvas.SetLeft(m, Math.Max(Canvas.GetLeft(img), 1));
                Canvas.SetBottom(m, Math.Max(WorldSize * _Window.MapZoomLevel - Canvas.GetTop(img) + 1, 1));
                Canvas.SetZIndex(m, Canvas.GetZIndex(img) + 1000001);
            }
            else
            {
                _Window.HideMenu(m);
            }
        }
        public override void ProcessStackMenu(GO marker)
        {
            if(Canvas.GetZIndex(_Window.OptionsMenu) != MainWindow.Z_HIDDEN){return;}
            _Window.STACKMENUGOs.Clear();
            string INDENT = "    ";
            Menu m = _Window.StackMenu;
            List<GO> all = [.. TYPE("PIECE", "GAMELOCATIONID", marker.GAMELOCATIONID).Where(n => !n.HIDDEN && !marker.GAMELOCATION.HIDDEN && FS.LOGICALPARENT(n) == n)];
            if (all.Count > 0 && marker != null && marker.DOMAIN == GO.DOMAIN_PIECE)
            {
                m.Items.Clear();
                _Window.HideMenu(_Window.OptionsMenu);
                //split ships up by present, enroute
                Dictionary<int, List<GO>> ENROUTETABLE = [];
                foreach (GO obj in all)
                {
                    int delay = !obj.DONE && obj.ACTIVATED && obj.UNITCATEGORY == "AIR" ? 0 : obj.ENROUTEDELAY;
                    if (!ENROUTETABLE.ContainsKey(delay))
                    {
                        ENROUTETABLE.Add(delay, []);
                    }
                    ENROUTETABLE[delay].Add(obj);
                }
                foreach (int d in ENROUTETABLE.Keys.Order())
                {
                    List<GO> tmp = ENROUTETABLE[d];
                    m.Items.Add(new MenuItem()
                    {
                        Header = d == 0 ? "IN LOCATION" : "ENROUTE (" + d + " TURNS)",
                        FontWeight = FontWeights.UltraBold,
                        Foreground = Brushes.White,
                        Background = Brushes.Gray
                    });
                    List<GO> stackedGOs = [];
                    stackedGOs.AddRange(tmp.Where(n => n.TYPE == "SQN" && n.AIRMISSION == "CAP"));
                    tmp.RemoveAll(stackedGOs.Contains);
                    stackedGOs.AddRange(tmp.Where(n => n.TYPE == "SQN"));
                    tmp.RemoveAll(stackedGOs.Contains);
                    stackedGOs.AddRange(tmp.Where(n => n.UNITCATEGORY == "SURFACE"));
                    tmp.RemoveAll(stackedGOs.Contains);
                    stackedGOs.AddRange(tmp.Where(n => n.UNITCATEGORY == "SUB"));
                    tmp.RemoveAll(stackedGOs.Contains);
                    stackedGOs.AddRange(tmp);
                    //Image img = marker.image;
                    for (int i = 0; i < stackedGOs.Count; i++)
                    {
                        GO obj = stackedGOs[i];
                        if (m.Items.Count > 0)
                        {
                            m.Items.Add(new Separator());
                        }
                        MenuItem mi = new() { Header = (obj.AIRMISSION == "CAP" ? "On CAP : " : "") + INFOLINE1(obj), FontWeight = FontWeights.UltraBold };
                        MENUITEM_SHOWALLEGIENCE(obj, mi);
                        _Window.STACKMENUGOs.Add(mi, obj);
                        mi.Click += _Window.StackcmiImg_Click;
                        m.Items.Add(mi);
                        foreach (GO gm in FS.GROUPMEMBERS(obj).Where(n => n != obj))
                        {
                            MenuItem gmi = new() { Header = INDENT + INFOLINE1(gm), FontWeight = FontWeights.UltraBold };
                            MENUITEM_SHOWALLEGIENCE(gm, gmi);
                            _Window.STACKMENUGOs.Add(gmi, gm);
                            gmi.Click += _Window.StackcmiImg_Click;
                            m.Items.Add(new Separator());
                            m.Items.Add(gmi);

                            foreach (GO gm2 in FS.GROUPMEMBERS(gm).Where(n => n != gm))
                            {
                                MenuItem gm2i = new() { Header = INDENT + INDENT + INFOLINE1(gm2), FontWeight = FontWeights.UltraBold };
                                MENUITEM_SHOWALLEGIENCE(gm2, gm2i);
                                _Window.STACKMENUGOs.Add(gm2i, gm2);
                                gm2i.Click += _Window.StackcmiImg_Click;
                                m.Items.Add(new Separator());
                                m.Items.Add(gm2i);
                            }
                        }
                    }
                }
                Canvas.SetRight(m, WorldSize * _Window.MapZoomLevel - (_Window.GetHorizontalOffset + _Window.CANVAS_SCROLL_VIEWER.ViewportWidth) + 1);
                Canvas.SetTop(m, _Window.GetVerticalOffset + 1);
                _Window.SetDockedMenuZ(m);
            }
            else
            {
                _Window.HideMenu(m);
            }
        }
        public override void ProcessStackMenuClick(GO marker)
        {
            bool PIECE = marker.DOMAIN == GO.DOMAIN_PIECE;
            bool inspecting = PIECE && InspectedLocations.Contains(marker.GAMELOCATION);
            bool canInteract = CANINTERACT(marker);
            if (PIECE)
            {
                //treat draggable pieces in DragOver phases differently.  move them to center and require them center before allowing drag
                if (canInteract)
                {
                    SelectedMarker = marker;
                    _Window.ActionContext = ["CLICKED"];
                    _Window.RefreshScenario();
                }
                else
                {
                    _Window.ClickMarker(marker, !inspecting);
                }
            }
        }
        public override void ProcessDoubleLeftClick(GO marker)
        {
            /*if(FS.ISGROUP(marker) || marker.TEMPLATE?.AIRUNITS != null || FS.TRAYSHEETS.Contains(marker.PARENTSHEET) || FS.TRAYSHEETS.Contains(marker)){
                ProcessControlClick(marker);
                _Window.ActionContext = ["CLICKED"];
                _Window.RefreshScenario();
            } else */
            if (marker.DOMAIN == GO.DOMAIN_SHEET && marker != DETAILSHEET)
            {
                _Window.ExpandOrCollapseSheet(marker, !marker.EXPANDED);
                _Window.ActionContext = ["CLICKED"];
                _Window.RefreshScenario();
            }
            else
            {
                ProcessDoubleRightClick(marker);
            }
        }
        public override void ProcessDoubleRightClick(GO marker)
        {
            if (marker == DETAILSHEET || InspectedLocations.Contains(marker.GAMELOCATION))
            {
                REMOVEINSPECTION(marker.GAMELOCATION);
                _Window.ActionContext = ["CLICKED"];
                _Window.RefreshScenario();
            }
            else if (marker.DOMAIN == GO.DOMAIN_PIECE)
            {
                foreach (GO loc in FS.FINDAIRRADIUS(marker.GAMELOCATION, 2).Intersect(InspectedLocations))
                {
                    REMOVEINSPECTION(loc);
                }
                ADDINSPECTION(marker.GAMELOCATION);
                _Window.ActionContext = ["CLICKED"];
                _Window.RefreshScenario();
            }

        }
        public override void PreLoadProcessing()
        {
            foreach (string category in new List<string>(){
                "SIDE",
                "CONNECTORLOCATIONID",
                "GAMELOCATIONID",
                "PARENTSHEETID",
                "CARRIERID",
                "GROUPID",
                "ACTIVATIONGRPID"
            })
            {
                GOCategorizedFields.Add(category);
            }
            foreach (string category in new List<string>(){
                "DOMAIN",
                "TYPE"
            })
            {
                GOTypedFields.Add(category);
            }
            foreach (string category in new List<string>(){
                "DAMAGED",
                "AIRFIELDDAMAGELEVEL",
                "PORTDAMAGELEVEL",
                "EXPANSION",
                "ENROUTEDELAY",
                "SEARCHMODE",
                "ASWPATROLMODE",
                "INTERCEPTMODE",
                "LOITERMODE",
                "DEEPMODE",
                "STRATDETECTED",
                "TACCOORDPIECEID",
                "DOCKED",
                "REPLENISHING",
                "LOADING",
                "DONE",
                "NUMCOMBATS",
                "FUELPTS",
                "TEMPLATEID",
                "IMAGEFILE",
                "NOORDERS"
            })
            {
                GOIndicatorFields.Add(category);
            }
        }
        public override Image GOImage(GO obj, Boolean refreshAll)
        {
            Image img = null;
            Boolean bNew = false;
            if (obj.image != null)
                img = obj.image;
            else if (obj.IMAGEFILENAME != null)
            {
                img = new Image();
                obj.image = img;
                if (obj.DOMAIN == GO.DOMAIN_SHEET || obj.DOMAIN == GO.DOMAIN_PIECE)
                {
                    _Window.AddImageToGame(img);
                    GOImageMap[img] = obj;
                }
                else
                {
                    img.MouseMove += _Window.Img_MouseMove;
                    _Window.WORLD_CANVAS.Children.Add(img);
                }
                bNew = true;
            }
            if (img != null)
            {
                string fn = obj.IMAGEFILENAME;
                double imgWidth = obj.DYNAMICSIZE ? obj.IMAGEWIDTHVALUE : (obj.DOMAIN == GO.DOMAIN_SHEET && !obj.EXPANDED ? obj.MINIMIZEDWIDTHVALUE : obj.IMAGEWIDTHVALUE) * obj.image_ratio;
                if (bNew || refreshAll || img.Width != imgWidth * _Window.MapZoomLevel)
                {
                    if (obj.DYNAMICSIZE)
                    {
                        _Window.SetZoomableImage(img, _Window.GetScenarioImageDir() + "/" + fn, imgWidth, obj.IMAGEHEIGHTVALUE);
                    }
                    else
                    {
                        
                        _Window.SetZoomableImage(img, _Window.GetScenarioImageDir() + "/" + fn, imgWidth);
                    }
                }
            }
            return img;
        }
        protected Dictionary<string, CWRectangleWrapper> BaseRectangleMap = new();
        public override List<CWRectangleWrapper> GORectangles(GO obj)
        {
            //produce a bunch of rectangles based on units status
            List<CWRectangleWrapper> info = new();
            HashSet<string> currentStatusKeys = FS.INDICATORSTATUSES(obj, AI_Sides.Count switch
            {
                1 => FS.ENEMY(AI_Sides.First()),
                _ => SIDE_MODE
            });
            foreach (string baseKey in BaseRectangleMap.Keys.Where(n => currentStatusKeys.Contains(n) || obj.RECTANGLES.ContainsKey(n)))
            {
                Boolean bNew = false;
                CWRectangleWrapper rw = BaseRectangleMap[baseKey];
                CWRectangleWrapper newrw = new();
                newrw.show = currentStatusKeys.Contains(baseKey);
                if (obj.RECTANGLES.ContainsKey(baseKey))
                {
                    newrw.rect = obj.RECTANGLES[baseKey];
                }
                else if (newrw.show)
                {
                    newrw.rect = new Rectangle();
                    newrw.rect.Fill = rw.rect.Fill;
                    newrw.rect.Stroke = rw.rect.Stroke;
                    obj.RECTANGLES[baseKey] = newrw.rect;
                    _Window.AddRectToGame(newrw.rect);
                    bNew = true;
                }
                newrw.x = rw.x;
                newrw.y = rw.y;
                newrw.z = rw.z;
                if (bNew || rw.width * _Window.MapZoomLevel * obj.image_ratio != newrw.rect.Width)
                {
                    newrw.rect.Width = rw.width * _Window.MapZoomLevel * obj.image_ratio;
                    newrw.rect.Height = (rw.height == 0 ? rw.width : rw.height) * _Window.MapZoomLevel * obj.image_ratio;
                    newrw.rect.StrokeThickness = rw.thickness * _Window.MapZoomLevel * obj.image_ratio;
                }
                info.Add(newrw);
            }
            return info;
        }
        public static HashSet<string> INDICATORSTATUSES(GO obj, string VIEWINGSIDE)
        {
            HashSet<string> currentStatusKeys = new();
            if (!obj.DESTROYED && !obj.RECYCLED)
            {
                if (obj.TYPE == "SHIP" || obj.TYPE == "SQN")
                {
                    if (obj.EXPANSION) { currentStatusKeys.Add("EXPANSION"); }
                    if (VIEWINGSIDE.Contains(obj.SIDE ?? "") || FS.AI_REVIEW)
                    {
                        if (obj.DONE) { currentStatusKeys.Add("DONE"); }
                        if (obj.OVERSTACKED) { currentStatusKeys.Add("OVERSTACKED"); }
                        if (obj.DEEPMODE) { currentStatusKeys.Add("DEEPMODE"); }
                        if (obj.ENROUTEDELAY > 0) { currentStatusKeys.Add("ENROUTE"); }
                        if (obj.ASWPATROLMODE || obj.SEARCHMODE) { currentStatusKeys.Add("SEARCH"); }
                        if (obj.NOORDERS) { currentStatusKeys.Add("NOORDERS"); }
                        if (obj.LOITERMODE) { currentStatusKeys.Add("LOITERMODE"); }
                        if (obj.INTERCEPTMODE) { currentStatusKeys.Add("INTERCEPTMODE"); }
                        if (obj.NUMCOMBATS > 1) { currentStatusKeys.Add("ATTACKS2"); }
                        if (obj.NUMCOMBATS > 0) { currentStatusKeys.Add("ATTACKS1"); }
                    }
                    if (VIEWINGSIDE.Contains(FS.ENEMY(obj.SIDE ?? "")) || FS.AI_REVIEW)
                    {
                        if (obj.TACCOORDPIECEID != null) { currentStatusKeys.Add("TACCOORD"); }
                        if (obj.STRATDETECTED) { currentStatusKeys.Add("STRATDETECTED"); }
                        //if(obj.LOCALDETECTED && !obj.STRATDETECTED){currentStatusKeys.Add("LOCALDETECTED");}
                    }
                    if(FS.AI_REVIEW)
                    {
                        if ((obj.LOCALDETECTED && !obj.STRATDETECTED) || obj.ADMINDETECTED) { currentStatusKeys.Add("LOCALDETECTED"); }
                    }
                    if (obj.DOCKED) { currentStatusKeys.Add("DOCKED"); }
                    if (obj.REPLENISHING || obj.LOADING) { currentStatusKeys.Add("REPLENISHING"); }
                    if (obj.AIRMISSION == "CAP")
                    {
                        currentStatusKeys.Add("CAP");
                        if (obj.NUMCOMBATS > 1) { currentStatusKeys.Add("ATTACKS2"); }
                        if (obj.NUMCOMBATS > 0) { currentStatusKeys.Add("ATTACKS1"); }
                    }
                    if (obj.GRPTYPE == "ACTIVATIONGRP")
                    {
                        currentStatusKeys.Add("ACT_0_" + obj.SIDE);
                        currentStatusKeys.Add("ACT_1_" + obj.SIDE);
                        currentStatusKeys.Add("ACT_2_" + obj.SIDE);
                        currentStatusKeys.Add("ACT_3_" + obj.SIDE);
                    }
                    if (obj.GRPTYPE == "TFTGGRP")
                    {
                        currentStatusKeys.Add("GRP_0_" + obj.SIDE);
                        currentStatusKeys.Add("GRP_1_" + obj.SIDE);
                        currentStatusKeys.Add("GRP_2_" + obj.SIDE);
                        currentStatusKeys.Add("GRP_3_" + obj.SIDE);
                    }
                }
                else if (obj.TYPE == "FACILITY")
                {
                    if (obj.PORT)
                    {
                        for (int i = 1; i <= 4; i++)
                        {
                            if (obj.PORTDAMAGELEVEL >= i) { currentStatusKeys.Add("PORTDAMAGE" + i); }
                        }
                    }
                    if (obj.AIRFIELD)
                    {
                        for (int i = 1; i <= 4; i++)
                        {
                            if (obj.AIRFIELDDAMAGELEVEL >= i) { currentStatusKeys.Add("AIRFIELDDAMAGE" + i); }
                        }
                    }
                }
                else if (obj.TYPE == "CLOSEDEFENSE")
                {
                    for (int i = 1; i <= 4; i++)
                    {
                        if (obj.CLOSEDEFENSEDAMAGELEVEL >= i) { currentStatusKeys.Add("CLOSEDEFENSEDAMAGE" + i); }
                    }
                }
            }
            return currentStatusKeys;
        }
        public static void SHOWBORDER(GameScenario GS, GO obj, Boolean show)
        {
            if (show || obj.lineIndicator2 != null)
            {
                Line l = GS.GetLine2(obj, false);
                //l.Stroke = colorMap[typecolorkey];
                Canvas.SetZIndex(l, show ? MainWindow.Z_BORDER_INDICATOR : MainWindow.Z_HIDDEN);
            }
        }
        public static Boolean CANSTACK(GameScenario GS, GO location, List<GO> units)
        {
            if (!units.Any()) { return true; }
            int stackingLimit = 0;
            return units.Distinct().Sum(n => n.STEPS) <= stackingLimit;
        }
        public static List<FSMovement> GENERATECONNECTIONS(GO fromLoc)
        {
            List<FSMovement> movements = new();
            fromLoc.GS.CONNECTIONS(fromLoc.ID, null).ForEach(
                n => movements.Add(GENERATEMOVEMENT(n[0], n[1]))
            );
            return movements;
        }
        public static List<FSMovement> GENERATESEAMOVEMENTCONNECTIONS(GO fromLoc)
        {
            List<FSMovement> movements = new();
            foreach (GO connector in fromLoc.GS.TYPE("UNITMOVEMENT", "CONNECTORLOCATIONID", fromLoc.ID).Where(n => n.TERRAIN == "SEA" || n.TERRAIN == "COASTAL"))
            {
                movements.Add(GENERATEMOVEMENT(connector, connector.CONNECTORLOCATION2));
            }
            return movements;
        }
        public static FSMovement GENERATEMOVEMENT(GO connector, GO toLoc)
        {
            if (connector == null || toLoc == null)
            {
                return null;
            }
            return new FSMovement()
            {
                MOVEMENTCONNECTORID = connector.ID,
                MOVEMENTCONNECTOR = connector,
                MOVEMENTLOCATIONID = toLoc.ID,
                MOVEMENTLOCATION = toLoc
            };
        }
        public static List<FSMovement> GENERATESEALOGISTICALCONNECTIONS(GO fromLoc)
        {
            List<FSMovement> movements = new();
            foreach (GO connector in fromLoc.GS.TYPE("LOGISTICAL", "CONNECTORLOCATIONID", fromLoc.ID).Where(n => n.LOGSEA))
            {
                movements.Add(GENERATEMOVEMENT(connector, connector.CONNECTORLOCATION2));
            }
            return movements;
        }
        public static List<FSMovement> GENERATELANDLOGISTICALCONNECTIONS(GO fromLoc)
        {
            List<FSMovement> movements = new();
            foreach (GO connector in fromLoc.GS.TYPE("LOGISTICAL", "CONNECTORLOCATIONID", fromLoc.ID).Where(n => n.LOGLAND))
            {
                movements.Add(GENERATEMOVEMENT(connector, connector.CONNECTORLOCATION2));
            }
            return movements;
        }
        private void SetConfigs()
        {
            FS.LANDWAR = GetBoolean("_CONFIG_ENABLE_LAND_COMBAT");
            FS.GARRISONWAR = GetBoolean("_CONFIG_ENABLE_GARRISON_COMBAT");
            FS.LANDCOMBATSIZE = Math.Max(1, GetDouble("_CONFIG_LAND_COMBAT_SIZE"));
            FS.LANDTRANSFERSIZE = Math.Max(1, GetDouble("_CONFIG_LAND_TRANSFER_SIZE"));
            FS.LANDSUPPLYSIZE = Math.Max(1, Math.Floor(FS.LANDCOMBATSIZE * .10));
            FS.SURFACEREALTIMEDETECTION = GetBoolean("_CONFIG_ENABLE_SURFACE_REALTIME_DETECTION");
            FS.SUBREALTIMEDETECTION = GetBoolean("_CONFIG_ENABLE_SUB_REALTIME_DETECTION");
            FS.COMBINEDATTACKS = GetBoolean("_CONFIG_ENABLE_COMBINED_COMBAT");
            FS.AIRSURFACEINTERACTION = GetBoolean("_CONFIG_ENABLE_SURFACE_VS_AIR_INTERRACTION");
            FS.STRATEGICMINING = GetBoolean("_CONFIG_STRATEGIC_PHASE_MINING");
            FS.STRATEGICTACCOORD = GetBoolean("_CONFIG_STRATEGIC_PHASE_TACCOORD");
            FS.SHOWAILOGIC = GetBoolean("AI.LOGICLINKLINES");
            AI_Sides.Clear();
            foreach(string s in FS.SIDE_NAMES.Where(n => Get("AI." + n) != null && Get("AI." + n) != "NONE"))
            {
                AI_Sides.Add(s);
            }
            AI_Behavior.Clear();
            foreach(string s in AI_Sides)
            {
                AI_Behavior[s] = Get("AI." + s);
            }
        }
        public override void PostLoadProcessing()
        {
            SetConfigs();
            FS.TEMPLOC = LOCATION("TEMP");
            FS.GRPSHEET = SHEET("GROUPTRAY");
            FS.DETAILSHEET = SHEET("DETAILTRAY");
            FS.CVSHEET = SHEET("CVTRAY");
            FS.ACTIVATIONGRPSHEET = SHEET("ACTIVATIONTRAY");
            FS.SETUPSHEET = SHEET("SETUPTRAY");
            FS.DEFENDSHEET = SHEET("DEFENDTRAY");
            FS.DEFENDSHEET.SHEETPARENTPIECE = PIECE("ACTION.TARGET");
            FS.TRAYSHEETS = new() { FS.GRPSHEET, FS.ACTIVATIONGRPSHEET, FS.CVSHEET };
            FS.TMPSHEETS = new() { FS.SETUPSHEET, FS.DEFENDSHEET };
            FS.STRATAIRSHEETS = TYPE("STRATEGICAIRTRAY");
            FS.FACILITYTEMPLATES = new(){
                PIECE("ALLIES.PORT.AIRFIELD"),
                PIECE("SOV.PORT.AIRFIELD"),
                PIECE("NEUT.PORT.AIRFIELD"),
                PIECE("ALLIES.PORT"),
                PIECE("SOV.PORT"),
                PIECE("NEUT.PORT"),
                PIECE("ALLIES.AIRFIELD"),
                PIECE("SOV.AIRFIELD"),
                PIECE("NEUT.AIRFIELD"),
            };
            FS.CLOSEDEFENSETEMPLATES = new(){
                PIECE("ALLIES.CLOSEDEFENSE"),
                PIECE("SOV.CLOSEDEFENSE"),
                PIECE("NEUT.CLOSEDEFENSE")
            };
            FS.FLAGTEMPLATES = new(){
                PIECE("FLAG.ALLIES.ALLIES"),
                PIECE("FLAG.ALLIES.SOV"),
                PIECE("FLAG.ALLIES.NEUT"),
                PIECE("FLAG.NEUT.NEUT"),
                PIECE("FLAG.SOV.SOV"),
                PIECE("FLAG.SOV.ALLIES"),
                PIECE("FLAG.SOV.NEUT"),
            };
            FS.FAILURETEMPLATES = new(){
                PIECE("ALLIES.FAILURE"),
                PIECE("SOV.FAILURE")
            };
            FS.OBJECTIVETEMPLATES = new(){
                PIECE("ALLIES.OBJECTIVE"),
                PIECE("SOV.OBJECTIVE")
            };
            FS.OBJECTIVELOGICTEMPLATES = new(){
                PIECE("ALLIES.OBJECTIVELOGIC"),
                PIECE("SOV.OBJECTIVELOGIC")
            };
            FS.DEPLOYMENTLOGICTEMPLATES = new(){
                PIECE("ALLIES.DEPLOYMENTLOGIC"),
                PIECE("SOV.DEPLOYMENTLOGIC")
            };
            FS.TRIGGERLOGICTEMPLATES = new(){
                PIECE("ALLIES.TRIGGERLOGIC"),
                PIECE("SOV.TRIGGERLOGIC")
            };
            FS.STRATEGICCOUNTRIES.Add("ALL", new());
            foreach (string map in FS.THEATERS.Keys)
            {
                List<string> countries = Get("_CONFIG_" + map + "_STRATEGIC_COUNTRIES").Split('|').ToList();
                FS.STRATEGICCOUNTRIES.Add(map, countries);
                FS.STRATEGICCOUNTRIES["ALL"].AddRange(countries);
            }
            foreach (GO sheet in new List<GO>() { FS.GRPSHEET, FS.ACTIVATIONGRPSHEET, FS.CVSHEET, FS.DETAILSHEET })
            {
                FS.REMOVEGROUPSHEET(sheet);

            }
            //for any sheet, set z
            foreach (GO sheet in SHEETS())
            {
                sheet.z = sheet.ZCOORD;
                if (sheet.GAMELOCATIONID != "TEMP")
                {
                    if (sheet == FS.DEFENDSHEET) { sheet.EXPANDED = true; }
                }
            }
            //for any location not on a sheet, assign x and y
            //for any location on a sheet, set x y and z
            foreach (GO loc in LOCATIONS().Where(n => n.PARENTSHEETID == null))
            {
                if (loc.PARENTMAPID != null)
                {
                    loc.x = loc.PARENTMAP.XCOORD + loc.XCOORD;
                    loc.y = loc.PARENTMAP.YCOORD + loc.YCOORD;
                    loc.z = loc.PARENTMAP.ZCOORD;
                }
                else
                {
                    loc.x = loc.XCOORD;
                    loc.y = loc.YCOORD;
                    loc.HIDDEN = loc.LOCATIONHIDDEN;
                }
            }
            foreach (GO loc in LOCATIONS().Where(n => n.PARENTSHEETID != null))
            {
                loc.x = loc.PARENTSHEET.GAMELOCATION.x + loc.XCOORD - loc.PARENTSHEET.IMAGEWIDTHVALUE * 0.5;
                loc.y = loc.PARENTSHEET.GAMELOCATION.y + loc.YCOORD - loc.PARENTSHEET.IMAGEHEIGHTVALUE * 0.5;
                loc.z = loc.PARENTSHEET.ZCOORD;
                loc.HIDDEN = !loc.PARENTSHEET.EXPANDED;
            }
            /*foreach(GO conn in CONNECTORS().Where(n => n.ALWAYSSHOW)){
                conn.MakeLineVisible(conn.TYPE.Contains("SEA") ? "LIGHTBLUE" : "WHITE");
                //if(conn.CONNECTORLOCATION.SIDE != null && conn.CONNECTORLOCATION2.SIDE != null && conn.CONNECTORLOCATION.SIDE != conn.CONNECTORLOCATION2.SIDE){
                //    SHOWBORDER(this, conn, true);
                //}
            }*/
            foreach (string s in new List<string> { "OBJECTIVE", "TARGET", "DESTINATION", "FACILITY", "POSSESSIONFLAG", "CLOSEDEFENSE", "OBJECTIVELOGIC", "DEPLOYMENTLOGIC" })
            {
                TYPE(s).Where(n => n.GAMELOCATIONID != null).ToList().ForEach(ShuffleMarkerToBottom);
            }
            /*//for any object without a history, give it a default history with its current GL
            foreach(GameObject obj in GameObjects()){
                if((obj.DOMAIN == GameObject.DOMAIN_PIECE || obj.DOMAIN == GameObject.DOMAIN_SHEET) && !HISTORIES(obj.ID).Any()){
                    SETMOVEMENTHISTORY(obj, obj.GAMELOCATIONID);
                }
            }*/
            //create dictionary metadata
            double rectangleWidth = MarkerSize * 0.125;
            CWRectangleWrapper rw = new();
            rw.width = rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Black;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("EXPANSION", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 6 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Black;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Yellow;
            BaseRectangleMap.Add("ENROUTE", rw);

            rw = new();
            rw.width = 8 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = Brushes.DarkBlue;
            BaseRectangleMap.Add("SEARCH", rw);

            rw = new();
            rw.width = 8 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = Brushes.LightGray;
            BaseRectangleMap.Add("LOITERMODE", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 6 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Black;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Red;
            BaseRectangleMap.Add("OVERSTACKED", rw);

            rw = new();
            rw.width = 1.5 * rectangleWidth;
            rw.x = 0.5 * rectangleWidth;
            rw.y = 0.75 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("DEEPMODE", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.height = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Gray;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Gray;
            BaseRectangleMap.Add("LOCALDETECTED", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.height = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("STRATDETECTED", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Black;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("TACCOORD", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 6 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Gray;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("DOCKED", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Gray;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("REPLENISHING", rw);

            rw = new();
            rw.width = 8 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = Brushes.LightSkyBlue;
            BaseRectangleMap.Add("CAP", rw);

            rw = new();
            rw.width = 8 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = Brushes.Red;
            BaseRectangleMap.Add("INTERCEPTMODE", rw);

            rw = new();
            rw.width = 8 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = Brushes.Yellow;
            BaseRectangleMap.Add("NOORDERS", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 6 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.Red;
            BaseRectangleMap.Add("ATTACKS1", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 5 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.Red;
            BaseRectangleMap.Add("ATTACKS2", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Black;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.Red;
            BaseRectangleMap.Add("DONE", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 2 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("PORTDAMAGE1", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("PORTDAMAGE2", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 2 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("PORTDAMAGE3", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("PORTDAMAGE4", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 4 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("AIRFIELDDAMAGE1", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 5 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("AIRFIELDDAMAGE2", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 4 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("AIRFIELDDAMAGE3", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 5 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("AIRFIELDDAMAGE4", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("CLOSEDEFENSEDAMAGE1", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 4 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("CLOSEDEFENSEDAMAGE2", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("CLOSEDEFENSEDAMAGE3", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 4 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = Brushes.Black;
            BaseRectangleMap.Add("CLOSEDEFENSEDAMAGE4", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.DarkGreen;
            BaseRectangleMap.Add("ACT_0_ALLIES", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 7 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.DarkGreen;
            BaseRectangleMap.Add("ACT_1_ALLIES", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.DarkGreen;
            BaseRectangleMap.Add("ACT_2_ALLIES", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 7 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.DarkGreen;
            BaseRectangleMap.Add("ACT_3_ALLIES", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.Red;
            BaseRectangleMap.Add("ACT_0_SOV", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 7 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.Red;
            BaseRectangleMap.Add("ACT_1_SOV", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.Red;
            BaseRectangleMap.Add("ACT_2_SOV", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 7 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.Red;
            BaseRectangleMap.Add("ACT_3_SOV", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("GRP_0_ALLIES", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 7 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("GRP_1_ALLIES", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("GRP_2_ALLIES", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 7 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("GRP_3_ALLIES", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("GRP_0_SOV", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 7 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("GRP_1_SOV", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("GRP_2_SOV", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 7 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = Brushes.White;
            rw.thickness = 1;
            rw.z = 3;
            rw.rect.Fill = Brushes.White;
            BaseRectangleMap.Add("GRP_3_SOV", rw);
        }
        public override Boolean CANACTION(GO obj)
        {
            return ACTIONS(obj).Count > 0;
        }
        public override Boolean CANDRAG(GO obj)
        {
            return DRAGTARGETS(obj).Count > 0 || (obj.DOMAIN == GO.DOMAIN_SHEET && obj != DETAILSHEET);
        }
        public override List<GO> DRAGTARGETS(GO obj)
        {
            if (InteractionMap.ContainsKey(obj) && InteractionMap[obj].Any())
            {
                return new(InteractionMap[obj]);
            }
            else if (obj.TYPE == "STRATEGICAIRTRAY")
            {
                return TYPE("HEX").Where(n => n.ZONE == obj.ZONE).ToList();
            }
            else
            {
                return new();
            }
        }
        public static List<FSMovement> FINDDIRECTMOVEMENTPATH(GameScenario gs, GO startLoc, GO endLoc)
        {
            double left = Math.Min(startLoc.x, endLoc.x);
            double right = Math.Max(startLoc.x, endLoc.x);
            if (left == right)
            {
                List<GO> connectedHexes = gs.CONNECTIONS(startLoc.ID, "ALLIES").Select(n => n[1]).ToList();
                left = connectedHexes.Min(n => n.x);
                right = connectedHexes.Max(n => n.x);
            }
            double top = Math.Min(startLoc.y, endLoc.y);
            double bottom = Math.Max(startLoc.y, endLoc.y);
            List<GO> validHexes = gs.TYPE("HEX").Where(n => n.x >= left && n.x <= right && n.y >= top && n.y <= bottom).ToList();
            return FINDMOVEMENTPATH(gs, startLoc, endLoc, validHexes);
        }
        public static List<FSMovement> FINDMOVEMENTPATH(GameScenario gs, GO startHex, GO endHex, List<GO> validHexes)
        {
            Dictionary<string, List<FSMovement>> movementPathMap = new();
            FSMovement startMovement = new()
            {
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            List<List<FSMovement>> movementPaths = new() { new() { startMovement } };
            while (movementPaths.Count > 0)
            {
                List<List<FSMovement>> newMovementPaths = new();
                foreach (List<FSMovement> movementPath in movementPaths)
                {
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    foreach (FSMovement nextMovement in FS.GENERATECONNECTIONS(from).Where(n =>
                                                                                !hexPath.Contains(n.MOVEMENTLOCATION) &&
                                                                                validHexes.Contains(n.MOVEMENTLOCATION)))
                    {
                        GO to = nextMovement.MOVEMENTLOCATION;
                        int newCost = movementPath.Count + 1;
                        Boolean lowestCostToThisHex = true;
                        if (movementPathMap.ContainsKey(to.ID))
                        {
                            int shortestCost = movementPathMap[to.ID].Count;
                            lowestCostToThisHex = newCost < shortestCost;
                        }
                        if (!lowestCostToThisHex) { continue; }
                        List<FSMovement> newMovementPath = new(movementPath) { nextMovement };
                        movementPathMap[to.ID] = newMovementPath;
                        newMovementPaths.Add(newMovementPath);
                    }
                }
                movementPaths = newMovementPaths;
            }
            if (movementPathMap.ContainsKey(endHex.ID))
            {
                return movementPathMap[endHex.ID];
            }
            else
            {
                return new();
            }
        }
        private static Dictionary<GO, Dictionary<int, List<GO>>> RADIUSTABLE = new();
        public static List<GO> FINDAIRRADIUS(GO startHex, int radius)
        {
            if (startHex.TYPE != "HEX" && !startHex.AIRFIELD) { return new(); }
            if (!RADIUSTABLE.ContainsKey(startHex)) { RADIUSTABLE.Add(startHex, new()); }
            if (!RADIUSTABLE[startHex].ContainsKey(radius)) { RADIUSTABLE[startHex].Add(radius, new()); }
            List<GO> radiusHexes = RADIUSTABLE[startHex][radius];
            if (radiusHexes.Any()) { return new(radiusHexes); }
            radiusHexes.Add(startHex);
            Dictionary<string, List<FSMovement>> movementPathMap = new();
            FSMovement startMovement = new()
            {
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            List<List<FSMovement>> movementPaths = new() { new() { startMovement } };
            while (movementPaths.Count > 0)
            {
                List<List<FSMovement>> newMovementPaths = new();
                foreach (List<FSMovement> movementPath in movementPaths)
                {
                    if (movementPath.Sum(n => n.DISTANCE) >= radius) { continue; }
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    foreach (FSMovement nextMovement in FS.FINDAIRMOVEMENTS(from).Where(n =>
                                                                                !hexPath.Contains(n.MOVEMENTLOCATION) &&
                                                                                !radiusHexes.Contains(n.MOVEMENTLOCATION)))
                    {
                        GO to = nextMovement.MOVEMENTLOCATION;
                        int newCost = movementPath.Sum(n => n.DISTANCE) + nextMovement.DISTANCE;
                        if (newCost > radius) { continue; }
                        Boolean lowestCostToThisHex = true;
                        if (movementPathMap.ContainsKey(to.ID))
                        {
                            int shortestCost = movementPathMap[to.ID].Sum(n => n.DISTANCE);
                            lowestCostToThisHex = newCost < shortestCost;
                        }
                        if (!lowestCostToThisHex) { continue; }
                        List<FSMovement> newMovementPath = new(movementPath) { nextMovement };
                        movementPathMap[to.ID] = newMovementPath;
                        newMovementPaths.Add(newMovementPath);
                        radiusHexes.Add(to);
                    }
                }
                movementPaths = newMovementPaths;
            }
            return new(radiusHexes);
        }
        public static List<FSMovement> FINDAIRMOVEMENTPATH(GO startHex, GO endHex)
        {
            GameScenario gs = startHex.GS;
            FSMovement startMovement = new()
            {
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            if (startHex == endHex) { return new() { startMovement }; }
            int distanceToEnd = 0;
            if (FS.THEATERS[startHex.ORGLEVEL1] != FS.THEATERS[endHex.ORGLEVEL1])
            {
                //if these are in different theaters, one of these locations must be 1 hop from other theater
                bool startConnectsToOtherTheater = FS.GENERATECONNECTIONS(startHex).Where(n => FS.THEATERS[n.MOVEMENTLOCATION.ORGLEVEL1] == FS.THEATERS[endHex.ORGLEVEL1]).Any();
                bool endConnectsToOtherTheater = FS.GENERATECONNECTIONS(endHex).Where(n => FS.THEATERS[n.MOVEMENTLOCATION.ORGLEVEL1] == FS.THEATERS[startHex.ORGLEVEL1]).Any();
                if (!startConnectsToOtherTheater && !endConnectsToOtherTheater)
                {
                    return new();
                }
            }
            List<FSMovement> directPath = FINDAIRMOVEMENTDIRECTPATH(startHex, endHex, 0);
            if (directPath.Any()) { return directPath; }

            Dictionary<string, List<FSMovement>> movementPathMap = new();
            List<List<FSMovement>> movementPaths = new() { new() { startMovement } };
            while (movementPaths.Count > 0)
            {
                List<List<FSMovement>> newMovementPaths = new();
                foreach (List<FSMovement> movementPath in movementPaths)
                {
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    foreach (FSMovement nextMovement in FINDAIRMOVEMENTS(from).Where(n =>
                                                                                !hexPath.Contains(n.MOVEMENTLOCATION)))
                    {
                        GO to = nextMovement.MOVEMENTLOCATION;
                        int newCost = movementPath.Sum(n => n.DISTANCE) + nextMovement.DISTANCE;
                        if (distanceToEnd > 0 && newCost >= distanceToEnd) { continue; }
                        if (to == endHex)
                        {
                            distanceToEnd = distanceToEnd == 0 ? newCost : Math.Min(distanceToEnd, newCost);
                        }
                        Boolean lowestCostToThisHex = true;
                        if (movementPathMap.ContainsKey(to.ID))
                        {
                            int shortestCost = movementPathMap[to.ID].Sum(n => n.DISTANCE);
                            lowestCostToThisHex = newCost < shortestCost;
                        }
                        if (!lowestCostToThisHex) { continue; }
                        List<FSMovement> newMovementPath = new(movementPath) { nextMovement };
                        movementPathMap[to.ID] = newMovementPath;
                        newMovementPaths.Add(newMovementPath);
                    }
                }
                movementPaths = newMovementPaths;
            }
            if (movementPathMap.ContainsKey(endHex.ID))
            {
                return movementPathMap[endHex.ID];
            }
            else
            {
                return new();
            }
        }
        private static List<FSMovement> FINDAIRMOVEMENTDIRECTPATH(GO startHex, GO endHex, int maxDistance)
        {
            GameScenario gs = startHex.GS;
            FSMovement startMovement = new()
            {
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            if (startHex == endHex) { return new() { startMovement }; }
            List<List<FSMovement>> movementPaths = new() { new() { startMovement } };
            while (movementPaths.Count > 0)
            {
                List<List<FSMovement>> newMovementPaths = new();
                foreach (List<FSMovement> movementPath in movementPaths)
                {
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    FSMovement nextMovement =
                    FINDAIRMOVEMENTS(from)
                        .Where(n => !hexPath.Contains(n.MOVEMENTLOCATION))
                        .OrderBy(n => gs.GetDistance(n.MOVEMENTLOCATION, endHex.x, endHex.y)).FirstOrDefault();

                    if (nextMovement == null) { return new(); }
                    GO to = nextMovement.MOVEMENTLOCATION;
                    List<FSMovement> newMovementPath = new(movementPath) { nextMovement };
                    newMovementPaths.Add(newMovementPath);
                    if (newMovementPath.Sum(n => n.DISTANCE) > maxDistance && maxDistance > 0)
                    {
                        return new();
                    }
                    if (to == endHex)
                    {
                        return newMovementPath;
                    }
                }
                movementPaths = newMovementPaths;
            }
            return new();
        }
        public static List<FSMovement> FINDAUTOSEAMOVEMENTPATH(GO obj, GO startHex, GO endHex)
        {
            GameScenario gs = startHex.GS;
            if (startHex == endHex) { return new() { new()
            {
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            } }; }
            double[] linePtA = [startHex.x, startHex.y];
            double[] linePtB = [endHex.x, endHex.y];
            Dictionary<string, List<FSMovement>> pathMapFROM = new();
            Dictionary<string, double> straightLineMapFROM = new();
            List<List<FSMovement>> movementPathsFROM = new() { new() { new()
            {
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            }}};
            Dictionary<string, List<FSMovement>> pathMapTO = new();
            Dictionary<string, double> straightLineMapTO = new();
            List<List<FSMovement>> movementPathsTO = new() { new() { new()
            {
                MOVEMENTLOCATIONID = endHex.ID,
                MOVEMENTLOCATION = endHex
            }}};
            List<string> INTERSECT = [];
            int FROMDistance = 0;
            int TODistance = 0;
            while (movementPathsFROM.Count > 0 || movementPathsTO.Count > 0)
            {
                //FROM
                List<List<FSMovement>> newMovementPaths = new();
                foreach (List<FSMovement> movementPath in movementPathsFROM.Where(n => !pathMapTO.ContainsKey(n.Last().MOVEMENTLOCATIONID)))
                {
                    if(FROMDistance > 0 && movementPath.Sum(n => n.DISTANCE) >= FROMDistance) { continue; }
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    List<FSMovement> nextMovements = obj.UNITCATEGORY switch
                    {
                        "SUB" => FS.FINDSUBMOVEMENTS(obj, from, true),
                        "SURFACE" => FS.FINDSURFACEMOVEMENTS(obj, from, true),
                        _ => new()
                    };
                    foreach (FSMovement nextMovement in nextMovements.Where(n => !hexPath.Contains(n.MOVEMENTLOCATION)))
                    {
                        GO to = nextMovement.MOVEMENTLOCATION;
                        int newCost = movementPath.Sum(n => n.DISTANCE) + nextMovement.DISTANCE;
                        double newStraightLine = 0;
                        Boolean lowestCostToThisHex = true;
                        if (pathMapFROM.ContainsKey(to.ID))
                        {
                            int shortestCost = pathMapFROM[to.ID].Sum(n => n.DISTANCE);
                            if (shortestCost >= newCost)
                            {
                                string challenger = string.Join('|', [.. hexPath.Select(n => n.ID)]) + "|" + to.ID;
                                string incumbent = string.Join('|', [.. pathMapFROM[to.ID].Select(n => n.MOVEMENTLOCATIONID)]);
                                newStraightLine = movementPath.Sum(n => FS.LineToPointDistance2D(linePtA, linePtB, [n.MOVEMENTLOCATION.x, n.MOVEMENTLOCATION.y]));
                                double shortestStraightLine = straightLineMapFROM[to.ID];
                                lowestCostToThisHex = newCost < shortestCost || newStraightLine < shortestStraightLine;
                            }
                            else
                            {
                                lowestCostToThisHex = false;
                            }
                        }
                        else
                        {
                            newStraightLine = movementPath.Sum(n => FS.LineToPointDistance2D(linePtA, linePtB, [n.MOVEMENTLOCATION.x, n.MOVEMENTLOCATION.y]));
                        }
                        if (!lowestCostToThisHex) { continue; }
                        List<FSMovement> newMovementPath = new(movementPath) { nextMovement };
                        pathMapFROM[to.ID] = newMovementPath;
                        straightLineMapFROM[to.ID] = newStraightLine;
                        newMovementPaths.Add(newMovementPath);
                        if(to == endHex)
                        {
                            return newMovementPath;
                        }
                        if (pathMapTO.ContainsKey(to.ID))
                        {
                            TODistance = pathMapTO[to.ID].Sum(n => n.DISTANCE);
                            FROMDistance = newMovementPath.Sum(n => n.DISTANCE);
                        }
                    }
                }
                movementPathsFROM = newMovementPaths;
                //TO
                newMovementPaths = new();
                foreach (List<FSMovement> movementPath in movementPathsTO.Where(n => !pathMapFROM.ContainsKey(n.Last().MOVEMENTLOCATIONID)))
                {
                    if (TODistance > 0 && movementPath.Sum(n => n.DISTANCE) >= TODistance) { continue; }
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    List<FSMovement> nextMovements = obj.UNITCATEGORY switch
                    {
                        "SUB" => FS.FINDSUBMOVEMENTS(obj, from, true),
                        "SURFACE" => FS.FINDSURFACEMOVEMENTS(obj, from, true),
                        _ => new()
                    };
                    foreach (FSMovement nextMovement in nextMovements.Where(n => !hexPath.Contains(n.MOVEMENTLOCATION)))
                    {
                        GO to = nextMovement.MOVEMENTLOCATION;
                        int newCost = movementPath.Sum(n => n.DISTANCE) + nextMovement.DISTANCE;
                        double newStraightLine = 0;
                        Boolean lowestCostToThisHex = true;
                        if (pathMapTO.ContainsKey(to.ID))
                        {
                            int shortestCost = pathMapTO[to.ID].Sum(n => n.DISTANCE);
                            if (shortestCost >= newCost)
                            {
                                string challenger = string.Join('|', [.. hexPath.Select(n => n.ID)]) + "|" + to.ID;
                                string incumbent = string.Join('|', [.. pathMapTO[to.ID].Select(n => n.MOVEMENTLOCATIONID)]);
                                newStraightLine = movementPath.Sum(n => FS.LineToPointDistance2D(linePtA, linePtB, [n.MOVEMENTLOCATION.x, n.MOVEMENTLOCATION.y]));
                                double shortestStraightLine = straightLineMapTO[to.ID];
                                lowestCostToThisHex = newCost < shortestCost || newStraightLine < shortestStraightLine;
                            }
                            else
                            {
                                lowestCostToThisHex = false;
                            }
                        }
                        else
                        {
                            newStraightLine = movementPath.Sum(n => FS.LineToPointDistance2D(linePtA, linePtB, [n.MOVEMENTLOCATION.x, n.MOVEMENTLOCATION.y]));
                        }
                        if (!lowestCostToThisHex) { continue; }
                        List<FSMovement> newMovementPath = [.. movementPath];
                        FSMovement lastMovement = newMovementPath.Last();
                        newMovementPath.Remove(lastMovement);
                        newMovementPath.Add(new()
                        {
                            MOVEMENTLOCATIONID = lastMovement.MOVEMENTLOCATIONID,
                            MOVEMENTLOCATION = lastMovement.MOVEMENTLOCATION,
                            MOVEMENTCONNECTORID = nextMovement.MOVEMENTCONNECTORID,
                            MOVEMENTCONNECTOR = nextMovement.MOVEMENTCONNECTOR,
                            DISTANCE = nextMovement.DISTANCE
                        });
                        newMovementPath.Add(nextMovement);
                        nextMovement.MOVEMENTCONNECTORID = null;
                        nextMovement.MOVEMENTCONNECTOR = null;
                        nextMovement.DISTANCE = 0;
                        pathMapTO[to.ID] = newMovementPath;
                        straightLineMapTO[to.ID] = newStraightLine;
                        newMovementPaths.Add(newMovementPath);
                        if(to == startHex)
                        {
                            return newMovementPath;
                        }
                        if (pathMapFROM.ContainsKey(to.ID))
                        {
                            FROMDistance = pathMapFROM[to.ID].Sum(n => n.DISTANCE);
                            TODistance = newMovementPath.Sum(n => n.DISTANCE);
                        }
                    }
                }
                movementPathsTO = newMovementPaths;

                INTERSECT = [..pathMapFROM.Keys.Intersect([.. pathMapTO.Keys])];
            }
            if (INTERSECT.Count > 0)
            {
                List<List<FSMovement>> pathFULLs = [];
                foreach(string join in INTERSECT)
                {
                    List<FSMovement> pathFULL = pathMapFROM[join];
                    List<FSMovement> pathREST = pathMapTO[join];
                    pathREST.Remove(pathREST.Last());
                    pathREST.Reverse();
                    pathFULL.AddRange(pathREST);
                    pathFULLs.Add(pathFULL);
                }                
                return pathFULLs.OrderBy(n => n.Sum(n2 => n2.DISTANCE)).ThenBy(n => n.Sum(n2 => FS.LineToPointDistance2D(linePtA, linePtB, [n2.MOVEMENTLOCATION.x, n2.MOVEMENTLOCATION.y]))).First();
            }
            else
            {
                return new();
            }
        }
        //Compute the cross product AB x AC
        public static double CrossProduct(double[] pointA, double[] pointB, double[] pointC)
        {
            double[] AB = new double[2];
            double[] AC = new double[2];
            AB[0] = pointB[0] - pointA[0];
            AB[1] = pointB[1] - pointA[1];
            AC[0] = pointC[0] - pointA[0];
            AC[1] = pointC[1] - pointA[1];
            double cross = AB[0] * AC[1] - AB[1] * AC[0];

            return cross;
        }

        //Compute the distance from A to B
        public static double Distance(double[] pointA, double[] pointB)
        {
            double d1 = pointA[0] - pointB[0];
            double d2 = pointA[1] - pointB[1];

            return Math.Sqrt(d1 * d1 + d2 * d2);
        }

        //Compute the distance from AB to C
        //if isSegment is true, AB is a segment, not a line.
        public static double LineToPointDistance2D(double[] linePtA, double[] linePtB, double[] pointC)
        {
            double dist = CrossProduct(linePtA, linePtB, pointC) / Distance(linePtA, linePtB);
            return Math.Abs(dist);
        }
        public static List<FSMovement> FINDSSMDIRECTPATH(GO startHex, GO endHex)
        {
            GameScenario gs = startHex.GS;
            FSMovement startMovement = new()
            {
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            List<List<FSMovement>> movementPaths = new() { new() { startMovement } };
            while (movementPaths.Count > 0)
            {
                List<List<FSMovement>> newMovementPaths = new();
                foreach (List<FSMovement> movementPath in movementPaths)
                {
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    FSMovement nextMovement =
                    FS.GENERATESEAMOVEMENTCONNECTIONS(from)
                        .Where(n => !hexPath.Contains(n.MOVEMENTLOCATION))
                        .OrderBy(n => gs.GetDistance(n.MOVEMENTLOCATION, endHex.x, endHex.y)).FirstOrDefault();

                    if (nextMovement == null) { return new(); }

                    GO to = nextMovement.MOVEMENTLOCATION;
                    List<FSMovement> newMovementPath = new(movementPath) { nextMovement };
                    newMovementPaths.Add(newMovementPath);
                    if (to == endHex)
                    {
                        return newMovementPath;
                    }
                }
                movementPaths = newMovementPaths;
            }
            return new();
        }
        public static double GETDEFENSE(GO obj)
        {
            return obj.TEMPLATE.DEF - (obj.OUTOFFUEL || ((obj.REPLENISHING || obj.LOADING) && !obj.DOCKED) ? 1 : 0);
        }
        public static double RESETMOVEMENTALLOWANCE(GO obj)
        {
            if (obj.UNITCATEGORY == "AIR")
            {
                double ratio = 1 +
                    (obj.EXTENDEDRANGE ? 0.25 : 0) +
                    (obj.HIGHMISSIONPROFILE ? 0.25 : 0) +
                    (obj.AERIALREFUELING ? 0.5 : 0) +
                    (obj.REDUCEDRANGE ? -0.5 : 0);
                return Math.Floor(obj.TEMPLATE.MOVEMENTALLOWANCE * ratio);
            }
            else
            {
                double move = obj.DEEPMODE || obj.OUTOFFUEL ? 1 : obj.TEMPLATE.MOVEMENTALLOWANCE;
                if (obj.FULLSPEED)
                {
                    if (obj.UNITCATEGORY == "SUB") { move++; }
                    if (obj.UNITCATEGORY == "SURFACE")
                    {
                        switch (obj.UNITTYPE)
                        {
                            case "PC":
                                break;
                            case "CO":
                            case "FF":
                                move += 2;
                                break;
                            default:
                                move++;
                                break;
                        }
                    }
                }
                if (PARENTGROUPLOCATION(obj).FJORD) { move = Math.Ceiling(move * 0.5); }
                if (PARENTGROUPLOCATION(obj).PACKICE) { move = 1; }
                return move;
            }
        }
        public static void DOCK(GO obj)
        {
            obj.DOCKED = true;
            obj.MOVEMENTALLOWANCE = 0;
        }
        public static bool CANDOCK(GO obj)
        {
            return obj.UNITCATEGORY switch
            {
                "SURFACE" => obj.OUTOFFUEL || obj.MOVEMENTALLOWANCE >= 2,
                "SUB" => obj.MOVEMENTALLOWANCE >= Math.Min(obj.TEMPLATE.MOVEMENTALLOWANCE - 1, 2),
                _ => false
            };
        }
        public static List<FSMovement> FINDAIRMOVEMENTS(GO fromLoc)
        {
            List<FSMovement> connections = new();
            foreach (GO connector in fromLoc.GS.TYPE("UNITMOVEMENT", "CONNECTORLOCATIONID", fromLoc.ID))
            {
                FSMovement movement = GENERATEMOVEMENT(connector, connector.CONNECTORLOCATION2);
                movement.DISTANCE = Math.Max(1, movement.MOVEMENTCONNECTOR.DISTANCE);
                connections.Add(movement);
            }
            return connections;
        }
        public static List<FSMovement> FINDSURFACEMOVEMENTS(GO obj, GO fromLoc, bool forAI)
        {
            int maxMovementAllowance = forAI ? (int)FS.GROUPMEMBERS(obj).Min(n => n.TEMPLATE.MOVEMENTALLOWANCE) : 0;
            GameScenario GS = obj.GS;
            List<FSMovement> connections = new();
            foreach (FSMovement movement in GENERATESEAMOVEMENTCONNECTIONS(fromLoc))
            {
                if (movement.MOVEMENTLOCATION.SHOALS && !obj.PCCOONLY) { continue; }
                if (movement.MOVEMENTLOCATION.PACKICE) { continue; }
                movement.DISTANCE = GS.Get(movement.MOVEMENTLOCATION.ZONE + ".WEATHER") switch
                {
                    "STORM" => 4,
                    "SQUALL" => 2,
                    _ => 1,
                };
                if (obj.FULLSPEED && movement.MOVEMENTLOCATION.RESTRICTED)
                {
                    movement.DISTANCE++;
                }
                if (movement.MOVEMENTLOCATION.DRIFTICE && GS.GetBoolean("_CONFIG_DRIFT_ICE"))
                {
                    if(forAI){
                        movement.DISTANCE += Math.Max(0, maxMovementAllowance - movement.DISTANCE);
                    } else {
                        movement.DISTANCE++;
                    }
                }
                if (movement.MOVEMENTLOCATION.FJORD && forAI)
                {
                    movement.DISTANCE += Math.Max(0, maxMovementAllowance - movement.DISTANCE);
                }
                connections.Add(movement);
            }
            return connections;
        }
        public static List<FSMovement> FINDSUBMOVEMENTS(GO obj, GO fromLoc, bool forAI)
        {
            int maxMovementAllowance = forAI ? (int)FS.GROUPMEMBERS(obj).Min(n => n.TEMPLATE.MOVEMENTALLOWANCE) : 0;
            List<FSMovement> connections = new();
            foreach (FSMovement movement in GENERATESEAMOVEMENTCONNECTIONS(fromLoc))
            {
                if (movement.MOVEMENTLOCATION.SHOALS) { continue; }
                if (obj.DEEPMODE || obj.FULLSPEED)
                {
                    if (movement.MOVEMENTLOCATION.RESTRICTED || movement.MOVEMENTLOCATION.SHALLOW || movement.MOVEMENTLOCATION.PACKICE) { continue; }
                }
                if (obj.FULLSPEED)
                {
                    if (movement.MOVEMENTLOCATION.DRIFTICE && obj.GS.GetBoolean("_CONFIG_DRIFT_ICE")) { continue; }
                }
                if (movement.MOVEMENTLOCATION.PACKICE && obj.UNITTYPE == "SS") { continue; }
                movement.DISTANCE = 1;
                if (movement.MOVEMENTLOCATION.FJORD && forAI)
                {
                    movement.DISTANCE += Math.Max(0, maxMovementAllowance - movement.DISTANCE);
                }
                connections.Add(movement);
            }
            return connections;
        }
        public override string GetToolTip(int column, int row)
        {
            return column switch
            {
                0 => row switch
                {
                    0 => "Help/Instructions",
                    1 => "Next Phase",
                    _ => "",
                },
                1 => row switch
                {
                    0 => "View Destroyed",
                    1 => "Victory Points",
                    _ => "",
                },
                2 => row switch
                {
                    0 => "Sequence of Play",
                    1 => "Game Options",
                    _ => "",
                },
                3 => row switch
                {
                    0 => "Scenario Rules",
                    1 => "Show AI Info in Menus",
                    _ => "",
                },
                4 => row switch
                {
                    0 => "ATLANTIC",
                    1 => "CARIBBEAN",
                    _ => "",
                },
                5 => row switch
                {
                    0 => "MEDITERRANEAN",
                    1 => "INDIAN",
                    _ => "",
                },
                6 => row switch
                {
                    0 => "PACIFIC",
                    1 => "",
                    _ => "",
                },
                7 => row switch
                {
                    0 => "Save Progress (limited)",
                    1 => "Copy To New Branch",
                    _ => "",
                },
                8 => row switch
                {
                    0 => "World View",
                    1 => "Zoom Level 3",
                    _ => "",
                },
                9 => row switch
                {
                    0 => "Zoom Level 2",
                    1 => "Max Zoom",
                    _ => "",
                },
                _ => "",
            };
        }
        public override string GetScenarioSpecificImage(int column, int row)
        {
            return column switch
            {
                0 => row switch
                {
                    0 => "IconHelp.png",
                    1 => "IconNext.png",
                    _ => "EMPTY.png",
                },
                1 => row switch
                {
                    0 => "IconDestroyed.png",
                    1 => "IconVP.png",
                    _ => "EMPTY.png",
                },
                2 => row switch
                {
                    0 => "IconSOP.png",
                    1 => "IconOptions.png",
                    _ => "EMPTY.png",
                },
                3 => row switch
                {
                    0 => "IconRules.png",
                    1 => "IconAI.png",
                    _ => "EMPTY.png",
                },
                4 => row switch
                {
                    0 => "Icon2nd.png",
                    1 => "IconCS.png",
                    _ => "EMPTY.png",
                },
                5 => row switch
                {
                    0 => "Icon6th.png",
                    1 => "Icon5th.png",
                    _ => "EMPTY.png",
                },
                6 => row switch
                {
                    0 => "Icon7th.png",
                    1 => "EMPTY.png",
                    _ => "EMPTY.png",
                },
                7 => row switch
                {
                    0 => "IconSave.png",
                    1 => "IconBranch.png",
                    _ => "",
                },
                8 => row switch
                {
                    0 => "IconZoom1.png",
                    1 => "IconZoom3.png",
                    _ => "",
                },
                9 => row switch
                {
                    0 => "IconZoom2.png",
                    1 => "IconZoom4.png",
                    _ => "",
                },
                _ => "",
            };
        }
        public override void ScenarioButtonClick(int column, int row)
        {
            if (_Window.INIT) { return; }
            switch (column)
            {
                case 0:
                    switch (row)
                    {
                        case 0: //HELP
                            if (HELPTEXT != null)
                            {
                                //MessageBox.Show(HELPTEXT);
                                //PresentRules(HELPTEXT);
                                Dictionary<string, string> dialogInfo = [];
                                dialogInfo["PHASE"] = HELPTEXT;
                                dialogInfo["RULES"] = _Window.RULES;
                                dialogInfo["SAVEDGAME"] = System.IO.File.ReadAllText(_Window.GetGameStateFile());
                                dialogInfo["MODE"] = "PHASE";
                                HelpDialog popupDialog = new HelpDialog(dialogInfo);
                                bool? result = popupDialog.ShowDialog();
                            }
                            break;
                        case 1: //NEXT PHASE
                            try
                            {
                                using (new WaitCursor())
                                {
                                    if (RESULT != null)
                                    {
                                        MessageBox.Show("Scenario " + data.ID + " is over. " + RESULT);
                                    }
                                    else if (ExecutingGamePhase().ManualAdvance)
                                    {
                                        _Window.ActionContext = ["SCROLL", "SAVE", "CLICKED"];
                                        _Window.UpdateScenario("NEXT");
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                _Window.throwError(ex);
                            }
                            break;
                    }
                    break;
                case 1:
                    switch (row)
                    {
                        case 0:
                            GO destroyed = LOCATION("ALLDESTROYED");
                            _Window.ScrollToCoordinate(destroyed.x, destroyed.y, true);
                            break;
                        case 1:
                            PresentVPMenu();
                            break;
                    }
                    break;
                case 2:
                    switch (row)
                    {
                        case 0:
                            SEQUENCEOFPLAY(this);
                            break;
                        case 1:
                            PresentConfigMenu();
                            break;
                    }
                    break;
                case 3:
                    switch (row)
                    {
                        case 0:
                            Dictionary<string, string> dialogInfo = [];
                            dialogInfo["PHASE"] = HELPTEXT;
                            dialogInfo["RULES"] = _Window.RULES;
                            dialogInfo["SAVEDGAME"] = System.IO.File.ReadAllText(_Window.GetGameStateFile());
                            dialogInfo["MODE"] = "RULES";
                            HelpDialog popupDialog = new HelpDialog(dialogInfo);
                            bool? result = popupDialog.ShowDialog();
                            //PresentRules(_Window.RULES);
                            break;
                        case 1:
                            SetBoolean("AI.MENUINFO", !GetBoolean("AI.MENUINFO"));
                            ProcessMarkerChoiceMenu(SelectedMarker);
                            break;
                    }
                    break;
                case 4:
                    switch (row)
                    {
                        case 0:
                            _Window.ScrollToCoordinate(9450, 2970, false);
                            break;
                        case 1:
                            _Window.ScrollToCoordinate(4164, 8230, false);
                            break;
                    }
                    break;
                case 5:
                    switch (row)
                    {
                        case 0: //CEUR
                            _Window.ScrollToCoordinate(11802, 5566, false);
                            break;
                        case 1: //SWASIA
                            _Window.ScrollToCoordinate(17945, 8410, false);
                            break;
                    }
                    break;
                case 6:
                    switch (row)
                    {
                        case 0: //CEUR
                            _Window.ScrollToCoordinate(25842, 6062, false);
                            break;
                        case 1: //SWASIA
                            break;
                    }
                    break;
                case 7:
                    switch (row)
                    {
                        case 0:
                            if (ExecutingGamePhase().InProgressSave)
                            {
                                _Window.SaveGameStateToLocalFiles();
                                MainWindow.Alert("Progress within current phase saved successfully");
                            }
                            else
                            {
                                MainWindow.Alert("Current phase does not support In-Progress save.  Please advance to next phase to save progress.");
                            }
                            break;
                        case 1: //save branch
                            if (ExecutingGamePhase().InProgressSave)
                            {
                                _Window.SaveGameStateToLocalFiles();
                            }
                            if (_Window.sessionDirExists)
                            {
                                string newSaveGameName = _Window.GenerateSessionID();
                                string newDirectory = _Window.GetGameSaveDir() + "/" + newSaveGameName;
                                System.IO.Directory.CreateDirectory(newDirectory);
                                string[] ofiles = System.IO.Directory.GetFiles(_Window.GetGameSessionDir(), "*.*");
                                foreach (string s in ofiles)
                                {
                                    // Use static Path methods to extract only the file name from the path.
                                    string fileName = System.IO.Path.GetFileName(s);
                                    string _currFileName = System.IO.Path.Combine(newDirectory, fileName);
                                    System.IO.File.Copy(s, _currFileName, true);
                                }
                                MainWindow.Alert("New Save Game folder created: " + newSaveGameName);
                            }
                            else
                            {
                                MainWindow.Alert("No available Save Game folder exists to copy.  Please advance to next phase to save progress.");
                            }
                            break;
                    }
                    break;
                case 8:
                    switch (row)
                    {
                        case 0: //zoom
                            if (_Window.MapZoomLevel != 0.075)
                            {
                                ZOOMONLOCATION(0.075);
                            }
                            break;
                        case 1: //zoom
                            if (_Window.MapZoomLevel != 1)
                            {
                                ZOOMONLOCATION(1);
                            }
                            break;
                    }
                    break;
                case 9:
                    switch (row)
                    {
                        case 0: //zoom
                            if (_Window.MapZoomLevel != 0.5)
                            {
                                ZOOMONLOCATION(0.5);
                            }
                            break;
                        case 1: //zoom
                            if (_Window.MapZoomLevel != 1.2)
                            {
                                ZOOMONLOCATION(1.2);
                            }
                            break;
                    }
                    break;
                default:
                    break;
            }
            ;
        }
        public void ZOOMONLOCATION(double newZoomLevel)
        {
            //find location we are looking at
            double viewportWidth = Math.Max(_Window.CANVAS_SCROLL_VIEWER.ViewportWidth, 1000);
            double viewportHeight = Math.Max(_Window.CANVAS_SCROLL_VIEWER.ViewportHeight, 500);
            double realX = _Window.GetHorizontalOffset + viewportWidth * 0.5;
            double realY = _Window.GetVerticalOffset + viewportHeight * 0.5;
            double gameX = realX / _Window.MapZoomLevel;
            double gameY = realY / _Window.MapZoomLevel;
            _Window.MapZoomLevel = newZoomLevel;
            _Window.ZoomAll();
            _Window.ScrollToCoordinate(gameX, gameY, true);
            _Window.ActionContext.Clear();
            _Window.RefreshScenario();
        }
        public static void SETVIEW(GameScenario GS)
        {
            bool changingSideView = SIDE_MODE != OLD_SIDE_MODE;
            HashSet<GO> changedLocations = [];
            List<GO> groups = [];
            foreach (string s in new List<string> { "NEUT", "SOV", "ALLIES" })
            {
                foreach (GO piece in FS.TYPESIDE(GS, "PIECE", s).Where(n => !n.OBJECTIVE && !FS.BASETYPES.Contains(n.TYPE) && n.GAMELOCATIONID != null))
                {
                    bool hidden = false;
                    if (!SIDE_MODE.Contains(piece.SIDE ?? ""))
                    {
                        hidden = !piece.STRATDETECTED && !piece.LOCALDETECTED && !piece.ADMINDETECTED;
                    }
                    else if (FS.ISGROUP(piece))
                    {
                        groups.Add(piece);
                        continue;
                    }
                    else if (piece.TYPE == "DESTINATION")
                    {
                        hidden = true;
                    }
                    else
                    {
                        hidden = false;
                    }
                    if (hidden != piece.HIDDEN)
                    {
                        changedLocations.Add(piece.GAMELOCATION);
                    }
                    else
                    {
                        string bINDICATORS = OLD_SIDE_MODE != null ? string.Join('|', FS.INDICATORSTATUSES(piece, OLD_SIDE_MODE)) : null;
                        string aINDICATORS = string.Join('|', FS.INDICATORSTATUSES(piece, SIDE_MODE));
                        if (aINDICATORS != bINDICATORS)
                        {
                            changedLocations.Add(piece.GAMELOCATION);
                        }
                    }
                    piece.HIDDEN = hidden;
                }
            }
            foreach (GO piece in groups)
            {
                bool hidden = !FS.GROUPMEMBERS(piece).Where(n => !n.HIDDEN).Any();
                if (hidden != piece.HIDDEN || ((piece.STRATDETECTED || piece.LOCALDETECTED) && changingSideView))
                {
                    changedLocations.Add(piece.GAMELOCATION);
                }
                piece.HIDDEN = hidden;
            }
            foreach (GO location in changedLocations)
            {
                GS._Window.DrawMarkerStack(location, true);
            }
        }
        public override void APPTOUR()
        {
            double dockImgSize = Math.Max(Math.Min(SystemParameters.PrimaryScreenWidth, SystemParameters.PrimaryScreenHeight) * 0.1, _Window.MinDockMarkerSize);
            MainWindow.Alert("Welcome to the Fleet Series App\n\nTo help you understand this application and the way to use it, a series of popups will show the important parts of the App User Interface (UI)\n\n" +
            "This open scrollable area is where all the gameplay will occur. it is a composite of the five FLEET SERIES maps with areas of the globe filling in the gaps\n\n" +
            "Note that in order to string together all the games into a cohesive global scope, the game has additional locations OFF MAP that you will use to either simulate reinforcements, transfer units from map to map, and in general, to give a larger world-spanning context to your scenarios.");
            //Selected Marker
            _Window.SetImage(_Window.SELECTED_MARKER_IMAGE, _Window.GetImageDir() + "/COLOR.BLACK.png", dockImgSize);
            MainWindow.Alert("Throughout the game, in the upper left corner will be the image of the game piece that is currently selected. The game will normally only enable a sub-set of game-pieces that are even selectable. If you scroll away from the selected piece, you can click the image and the game will navigate back to the piece.  You will normally use the left and right buttons (surrounding this image) to progress through each game piece that is selectable in the current phase");
            _Window.SetImage(_Window.SELECTED_MARKER_IMAGE, _Window.GetImageDir() + "/EMPTY.png", dockImgSize);

            ((TextBlock)_Window.FindName("txtSelectedMarkerInfo")).Text = "**SELECTED MARKER INFO**";
            MainWindow.Alert("As we move across the top menu area, the next are is a TEXT AREA where you will see info about the selected game piece.  IF YOU CLICK HERE, you will get a popup where you can edit the unit's Name");
            ((TextBlock)_Window.FindName("txtSelectedMarkerInfo")).Text = "";

            _Window.SetImage(_Window.CLICKED_MARKER_IMAGE, _Window.GetImageDir() + "/COLOR.BLACK.png", dockImgSize);
            ((TextBlock)_Window.FindName("txtClickedMarkerInfo")).Text = "**CLICKED MARKER INFO**";
            MainWindow.Alert("Any game piece you click on, if it isn't a marker you can interact with, will show up in this location.  And to its right a TEXT AREA with details on that piece. IF YOU CLICK the text area, you will get a popup where you can edit the unit's Name");
            ((TextBlock)_Window.FindName("txtClickedMarkerInfo")).Text = "";
            _Window.SetImage(_Window.CLICKED_MARKER_IMAGE, _Window.GetImageDir() + "/EMPTY.png", dockImgSize);

            MainWindow.Alert("The next buttons are ones that will not work until you choose a scenario, but let's go through them..");
            for (int c = 0; c < 10; c++)
            {
                for (int r = 0; r <= 1; r++)
                {
                    string img = GetScenarioSpecificImage(c, r);
                    if (img != "EMPTY.png")
                    {
                        Button btnImage = (Button)_Window.FindName("btn0" + c + "0" + r);
                        //Image ssImage = (Image)_Window.FindName("imgbtn0" + c + "0" + r);
                        //_Window.SetImage(ssImage, _Window.GetImageDir() + "/COLOR.BLACK.png", 30);
                        Brush brush = btnImage.Background;
                        btnImage.Background = Brushes.Black;
                        string a = c switch
                        {
                            0 => r switch
                            {
                                0 => "PHASE INFORMATION\n\nThe specific instructions for whatever phase of the game you are in.  VERY HELPFUL",
                                1 => "NEXT PHASE\n\nSome phases automatically end when there is nothing left to do.  But sometimes the user is asked to advance the phase when they are done with their actions.  This button advances the game to the next phase and you will use it often",
                                _ => "",
                            },
                            1 => r switch
                            {
                                0 => "DESTROYED UNITS\n\nClicking this button will scroll your view to the Holding area for all destroyed units.  It will be a stack of units likely.  To see all the units in the stack, double click any stack and the game will show you all the units at the location",
                                1 => "VP MENU\n\nThis brings up a display showing current VP totals, and options to increase or decrease either sides VPs.  This is how you can track VPs during a mission. No automation currently updates VP, this is a manual process",
                                _ => "",
                            },
                            2 => r switch
                            {
                                0 => "SEQUENCE OF PLAY\n\nThis shows the overall sequence of play and there will be an indicator to let you know which phase you are in.  This will show you all the major phases, and for the specific cycle you are in, you will see more of the sub-phases",
                                1 => "GAME OPTIONS\n\nThis brings up a menu where you can turn on/off features in the scenario.  This is best done during Setup, and if options are changed during gameplay you may exhibit issues, so be advised",
                                _ => "",
                            },
                            3 => r switch
                            {
                                0 => "SCENARIO RULES\n\nThis shows the file content of the RULES.txt file in your scenario directory.  Remember that anything prescribed in that file is normally something the user will have to manage manually.  The game engine does NOT enforce scenario specific rules",
                                1 => "AI INFO\n\nWhen selected, the upper left menu shows linkages to Objective/Deployment logics for selected units.  This additional info only shows in certain key phases.  In the SETUP phases, since there is SO MUCH things you can do, this button will also toggle the types of actions you can do in the left side menu, to help with clutter",
                                _ => "",
                            },
                            4 => r switch
                            {
                                0 => "2ND FLEET AREA\n\nThis navigates you to the North Atlantic map area for quick moving around the globe",
                                1 => "CARIBBEAN SEA AREA\n\nThis navigates you to the 3rd Fleet Caribbean map",
                                _ => "",
                            },
                            5 => r switch
                            {
                                0 => "6TH FLEET AREA\n\nNavigates you to the Mediterranean Sea map",
                                1 => "5TH FLEET AREA\n\nNavigates you to the Indian Ocean map",
                                _ => "",
                            },
                            6 => r switch
                            {
                                0 => "7TH FLEET AREA\n\nNavigates you to the Pacific Ocean map",
                                1 => "",
                                _ => "",
                            },
                            7 => r switch
                            {
                                0 => "SAVE IN PROGRESS\n\nThis button is largely not used in the game. The game automatically saves whenever you advance to a new phase.  You dont have to do anything.  However, during the SETUP portion of your scenario, in the Setup Forces and Final Deployment phases, since they are lengthy, you can save your progress to the last action you just did, and be able to pick up from where you left off",
                                1 => "SAVE A COPY OF YOUR GAME\n\nThis button will take the current version of your save game file, and copy it to a new directory, essentially cloning your current scenario.  This is most helpful for scenario designers who want to create multiple scenarios all from a common point",
                                _ => "",
                            },
                            8 => r switch
                            {
                                0 => "ZOOM LEVEL 1\n\nThe widest zoom, this will show as much of the world map as possible",
                                1 => "ZOOM LEVEL 3",
                                _ => "",
                            },
                            9 => r switch
                            {
                                0 => "ZOOM LEVEL 2",
                                1 => "ZOOM LEVEL 4\n\nThe closest zoom, this will show a good close up of an area and pieces present",
                                _ => "",
                            },
                            _ => ""
                        };
                        MainWindow.Alert(a);
                        //_Window.SetImage(ssImage, _Window.GetScenarioImageDir() + "/" + img, 30);
                        btnImage.Background = brush;
                    }
                }
            }
            TextBlock textBlock = (TextBlock)_Window.FindName("TXTINFO");
            textBlock.Text = "****INSTRUCTIONS****";
            System.Windows.Media.Brush ob = textBlock.Background;
            System.Windows.Media.Brush of = textBlock.Foreground;
            textBlock.Background = Brushes.Black;
            textBlock.Foreground = Brushes.White;
            MainWindow.Alert("The Bar below the buttons is for a short list of INSTRUCTIONS that each phase provides. To get more detail, press the HELP button");
            textBlock.Text = "";
            textBlock.Background = ob;
            textBlock.Foreground = of;
            MainWindow.Alert("The last thing to mention, is the selection of your scenario\n\nThe game comes as a sandbox.  You have full control to establish which countries are involved and which units are on the board, which you will be given the opportunity to set up after starting the scenario\n\n" +
            "Each time you begin a new Sandbox session, a new directory will be created in the FS/Scenarios/CombinedGame/SavedGames directory.\n\n" +
            "Also, After you have used the SAVE COPY button, the next time you start the app, you should see the new scenario listed as a choice upon opening the game\n\n" +
            "You can also download scenarios other users have set up and as long as you put them in the FS/Scenarios/CombinedGame/SavedGames directory, you'll see them show up next time you open the app\n\n" +
            "TIP: you can create subdirectories in the SavedGames directory to organize your save files. As long as each game file is alone in its own directory, the game will recognize it. In response to this, the initial menu should create a series of submenus that follow the directory structure\n\n" +
            "Thats it.  Select a scenario OR start a new sandbox session and get designing/playing!");
        }
        public override string INFO(GameScenario GS, GO obj)
        {
            string returnString = "";
            foreach (string line in new List<string> { INFOLINE1(obj), INFOLINE2(obj), INFOLINE3(obj), INFOLINE4(obj), INFOLINE5(obj) })
            {
                returnString += (returnString != "" ? "\n" : "") + line;
            }
            return returnString;
        }
        public static string INFOLINE1(GO obj)
        {
            return INFOLINE1(obj, false);
        }
        public static string INFOLINE1(GO obj, bool minimized)
        {
            string returnString = "";
            switch (obj.TYPE)
            {
                case "SQN":
                case "SHIP":
                    if (FS.ISGROUP(obj))
                    {
                        GO first = FS.GROUPMEMBERS(obj).FirstOrDefault();
                        returnString += obj.SIDE + " " + obj.UNITTYPE + (first != null ? " - " + first.UNITTYPE + " " + first.LABEL : "");
                    }
                    else
                    {
                        returnString += obj.UNITTYPE + " " + obj.LABEL;
                        if (!minimized)
                        {
                            returnString += obj.TYPE == "SHIP" && !FS.GENERICCOUNTRIES.Contains(obj.COUNTRY) ? " (" + obj.TEMPLATE.LABEL + " class)" : "";
                        }
                    }
                    break;
                case "FACILITY":
                case "CLOSEDEFENSE":
                    returnString += obj.LABEL;
                    break;
                case "POSSESSIONFLAG":
                    returnString += obj.LABEL + " " + (obj.COUNTRY ?? "") + (obj.COUNTRY != null && obj.SIDE != null ? "/" : "") + (obj.SIDE ?? "");
                    if (FS.LANDWAR)
                    {
                        List<GO> LANDCOMBATS = obj.GS.TYPE("LANDCOMBAT").Where(n => (n.SIDE == FS.ENEMY(obj.SIDE) && n.DEFENDER == obj) || (n.SIDE == obj.SIDE && n.ATTACKER == obj)).ToList();
                        returnString += (LANDCOMBATS.Any() ? " (IN CONFLICT)" : "");
                    }
                    break;
                case "TARGET":
                    returnString += obj.SIDE != null && obj.GAMEPIECE?.ATTACKER != null ? INFOLINE1(obj.GAMEPIECE.ATTACKER, minimized) + " : " + obj.LABEL + " Attack" : "DEFENSE SHEET ANCHOR";
                    break;
                case "DESTINATION":
                    returnString += obj.GAMEPIECE != null ? INFOLINE1(obj.GAMEPIECE, minimized) + " : Destination" : "";
                    break;
                case "FAILURE":
                    returnString += obj.LABEL + " - " + obj.GAMELOCATION.ZONE;
                    break;
                case "OBJECTIVE":
                    returnString += obj.LABEL + (obj.OBJECTIVEUNITTYPES != null ? " - " + obj.OBJECTIVEUNITTYPES?.Replace('|', ',') : "");
                    break;
                case "DEPLOYMENTLOGIC":
                    returnString += "DEPLOY " + obj.LABEL;
                    break;
                case "OBJECTIVELOGIC":
                    returnString += (obj.OBJECTIVETYPE == null ? "" : obj.OBJECTIVETYPE + " ") + obj.LABEL;
                    break;
                case "TRIGGERLOGIC":
                    returnString += "TRIGGER " + (obj.ACTIVE ? "ON" : "OFF") + " " + obj.LABEL;
                    break;
                default:
                    returnString += obj.TYPE;
                    break;
            }
            return returnString;
        }
        public static string INFOLINE2(GO obj)
        {
            bool GRP = FS.ISGROUP(obj);
            GO parent = FS.LOGICALPARENT(obj);
            bool FREE = parent == obj;
            string returnString = "";
            List<string> INFOPARTS = new();
            switch (obj.TYPE)
            {
                case "SQN":
                case "SHIP":
                    if (obj.SIDE == null) { break; }
                    if (SIDE_MODE.Contains(obj.SIDE ?? ""))
                    {
                        INFOPARTS.Add(GRP ? "" : obj.SIDE + "/" + obj.COUNTRY);
                        INFOPARTS.Add(obj.MOVEMENTALLOWANCE > 0 ? "MOV:" + obj.MOVEMENTALLOWANCE : "");
                        INFOPARTS.Add(FREE ? "" : "Parent:" + (FS.ISGROUP(parent) ? INFOLINE1(parent) : parent.UNITTYPE + " " + parent.LABEL));

                        if (GRP && AIRSURFACEINTERACTION)
                        {
                            List<GO> gms = FS.GROUPMEMBERS(obj);
                            if (obj.TYPE == "SQN")
                            {
                                INFOPARTS.Add("AIRSearch:" + gms.Max(FS.GETAIRAIRSEARCH));
                                double avsMax = gms.Max(FS.GETAIRSURFACESEARCH);
                                double airToSurfaceRecon = Math.Floor(gms.Max(n => FS.GETAIRSURFACESEARCH(n) * (obj.SEARCHMODE || obj.AIRMISSION == "CAP" ? 1 : 0.5)));
                                INFOPARTS.Add(avsMax > 0 ? "SURFSearch:" + airToSurfaceRecon + (airToSurfaceRecon == avsMax ? "" : "/" + avsMax) : "");
                            }
                            else
                            {
                                bool AAA = gms.Where(n => n.TEMPLATE.AAA > 0).Any();
                                bool MAA = gms.Where(n => n.TEMPLATE.MAA).Any();
                                bool LAA = gms.Where(n => n.TEMPLATE.LAA).Any();
                                int airSearchNum = LAA ? 2 : AAA ? 1 : 0;
                                int airRangeNum = LAA ? 2 : MAA ? 1 : 0;
                                INFOPARTS.Add(airSearchNum > 0 ? "AIRSearch:" + airSearchNum : "");
                                if (AAA)
                                {
                                    INFOPARTS.Add(airRangeNum > 0 ? "AAARange:" + airRangeNum : "");
                                }
                            }
                        }

                        INFOPARTS.Add(obj.ENROUTEDELAY > 0 ? !obj.DONE && obj.ACTIVATED && obj.UNITCATEGORY == "AIR" ? "ENROUTE (" + obj.ENROUTEDELAY + " cycles)" : "ENROUTE (" + obj.ENROUTEDELAY + " turns)" : "");
                        INFOPARTS.Add(obj.SEARCHMODE ? !obj.DONE && obj.ACTIVATED && obj.UNITCATEGORY == "AIR" ? "SEARCH (" + obj.SEARCHDELAY + " cycles)" : "" : "");
                        INFOPARTS.Add(obj.LOITERMODE ? "LOITER" : "");
                        INFOPARTS.Add(obj.INTERCEPTMODE ? "AUTO-INTERCEPT" + (obj.MAA ? " (1 hex)" : "") : "");
                        INFOPARTS.Add(obj.ASWPATROLMODE ? "LOITER/PATROL" : "");
                    }
                    else
                    {
                        if (GRP && AIRSURFACEINTERACTION)
                        {
                            List<GO> gms = FS.GROUPMEMBERS(obj);
                            if (obj.TYPE == "SQN")
                            {
                                INFOPARTS.Add("AIRSearch:" + gms.Max(FS.GETAIRAIRSEARCH));
                                double avsMax = gms.Max(FS.GETAIRSURFACESEARCH);
                                INFOPARTS.Add(avsMax > 0 ? "SURFSearch:?/" + avsMax : "");
                            }
                            else
                            {
                                bool AAA = gms.Where(n => n.TEMPLATE.AAA > 0).Any();
                                bool MAA = gms.Where(n => n.TEMPLATE.MAA).Any();
                                bool LAA = gms.Where(n => n.TEMPLATE.LAA).Any();
                                int airSearchNum = LAA ? 2 : AAA ? 1 : 0;
                                int airRangeNum = LAA ? 2 : MAA ? 1 : 0;
                                INFOPARTS.Add(airSearchNum > 0 ? "AIRSearch:" + airSearchNum : "");
                                if (AAA)
                                {
                                    INFOPARTS.Add(airRangeNum > 0 ? "AAARange:" + airRangeNum : "");
                                }
                            }
                        }
                        INFOPARTS.Add(GRP ? "" : obj.SIDE + "/" + obj.COUNTRY);
                    }
                    break;
                case "TARGET":
                case "DESTINATION":
                    break;
                case "POSSESSIONFLAG":
                    if (FS.LANDWAR)
                    {
                        INFOPARTS.Add("TROOP STRENGTH: " + Math.Round(obj.STRENGTH, 0) +
                                        (obj.STRENGTHPRODUCTIONRATE > 0 ? " (+" + Math.Round(obj.STRENGTHPRODUCTIONRATE, 1) + ")" : ""));
                        INFOPARTS.Add("SUPPLIES: " + Math.Round(obj.SUPPLIES, 0) +
                                        (obj.SUPPLYPRODUCTIONRATE > 0 ? " (+" + Math.Round(obj.SUPPLYPRODUCTIONRATE, 1) + ")" : ""));
                    }
                    break;
                default:
                    INFOPARTS.Add((obj.COUNTRY ?? "") + (obj.COUNTRY != null && obj.SIDE != null ? "/" : "") + (obj.SIDE ?? ""));
                    break;
            }
            returnString += string.Join(' ', [.. INFOPARTS.Where(n => n != "")]);
            return returnString;
        }
        public static string INFOLINE3(GO obj)
        {
            bool GRP = FS.ISGROUP(obj);
            GO parent = FS.LOGICALPARENT(obj);
            bool FREE = parent == obj;
            string returnString = "";
            List<string> INFOPARTS = new();
            switch (obj.TYPE)
            {
                case "SQN":
                    if (obj.SIDE == null) { break; }
                    if (SIDE_MODE.Contains(obj.SIDE ?? ""))
                    {
                        bool ISCAP = obj.AIRMISSION == "CAP" && !obj.DONE;
                        bool ISACTIVATED = obj.ACTIVATED && !obj.DONE;
                        if (ISCAP) { INFOPARTS.Add(obj.NUMCOMBATS > 0 ? "CAP Attacks:" + obj.NUMCOMBATS : ""); }
                        if (FREE && ISACTIVATED) { INFOPARTS.Add(obj.NUMCOMBATS > 0 ? "Combats:" + obj.NUMCOMBATS : ""); }
                        INFOPARTS.Add(obj.SSMPTS > 0 ? "SSM:" + obj.SSMPTS : "");
                        INFOPARTS.Add(obj.CMPTS == obj.TEMPLATE.CMPTS ? (obj.CMPTS > 0 ? "CM:" + obj.CMPTS : "") : "CM:" + obj.CMPTS + "/" + obj.TEMPLATE.CMPTS);
                        INFOPARTS.Add(obj.BOMBPTS > 0 ? "BMB:" + obj.BOMBPTS : "");
                        INFOPARTS.Add(obj.TORPPTS > 0 ? "TRP:" + obj.TORPPTS : "");
                        INFOPARTS.Add(obj.MINEPTS > 0 ? "MINES" : "");
                        INFOPARTS.Add("AIRSearch:" + FS.GETAIRAIRSEARCH(obj));
                        if (AIRSURFACEINTERACTION && !GRP)
                        {
                            double avsMax = FS.GETAIRSURFACESEARCH(obj);
                            double airToSurfaceRecon = Math.Floor(avsMax * (obj.SEARCHMODE || obj.AIRMISSION == "CAP" ? 1 : 0.5));
                            if (ISCAP || ISACTIVATED)
                            {
                                INFOPARTS.Add(avsMax > 0 ? "SURFSearch:" + airToSurfaceRecon + (airToSurfaceRecon == avsMax ? "" : "/" + avsMax) : "");
                            }
                            else
                            {
                                INFOPARTS.Add(avsMax > 0 ? "SURFSearch:" + avsMax : "");
                            }
                        }
                    }
                    else if (!GRP)
                    {
                        INFOPARTS.Add("AIRSearch:" + FS.GETAIRAIRSEARCH(obj));
                        bool ISCAP = obj.AIRMISSION == "CAP" && !obj.DONE;
                        bool ISACTIVATED = obj.ACTIVATED && !obj.DONE;
                        if (AIRSURFACEINTERACTION)
                        {
                            double avsMax = FS.GETAIRSURFACESEARCH(obj);
                            INFOPARTS.Add(avsMax > 0 ? "SURFSearch:" + (ISCAP || ISACTIVATED ? "?/" : "") + avsMax : "");
                        }
                    }
                    break;
                case "SHIP":
                    if (obj.SIDE == null) { break; }
                    if (SIDE_MODE.Contains(obj.SIDE ?? ""))
                    {
                        if (FS.SURFACELADENTYPES.Contains(obj.UNITTYPE)) { INFOPARTS.Add(obj.EMPTY ? "EMPTY" : "LOADED"); }
                        if (FREE && obj.ACTIVATED) { INFOPARTS.Add(obj.NUMCOMBATS > 0 ? "Combats:" + obj.NUMCOMBATS : ""); }
                        INFOPARTS.Add(obj.FUELPTS == obj.TEMPLATE.FUELPTS ? (obj.FUELPTS > 0 ? "F:" + obj.FUELPTS : "") : "F:" + obj.FUELPTS + "/" + obj.TEMPLATE.FUELPTS);
                        INFOPARTS.Add(obj.SSMPTS == obj.TEMPLATE.SSMPTS ? (obj.SSMPTS > 0 ? "SSM:" + obj.SSMPTS : "") : "SSM:" + obj.SSMPTS + "/" + obj.TEMPLATE.SSMPTS);
                        INFOPARTS.Add(obj.SSM2PTS == obj.TEMPLATE.SSM2PTS ? (obj.SSM2PTS > 0 ? "SSM2:" + obj.SSM2PTS : "") : "SSM2:" + obj.SSM2PTS + "/" + obj.TEMPLATE.SSM2PTS);
                        INFOPARTS.Add(obj.TORPPTS == obj.TEMPLATE.TORPPTS ? (obj.TORPPTS > 0 ? "TRP:" + obj.TORPPTS : "") : "TRP:" + obj.TORPPTS + "/" + obj.TEMPLATE.TORPPTS);
                        INFOPARTS.Add(obj.CMPTS == obj.TEMPLATE.CMPTS ? (obj.CMPTS > 0 ? "CM:" + obj.CMPTS : "") : "CM:" + obj.CMPTS + "/" + obj.TEMPLATE.CMPTS);
                        INFOPARTS.Add(obj.ASWPTS == obj.TEMPLATE.ASWPTS ? (obj.ASWPTS > 0 ? "ASW:" + obj.ASWPTS : "") : "ASW:" + obj.ASWPTS + "/" + obj.TEMPLATE.ASWPTS);
                        INFOPARTS.Add(obj.AAPTS == obj.TEMPLATE.AAPTS ? (obj.AAPTS > 0 ? "AA:" + obj.AAPTS : "") : "AA:" + obj.AAPTS + "/" + obj.TEMPLATE.AAPTS);
                        INFOPARTS.Add(obj.AIRSSMPTS == obj.TEMPLATE.AIRSSMPTS ? (obj.AIRSSMPTS > 0 ? "AirSSM:" + obj.AIRSSMPTS : "") : "AirSSM:" + obj.AIRSSMPTS + "/" + obj.TEMPLATE.AIRSSMPTS);
                        INFOPARTS.Add(obj.BOMBPTS == obj.TEMPLATE.BOMBPTS ? (obj.BOMBPTS > 0 ? "BMB:" + obj.BOMBPTS : "") : "BMB:" + obj.BOMBPTS + "/" + obj.TEMPLATE.BOMBPTS);
                        INFOPARTS.Add(obj.MINEPTS > 0 ? "MINES" : "");
                        INFOPARTS.Add(obj.COMMANDOPTS > 0 ? "CMNDO" : "");
                        INFOPARTS.Add(obj.APTS == obj.TEMPLATE.APTS ? (obj.APTS > 0 ? "AP:" + obj.APTS : "") : "AP:" + obj.APTS + "/" + obj.TEMPLATE.APTS);
                        INFOPARTS.Add(obj.FPTS == obj.TEMPLATE.FPTS ? (obj.FPTS > 0 ? "FP:" + obj.FPTS : "") : "FP:" + obj.FPTS + "/" + obj.TEMPLATE.FPTS);
                        if (AIRSURFACEINTERACTION && obj.UNITCATEGORY == "SURFACE" && !GRP)
                        {
                            bool AAA = obj.TEMPLATE.AAA > 0;
                            bool MAA = obj.TEMPLATE.MAA;
                            bool LAA = obj.TEMPLATE.LAA;
                            int airSearchNum = LAA ? 2 : AAA ? 1 : 0;
                            int airRangeNum = LAA ? 2 : MAA ? 1 : 0;
                            INFOPARTS.Add(airSearchNum > 0 ? "AIRSearch:" + airSearchNum : "");
                            if (AAA)
                            {
                                INFOPARTS.Add(airRangeNum > 0 ? "AAARange:" + airRangeNum : "");
                            }
                        }
                    }
                    else
                    {
                        if (AIRSURFACEINTERACTION && obj.UNITCATEGORY == "SURFACE" && !GRP)
                        {
                            bool AAA = obj.TEMPLATE.AAA > 0;
                            bool MAA = obj.TEMPLATE.MAA;
                            bool LAA = obj.TEMPLATE.LAA;
                            int airSearchNum = LAA ? 2 : AAA ? 1 : 0;
                            int airRangeNum = LAA ? 2 : MAA ? 1 : 0;
                            INFOPARTS.Add(airSearchNum > 0 ? "AIRSearch:" + airSearchNum : "");
                            if (AAA)
                            {
                                INFOPARTS.Add(airRangeNum > 0 ? "AAARange:" + airRangeNum : "");
                            }
                        }
                    }
                    break;
                case "FACILITY":
                case "CLOSEDEFENSE":
                    INFOPARTS.Add(obj.PORT ? "PORT DMG: " + obj.PORTDAMAGELEVEL + " CAA: " + FS.GETFACILITYCAA(obj, "PORT") + " " : "");
                    INFOPARTS.Add(obj.AIRFIELD ? "AIRFIELD DMG: " + obj.AIRFIELDDAMAGELEVEL + " CAA: " + FS.GETFACILITYCAA(obj, "AIRFIELD") : "");
                    INFOPARTS.Add(obj.CLOSEDEFENSE ? "CLOSEDEFENSE DMG: " + obj.CLOSEDEFENSEDAMAGELEVEL + " CAA: " + FS.GETFACILITYCAA(obj, "CLOSEDEFENSE") + " " : "");
                    break;
                case "POSSESSIONFLAG":
                    List<GO> LANDCOMBATS = obj.GS.TYPE("LANDCOMBAT").Where(n => n.SIDE == FS.ENEMY(obj.SIDE) && n.ATTACKER == null && n.DEFENDER == obj).ToList();
                    double ENEMYSTRENGTH = LANDCOMBATS.Sum(n => n.STRENGTH);
                    double ENEMYSUPPLIES = LANDCOMBATS.Sum(n => n.SUPPLIES);
                    INFOPARTS.Add(ENEMYSTRENGTH > 0 ? "ENEMY INVASION: " + Math.Round(ENEMYSTRENGTH, 0) + " SUPPLIES: " + Math.Round(ENEMYSUPPLIES, 0) : "");
                    break;
                case "OBJECTIVELOGIC":
                    INFOPARTS.Add("OBJ TYPE: " + obj.OBJECTIVETYPE);
                    GO LOGICLINK = obj.GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == obj && n.LOGIC.TYPE == "TRIGGERLOGIC").FirstOrDefault();
                    if (LOGICLINK != null)
                    {
                        INFOPARTS.Add("AI TRIGGER:" + (LOGICLINK.LOGIC.ACTIVE ? "TRUE" : "FALSE"));
                    }
                    break;
                default:
                    break;
            }
            returnString += string.Join(' ', [.. INFOPARTS.Where(n => n != "")]);
            return returnString;
        }
        public static string INFOLINE4(GO obj)
        {
            bool GRP = FS.ISGROUP(obj);
            GO parent = FS.LOGICALPARENT(obj);
            bool FREE = parent == obj;
            string returnString = "";
            List<string> INFOPARTS = new();
            switch (obj.TYPE)
            {
                case "SQN":
                    if (obj.SIDE == null) { break; }
                    if (SIDE_MODE.Contains(obj.SIDE ?? ""))
                    {
                        if (obj.AIRMISSION != null)
                        {
                            INFOPARTS.Add(obj.AIRMISSION);
                        }
                    }
                    INFOPARTS.Add(obj.ACTIVATED ? "ACTIVE" : ""); 
                    INFOPARTS.Add(obj.DOCKED ? "DOCKED" : "");
                    INFOPARTS.Add(obj.LOADING ? "LOADING" : "");
                    INFOPARTS.Add(obj.REPLENISHING ? "REPLENISHING" : "");
                    INFOPARTS.Add(obj.DONE ? "DONE" : "");
                    break;
                case "SHIP":
                    INFOPARTS.Add(obj.ACTIVATED ? "ACTIVE" : ""); 
                    INFOPARTS.Add(obj.DOCKED ? "DOCKED" : "");
                    INFOPARTS.Add(obj.LOADING ? "LOADING" : "");
                    INFOPARTS.Add(obj.REPLENISHING ? "REPLENISHING" : "");
                    INFOPARTS.Add(obj.DONE ? "DONE" : "");
                    break;
                case "FACILITY":
                    if (FS.GARRISONWAR)
                    {
                        INFOPARTS.Add("Garrison:" + obj.STRENGTH);
                        INFOPARTS.Add("Enemy:" + obj.ENEMYSTRENGTH);
                    }
                    break;
                default:
                    break;
            }
            returnString += string.Join(' ', [.. INFOPARTS.Where(n => n != "")]);
            return returnString;
        }
        public static string INFOLINE5(GO obj)
        {
            bool GRP = FS.ISGROUP(obj);
            GO parent = FS.LOGICALPARENT(obj);
            bool FREE = parent == obj;
            string returnString = "";
            List<string> INFOPARTS = new();
            switch (obj.TYPE)
            {
                case "SQN":
                    if(!FS.ISGROUP(obj)){
                        INFOPARTS.Add("VP:" + FS.VPVALUE(obj)); 
                    }
                    break;
                case "SHIP":
                    if (FS.AI_REVIEW) {
                        GO LOGICLINK = obj.GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == obj && n.ACTIVE).FirstOrDefault();
                        if(LOGICLINK != null)
                        {
                            INFOPARTS.Add(LOGICLINK.LOGIC.OBJECTIVETYPE);
                        }
                    }
                    if(!FS.ISGROUP(obj)){
                        INFOPARTS.Add("VP:" + FS.VPVALUE(obj)); 
                    }
                    break;
                case "FACILITY":
                    break;
                default:
                    break;
            }
            returnString += string.Join(' ', [.. INFOPARTS.Where(n => n != "")]);
            return returnString;
        }
        private static List<GamePhase> _SOP = new();
        private static void SEQUENCEOFPLAY(GameScenario GS)
        {
            if (!_SOP.Any())
            {
                foreach (GamePhase gp in GS._GamePhases)
                {
                    List<GamePhase> parents = new();
                    GamePhase tmp = gp.ParentGamePhase;
                    while (tmp != null && !_SOP.Contains(tmp))
                    {
                        parents.Add(tmp);
                        tmp = tmp.ParentGamePhase;
                    }
                    parents.Reverse();
                    foreach (GamePhase p in parents)
                    {
                        _SOP.Add(p);
                    }
                    if (!_SOP.Contains(gp))
                    {
                        _SOP.Add(gp);
                    }
                }
            }
            string sop = "";
            List<GamePhase> keyGPs = new();
            GamePhase tmpGP = GS.ExecutingGamePhase().ParentGamePhase;
            while (tmpGP != null)
            {
                keyGPs.Add(tmpGP);
                tmpGP = tmpGP.ParentGamePhase;
            }
            foreach (GamePhase gp in _SOP)
            {
                bool isExecuting = gp.UNIQUEPATH == GS.EXECUTINGPHASE;
                bool inKeyGroup = gp.ParentGamePhase == null || keyGPs.Contains(gp.ParentGamePhase);
                List<string> pathComponents = gp.UNIQUEPATH.Split('|').Select(n => n.Trim()).ToList();
                string tmp = "";
                for (int pc = 0; pc < pathComponents.Count; pc++)
                {
                    tmp += pc == pathComponents.Count - 1 ? (isExecuting ? "<<<" : "") + pathComponents[pc] + (isExecuting ? ">>>" : "") : "   ";
                }
                if (inKeyGroup)
                {
                    sop += (sop != "" ? "\n" : "") + tmp;
                }
            }
            MainWindow.Alert(sop);
        }
        Dictionary<string, string> configMenuItems = new(){
            {"AI: ALLIES", "AI.ALLIES"},
            {"AI: SOV", "AI.SOV"},
            {"SHOW LINES TO AI LOGICS?", "AI.LOGICLINKLINES" },
            {"DRIFT ICE IN EFFECT?", "_CONFIG_DRIFT_ICE"},
            {"GARRISON COMBAT?", "_CONFIG_ENABLE_GARRISON_COMBAT"},
            {"FULL LAND COMBAT?", "_CONFIG_ENABLE_LAND_COMBAT"},
            {"AIR/SURFACE DETECTIONS AND COMBAT?", "_CONFIG_ENABLE_SURFACE_VS_AIR_INTERRACTION"},
            {"STATIONARY SURFACE DETECTION?", "_CONFIG_ENABLE_SURFACE_REALTIME_DETECTION"},
            {"REALTIME SUB DETECTION?", "_CONFIG_ENABLE_SUB_REALTIME_DETECTION"},
            {"COMBINED COMBAT?", "_CONFIG_ENABLE_COMBINED_COMBAT"},
            {"COMMAND FAILURE IMPACTS ACTIVATIONS?", "_CONFIG_COMMAND_FAILURE_AFFECTS_ACTIVATIONS_AND_FRIENDLY_CAP"},
            {"AUTO-SHOW HELP FIRST TIME?", "_CONFIG_SHOW_HELP_FIRST_TIME_THROUGH"},
            {"PAUSE WHEN SWITCHING SIDE VIEWS?", "_CONFIG_PROMPT_WHEN_SWITCHING_SIDE_VISIBILITY"},
            {"STRATEGIC MINING?", "_CONFIG_STRATEGIC_PHASE_MINING"},
            {"STRATEGIC TAC COORD?", "_CONFIG_STRATEGIC_PHASE_TACCOORD"}
        };
        private void PresentConfigMenu()
        {
            _Window.HideMenu(_Window.StackMenu);
            Menu m = _Window.OptionsMenu;
            m.Items.Clear();
            foreach (string o in configMenuItems.Keys)
            {
                bool showMenuItem = true;
                bool isBoolean = o.EndsWith("?");
                string option = isBoolean ? o.Substring(0, o.Length - 1) : o;
                switch (option)
                {
                    case "AI: ALLIES":
                        string val = Get("AI.ALLIES") ?? "NONE";
                        option = "AI: ALLIES - " + val;
                        showMenuItem = TYPE("AI.LOGICLINK").Any();
                        break;
                    case "AI: SOV":
                        val = Get("AI.SOV") ?? "NONE";
                        option = "AI: SOV - " + val;
                        showMenuItem = TYPE("AI.LOGICLINK").Any();
                        break;
                    case "SHOW LINES TO AI LOGICS":
                        showMenuItem = TYPE("AI.LOGICLINK").Any();
                        break;
                    default:
                        break;
                }
                if (!showMenuItem) { continue; }
                if (m.Items.Count > 0)
                {
                    m.Items.Add(new Separator());
                }
                string var = configMenuItems[o];
                MenuItem mi = new() { Header = option, FontWeight = FontWeights.UltraBold };
                mi.IsCheckable = isBoolean;
                mi.IsChecked = isBoolean && GetBoolean(var);
                mi.Click += _Window.ConfigMenucmiImg_Click;
                m.Items.Add(mi);
            }

            m.Items.Add(new Separator());
            MenuItem mmi = new() { Header = "DONE", FontWeight = FontWeights.UltraBold };
            mmi.Click += _Window.MainMenucmiImg_Click;
            m.Items.Add(mmi);

            Canvas.SetRight(m, WorldSize * _Window.MapZoomLevel - (_Window.GetHorizontalOffset + _Window.CANVAS_SCROLL_VIEWER.ViewportWidth) + 1);
            Canvas.SetTop(m, _Window.GetVerticalOffset + 1);
            _Window.SetDockedMenuZ(m);
        }
        public override void ProcessMainMenuClick(string header, string menuType, bool toggle)
        {
            if (menuType == "CONFIG")
            {
                bool canToggle = true;
                if (header != null)
                {
                    if (header.StartsWith("AI: ALLIES"))
                    {
                        header = "AI: ALLIES";
                    }
                    else if (header.StartsWith("AI: SOV"))
                    {
                        header = "AI: SOV";
                    }
                    else if (toggle)
                    {
                        header += "?";
                        canToggle = header switch
                        {
                            "AUTO-SHOW HELP FIRST TIME?" => true,
                            "SHOW LINES TO AI LOGICS?" => true,
                            "PAUSE WHEN SWITCHING SIDE VIEWS?" => true,
                            _ => FS.SETUP
                        };
                    }
                }
                //header = header.Split(':').FirstOrDefault()?.Trim();
                if (header != null && configMenuItems.ContainsKey(header))
                {
                    string var = configMenuItems[header];
                    if (toggle)
                    {
                        if (canToggle)
                        {
                            SetBoolean(var, !GetBoolean(var));
                            string a = header switch
                            {
                                "FULL LAND COMBAT?" => GetBoolean(var) switch
                                {
                                    true => "Game will allow player to invade territories at the strategic level and bases and will perform combat automatically each turn.  Complexity:  High",
                                    false => "Player will keep track of base captures manually outside of game."
                                },
                                "GARRISON COMBAT?" => GetBoolean(var) switch
                                {
                                    true => "Game will allow player to move supplies and troops between friendly or enemy bases via loading/unloading only.  Allows tracking of troop levels for VP purposes.  Bases can be conquered manually by player.  Complexity:  Low",
                                    false => "Player will keep track of base captures manually outside of game."
                                },
                                "AIR/SURFACE DETECTIONS AND COMBAT?" => GetBoolean(var) switch
                                {
                                    true => "Air units can detect Surface and vice-versa during Action Cycle.  Surface can execute AAA combat against air units in range",
                                    false => "No AAA combat, No detections between Air and Surface"
                                },
                                "STATIONARY SURFACE DETECTION?" => GetBoolean(var) switch
                                {
                                    true => "During Action Segment, Stationary surface can be detected if they spend more than 1 movement cycle in a LDZ",
                                    false => "During Action Segment, Surface gets detected when only moving or firing"
                                },
                                "REALTIME SUB DETECTION?" => GetBoolean(var) switch
                                {
                                    true => "Sub detection is more fluid, and sub can go in and out of detection during turn.  if either air units in LOITER, ships in ASW-PATROL, or the target sub are moving, a detection attempt is made.  Stationary subs are harder to detect, already detected are easier, and if more than 6 ASW pts are nearby pre- and post- move is easier. All other factors into detection are included per physical rules",
                                    false => "Subs only detected by moving or firing.  As written in physical game, during Action Segment, only 1 attempt can be made on a moving sub.  Once detected, sub cannot break detection unless they end the action phase out of detection range"
                                },
                                "COMBINED COMBAT?" => GetBoolean(var) switch
                                {
                                    true => "Combats of the same type against the same target/location are combined during automation.  Applies to all combat types except TORP and ASW",
                                    false => "Each combat is resolved on its own"
                                },
                                "COMMAND FAILURE IMPACTS ACTIVATIONS?" => GetBoolean(var) switch
                                {
                                    true => "In addition to Strategic Missions, Command Failure prevents Activations in that Zone, as well as friendly CAP assistance",
                                    false => "Command Failure only affects Strategic Missions"
                                },
                                "AUTO-SHOW HELP FIRST TIME?" => GetBoolean(var) switch
                                {
                                    true => "The first time through each phase, the HELP message will automatically pop-up",
                                    false => "HELP message will only pop-up when hitting the button in the top menu"
                                },
                                "PAUSE WHEN SWITCHING SIDE VIEWS?" => GetBoolean(var) switch
                                {
                                    true => "When transitioning between sides, a black screen and alert pops up.  Useful to hide the other side's units during hot-seat games",
                                    false => "No warnings when switching sides, useful for Solitaire"
                                },
                                "STRATEGIC MINING?" => GetBoolean(var) switch
                                {
                                    true => "Deploying Mines is executed during the Strategic Phase, using physical game rules",
                                    false => "Mining Missions are more realistic, performed in the Action Phase, as part of the units Orders.  Units will need to be intentionally loaded with Mines, and SUBs laying mines will use their entire turn's activation on performing the mission"
                                },
                                "STRATEGIC TAC COORD?" => GetBoolean(var) switch
                                {
                                    true => "Tac Coordination is executed by air units on Strategic missions, using physical game rules",
                                    false => "Tac Coordination is more flexible, performed in the Action Phase. Eligible air units must be in SEARCH MODE and can select a hex within search range in concert with attacks.  ASW capable air can select SUBs"
                                },
                                "SHOW LINES TO AI LOGICS?" => GetBoolean(var) switch
                                {
                                    true => "Units will show yellow lines to logics they are linked to, red lines to ones they are actively using",
                                    false => "No lines between units and AI logics will be shown"
                                },
                                _ => ""
                            };
                            if (a != "")
                            {
                                MainWindow.Alert(a);
                            }
                        }
                        else
                        {
                            MainWindow.Alert("Cannot toggle this setting after leaving the setup phase.");
                        }
                    }
                    switch (var)
                    {
                        case "_CONFIG_ENABLE_LAND_COMBAT":
                            if (GetBoolean(var))
                            {
                                SetBoolean("_CONFIG_ENABLE_GARRISON_COMBAT", false);
                                Set("AI.ALLIES", "NONE");
                                Set("AI.SOV", "NONE");
                            }
                            break;
                        case "_CONFIG_ENABLE_GARRISON_COMBAT":
                            if (GetBoolean(var))
                            {
                                SetBoolean("_CONFIG_ENABLE_LAND_COMBAT", false);
                            }
                            break;
                        case "AI.ALLIES":
                        case "AI.SOV":
                            switch (Get(var))
                            {
                                case "CAUTIOUS":
                                    Set(var, "NORMAL");
                                    SetBoolean("_CONFIG_ENABLE_LAND_COMBAT", false);
                                    break;
                                case "NORMAL":
                                    Set(var, "AGGRESSIVE");
                                    SetBoolean("_CONFIG_ENABLE_LAND_COMBAT", false);
                                    break;
                                case "AGGRESSIVE":
                                    if(FS.SETUP)
                                    {
                                        Set(var, "NONE");
                                    }
                                    else
                                    {
                                        Set(var, "CAUTIOUS");
                                        SetBoolean("_CONFIG_ENABLE_LAND_COMBAT", false);
                                    }
                                    break;
                                case "NONE":
                                    if (FS.SETUP)
                                    {
                                        Set(var, "CAUTIOUS");
                                        SetBoolean("_CONFIG_ENABLE_LAND_COMBAT", false);
                                    }
                                    else
                                    {
                                        MainWindow.Alert("Cannot toggle this setting after leaving the setup phase.");
                                    }
                                    break;
                                default:
                                    break;
                            }
                            break;
                        default:
                            break;
                    }
                    SetConfigs();
                }
                PresentConfigMenu();
            }
            else if (menuType == "VP")
            {
                switch (header)
                {
                    case "SOV: Increase":
                        IncrementDouble("VP.SOV", 1);
                        break;
                    case "SOV: Decrease":
                        IncrementDouble("VP.SOV", -1);
                        break;
                    case "ALLIES: Increase":
                        IncrementDouble("VP.ALLIES", 1);
                        break;
                    case "ALLIES: Decrease":
                        IncrementDouble("VP.ALLIES", -1);
                        break;
                    default:
                        break;
                }
                PresentVPMenu();
            }
        }
        private void PresentVPMenu()
        {
            _Window.HideMenu(_Window.StackMenu);
            Menu m = _Window.OptionsMenu;
            m.Items.Clear();
            MenuItem mmi = new() { Header = "SOV VP: " + GetDouble("VP.SOV"), FontWeight = FontWeights.UltraBold };
            m.Items.Add(mmi);
            m.Items.Add(new Separator());
            mmi = new() { Header = "ALLIES VP: " + GetDouble("VP.ALLIES"), FontWeight = FontWeights.UltraBold };
            m.Items.Add(mmi);

            foreach (string side in FS.SIDE_NAMES)
            {
                m.Items.Add(new Separator());
                MenuItem mi = new() { Header = side + ": Increase", FontWeight = FontWeights.UltraBold };
                mi.Click += _Window.VPMenucmiImg_Click;
                m.Items.Add(mi);
                m.Items.Add(new Separator());
                mi = new() { Header = side + ": Decrease", FontWeight = FontWeights.UltraBold };
                mi.Click += _Window.VPMenucmiImg_Click;
                m.Items.Add(mi);
            }
            m.Items.Add(new Separator());
            mmi = new() { Header = "DONE", FontWeight = FontWeights.UltraBold };
            mmi.Click += _Window.MainMenucmiImg_Click;
            m.Items.Add(mmi);

            Canvas.SetRight(m, WorldSize * _Window.MapZoomLevel - (_Window.GetHorizontalOffset + _Window.CANVAS_SCROLL_VIEWER.ViewportWidth) + 1);
            Canvas.SetTop(m, _Window.GetVerticalOffset + 1);
            _Window.SetDockedMenuZ(m);
        }
        private void PresentRules(string info)
        {
            _Window.HideMenu(_Window.StackMenu);
            Menu m = _Window.OptionsMenu;
            m.Items.Clear();
            MenuItem mmi = new() { Header = "DONE", FontWeight = FontWeights.UltraBold };
            mmi.Click += _Window.MainMenucmiImg_Click;
            m.Items.Add(mmi);
            m.Items.Add(new Separator());
            ScrollViewer scrollViewer = new() {VerticalScrollBarVisibility = ScrollBarVisibility.Auto, MaxWidth = _Window.CANVAS_SCROLL_VIEWER.ViewportWidth * 0.5, MaxHeight = _Window.CANVAS_SCROLL_VIEWER.ViewportHeight * 0.75 };
            TextBlock itemContent = new() { Text = info, TextWrapping = TextWrapping.Wrap, MaxWidth = _Window.CANVAS_SCROLL_VIEWER.ViewportWidth * 0.5 };
            scrollViewer.Content = itemContent;
            MenuItem mi = new() { Header = scrollViewer };
            m.Items.Add(mi);

            Canvas.SetRight(m, WorldSize * _Window.MapZoomLevel - (_Window.GetHorizontalOffset + _Window.CANVAS_SCROLL_VIEWER.ViewportWidth) + 1);
            Canvas.SetTop(m, _Window.GetVerticalOffset + 1);
            _Window.SetDockedMenuZ(m);
        }
        public override void ShowPrompt(bool initial)
        {
            string path = EXECUTINGPHASE;
            if (!GetBoolean(path) || (initial && FS.SETUP))
            {
                SetBoolean(path, true);
                if (GetBoolean("_CONFIG_SHOW_HELP_FIRST_TIME_THROUGH") || FS.SETUP)
                {
                    PresentRules(HELPTEXT);
                }
            }
        }
        public static List<string> AIRCOMBATTYPES = new() { "INT", "ATK", "BMB" };
        public static List<string> AIRIMMOBILETYPES = new() { "AR", "MSW" };

        public static Boolean CANSTACKONCARRIER(GameScenario GS, GO parent, List<GO> units)
        {
            if (!units.Any()) { return true; }
            //check combat aircraft
            if (units.Where(n => AIRCOMBATTYPES.Contains(n.UNITTYPE)).Count() > parent.TEMPLATE.AIRCAPACITYCOMBAT)
            {
                return false;
            }
            //check other types
            if (units.Where(n => n.UNITTYPE == "AEW").Count() > parent.TEMPLATE.AIRCAPACITYAEW)
            {
                return false;
            }
            if (units.Where(n => n.UNITTYPE == "EW").Count() > parent.TEMPLATE.AIRCAPACITYEW)
            {
                return false;
            }
            if (units.Where(n => n.UNITTYPE == "RCN").Count() > parent.TEMPLATE.AIRCAPACITYRCN)
            {
                return false;
            }
            if (units.Where(n => n.UNITTYPE == "MSW").Count() > parent.TEMPLATE.AIRCAPACITYMSW)
            {
                return false;
            }
            if (units.Where(n => n.UNITTYPE == "AR").Count() > parent.TEMPLATE.AIRCAPACITYAR)
            {
                return false;
            }
            return true;
        }
        public static List<string> SURFACECOMBATTYPES = new() { "CV", "BB", "CT", "CG", "DD", "FF", "CO", "PC" };
        public static List<string> SURFACELADENTYPES = new() { "FC", "SC", "TK", "AA", "MP" };
        public static List<string> SURFACECARGOTYPES = new() { "FC", "SC", "TK" };
        public static List<string> SURFACETROOPTYPES = new() { "AA", "MP" };
        public static List<string> SHOALTYPES = new() { "PC", "CO" };
        public static List<string> REMOVABLETYPES = new() { "FC", "SC", "TK", "AA", "MP", "CS", "AM", "OL" };
        public static Dictionary<string, List<string>> AI_UNITTYPE_ROLES = new()
        {
            { "AA", new() { "TRANSPORT" } },
            { "CV", new() { "WARSHIP", "ANTI-SURFACE", "ANTI-SUB" } },
            { "BB", new() { "WARSHIP", "ANTI-SURFACE" } },
            { "CG", new() { "WARSHIP", "ANTI-SURFACE", "ANTI-SUB" } },
            { "DD", new() { "WARSHIP", "ANTI-SUB", "ANTI-SURFACE" } },
            { "FF", new() { "WARSHIP", "ANTI-SUB", "ANTI-SURFACE" } },
            { "CT", new() { "WARSHIP", "ANTI-SUB", "ANTI-SURFACE" } },
            { "CO", new() { "WARSHIP", "ANTI-SUB", "ANTI-SURFACE" } },
            { "PC", new() { "WARSHIP", "ANTI-SURFACE" } },
            { "TK", new() { "TRANSPORT" } },
            { "SC", new() { "TRANSPORT" } },
            { "FC", new() { "TRANSPORT" } },
            { "MP", new() { "TRANSPORT" } },
            { "MS", new() { "MINESWEEPING" } },
            { "CS", new() { "SUPPORT", "TRANSPORT" } },
            { "AM", new() { "SUPPORT", "TRANSPORT" } },
            { "OL", new() { "SUPPORT", "TRANSPORT" } },
            { "SN", new() { "WARSHIP", "ANTI-SUB", "ANTI-SURFACE", "TRANSPORT" } },
            { "SS", new() { "WARSHIP", "ANTI-SUB", "ANTI-SURFACE", "TRANSPORT" } },
            { "INT", new() { "ESCORT", "CAP", "BOMBING", "SSM" } },
            { "ATK", new() { "BOMBING", "SSM" } },
            { "BMB", new() { "BOMBING", "SSM", "CRUISE MISSILE" } },
            { "RCN", new() { "ASW", "SSM" } },
            { "AEW", new() { "CAP", "RECON" } },
            { "EW", new() { "ESCORT", "CAP" } }
        };
        public static List<string> AI_OBJECTIVETYPES = new()
        {
            "UNLOAD", "INVADE", "LOAD", "INSERT COMMANDOS", "LAY MINES", "PATROL", "DESTROY BASE", "DESTROY AIRFIELD", "DESTROY PORT", "DESTROY CLOSEDEFENSE", "REPLENISH", "GROUPING", "TRANSIT"
        };
        public static Dictionary<string, List<string>> AI_ALLOWEDOBJECTIVETYPES = new()
        {
            { "SQN", new() { "PATROL", "DESTROY BASE", "DESTROY AIRFIELD", "DESTROY PORT", "DESTROY CLOSEDEFENSE" } },
            { "SHIP", new() { "UNLOAD", "INVADE", "LOAD", "INSERT COMMANDOS", "LAY MINES", "PATROL", "DESTROY BASE", "DESTROY AIRFIELD", "DESTROY PORT", "DESTROY CLOSEDEFENSE", "REPLENISH", "GROUPING", "TRANSIT" } }
        };
        public static List<double> AI_VPMULTIPLES = new()
        {
            0, 1, 1.5, 2, 3, 0.75, 0.5, 0.25
        };
        public static Boolean CANSTACKSURFACE(List<GO> units)
        {
            return units.Where(n => SURFACECOMBATTYPES.Contains(n.UNITTYPE)).Count() <= 12;
        }
        public static Boolean CANSTACKAIR(List<GO> units)
        {
            return units.Where(n => AIRCOMBATTYPES.Contains(n.UNITTYPE) && n.CARRIERID == null).Distinct().Count() <= 4;
        }
        public static void MOVETOGRIDSECTION(GameScenario GS, GO obj, string gridLocation)
        {
            Dictionary<int, List<GO>> locPopulationMap = new();
            List<GO> locs = GS.TYPE(gridLocation).OrderBy(n => n.ID).ToList();
            for (int i = 0; i < locs.Count; i++)
            {
                GO loc = locs[i];
                int population = GS.PIECESATLOCATION(loc.ID).Where(n => n != obj).Count();
                if (!locPopulationMap.ContainsKey(population))
                {
                    locPopulationMap.Add(population, new());
                }
                locPopulationMap[population].Add(loc);
            }
            GO chosenLoc = locPopulationMap[locPopulationMap.Keys.OrderBy(n => n).First()].First();
            GS.CHANGELOCATION(obj, chosenLoc);
        }
        public static string GENERATETIMESTAMP()
        {
            return DateTime.Now.ToString("yyyyMMddHHmmssfff");
        }
        public static GO DISPLAYGROUP(GameScenario GS, GO group)
        {
            GO sheet = group.GRPTYPE == "TFTGGRP" ? GRPSHEET :
                group.GRPTYPE == "ACTIVATIONGRP" ? ACTIVATIONGRPSHEET :
                        CVSHEET;
            if (sheet.SHEETPARENTPIECE != group)
            {
                GO groupLocation = group.GAMELOCATION.LOCATIONHIDDEN ? PARENTGROUPLOCATION(group) : group.GAMELOCATION;
                if (GS.TYPE("PIECE", "PARENTSHEETID", sheet.ID).Any())
                {
                    REMOVEGROUPSHEET(sheet);
                }
                double realY = groupLocation.y;
                double offset = sheet == GRPSHEET ? -125 : sheet == CVSHEET ? -250 : sheet == ACTIVATIONGRPSHEET ? 125 : 0;
                //by default add above location
                if (offset < 0)
                {
                    if (realY + offset <= 0) { offset = 0 - offset; }
                }
                else
                {
                    if (realY + offset >= GS.WorldSize) { offset = 0 - offset; }
                }
                realY += offset;
                GO anchor = GS.LOCATION(sheet.SHEETANCHORLOCATIONID);
                anchor.x = groupLocation.x;
                anchor.XCOORD = anchor.x;
                anchor.y = realY;
                anchor.YCOORD = anchor.y;
            }
            List<GO> grpMembers = [.. FS.GROUPMEMBERS(group).Where(n => !n.HIDDEN)];
            //dynamic size
            double baseSize = GS.MarkerSize * 1.25;
            double c = Math.Max(1, grpMembers.Count);
            double r = 1;
            //while(c * r < grpMembers.Count){
            //if(c == r){c++;} else {r++;}
            //}
            sheet.IMAGEWIDTH = c * baseSize;
            sheet.MINIMIZEDWIDTH = sheet.IMAGEWIDTH;
            sheet.IMAGEHEIGHT = r * baseSize;
            sheet.SHEETPARENTPIECE = group;
            List<GO> dynamiccolorsheets = new() { FS.ACTIVATIONGRPSHEET, FS.CVSHEET, FS.GRPSHEET };
            Dictionary<string, string> sidecolors = new() { { "SOV", "RED" }, { "ALLIES", "BLUE" }, { "NEUT", "GRAY" } };
            if (dynamiccolorsheets.Contains(sheet))
            {
                sheet.IMAGEFILE = "COLOR." + sidecolors[group.SIDE] + "." + (sheet == FS.CVSHEET || group.TYPE == "SQN" ? "LIGHT.png" : "GRAY.png");
            }
            GS.CHANGELOCATION(sheet, sheet.SHEETANCHORLOCATIONID);
            List<GO> locs = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", sheet.ID).Where(n => n.XCOORD < sheet.IMAGEWIDTH && n.YCOORD < sheet.IMAGEHEIGHT).ToList();
            for (int i = 0; i < grpMembers.Count; i++)
            {
                GS.CHANGELOCATION(grpMembers[i], locs[i]);
            }
            GS._Window.ExpandOrCollapseSheet(sheet, true);
            return sheet;
        }
        public static void REMOVEGROUPSHEET(GO sheet)
        {
            GameScenario GS = sheet.GS;
            if (FS.TRAYSHEETS.Contains(sheet)) { sheet.SHEETPARENTPIECE = null; }
            GS._Window.ExpandOrCollapseSheet(sheet, false);
            GS.CHANGELOCATION(sheet, "TEMP");
            foreach (GO obj in GS.TYPE("PIECE", "PARENTSHEETID", sheet.ID))
            {
                obj.GAMELOCATION.GAMEPIECEID = null;
                //GS.CHANGELOCATION(obj, "TEMP");
            }
        }
        public static void REMOVECOMBATSHEET()
        {
            GameScenario GS = FS.DEFENDSHEET.GS;
            foreach (GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).Where(n => n.HOMEBASEID != null))
            {
                GS.CHANGELOCATION(obj, obj.HOMEBASE);
                obj.HOMEBASEID = null;
                foreach (GO gm in FS.GROUPMEMBERS(obj).Where(n => n != obj))
                {
                    gm.GAMELOCATIONID = obj.GAMELOCATIONID;
                    gm.GAMELOCATION = obj.GAMELOCATION;
                    foreach (GO gm2 in FS.GROUPMEMBERS(gm).Where(n => n != gm))
                    {
                        gm2.GAMELOCATIONID = obj.GAMELOCATIONID;
                        gm2.GAMELOCATION = obj.GAMELOCATION;
                    }
                }
            }
            GS.CHANGELOCATION(FS.DEFENDSHEET.SHEETPARENTPIECE, "TEMP");
            GS.CHANGELOCATION(FS.DEFENDSHEET, "TEMP");
            GS.SetBoolean("ACTION.DEFENDTRAYACTIVE", false);
        }
        public static GO DISPLAYCOMBATSHEET(GameScenario GS, List<GO> grpMembers)
        {
            GO first = grpMembers.First();
            GO maplocation = first.HOMEBASE.DOMAIN == GO.DOMAIN_LOCATION ? first.HOMEBASE : FS.PARENTGROUPLOCATION(first.HOMEBASE);
            return DISPLAYCOMBATSHEET(GS, grpMembers, maplocation);
        }
        public static GO DISPLAYCOMBATSHEET(GameScenario GS, List<GO> grpMembers, GO maplocation)
        {
            GO first = grpMembers.First();
            GO sheet = DEFENDSHEET;
            if (first.PARENTSHEET != sheet)
            {
                GO anchor = GS.LOCATION(sheet.SHEETANCHORLOCATIONID);
                anchor.XCOORD = maplocation.x;
                anchor.YCOORD = maplocation.y;
                anchor.x = maplocation.x;
                anchor.y = maplocation.y;
            }
            //dynamic size
            double baseSize = GS.MarkerSize * 1.25;
            int c = Math.Max(1, grpMembers.Count);
            int r = 1;
            //while(c * r < grpMembers.Count){
            //if(c == r){c++;} else {r++;}
            //}
            sheet.IMAGEWIDTH = c * baseSize;
            sheet.MINIMIZEDWIDTH = sheet.IMAGEWIDTH;
            sheet.IMAGEHEIGHT = r * baseSize;
            GS.CHANGELOCATION(sheet, sheet.SHEETANCHORLOCATIONID);
            GS.CHANGELOCATION(sheet.SHEETPARENTPIECE, maplocation);
            List<GO> locs = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", sheet.ID).Where(n => n.XCOORD < sheet.IMAGEWIDTH && n.YCOORD < sheet.IMAGEHEIGHT).ToList();
            for (int i = 0; i < grpMembers.Count; i++)
            {
                GS.CHANGELOCATION(grpMembers[i], locs[i]);
            }
            GS._Window.ExpandOrCollapseSheet(sheet, true);
            GS.SetBoolean("ACTION.DEFENDTRAYACTIVE", true);
            return sheet;
        }
        public static void DISPLAYDETAILSHEET(GameScenario GS)
        {
            /*
            bool hide = true;
            if(GS.InspectedLocation != null){
                List<GO> tmp = GS.TYPE("PIECE", "GAMELOCATIONID", GS.InspectedLocation.ID).Where(n => !n.HIDDEN).ToList();
                if(tmp.Count > 1){
                    GO sheet = DETAILSHEET;
                    //dynamic size
                    double baseSize = GS.MarkerSize * 1.25;
                    int c = 1; //Math.Max(1, tmp.Count);
                    int r = 1;
                    while(c * r < tmp.Count){
                        if(c == r){c++;} else {r++;}
                    }
                    sheet.IMAGEWIDTH = c * baseSize;
                    sheet.MINIMIZEDWIDTH = sheet.IMAGEWIDTH;
                    sheet.IMAGEHEIGHT = r * baseSize;
                    GS.CHANGELOCATION(sheet, GS.InspectedLocation);
                    GS._Window.ExpandOrCollapseSheet(sheet, true);
                    hide = false;
                }
            }
            if(hide && DETAILSHEET.GAMELOCATIONID != "TEMP"){
                GS.CHANGELOCATION(DETAILSHEET, "TEMP");
                GS._Window.ExpandOrCollapseSheet(DETAILSHEET, false);
            }*/
        }
        public static GO CLONE(GameScenario GS, GO obj, string locId)
        {
            Dictionary<string, string> clonedData = new(obj._data);
            clonedData["ID"] = obj.ID + GO.DELIM + locId + GO.DELIM + GENERATETIMESTAMP();
            clonedData["LABEL"] = obj.LABEL;
            GO clone = new(GS, clonedData, null, null);
            GS.CHANGELOCATION(clone, locId);
            return clone;
        }
        public static GO UPDATEBASE(GO current, GO obj, GO loc)
        {
            GameScenario GS = obj.GS;
            if (current != null)
            {
                current.SIDE = loc.SIDE;
                current.IMAGEFILE = obj.IMAGEFILE;
                GS.CHANGELOCATION(current, loc);
                return current;
            }
            else
            {
                Dictionary<string, string> clonedData = new(obj._data);
                clonedData["ID"] = loc.SIDE + "BASE" + GO.DELIM + (loc.LABEL ?? loc.ID).Replace(' ', '_') + GO.DELIM + GENERATETIMESTAMP();
                clonedData["TYPE"] = "FACILITY";
                GO clone = new(GS, clonedData, null, null);
                clone.SIDE = loc.SIDE;
                clone.COUNTRY = loc.COUNTRY;
                clone.LABEL = loc.LABEL;
                clone.CAA = loc.CAA;
                clone.PORT = loc.PORT;
                clone.PORTDAMAGELEVEL = clone.PORT ? loc.PORTDAMAGELEVEL : 4;
                clone.PORTDESTROYED = !clone.PORT || loc.PORTDESTROYED;
                clone.AIRFIELD = loc.AIRFIELD;
                clone.AIRFIELDDAMAGELEVEL = clone.AIRFIELD ? loc.AIRFIELDDAMAGELEVEL : 4;
                clone.AIRFIELDDESTROYED = !clone.AIRFIELD || loc.AIRFIELDDESTROYED;
                GS.CHANGELOCATION(clone, loc);
                loc.GAMEPIECEID = clone.ID;
                loc.GAMEPIECE = clone;
                GS.ShuffleMarkerToBottom(clone);
                return clone;
            }
        }
        public static GO UPDATECLOSEDEFENSE(GO current, GO obj, GO loc)
        {
            GameScenario GS = obj.GS;
            if (current != null)
            {
                current.SIDE = loc.SIDE;
                current.IMAGEFILE = obj.IMAGEFILE;
                GS.CHANGELOCATION(current, loc);
                return current;
            }
            else
            {
                Dictionary<string, string> clonedData = new(obj._data);
                clonedData["ID"] = loc.SIDE + "CLOSEDEFENSE" + GO.DELIM + (loc.LABEL ?? loc.ID).Replace(' ', '_') + GO.DELIM + GENERATETIMESTAMP();
                clonedData["TYPE"] = "CLOSEDEFENSE";
                GO clone = new(GS, clonedData, null, null);
                clone.SIDE = loc.SIDE;
                clone.COUNTRY = loc.COUNTRY;
                clone.LABEL = obj.LABEL;
                clone.CAA = loc.CAA;
                clone.ASW = 10;
                clone.SSM = 20;
                clone.CLOSEDEFENSE = loc.CLOSEDEFENSE;
                clone.CLOSEDEFENSEDAMAGELEVEL = loc.CLOSEDEFENSEDAMAGELEVEL;
                GS.CHANGELOCATION(clone, loc);
                loc.CLOSEDEFENSEFACILITYID = clone.ID;
                loc.CLOSEDEFENSEFACILITY = clone;
                GS.ShuffleMarkerToBottom(clone);
                return clone;
            }
        }
        public static GO UPDATELOGISTICALBASE(GO loc, string oldSide, string newSide)
        {
            GameScenario GS = loc.GS;
            GO flagTemplate = FS.FLAGTEMPLATES.Where(n => n.ID == "FLAG." + newSide + "." + oldSide).Single();
            GO flagClone = FS.TYPELOCATION(GS, "POSSESSIONFLAG", loc.ID).FirstOrDefault();
            //if clone doesn't already exists, create here
            if (flagClone == null)
            {
                flagClone = FS.CLONE(GS, flagTemplate, loc.ID);
                flagClone.LABEL = flagTemplate.LABEL;
                flagClone.LABEL ??= loc.LABEL;
                flagClone.COUNTRY ??= loc.COUNTRY;
                flagClone.SIDE = newSide;
                flagClone.LOGISTICALZONE = loc.LOGISTICALZONE;
                flagClone.SUPPLIES = loc.SUPPLIES;
                flagClone.SUPPLYPRODUCTIONRATE = loc.SUPPLYPRODUCTIONRATE;
                flagClone.STRENGTH = loc.STRENGTH;
                flagClone.STRENGTHPRODUCTIONRATE = loc.STRENGTHPRODUCTIONRATE;
                GS.ShuffleMarkerToBottom(flagClone);
            }
            else
            {
                flagClone.IMAGEFILE = flagTemplate.IMAGEFILE;
                flagClone.SIDE = newSide;
                GS.CHANGELOCATION(flagClone, loc);
            }

            return flagClone;
        }
        public static void ALIGNCOUNTRY(GameScenario GS, string COUNTRY, string SIDE)
        {
            GS.Set(COUNTRY + ".SIDE", SIDE);
            foreach (GO flag in GS.TYPE("POSSESSIONFLAG").Where(n => n.COUNTRY == COUNTRY).ToList())
            {
                GO flagClone = FS.UPDATELOGISTICALBASE(flag.GAMELOCATION, SIDE, SIDE);
            }
            foreach (GO hex in GS.LOCATIONS().Where(n => n.COUNTRY == COUNTRY))
            {
                hex.SIDE = SIDE;
                hex.INITSIDE = hex.SIDE;
                if (hex.PORT || hex.AIRFIELD)
                {
                    FS.UPDATEBASE(hex.GAMEPIECE, FS.FACILITYTEMPLATES.Where(n => n.ID == hex.SIDE + (hex.PORT ? ".PORT" : "") + (hex.AIRFIELD ? ".AIRFIELD" : "")).Single(), hex);
                }
                if(hex.CLOSEDEFENSE)
                {
                    FS.UPDATECLOSEDEFENSE(hex.CLOSEDEFENSEFACILITY, FS.CLOSEDEFENSETEMPLATES.Where(n => n.ID == hex.SIDE + ".CLOSEDEFENSE").Single(), hex);
                }
            }
            foreach (string s in new List<string> { "NEUT", "SOV", "ALLIES" })
            {
                foreach (GO obj in FS.TYPESIDE(GS, "PIECE", s).Where(n => n.TYPE != "POSSESSIONFLAG" && n.COUNTRY == COUNTRY))
                {
                    obj.SIDE = SIDE;
                    obj.INITSIDE = obj.SIDE;
                    if (obj.TEMPLATEID != null)
                    {
                        if (FS.GENERICCOUNTRIES.Contains(obj.TEMPLATE.COUNTRY))
                        {
                            List<string> ss = obj.TEMPLATE.ID.Split('.').ToList();
                            ss[0] = obj.SIDE;
                            obj.TEMPLATEID = string.Join('.', ss);
                        }
                    }
                }
            }
        }
        public static void CONQUERLOGISTICALZONE(GO logisticalBase)
        {
            string SIDE = FS.ENEMY(logisticalBase.SIDE);
            GameScenario GS = logisticalBase.GS;
            FS.UPDATELOGISTICALBASE(logisticalBase, logisticalBase.SIDE, SIDE);
            logisticalBase.STRENGTHPRODUCTIONRATE *= 0.25;
            logisticalBase.SUPPLYPRODUCTIONRATE *= 0.25;

            foreach (GO hex in GS.LOCATIONS().Where(n => n.LOGISTICALZONE == logisticalBase.LOGISTICALZONE))
            {
                hex.SIDE = SIDE;
                DESTROYAIRATAIRFIELD(hex, FS.ENEMY(SIDE));
                CONQUERBASE(hex);
            }
        }
        public static void CONQUERBASE(GO hex)
        {
            if (hex.PORT || hex.AIRFIELD)
            {
                FS.UPDATEBASE(hex.GAMEPIECE, FS.FACILITYTEMPLATES.Where(n => n.ID == hex.SIDE + (hex.PORT ? ".PORT" : "") + (hex.AIRFIELD ? ".AIRFIELD" : "")).Single(), hex);
                if (hex.PORT)
                {
                    FS.DESTROYBASE(hex, "PORT");
                }
                if (hex.AIRFIELD)
                {
                    FS.DESTROYBASE(hex, "AIRFIELD");
                }
            }
            if(hex.CLOSEDEFENSE)
            {
                FS.UPDATECLOSEDEFENSE(hex.CLOSEDEFENSEFACILITY, FS.CLOSEDEFENSETEMPLATES.Where(n => n.ID == hex.SIDE + ".CLOSEDEFENSE").Single(), hex);
                FS.DESTROYBASE(hex, "CLOSEDEFENSE");
            }            
        }
        public static GO CREATEOBJECTIVE(string side, GO loc)
        {
            GameScenario GS = loc.GS;
            GO objectiveTemplate = FS.OBJECTIVETEMPLATES.Where(n => n.ID == side + ".OBJECTIVE").Single();
            GO clone = FS.CLONE(GS, objectiveTemplate, loc.ID);
            clone.SIDE = side;
            GS.ShuffleMarkerToBottom(clone);
            return clone;
        }
        public static GO CREATEOBJECTIVELOGIC(string side, GO loc)
        {
            GameScenario GS = loc.GS;
            GO objectiveTemplate = FS.OBJECTIVELOGICTEMPLATES.Where(n => n.ID == side + ".OBJECTIVELOGIC").Single();
            Dictionary<string, string> clonedData = new(objectiveTemplate._data)
            {
                ["ID"] = objectiveTemplate.ID + GO.DELIM + loc.ID + GO.DELIM + GENERATETIMESTAMP(),
                ["TYPE"] = "OBJECTIVELOGIC"
            };
            GO clone = new(GS, clonedData, null, null);
            GS.CHANGELOCATION(clone, loc.ID);
            clone.LABEL = clone.ID;
            clone.SIDE = side;
            clone.OBJECTIVETYPE = "PATROL";
            clone.VP_MULTIPLE = 0;
            GS.ShuffleMarkerToBottom(clone);
            return clone;
        }
        public static GO CREATEDEPLOYMENTLOGIC(string side, GO loc)
        {
            GameScenario GS = loc.GS;
            GO objectiveTemplate = FS.DEPLOYMENTLOGICTEMPLATES.Where(n => n.ID == side + ".DEPLOYMENTLOGIC").Single();
            Dictionary<string, string> clonedData = new(objectiveTemplate._data)
            {
                ["ID"] = objectiveTemplate.ID + GO.DELIM + loc.ID + GO.DELIM + GENERATETIMESTAMP(),
                ["TYPE"] = "DEPLOYMENTLOGIC"
            };
            GO clone = new(GS, clonedData, null, null);
            GS.CHANGELOCATION(clone, loc.ID);
            clone.LABEL = clone.ID;
            clone.SIDE = side;
            clone.DEPLOYMENTTYPE = "SHIP";
            GS.ShuffleMarkerToBottom(clone);
            return clone;
        }
        public static GO CREATETRIGGERLOGIC(string side, GO loc)
        {
            GameScenario GS = loc.GS;
            GO objectiveTemplate = FS.TRIGGERLOGICTEMPLATES.Where(n => n.ID == side + ".TRIGGERLOGIC").Single();
            Dictionary<string, string> clonedData = new(objectiveTemplate._data)
            {
                ["ID"] = objectiveTemplate.ID + GO.DELIM + loc.ID + GO.DELIM + GENERATETIMESTAMP(),
                ["TYPE"] = "TRIGGERLOGIC"
            };
            GO clone = new(GS, clonedData, null, null);
            GS.CHANGELOCATION(clone, loc.ID);
            clone.LABEL = clone.ID;
            clone.SIDE = side;
            clone.OBJECTIVE = true;
            GS.ShuffleMarkerToBottom(clone);
            return clone;
        }
        public static GO CREATEGROUP(GameScenario GS, GO obj, string locId)
        {
            Dictionary<string, string> clonedData = new();
            clonedData["ID"] = obj.SIDE + "GROUP" + GO.DELIM + GENERATETIMESTAMP();
            clonedData["DOMAIN"] = "PIECE";
            clonedData["TYPE"] = obj.TYPE;
            clonedData["UNITCATEGORY"] = "SURFACE";
            clonedData["SIDE"] = obj.SIDE;
            clonedData["COUNTRY"] = obj.SIDE == "ALLIES" ? "APW" : "SPW";
            clonedData["GRPTYPE"] = "TFTGGRP";
            GO clone = new(GS, clonedData, null, null);
            clone.UNITTYPE = "TG";
            GS.CHANGELOCATION(clone, locId);
            FS.ADDTOGROUP(obj, clone);
            return clone;
        }
        public static GO CREATEACTIVATIONGROUP(GO obj, string locId)
        {
            GameScenario GS = obj.GS;
            Dictionary<string, string> clonedData = new();
            clonedData["ID"] = obj.SIDE + "ACTGROUP" + GO.DELIM + GENERATETIMESTAMP();
            clonedData["DOMAIN"] = "PIECE";
            clonedData["TYPE"] = obj.TYPE;
            clonedData["UNITCATEGORY"] = obj.UNITCATEGORY;
            clonedData["SIDE"] = obj.SIDE;
            clonedData["COUNTRY"] = obj.SIDE == "ALLIES" ? "APW" : "SPW";
            clonedData["GRPTYPE"] = "ACTIVATIONGRP";
            GO clone = new(GS, clonedData, null, null);
            clone.UNITTYPE = "SHIPGRP";
            GS.CHANGELOCATION(clone, locId);
            FS.ADDTOGROUP(obj, clone);
            return clone;
        }
        public static void ADDTOGROUP(GO obj, GO group)
        {
            GameScenario GS = obj.GS;
            switch (group.GRPTYPE)
            {
                case "TFTGGRP":
                    obj.GROUPID = group.ID;
                    obj.GROUP = group;
                    obj.GROUPINDEX = 999999;
                    break;
                case "ACTIVATIONGRP":
                    obj.ACTIVATIONGRPID = group.ID;
                    obj.ACTIVATIONGRP = group;
                    obj.GROUPINDEX = 999999;
                    break;
                default:
                    obj.CARRIERID = group.ID;
                    obj.CARRIER = group;
                    break;
            }
            FS.UPDATEGROUP(group);
        }
        public static List<GO> GROUPMEMBERS(GO group)
        {
            GameScenario GS = group.GS;
            return group.GRPTYPE == "TFTGGRP" ?
                [.. GS.TYPE("SHIP", "GROUPID", group.ID).OrderBy(n => n.GROUPINDEX)] :
                            group.GRPTYPE == "ACTIVATIONGRP" ?
                                [.. GS.TYPE("PIECE", "ACTIVATIONGRPID", group.ID).OrderBy(n => n.GROUPINDEX)] :
                                    group.TEMPLATE?.AIRUNITS != null ?
                                        GS.TYPE("SQN", "CARRIERID", group.ID) :
                                            new() { group };
        }
        public static void REMOVEFROMGROUP(GO obj, GO group)
        {
            switch (group.GRPTYPE)
            {
                case "TFTGGRP":
                    if(obj.GROUPID == group.ID)
                    {
                        obj.GROUPID = null;
                        obj.GROUPINDEX = 0;
                        FS.UPDATEGROUP(group);
                    }
                    break;
                case "ACTIVATIONGRP":
                    if(obj.ACTIVATIONGRPID == group.ID)
                    {
                        obj.ACTIVATIONGRPID = null;
                        obj.GROUPINDEX = 0;
                        FS.UPDATEGROUP(group);
                    }
                    break;
                default:
                    obj.CARRIERID = null;
                    break;
            }
        }
        public static void MOVEUPINGROUP(GameScenario GS, GO obj, GO group)
        {
            obj.GROUPINDEX--;
            GROUPMEMBERS(group).Where(n => n != obj && n.GROUPINDEX == obj.GROUPINDEX).ToList().ForEach(n => n.GROUPINDEX++);
            FS.UPDATEGROUP(group);
        }
        public static void MOVEDOWNINGROUP(GameScenario GS, GO obj, GO group)
        {
            obj.GROUPINDEX++;
            GROUPMEMBERS(group).Where(n => n != obj && n.GROUPINDEX == obj.GROUPINDEX).ToList().ForEach(n => n.GROUPINDEX--);
            FS.UPDATEGROUP(group);
        }
        public static void UPDATEGROUP(GO group)
        {
            if(!FS.ISGROUP(group)){ return; }
            bool canBeEmpty = FS.CREATE_TF_PHASE || FS.CREATE_ACTGRP_PHASE;
            GameScenario GS = group.GS;
            //for simplicity, AI player can have Activation groups active throughout turn, think of just as a stack
            bool AIACTIVE = GS.AI_Sides.Contains(group.SIDE); // GS.GetBoolean("AI.ACTIVATIONGROUPS") && GS.AI_Sides.Contains(group.SIDE);
            List<GO> groupMembers = GROUPMEMBERS(group);
            switch(group.UNITCATEGORY)
            {
                case "SURFACE":
                    List<GO> combatships = [.. groupMembers.Where(n => SURFACECOMBATTYPES.Contains(n.UNITTYPE))];
                    bool GRPACTIVE = (group.ACTIVATED && !group.DONE) || AIACTIVE;
                    if (!canBeEmpty && !GRPACTIVE && group.GRPTYPE == "TFTGGRP" && combatships.Count <= 1)
                    {
                        groupMembers.ForEach(n => REMOVEFROMGROUP(n, group));
                        groupMembers.Clear();
                    }
                    if (!canBeEmpty && groupMembers.Count == 1)
                    {
                        groupMembers.ForEach(n => REMOVEFROMGROUP(n, group));
                        groupMembers.Clear();
                    }
                    if (groupMembers.Count > 0)
                    {
                        string unitType = "";
                        switch (combatships.Count)
                        {
                            case 0:
                            case 1:
                                unitType = FS.CREATE_TF_PHASE ? "TG" : "SHIPGRP";
                                break;
                            case 2:
                            case 3:
                                unitType = FS.CREATE_TF_PHASE || group.GRPTYPE == "TFTGGRP" || AIACTIVE ? "TG" : "SHIPGRP";
                                break;
                            default:
                                unitType = FS.CREATE_TF_PHASE || group.GRPTYPE == "TFTGGRP" || AIACTIVE ? "TF" : "SHIPGRP";
                                break;
                        }
                        if (unitType != group.UNITTYPE || group.TEMPLATEID == null)
                        {
                            group.UNITTYPE = unitType;
                            group.TEMPLATEID = group.SIDE + GO.DELIM + unitType;
                            if (unitType == "SHIPGRP")
                            {
                                group.GRPTYPE = "ACTIVATIONGRP";
                                groupMembers.ForEach(n => n.GROUPID = null);
                                groupMembers.ForEach(n => n.ACTIVATIONGRPID = group.ID);
                            }
                            else
                            {
                                group.GRPTYPE = "TFTGGRP";
                                groupMembers.ForEach(n => n.GROUPID = group.ID);
                                groupMembers.ForEach(n => n.ACTIVATIONGRPID = null);
                            }
                        }
                        group.IMAGEFILE = groupMembers.First().TEMPLATE.IMAGEFILE;
                        group.LABEL = group.SIDE + " " + unitType;
                        group.MOVEMENTALLOWANCE = groupMembers.Min(n => n.MOVEMENTALLOWANCE);
                        group.ENROUTEDELAY = groupMembers.Max(n => n.ENROUTEDELAY);
                        group.STRATDETECTED = groupMembers.Where(n => n.STRATDETECTED).Any();
                        group.LOCALDETECTED = groupMembers.Where(n => n.LOCALDETECTED).Any() || group.STRATDETECTED;
                        group.ADMINDETECTED = groupMembers.Where(n => n.ADMINDETECTED).Any();group.FULLSPEED = groupMembers.Where(n => n.FULLSPEED).Any();
                        group.PCCOONLY = !groupMembers.Where(n => !FS.SHOALTYPES.Contains(n.UNITTYPE)).Any();
                        int index = 0;
                        foreach (GO member in groupMembers)
                        {
                            member.GROUPINDEX = index;
                            index++;
                            member.ENROUTEDELAY = group.ENROUTEDELAY;
                            member.STRATDETECTED = group.STRATDETECTED;
                            member.LOCALDETECTED = group.LOCALDETECTED;
                            member.ADMINDETECTED = group.ADMINDETECTED;
                            if (member.TEMPLATE.AIRUNITS != null)
                            {
                                foreach (GO airunit in GS.TYPE("SQN", "CARRIERID", member.ID))
                                {
                                    airunit.ENROUTEDELAY = group.ENROUTEDELAY;
                                }
                            }
                        }
                    }
                    else
                    {
                        FS.DISCARDTAGGED(group);
                    }
                    break;
                case "AIR":
                    if (groupMembers.Any())
                    {
                        string unitType = "SQNGRP";
                        if (unitType != group.UNITTYPE || group.TEMPLATEID == null)
                        {
                            group.UNITTYPE = unitType;
                            group.TEMPLATEID = group.SIDE + GO.DELIM + unitType;
                        }
                        group.IMAGEFILE = groupMembers.First().TEMPLATE.IMAGEFILE;
                        group.LABEL = group.SIDE + " " + unitType;
                        group.MOVEMENTALLOWANCE = groupMembers.Min(n => n.MOVEMENTALLOWANCE);
                        group.STRATDETECTED = groupMembers.Where(n => n.STRATDETECTED).Any();
                        group.LOCALDETECTED = groupMembers.Where(n => n.LOCALDETECTED).Any() || group.STRATDETECTED;
                        group.ADMINDETECTED = groupMembers.Where(n => n.ADMINDETECTED).Any();
                        group.FULLSPEED = groupMembers.Where(n => n.FULLSPEED).Any();
                        group.PCCOONLY = !groupMembers.Where(n => !FS.SHOALTYPES.Contains(n.UNITTYPE)).Any();
                        int index = 0;
                        foreach (GO member in groupMembers.OrderBy(n => n.GROUPINDEX))
                        {
                            member.GROUPINDEX = index;
                            member.STRATDETECTED = group.STRATDETECTED;
                            member.LOCALDETECTED = group.LOCALDETECTED;
                            member.ADMINDETECTED = group.ADMINDETECTED;
                            index++;
                        }
                    }
                    else
                    {
                        FS.DISCARDTAGGED(group);
                    }
                    break;
                default:
                    break;
            }
            
        }
        public static GO CREATECONVOY(GO obj, string unitType, string locId)
        {
            GameScenario GS = obj.GS;
            GO template = GS.PIECE(obj.SIDE + "." + unitType);
            Dictionary<string, string> clonedData = new(){
                {"ID", obj.SIDE + unitType + "CONVOY" + GO.DELIM + GENERATETIMESTAMP()},
                {"DOMAIN", GO.DOMAIN_PIECE},
                {"TYPE", "SHIP"},
                {"UNITTYPE", template.UNITTYPE},
                {"UNITCATEGORY", template.UNITCATEGORY},
                {"TEMPLATEID", template.ID},
                {"COUNTRY", template.COUNTRY},
                {"SIDE", obj.SIDE},
                {"LABEL", "Convoy"},
            };
            GO clone = new(GS, clonedData, null, null);
            GS.CHANGELOCATION(clone, locId);
            return clone;
        }
        public static void DAMAGE(GO obj)
        {
            GameScenario GS = obj.GS;
            if (!obj.DESTROYED && !obj.RECYCLED)
            {
                if (obj.TEMPLATE != null)
                {
                    if (obj.TEMPLATE.REPLACEID != null)
                    {
                        GO newTemplate = GS.PIECE(obj.TEMPLATE.REPLACEID);
                        obj.TEMPLATEID = newTemplate.ID;
                        obj.TEMPLATE = newTemplate;
                        obj.DAMAGED = true;
                        if (obj.UNITCATEGORY == "AIR")
                        {
                            if (obj.BOMBPTS > 0)
                            {
                                obj.SPECIAL = FS.GETAIRBOMB(obj);
                            }
                            if (obj.SSMPTS > 0)
                            {
                                obj.SSM = FS.GETAIRSSM(obj);
                            }
                        }
                    }
                    else
                    {
                        DESTROY(obj);
                    }
                }
                else
                {
                    DESTROY(obj);
                }
            }
        }
        public static void DESTROY(GO obj)
        {
            GameScenario GS = obj.GS;
            if (!obj.DESTROYED && !obj.RECYCLED)
            {
                //immediately destroy any aircraft aboard
                if (obj.TEMPLATE?.AIRUNITS != null)
                {
                    FS.GROUPMEMBERS(obj).ForEach(n => GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(n) * (n.DAMAGED ? 0.5 : 1)));
                    FS.GROUPMEMBERS(obj).ForEach(DESTROY);
                }
                REMOVESCENARIOOBJECT(GS, obj, true);
                GO group = LOGICALPARENT(obj);
                if (group != obj)
                {
                    REMOVEFROMGROUP(obj, group);
                }
                obj.SetToOriginalState();
                obj.SavedState.Clear();
                GS.CHANGELOCATION(obj, "ALLDESTROYED");
                obj.DESTROYED = true;
                obj.SIDE = null;
                obj.CARRIERID = null;
                obj.HIDDEN = false;
            }
            GS.REMOVEINTERACTIVE(obj);
            foreach (GO c in GS.LOGICS().Where(n => n.UNIT == obj))
            {
                DISCARDLOGIC(c);
            }
        }
        public static void DAMAGEBASE(GO obj, string baseTarget)
        {
            GameScenario GS = obj.GS;
            if (baseTarget == "AIRFIELD")
            {
                if (!obj.AIRFIELDDESTROYED)
                {
                    obj.AIRFIELDDAMAGELEVEL++;
                    obj.GAMEPIECE.AIRFIELDDAMAGELEVEL++;
                    if (obj.AIRFIELDDAMAGELEVEL >= 4)
                    {
                        DESTROYAIRATAIRFIELD(obj, obj.SIDE);
                        DESTROYBASE(obj, baseTarget);

                    }
                }
            }
            else if(baseTarget == "PORT")
            {
                if (!obj.PORTDESTROYED)
                {
                    obj.PORTDAMAGELEVEL++;
                    obj.GAMEPIECE.PORTDAMAGELEVEL++;
                    if (obj.PORTDAMAGELEVEL >= 4)
                    {
                        DESTROYBASE(obj, baseTarget);
                    }
                }
            }
            else if(baseTarget == "CLOSEDEFENSE")
            {
                if (!obj.CLOSEDEFENSEDESTROYED)
                {
                    obj.CLOSEDEFENSEDAMAGELEVEL++;
                    if(obj.CLOSEDEFENSEFACILITY == null){
                        FS.UPDATECLOSEDEFENSE(obj.CLOSEDEFENSEFACILITY, FS.CLOSEDEFENSETEMPLATES.Where(n => n.ID == obj.SIDE + ".CLOSEDEFENSE").Single(), obj);
                    }
                    obj.CLOSEDEFENSEFACILITY.CLOSEDEFENSEDAMAGELEVEL++;
                    if (obj.CLOSEDEFENSEDAMAGELEVEL >= 4)
                    {
                        DESTROYBASE(obj, baseTarget);
                    }
                }
            }
        }
        public static void DESTROYBASE(GO obj, string baseTarget)
        {
            GameScenario GS = obj.GS;
            if (baseTarget == "AIRFIELD")
            {
                if (!obj.AIRFIELDDESTROYED)
                {
                    obj.AIRFIELDDAMAGELEVEL = 4;
                    obj.AIRFIELDDESTROYED = true;
                    obj.GAMEPIECE.AIRFIELDDAMAGELEVEL = 4;
                    obj.GAMEPIECE.AIRFIELDDESTROYED = true;
                }
            }
            else if(baseTarget == "PORT")
            {
                if (!obj.PORTDESTROYED)
                {
                    obj.PORTDAMAGELEVEL = 4;
                    obj.PORTDESTROYED = true;
                    obj.GAMEPIECE.PORTDAMAGELEVEL = 4;
                    obj.GAMEPIECE.PORTDESTROYED = true;
                }
            }
            else if(baseTarget == "CLOSEDEFENSE")
            {
                if (!obj.CLOSEDEFENSEDESTROYED)
                {
                    obj.CLOSEDEFENSEDAMAGELEVEL = 4;
                    obj.CLOSEDEFENSEDESTROYED = true;
                    if(obj.CLOSEDEFENSEFACILITY == null){
                        FS.UPDATECLOSEDEFENSE(obj.CLOSEDEFENSEFACILITY, FS.CLOSEDEFENSETEMPLATES.Where(n => n.ID == obj.SIDE + ".CLOSEDEFENSE").Single(), obj);
                    }
                    obj.CLOSEDEFENSEFACILITY.CLOSEDEFENSEDAMAGELEVEL = 4;
                    obj.CLOSEDEFENSEFACILITY.CLOSEDEFENSEDESTROYED = true;
                }
            }
        }
        public static void DESTROYAIRATAIRFIELD(GO location, string side){
            //destroy any aircraft currently on it
            foreach (GO sqn in FS.TYPESIDELOCATION(location.GS, "SQN", side, location.ID).Where(n => 
                !FS.ISGROUP(n) && 
                FS.LOGICALPARENT(n) == n && 
                n.HOMEBASE == null))
            {
                location.GS.IncrementDouble("VP." + FS.ENEMY(sqn.SIDE), FS.VPVALUE(sqn) * (sqn.DAMAGED ? 0.5 : 1)); 
                FS.DESTROY(sqn);
            }
        }
        public static void DISCARDTAGGED(GO obj)
        {
            if(obj.GS == null){
                return;
            }
            REMOVESCENARIOOBJECT(obj.GS, obj, true);
            obj.GS.DISCARD(obj);
        }
        public static void REPAIR(GO obj)
        {
            if (obj.DOMAIN == GO.DOMAIN_LOCATION)
            {
                if (obj.PORT && !obj.PORTDESTROYED && obj.PORTDAMAGELEVEL > 0)
                {
                    obj.PORTDAMAGELEVEL = Math.Max(0, obj.PORTDAMAGELEVEL - 1);
                    obj.GAMEPIECE.PORTDAMAGELEVEL = Math.Max(0, obj.GAMEPIECE.PORTDAMAGELEVEL - 1);
                }
                if (obj.AIRFIELD && !obj.AIRFIELDDESTROYED && obj.AIRFIELDDAMAGELEVEL > 0)
                {
                    obj.AIRFIELDDAMAGELEVEL = Math.Max(0, obj.AIRFIELDDAMAGELEVEL - 1);
                    obj.GAMEPIECE.AIRFIELDDAMAGELEVEL = Math.Max(0, obj.GAMEPIECE.AIRFIELDDAMAGELEVEL - 1);
                }
                if (obj.CLOSEDEFENSE && !obj.CLOSEDEFENSEDESTROYED && obj.CLOSEDEFENSEDAMAGELEVEL > 0)
                {
                    obj.CLOSEDEFENSEDAMAGELEVEL = Math.Max(0, obj.CLOSEDEFENSEDAMAGELEVEL - 1);
                    if(obj.CLOSEDEFENSEFACILITY == null){
                        FS.UPDATECLOSEDEFENSE(obj.CLOSEDEFENSEFACILITY, FS.CLOSEDEFENSETEMPLATES.Where(n => n.ID == obj.SIDE + ".CLOSEDEFENSE").Single(), obj);
                    }
                    obj.CLOSEDEFENSEFACILITY.CLOSEDEFENSEDAMAGELEVEL = Math.Max(0, obj.CLOSEDEFENSEFACILITY.CLOSEDEFENSEDAMAGELEVEL - 1);
                }
            }
            else if (!obj.DESTROYED && !obj.RECYCLED)
            {
                if (obj.TEMPLATE != null)
                {
                    if (obj.TEMPLATE.REPLACEID == null)
                    {
                        GO newTemplate = obj.GS.PIECE(obj.TEMPLATEID.Replace(".DMG", ""));
                        obj.TEMPLATEID = newTemplate.ID;
                        obj.TEMPLATE = newTemplate;
                        obj.DAMAGED = false;
                        if(obj.UNITCATEGORY == "AIR")
                        {
                            if(obj.BOMBPTS > 0)
                            {
                                obj.SPECIAL = FS.GETAIRBOMB(obj);
                            }
                            if(obj.SSMPTS > 0)
                            {
                                obj.SSM = FS.GETAIRSSM(obj);
                            }
                        }
                    }
                }
            }
        }
        public static GO PARENTGROUPLOCATION(GO obj)
        {
            return LOCATIONPARENT(obj).GAMELOCATION;
        }
        public static GO LOCATIONPARENT(GO obj)
        {
            GO objAtLocation = obj;
            objAtLocation = objAtLocation.CARRIERID != null ? objAtLocation.CARRIER : objAtLocation;
            objAtLocation = objAtLocation.ACTIVATIONGRPID != null ? objAtLocation.ACTIVATIONGRP : objAtLocation;
            objAtLocation = objAtLocation.GROUPID != null ? objAtLocation.GROUP : objAtLocation;
            return objAtLocation;
        }
        public static GO LOGICALPARENT(GO obj)
        {
            if (obj.CARRIERID != null) { return obj.CARRIER; }
            if (obj.ACTIVATIONGRPID != null) { return obj.ACTIVATIONGRP; }
            if (obj.GROUPID != null) { return obj.GROUP; }
            return obj;
        }
        public static Dictionary<string, Dictionary<int, string>> RANDOMZONETABLE = new(){
            {"CARIBBEAN", new(){
                {0, "LESSER ANTILLES|PUERTO RICO|VENEZUELA"},
                {1, "ATLANTIC|BAHAMAS"},
                {2, "FLORIDA|WINDWARD PASSAGE"},
                {3, "PANAMA CANAL|WESTERN CARIBBEAN"},
                {4, "FLORIDA|VENEZUELA|ATLANTIC"},
                {5, "WESTERN CARIBBEAN|BAHAMAS"},
                {6, "WINDWARD PASSAGE|LESSER ANTILLES"},
                {7, "PANAMA CANAL|PUERTO RICO"},
                {8, "FLORIDA|WESTERN CARIBBEAN|PANAMA CANAL|LESSER ANTILLES|PUERTO RICO"},
                {9, "BAHAMAS|WINDWARD PASSAGE|VENEZUELA|ATLANTIC"}
            }},
            {"NPACIFIC", new(){
                {0, "KAMCHATKA"},
                {1, "ALEUTIAN"},
                {2, "KAMCHATKA"},
                {3, "ALEUTIAN"},
                {4, "KAMCHATKA"},
                {5, "ALEUTIAN"},
                {6, "KAMCHATKA"},
                {7, "ALEUTIAN"},
                {8, "KAMCHATKA"},
                {9, "ALEUTIAN"}
            }},
            {"ATLANTIC", new(){
                {0, "BALTIC SEA|BOTHNIA GULF|NORTH SEA|CAPE FAREWELL|BARENTS SEA|LABRADOR SEA"},
                {1, "IRELAND|WESTERN APPROACHES|SVALBARD"},
                {2, "NORTH ATLANTIC|AZORES|NORWEGIAN SEA"},
                {3, "BAY OF BISCAY|IBERIAN|CAPE FAREWELL|GREENLAND|ICELAND SEA"},
                {4, "NORTH ATLANTIC|BAY OF BISCAY|BALTIC SEA|BOTHNIA GULF|WESTERN APPROACHES|BARENTS SEA|SVALBARD|LABRADOR SEA"},
                {5, "AZORES|IRELAND|NORTH SEA|GREENLAND|ICELAND SEA|NORWEGIAN SEA"},
                {6, "NORTH ATLANTIC|BALTIC SEA|BOTHNIA GULF|IBERIAN|SVALBARD|NORWEGIAN SEA"},
                {7, "AZORES|CAPE FAREWELL|WESTERN APPROACHES|BARENTS SEA|GREENLAND"},
                {8, "NORTH ATLANTIC|BALTIC SEA|BOTHNIA GULF|NORTH SEA|CAPE FAREWELL|WESTERN APPROACHES|BARENTS SEA|SVALBARD"},
                {9, "AZORES|BAY OF BISCAY|IBERIAN|IRELAND|BARENTS SEA|SVALBARD|GREENLAND|ICELAND SEA|LABRADOR SEA|NORWEGIAN SEA"}
            }},
            {"MED", new(){
                {0, "CENTRAL MEDITERRANEAN|AEGEAN|EASTERN MEDITERRANEAN"},
                {1, "WESTERN MEDITERRANEAN|THYRRENIAN SEA"},
                {2, "ADRIATIC|BLACK SEA"},
                {3, "ADRIATIC|EASTERN MEDITERRANEAN"},
                {4, "THYRRENIAN SEA|CENTRAL MEDITERRANEAN|BLACK SEA"},
                {5, "WESTERN MEDITERRANEAN|AGEAN"},
                {6, "CENTRAL MEDITERRANEAN|THYRRENIAN SEA|ADRIATIC"},
                {7, "WESTERN MEDITERRANEAN|EASTERN MEDITERRANEAN|BLACK SEA"},
                {8, "THYRRENIAN SEA|CENTRAL MEDITERRANEAN|AEGEA|EASTERN MEDITERRANEAN|BLACK SEA"},
                {9, "WESTERN MEDITERRANEAN|ADRIATIC|AEGEAN"}
            }},
            {"INDIAN", new(){
                {0, "WEST INDIAN OCEAN|EAST INDIAN OCEAN|CHAGOS ARCHIPELAGO"},
                {1, "PERSIAN GULF|SAUDI ARABIA|GULF OF OMAN"},
                {2, "BAY OF BENGAL|INDIA|NORTH ARABIAN SEA|SUMATRA"},
                {3, "GULF OF ADEN|SOCOTRA|MALDIVES|LACCADIVES"},
                {4, "PERSIAN GULF|BAY OF BENGAL|SOUTH ARABIAN SEA|SRI LANKA"},
                {5, "SAUDI ARABIA|INDIA|NORTH ARABIAN SEA|SUMATRA|MALDIVES"},
                {6, "BAY OF BENGAL|INDIA|NORTH ARABIAN SEA|GULF OF ADEN|SOUTH ARABIAN SEA"},
                {7, "GULF OF OMAN|INDIA|SUMATRA|SOCOTRA|LACCADIVES|SRI LANKA"},
                {8, "EAST INDIAN OCEAN|CHAGOS ARCHIPELAGO|BAY OF BENGAL|INDIA|SUMATRA|MALDIVES|LACCADIVES|SRI LANKA"},
                {9, "WEST INDIAN OCEAN|PERSIAN GULF|SAUDI ARABIA|GULF OF OMAN|NORTH ARABIAN SEA|GULF OF ADEN|SOCOTRA|SOUTH ARABIAN SEA"}
            }},
            {"PACIFIC", new(){
                {0, "SEA OF OKHOTSK|NORTHWEST PACIFIC|NORTH PACIFIC"},
                {1, "SEA OF OKHOTSK|HOKKAIDO|NORTHWEST PACIFIC"},
                {2, "SEA OF OKHOTSK|HOKKAIDO|SEA OF JAPAN"},
                {3, "NORTHWEST PACIFIC|JAPAN|NORTH PACIFIC"},
                {4, "BONIN ISLANDS|SOUTH PACIFIC|MARIANAS"},
                {5, "BONIN ISLANDS|PHILIPPINES|CENTRAL PACIFIC|EAST CHINA SEA|YELLOW SEA"},
                {6, "SEA OF OKHOTSK|NORTH PACIFIC|SOUTH CHINA SEA|FORMOSA|HAINAN"},
                {7, "HOKKAIDO|NORTHWEST PACIFIC|SEA OF JAPAN|JAPAN"},
                {8, "BONIN ISLANDS|SEA OF OKHOTSK|HOKKAIDO|NORTHWEST PACIFIC|SEA OF JAPAN|JAPAN|NORTH PACIFIC"},
                {9, "SOUTH CHINA SEA|PHILIPPINES|SOUTH PACIFIC|CENTRAL PACIFIC|FORMOSA|EAST CHINA SEA|MARIANAS|HAINAN|YELLOW SEA"}
            }},
        };

        public static string WEATHER(GameScenario GS, string zone)
        {
            return GS.Get(zone + ".WEATHER");
        }
        public static string WEATHER(GO location)
        {
            return WEATHER(location.GS, location.ZONE);
        }
        public static bool STORM(GO location)
        {
            return WEATHER(location.GS, location.ZONE) == "STORM";
        }
        public static bool SQUALL(GO location)
        {
            return WEATHER(location.GS, location.ZONE) == "SQUALL";
        }
        public static bool UNDERCOMMANDFAILURE(GO location, string side, bool strategic)
        {
            return UNDERCOMMANDFAILURE(location.GS, location.ZONE, side, strategic);
        }
        public static bool UNDERCOMMANDFAILURE(GameScenario GS, string zone, string side, bool strategic)
        {
            if (GS.GetBoolean("_CONFIG_COMMAND_FAILURE_EFFECTS_ACTIVATIONS_AND_FRIENDLY_CAP") || strategic)
            {
                if (GS.Get("RANDOM.COMMANDFAILURE") == side)
                {
                    return FS.SCENARIOSTRINGS(GS, "RANDOM.COMMANDFAILUREZONES").Contains(zone);
                }
            }
            return false;
        }
        public static Dictionary<GO, List<List<GO>>> DETECTIONRADIUSTABLE(GameScenario GS)
        {
            List<string> STORMZONES = ZONECONNECTIONS.Keys.Where(n => WEATHER(GS, n) == "STORM").ToList();
            List<string> SQUALLZONES = ZONECONNECTIONS.Keys.Where(n => WEATHER(GS, n) == "SQUALL").ToList();
            Dictionary<GO, List<List<GO>>> DetectionRadius = [];
            foreach (string s in FS.SIDE_NAMES)
            {
                foreach (GO obj in FS.TYPESIDE(GS, "SHIP", s).Where(n => !FS.ISGROUP(n)))
                {
                    GO loc = obj.GAMELOCATION;
                    if (loc.TYPE == "HEX")
                    {
                        if (obj.UNITCATEGORY == "SURFACE" && STORMZONES.Contains(loc.ZONE)) { continue; }
                        List<GO> r1 = FS.FINDAIRRADIUS(loc, 1);
                        List<GO> r2 = FS.FINDAIRRADIUS(loc, 2);
                        if (obj.UNITCATEGORY == "SURFACE")
                        {
                            r1.RemoveAll(n => STORMZONES.Contains(n.ZONE));
                            r2.RemoveAll(n => STORMZONES.Contains(n.ZONE));
                        }
                        List<GO> SubRadius = [..r1];
                        List<GO> SurfaceRadius1 = [..r1];
                        List<GO> SurfaceRadius2 = SQUALLZONES.Contains(loc.ZONE) || obj.UNITCATEGORY == "SUB" ? [..r1] : [..r2];
                        DetectionRadius.Add(obj, new() { SurfaceRadius1, SurfaceRadius2, SubRadius });
                    }
                }
            }
            return DetectionRadius;
        }
        public static string SUBDETECTIONRESULT(GO obj, string phase, string combat, List<GO> detectors)
        {
            string result = "";
            string priorStatus = (obj.LOCALDETECTED || obj.STRATDETECTED ? "D" : "U");
            double totalASW = detectors.Sum(n => Math.Max(n.ASW, n.TEMPLATE?.ASW ?? 0));
            string report = obj.LABEL + " " + phase + " " + (phase.StartsWith("REALTIME") ? "CYCLE" + (obj.GS.GetInt("ACTION.CYCLES") + 1) + " " : "") + combat + " " + totalASW;
            double noise = obj.TEMPLATE.NOISELEVEL;
            int modifier = 0;
            if (obj.DEEPMODE) { modifier += 2; }
            if (obj.GAMELOCATION.FJORD || obj.GAMELOCATION.RESTRICTED || (obj.GAMELOCATION.SHALLOW && obj.UNITTYPE != "SS")) { modifier -= 3; }
            switch (phase)
            {
                case "STRATRECON":
                    if (totalASW >= 8) { modifier -= 3; }
                    else if (totalASW >= 6) { modifier -= 2; }
                    else if (totalASW >= 4) { modifier -= 1; }
                    break;
                case "REALTIME":
                case "REALTIMETRACKED":
                case "REALTIMEMOVINGTRACKED":
                case "REALTIMEMOVING":
                    bool tracked = phase.Contains("TRACKED");
                    bool moving = phase.Contains("MOVING");
                    int modifier2 = moving ? 3 : 2;
                    if (obj.LOCALDETECTED || obj.STRATDETECTED) { modifier -= modifier2; }
                    if (tracked) { modifier -= modifier2; }
                    if (totalASW >= 26) { modifier -= 3; }
                    else if (totalASW >= 18) { modifier -= 2; }
                    else if (totalASW >= 10) { modifier -= 1; }
                    break;
                default:
                    if (combat != null)
                    {
                        if (obj.UNITTYPE == "SS" || combat == "CM" || combat == "SSM") { modifier -= 4; }
                        else { modifier -= 2; }
                    }
                    if (totalASW >= 26) { modifier -= 3; }
                    else if (totalASW >= 18) { modifier -= 2; }
                    else if (totalASW >= 10) { modifier -= 1; }
                    break;
            }
            double roll = FS.DIEROLL();
            report += ": " + modifier + " + " + roll + " => ";
            result = roll + modifier <= noise ? "D" : "U";
            //MainWindow.Alert(report + priorStatus + " to " + result, true, true);
            return result;
        }
        public static int COMBATRESULTSTABLE(bool attack, int roll, int combatValue)
        {
            if (combatValue < 1) { return 0; }
            List<int> D = new() { -99, -99, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
            List<int> A = new() { -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };
            List<int> CV = new() { 1, 2, 3, 4, 5, 6, 7, 10, 14, 19, 25, 32, 42, 53, 64, 76, 90 };
            combatValue = Math.Min(CV.Last(), Math.Max(CV.First(), combatValue));
            int[] TABLE = new int[]
            {
                0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,
                0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,
                0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,
                0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,
                0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,
                0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,
                0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,
                0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,
                0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,
                0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,
                0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,
                0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,
                0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,
                0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,
                0,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,
                1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,
                1,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,11
            };
            roll = attack ? Math.Max(A.First(), Math.Min(A.Last(), roll)) : Math.Max(-6, Math.Min(12, roll));
            int row = attack ? A.IndexOf(roll) : D.IndexOf(roll);
            int column = CV.IndexOf(CV.Where(n => combatValue <= n).First());
            int tableIndex = column * D.Count + row;
            return TABLE[tableIndex];
        }
        public static int MINERESULTSTABLE(int roll, int numMines)
        {
            if (numMines == 0) { return 0; }
            List<int> ROLL = new() { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            List<int> NUMMINES = new() { 1, 2, 3, 4 };
            int[] TABLE = new int[]
            {
                1,1,1,1,1,0,0,0,0,0,
                2,1,1,1,1,1,0,0,0,0,
                2,2,2,1,1,1,1,1,0,0,
                3,3,2,2,2,1,1,1,1,0
            };
            roll = Math.Max(0, Math.Min(9, roll));
            int row = ROLL.IndexOf(roll);
            int column = NUMMINES.IndexOf(NUMMINES.Where(n => numMines <= n).First());
            int tableIndex = column * ROLL.Count + row;
            return TABLE[tableIndex];
        }
        public static void ADVANCESIDE(GamePhase gamePhase, string side)
        {
            GameScenario GS = gamePhase.GS;
            if (side == GS.Get("ACTIVE.SIDE1"))
            {
                GS.advanced = true;
                GS.Set("ACTIVE.SIDE", FS.ENEMY(side));
                GS.ResetBetweenUpdates();
                GS.ResetBetweenPhases();
                gamePhase.Start(true);
            }
            else
            {
                GS.Set("ACTIVE.SIDE1", side);
                GS.Done(gamePhase);
            }
        }
        private static bool CANLAUNCH(GO obj)
        {
            if (
                !FS.SIDE_NAMES.Contains(obj.SIDE) ||
                FS.AIRIMMOBILETYPES.Contains(obj.UNITTYPE) ||
                obj.ENROUTEDELAY > 0 ||
                obj.GAMELOCATION.AIRFIELDDAMAGELEVEL > 0
                ) { return false; }
            //check location is in a valid zone
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            if (locationToCheck.TYPE == "ENROUTE") { return false; }
            if (locationToCheck.ZONE == null) { return false; }
            if (!ZONECONNECTIONS.ContainsKey(locationToCheck.ZONE)) { return false; }
            //check weather
            if (STORM(locationToCheck)) { return false; }
            return true;
        }
        public static Dictionary<string, List<string>> MISSIONELIGIBILITY = new(){
            {"INT", new(){"STRATRECON", "STRATINTERCEPTION"}},
            {"ATK", new(){"STRATRECON"}},
            {"BMB", new(){"STRATRECON", "STRATMINING"}},
            {"RCN", new(){"STRATRECON", "STRATTACCOORD", "STRATMINING"}},
            {"EW", new(){"STRATINTERCEPTION"}},
            {"AEW", new(){"STRATRECON"}},
            {"AR", new()},
            {"MSW", new()},
            {"ATR", new()}
        };
        public static bool CANLAUNCHSTRATEGIC(GO obj)
        {
            if (obj.AIRMISSION != null) { return false; }
            if (!FS.MISSIONELIGIBILITY[obj.UNITTYPE].Any()) { return false; }
            if (FS.UNDERCOMMANDFAILURE(FS.PARENTGROUPLOCATION(obj), obj.SIDE, true)) { return false; }
            return CANLAUNCH(obj);
        }
        public static bool CANLAUNCHCAP(GO obj)
        {
            if (obj.AIRMISSION != null) { return false; }
            if (!new List<string>() { "INT", "AEW", "EW" }.Contains(obj.UNITTYPE)) { return false; }
            return CANLAUNCH(obj);
        }
        public static bool CANLAUNCHACTIVATE(GO obj)
        {
            if (obj.AIRMISSION == "CAP") { return false; }
            if (obj.AIRMISSION?.StartsWith("STRAT") == true) { return false; }
            GameScenario GS = obj.GS;
            if (obj.DONE) { return false; }
            //docked carrier
            if (obj.HOMEBASE?.DOCKED == true || obj.HOMEBASE?.REPLENISHING == true || obj.HOMEBASE?.LOADING == true) { return false; }
            if (obj.CARRIER?.DOCKED == true || obj.CARRIER?.REPLENISHING == true || obj.CARRIER?.LOADING == true) { return false; }
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            //check weather
            if (GS.Get(locationToCheck.ZONE + ".WEATHER") == "SQUALL") { return false; }
            if (FS.UNDERCOMMANDFAILURE(locationToCheck, obj.SIDE, false)) { return false; }
            //no fjord
            if (obj.CARRIER != null && locationToCheck.FJORD) { return false; }
            return CANLAUNCH(obj);
        }
        public static bool CANSHIPACTIVATE(GO obj)
        {
            if (!FS.SIDE_NAMES.Contains(obj.SIDE)) { return false; }
            if (obj.DONE) { return false; }
            if (obj.REPLENISHING || obj.LOADING || obj.ENROUTEDELAY > 0) { return false; }
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            if (locationToCheck.TYPE == "ENROUTE") { return false; }
            if (locationToCheck.ZONE == null) { return false; }
            if (!ZONECONNECTIONS.ContainsKey(locationToCheck.ZONE)) { return false; }
            if (FS.ISGROUP(obj))
            {
                if (FS.GROUPMEMBERS(obj).Where(n => !CANSHIPACTIVATE(n)).Any()) { return false; }
            }
            return true;
        }
        public static bool CANSHIPGROUPUP(GO obj)
        {
            if (!FS.SIDE_NAMES.Contains(obj.SIDE)) { return false; }
            if (obj.DONE) { return false; }
            if (obj.ENROUTEDELAY > 0) { return false; }
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            return locationToCheck.TERRAIN == "SEA" || locationToCheck.LOGSEA;
        }
        public static bool CANSHIPLOAD(GO obj)
        {
            if (!(LANDWAR || GARRISONWAR)) { return false; }
            GameScenario GS = obj.GS;
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            if (locationToCheck.SIDE != obj.SIDE) { return false; }
            if (!FS.SIDE_NAMES.Contains(obj.SIDE)) { return false; }
            if (!FS.SURFACELADENTYPES.Contains(obj.UNITTYPE)) { return false; }
            if (!obj.EMPTY) { return false; }
            if (obj.DONE) { return false; }
            if (obj.LOADING || obj.ENROUTEDELAY > 0) { return false; }
            bool cargo = FS.SURFACECARGOTYPES.Contains(obj.UNITTYPE);
            if (locationToCheck.PORT && !obj.DOCKED) { return false; }
            if (!(locationToCheck.PORT || (locationToCheck.LOGSEA && locationToCheck.LOGISTICALBASE))) { return false; }
            if (cargo && (locationToCheck.PORTDAMAGELEVEL > 0 || FS.STORM(locationToCheck))) { return false; }
            if (LANDWAR)
            {
                //find logistical zone marker
                GO logisticalZone = FS.TYPESIDE(GS, "POSSESSIONFLAG", obj.SIDE).Where(n => n.LOGISTICALZONE == locationToCheck.LOGISTICALZONE).Single();
                //confirm loc has enough to load
                if (cargo)
                {
                    if (logisticalZone.SUPPLIES < obj.TEMPLATE.SPECIAL) { return false; }
                }
                else
                {
                    if (logisticalZone.STRENGTH < obj.TEMPLATE.SPECIAL) { return false; }
                }
            }
            else if (GARRISONWAR)
            {
                //find facility
                GO facility = FS.TYPESIDELOCATION(GS, "FACILITY", obj.SIDE, locationToCheck.ID).Where(n => n.PORT).FirstOrDefault();
                if (facility == null) { return false; }
                if (facility.STRENGTH < obj.TEMPLATE.SPECIAL) { return false; }
            }
            return true;
        }
        public static bool CANSHIPUNLOAD(GO obj)
        {
            if (!(LANDWAR || GARRISONWAR)) { return false; }
            GameScenario GS = obj.GS;
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            if (locationToCheck.SIDE != obj.SIDE) { return false; }
            if (!FS.SIDE_NAMES.Contains(obj.SIDE)) { return false; }
            if (!FS.SURFACELADENTYPES.Contains(obj.UNITTYPE)) { return false; }
            if (obj.EMPTY) { return false; }
            if (obj.DONE) { return false; }
            if (obj.LOADING || obj.ENROUTEDELAY > 0) { return false; }
            bool cargo = FS.SURFACECARGOTYPES.Contains(obj.UNITTYPE);
            if (locationToCheck.PORT && !obj.DOCKED) { return false; }
            if (!(locationToCheck.PORT || (locationToCheck.LOGSEA && locationToCheck.LOGISTICALBASE))) { return false; }
            if (cargo && (locationToCheck.PORTDAMAGELEVEL > 0 || FS.STORM(locationToCheck))) { return false; }
            if (GARRISONWAR)
            {
                //find facility
                GO facility = FS.TYPESIDELOCATION(GS, "FACILITY", obj.SIDE, locationToCheck.ID).Where(n => n.PORT).FirstOrDefault();
                if (facility == null) { return false; }
            }
            return true;
        }
        public static bool CANATR(GO obj, bool cargo, bool execute)
        {
            if (!(LANDWAR || (GARRISONWAR && !cargo))) { return false; }
            GameScenario GS = obj.GS;
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            if (locationToCheck.SIDE != obj.SIDE) { return false; }
            if (!FS.SIDE_NAMES.Contains(obj.SIDE)) { return false; }
            if (obj.UNITTYPE != "ATR") { return false; }
            if (!obj.EMPTY) { return false; }
            if (obj.DONE) { return false; }
            if (obj.LOADING || obj.ENROUTEDELAY > 0) { return false; }
            if (!locationToCheck.AIRFIELD) { return false; }
            if (locationToCheck.AIRFIELDDAMAGELEVEL > 0 || FS.STORM(locationToCheck)) { return false; }
            if (LANDWAR)
            {
                //find logistical zone marker
                GO logisticalZone = FS.TYPESIDE(GS, "POSSESSIONFLAG", obj.SIDE).Where(n => n.LOGISTICALZONE == locationToCheck.LOGISTICALZONE).Single();
                //confirm loc has enough to load
                if (cargo)
                {
                    if (logisticalZone.SUPPLIES < obj.TEMPLATE.SPECIAL) { return false; }
                    if (execute)
                    {
                        logisticalZone.SUPPLIES -= obj.TEMPLATE.SPECIAL;
                        obj.EMPTY = false;
                    }
                }
                else
                {
                    if (logisticalZone.STRENGTH < obj.TEMPLATE.SPECIAL) { return false; }
                    if (execute)
                    {
                        logisticalZone.STRENGTH -= obj.TEMPLATE.SPECIAL;
                        obj.EMPTY = false;
                    }
                }
            }
            else if (GARRISONWAR)
            {
                //find facility
                GO facility = FS.TYPESIDELOCATION(GS, "FACILITY", obj.SIDE, locationToCheck.ID).Where(n => n.AIRFIELD).FirstOrDefault();
                if (facility == null) { return false; }
                if (facility.STRENGTH < obj.TEMPLATE.SPECIAL) { return false; }
                if (execute)
                {
                    facility.STRENGTH -= obj.TEMPLATE.SPECIAL;
                    obj.EMPTY = false;
                }
            }
            return true;
        }
        public static List<GO> CAPSQNS(GameScenario GS, string side)
        {
            List<GO> returnList = new();
            if (side == null)
            {
                foreach (string s in FS.SIDE_NAMES)
                {
                    returnList.AddRange(FS.TYPESIDE(GS, "SQN", s).Where(n => n.AIRMISSION == "CAP"));
                }
            }
            else
            {
                returnList.AddRange(FS.TYPESIDE(GS, "SQN", side).Where(n => n.AIRMISSION == "CAP"));
            }
            returnList.RemoveAll(STORM);
            return returnList;
        }
        public static List<GO> EWSQNS(string side, GO location)
        {
            return [.. FS.TYPESIDE(location.GS, "SQN", side).Where(n =>
                n.UNITTYPE == "EW" &&
                (n.AIRMISSION == "CAP" || n.ACTIVATED) &&
                !n.DONE && FS.PARENTGROUPLOCATION(n) == location)];
        }
        public static List<GO> SCENARIOUNITS(GameScenario GS, string variable)
        {
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            return currentObjIds.Select(n => GS.TYPE("ID", null, n).First()).ToList();
        }
        public static List<GO> SCENARIOLOCATIONS(GameScenario GS, string variable)
        {
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            return currentObjIds.Select(n => GS.TYPE("ID", null, n).First()).ToList();
        }
        public static List<GO> SCENARIOLOGICS(GameScenario GS, string variable)
        {
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            return currentObjIds.Select(n => GS.TYPE("ID", null, n).First()).ToList();
        }
        public static List<string> SCENARIOSTRINGS(GameScenario GS, string variable)
        {
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            return currentObjIds;
        }
        public static void SETSCENARIOOBJECTS(GameScenario GS, string variable, List<GO> objs)
        {
            SETSCENARIOSTRINGS(GS, variable, objs.Select(n => n.ID).ToList());
        }
        public static void SETSCENARIOSTRINGS(GameScenario GS, string variable, List<string> objs)
        {
            GS.Set(variable, string.Join('|', objs.Distinct()));
        }
        public static void CLEARSCENARIOVAR(GameScenario GS, string variable)
        {
            GS.Set(variable, null);
        }
        public static void REMOVESCENARIOOBJECT(GameScenario GS, string variable, GO obj)
        {
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            currentObjIds.Remove(obj.ID);
            SETSCENARIOSTRINGS(GS, variable, currentObjIds);
        }
        public static void REMOVESCENARIOOBJECT(GameScenario GS, GO obj, bool full)
        {
            if(GS == null){
                return;
            }
            //remove destination
            if (full && obj.DESTINATIONPIECEID != null)
            {
                obj.DESTINATIONPIECE.GAMEPIECEID = null;
                GS.DISCARD(obj.DESTINATIONPIECE);
                obj.DESTINATIONPIECEID = null;
            }
            //remove from lists
            foreach (string variable in GS.data._data.Keys.Where(n => n.Contains("ACTION.")))
            {
                string value = GS.Get(variable);
                if (value != null && value.Contains(obj.ID))
                {
                    REMOVESCENARIOOBJECT(GS, variable, obj);
                }
            }
            //remove combats and target markers
            foreach (GO c in GS.LOGICS().Where(n => n.ATTACKER == obj || n.INTERCEPTEDGRP == obj))
            {
                DISCARDLOGIC(c);
            }
            if (obj.UNITCATEGORY == "AIR" && obj.ADMINDETECTED)
            {
                obj.ADMINDETECTED = false;
            }
        }
        public static void ADDSCENARIOOBJECT(GameScenario GS, string variable, GO obj)
        {
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            currentObjIds.Add(obj.ID);
            SETSCENARIOSTRINGS(GS, variable, currentObjIds);
        }
        public static bool VALIDHOMEBASE(GO obj)
        {
            if (obj.HOMEBASE == null) { return false; }
            if (obj.HOMEBASE.DOMAIN == GO.DOMAIN_PIECE)
            {
                GO carrier = obj.HOMEBASE;
                if (carrier.DESTROYED) { return false; }
            }
            else
            {
                if (obj.HOMEBASE.AIRFIELDDESTROYED) { return false; }
            }
            return true;
        }
        public static void RETURNTOHOMEBASE(GO obj)
        {
            if (!VALIDHOMEBASE(obj))
            {
                obj.GS.IncrementDouble("VP." + FS.ENEMY(obj.SIDE), FS.VPVALUE(obj) * (obj.DAMAGED ? 0.5 : 1));
                FS.DESTROY(obj);
            }
            else
            {
                if (obj.HOMEBASE.DOMAIN == GO.DOMAIN_PIECE)
                {
                    GO carrier = obj.HOMEBASE;
                    FS.ADDTOGROUP(obj, carrier);
                    //return ammo if possible
                    carrier.AIRSSMPTS += obj.SSMPTS;
                    carrier.BOMBPTS += obj.BOMBPTS;
                    obj.GS.CHANGELOCATION(obj, FS.PARENTGROUPLOCATION(carrier));                    
                }
                else
                {
                    obj.GS.CHANGELOCATION(obj, obj.HOMEBASE);
                    if (obj.UNITTYPE == "ATR" && !obj.EMPTY)
                    {
                        if (FS.LANDWAR)
                        {
                            //find logistical zone marker
                            GO logisticalZone = FS.TYPESIDE(obj.GS, "POSSESSIONFLAG", obj.SIDE).Where(n => n.LOGISTICALZONE == obj.GAMELOCATION.LOGISTICALZONE).Single();
                            //confirm loc has enough to load
                            if (obj.AIRMISSION == "CARGO")
                            {
                                logisticalZone.SUPPLIES += obj.TEMPLATE.SPECIAL;
                            }
                            else
                            {
                                logisticalZone.STRENGTH += obj.TEMPLATE.SPECIAL;
                            }
                        }
                        else if (FS.GARRISONWAR)
                        {
                            //find facility
                            GO facility = FS.TYPESIDELOCATION(obj.GS, "FACILITY", obj.SIDE, obj.GAMELOCATIONID).Where(n => n.AIRFIELD).First();
                            facility.STRENGTH += obj.TEMPLATE.SPECIAL;
                        }
                    }
                }
            }
            obj.HOMEBASEID = null;
            obj.EMPTY = true;
            obj.LOCATIONFUTURE = null;
        }
        public static Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> ATTACKDATA(List<GO> objs, string COMBATTYPE)
        {
            return ATTACKDATA(objs, new List<string>() { COMBATTYPE });
        }
        public static Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> ATTACKDATA(List<GO> objs)
        {
            return ATTACKDATA(objs, FS.COMBATMISSIONTYPES);
        }
        public static Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> ATTACKDATA(List<GO> objs, List<string> COMBATTYPES)
        {
            Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> data = new();
            foreach (GO obj in objs)
            {
                Dictionary<string, Dictionary<string, Dictionary<string, double>>> obj_data = new();
                foreach (string COMBATTYPE in COMBATTYPES)
                {
                    switch (COMBATTYPE)
                    {
                        case "SSM":
                            Dictionary<string, Dictionary<string, double>> ssm = SSMDATA(obj);
                            Dictionary<string, Dictionary<string, double>> ssm2 = SSM2DATA(obj);
                            Dictionary<string, Dictionary<string, double>> ssmaaa = SSMAAADATA(obj);
                            if (ssm.Any() || ssm2.Any() || ssmaaa.Any())
                            {
                                obj_data.Add("SSM", new());
                                ssm.ToList().ForEach(n => obj_data["SSM"].Add(n.Key, n.Value));
                                ssm2.ToList().ForEach(n => obj_data["SSM"].Add(n.Key, n.Value));
                                ssmaaa.ToList().ForEach(n => obj_data["SSM"].Add(n.Key, n.Value));
                            }
                            break;
                        case "CC":
                            Dictionary<string, Dictionary<string, double>> cc = CLOSECOMBATDATA(obj);
                            Dictionary<string, Dictionary<string, double>> basecc = BASECLOSECOMBATDATA(obj);
                            if (cc.Any() || basecc.Any())
                            {
                                obj_data.Add("CC", new());
                                cc.ToList().ForEach(n => obj_data["CC"].Add(n.Key, n.Value));
                                basecc.ToList().ForEach(n => obj_data["CC"].Add(n.Key, n.Value));
                            }
                            break;
                        case "BOMB":
                            Dictionary<string, Dictionary<string, double>> bomb = BOMBDATA(obj);
                            if (bomb.Any())
                            {
                                obj_data.Add("BOMB", new());
                                bomb.ToList().ForEach(n => obj_data["BOMB"].Add(n.Key, n.Value));
                            }
                            break;
                        case "CM":
                            Dictionary<string, Dictionary<string, double>> cm = CMDATA(obj);
                            if (cm.Any())
                            {
                                obj_data.Add("CM", new());
                                cm.ToList().ForEach(n => obj_data["CM"].Add(n.Key, n.Value));
                            }
                            break;
                        case "ASW":
                            Dictionary<string, Dictionary<string, double>> asw = ASWDATA(obj);
                            if (asw.Any())
                            {
                                obj_data.Add("ASW", new());
                                asw.ToList().ForEach(n => obj_data["ASW"].Add(n.Key, n.Value));
                            }
                            break;
                        case "TORP":
                            Dictionary<string, Dictionary<string, double>> torp = TORPDATA(obj);
                            if (torp.Any())
                            {
                                obj_data.Add("TORP", new());
                                torp.ToList().ForEach(n => obj_data["TORP"].Add(n.Key, n.Value));
                            }
                            break;
                        case "AAA":
                            Dictionary<string, Dictionary<string, double>> aaa = AAADATA(obj);
                            if (aaa.Any())
                            {
                                obj_data.Add("AAA", new());
                                aaa.ToList().ForEach(n => obj_data["AAA"].Add(n.Key, n.Value));
                            }
                            break;
                        default:
                            break;
                    }
                }
                if (obj_data.Any())
                {
                    data.Add(obj, obj_data);
                }
            }
            return data;
        }
        public static double GETAIRCAA(GO obj)
        {
            double ratio = 0;
            GameScenario GS = obj.GS;
            double template = obj.TEMPLATE.CAA;
            if (template == 0) { return 0; }
            if (GS.GetBoolean("TURN.DARKNESS") && !obj.NIGHTAA)
            {
                template = Math.Max(1, template - 2);
            }
            if (obj.ROLE == "FIGHTER" || obj.UNITTYPE != "INT" || (obj.UNITTYPE == "INT" && obj.ROLE == null))
            {
                ratio = 1;
            }
            else if (obj.ROLE == "BOMBER")
            {
                ratio = 0;
            }
            else
            {
                ratio = 0.5;
            }
            if (obj.EXTENDEDRANGE)
            {
                ratio *= 0.5;
            }
            return Math.Max(1, Math.Floor(template * ratio));
        }
        public static double GETAIRSSM(GO obj)
        {
            double ratio = 0;
            double template = obj.TEMPLATE.SSM;
            if (template == 0 || obj.ROLE == "FIGHTER") { return 0; }
            if (obj.ROLE == "BOMBER" || obj.UNITTYPE != "INT")
            {
                ratio = 1;
            }
            else
            { //FIGHTER-BOMBER
                ratio = 0.5;
            }
            if (obj.EXTENDEDRANGE)
            {
                ratio *= 0.5;
            }
            return Math.Max(1, Math.Floor(template * ratio));
        }
        public static double GETAIRBOMB(GO obj)
        {
            double ratio = 0;
            double template = obj.TEMPLATE.SPECIAL;
            if (template == 0 || obj.ROLE == "FIGHTER" || obj.UNITTYPE == "ATR") { return 0; }
            if (obj.ROLE == "BOMBER" || obj.UNITTYPE != "INT")
            {
                ratio = 1;
            }
            else
            { //FIGHTER-BOMBER
                ratio = 0.5;
            }
            if (obj.EXTENDEDRANGE)
            {
                ratio *= 0.5;
            }

            template = Math.Max(1, Math.Floor(template * ratio));
            return template + (obj.REDUCEDRANGE ? template < 20 ? 15 : 30 : 0);
        }
        public static double GETAIRMINE(GO obj)
        {
            if (obj.UNITTYPE == "BMB" || (obj.TEMPLATE.ASW > 0 && obj.UNITTYPE == "RCN"))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        public static int GETAIRSURFACESEARCH(GO obj)
        {
            return (int)Math.Max(obj.TEMPLATE.AIRTOSURFACERECON, obj.TEMPLATE.SSMRANGE);
        }
        public static int GETAIRAIRSEARCH(GO obj)
        {
            return obj.AIRMISSION == "CAP" && !obj.DONE ? 4 : obj.UNITTYPE switch
            {
                "AEW" => 4,
                "RCN" => 2,
                "INT" => (int)Math.Min(4, obj.TEMPLATE.CAA / 2),
                _ => 1
            };
        }
        public static double GETSUBTORP(GO obj)
        {
            if (obj.DEEPMODE)
            {
                return Math.Floor(obj.TEMPLATE.SPECIAL * 0.5);
            }
            else
            {
                return obj.TEMPLATE.SPECIAL;
            }
        }
        public static double GETFACILITYCAA(GO obj, string facilityType)
        {
            return facilityType switch
            {
                "PORT" => obj.PORTDAMAGELEVEL switch
                {
                    1 => Math.Max(5, Math.Floor(obj.GAMELOCATION.CAA * 0.5)),
                    2 => 5,
                    3 => 4,
                    4 => 0,
                    _ => obj.GAMELOCATION.CAA,
                },
                "AIRFIELD" => obj.AIRFIELDDAMAGELEVEL switch
                {
                    1 => Math.Max(5, Math.Floor(obj.GAMELOCATION.CAA * 0.5)),
                    2 => 5,
                    3 => 4,
                    4 => 0,
                    _ => obj.GAMELOCATION.CAA,
                },
                "CLOSEDEFENSE" => obj.CLOSEDEFENSEDAMAGELEVEL switch
                {
                    1 => Math.Max(5, Math.Floor(obj.GAMELOCATION.CAA * 0.5)),
                    2 => 5,
                    3 => 4,
                    4 => 0,
                    _ => obj.GAMELOCATION.CAA,
                },
                _ => 0,
            };
        }
        public static double GETSURFACECC(GO obj)
        {
            return Math.Max(0, obj.TEMPLATE.SPECIAL - obj.TEMPLATE.SSM);
        }
        private static Dictionary<string, Dictionary<string, double>> SSMDATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if (obj.TYPE == "CLOSEDEFENSE")
            {
                //normal SSM only
                data.Add("SSM", new());
                data["SSM"].Add("PTS", obj.SSM);
                data["SSM"].Add("RANGE", 0);
                data["SSM"].Add("FAST", 0);
                data["SSM"].Add("SEASKIMMER", 1);
            }
            else if (obj.TEMPLATE.SSM > 0 && !obj.DEEPMODE)
            {
                if (obj.UNITTYPE == "PC")
                {
                    //normal SSM only
                    data.Add("SSM", new());
                    data["SSM"].Add("PTS", obj.TEMPLATE.SSM);
                    data["SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                    data["SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                    data["SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                }
                else if (obj.TYPE == "SHIP" && obj.SSMPTS > 0)
                {
                    //normal SSM
                    data.Add("SSM", new());
                    data["SSM"].Add("PTS", obj.TEMPLATE.SSM);
                    data["SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                    data["SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                    data["SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                    if (obj.SSMPTS >= 2 && obj.UNITCATEGORY == "SURFACE")
                    {
                        //intensive SSM
                        data.Add("INTENSIVE SSM", new());
                        data["INTENSIVE SSM"].Add("PTS", Math.Floor(obj.TEMPLATE.SSM * 1.5));
                        data["INTENSIVE SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                        data["INTENSIVE SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                        data["INTENSIVE SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        if (obj.SSMPTS >= 3)
                        {
                            //maximum SSM
                            data.Add("MAXIMUM SSM", new());
                            data["MAXIMUM SSM"].Add("PTS", obj.TEMPLATE.SSM * 2);
                            data["MAXIMUM SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                            data["MAXIMUM SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                            data["MAXIMUM SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        }
                    }
                }
                else if (obj.TYPE == "SQN")
                {
                    bool sqnQualifies = obj.ACTIVATED ? obj.SSM > 0 : FS.GETAIRSSM(obj) > 0 && ((obj.CARRIERID == null && !obj.TEMPLATE.LIMITEDSSM) || obj.CARRIER?.AIRSSMPTS >= obj.TEMPLATE.AIRSSMCOST);
                    if (sqnQualifies)
                    {
                        //normal SSM
                        data.Add("SSM", new());
                        data["SSM"].Add("PTS", obj.SSM);
                        data["SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                        data["SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                        data["SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                    }
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> SSM2DATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if (obj.TEMPLATE?.SSM2 > 0 && !obj.DEEPMODE)
            {
                if (obj.TYPE == "SHIP" && obj.SSM2PTS > 0)
                {
                    //normal SSM2
                    data.Add("SSM2", new());
                    data["SSM2"].Add("PTS", obj.TEMPLATE.SSM2);
                    data["SSM2"].Add("RANGE", obj.TEMPLATE.SSM2RANGE);
                    data["SSM2"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                    data["SSM2"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                    if (obj.SSM2PTS >= 2 && obj.UNITCATEGORY == "SURFACE")
                    {
                        //intensive SSM2
                        data.Add("INTENSIVE SSM2", new());
                        data["INTENSIVE SSM2"].Add("PTS", Math.Floor(obj.TEMPLATE.SSM2 * 1.5));
                        data["INTENSIVE SSM2"].Add("RANGE", obj.TEMPLATE.SSM2RANGE);
                        data["INTENSIVE SSM2"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                        data["INTENSIVE SSM2"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        if (obj.SSM2PTS >= 3)
                        {
                            //maximum SSM2
                            data.Add("MAXIMUM SSM2", new());
                            data["MAXIMUM SSM2"].Add("PTS", obj.TEMPLATE.SSM2 * 2);
                            data["MAXIMUM SSM2"].Add("RANGE", obj.TEMPLATE.SSM2RANGE);
                            data["MAXIMUM SSM2"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                            data["MAXIMUM SSM2"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        }
                    }
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> SSMAAADATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if (obj.COUNTRY == "USA" && obj.TEMPLATE?.AAA > 0)
            {
                if (obj.TYPE == "SHIP" && obj.AAPTS > 0)
                {
                    //normal SSM
                    data.Add("AAA AS SSM", new());
                    data["AAA AS SSM"].Add("PTS", 4);
                    data["AAA AS SSM"].Add("RANGE", 1);
                    data["AAA AS SSM"].Add("FAST", 1);
                    data["AAA AS SSM"].Add("SEASKIMMER", 0);
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> BASECLOSECOMBATDATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if (SURFACECOMBATTYPES.Contains(obj.UNITTYPE) && GETSURFACECC(obj) > 0)
            {
                data.Add("BASE CC", new());
                data["BASE CC"].Add("PTS", GETSURFACECC(obj));
                data["BASE CC"].Add("RANGE", 0);
                data["BASE CC"].Add("FAST", 0);
                data["BASE CC"].Add("SEASKIMMER", 0);
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> CLOSECOMBATDATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if (SURFACECOMBATTYPES.Contains(obj.UNITTYPE) && obj.TEMPLATE.SPECIAL > 0)
            {
                if (obj.UNITTYPE == "PC")
                {
                    //normal CC only
                    data.Add("CC", new());
                    data["CC"].Add("PTS", obj.TEMPLATE.SPECIAL);
                    data["CC"].Add("RANGE", 0);
                    data["CC"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                    data["CC"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                }
                else if (obj.SSMPTS > 0)
                {
                    //normal CC
                    data.Add("CC", new());
                    data["CC"].Add("PTS", obj.TEMPLATE.SPECIAL);
                    data["CC"].Add("RANGE", 0);
                    data["CC"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                    data["CC"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                    if (obj.SSMPTS >= 2)
                    {
                        //intensive CC
                        data.Add("INTENSIVE CC", new());
                        data["INTENSIVE CC"].Add("PTS", Math.Floor(obj.TEMPLATE.SSM * 1.5) + GETSURFACECC(obj));
                        data["INTENSIVE CC"].Add("RANGE", 0);
                        data["INTENSIVE CC"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                        data["INTENSIVE CC"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        if (obj.SSMPTS >= 3)
                        {
                            //maximum SSM
                            data.Add("MAXIMUM CC", new());
                            data["MAXIMUM CC"].Add("PTS", obj.TEMPLATE.SSM * 2 + GETSURFACECC(obj));
                            data["MAXIMUM CC"].Add("RANGE", 0);
                            data["MAXIMUM CC"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                            data["MAXIMUM CC"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        }
                    }
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> BOMBDATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if (obj.TYPE == "SQN")
            {
                bool sqnQualifies = obj.ACTIVATED ? obj.SPECIAL > 0 : FS.GETAIRBOMB(obj) > 0 && (obj.CARRIERID == null || obj.CARRIER.BOMBPTS > 0);
                double special = obj.ACTIVATED ? obj.SPECIAL : FS.GETAIRBOMB(obj);

                if (sqnQualifies && special > 0)
                {
                    //normal SSM
                    data.Add("BOMB", new());
                    data["BOMB"].Add("PTS", special);
                    data["BOMB"].Add("RANGE", 0);
                    data["BOMB"].Add("FAST", 0);
                    data["BOMB"].Add("SEASKIMMER", 0);
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> CMDATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if (obj.TEMPLATE.CM > 0 && !obj.DEEPMODE)
            {
                if (obj.TYPE == "SQN")
                {
                    double special = obj.ACTIVATED ? obj.CM : obj.TEMPLATE.CM;
                    if (special > 0)
                    {
                        //normal CM
                        data.Add("CM", new());
                        data["CM"].Add("PTS", special);
                        data["CM"].Add("RANGE", obj.TEMPLATE.CMRANGE);
                        data["CM"].Add("FAST", 0);
                        data["CM"].Add("SEASKIMMER", 0);
                    }
                }
                else
                {
                    if (obj.CMPTS > 0)
                    {
                        //normal CM
                        data.Add("CM", new());
                        data["CM"].Add("PTS", obj.TEMPLATE.CM);
                        data["CM"].Add("RANGE", obj.TEMPLATE.CMRANGE);
                        data["CM"].Add("FAST", 0);
                        data["CM"].Add("SEASKIMMER", 0);
                    }
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> ASWDATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if(obj.TYPE == "CLOSEDEFENSE")
            {
                //normal ASW
                data.Add("ASW", new());
                data["ASW"].Add("PTS", obj.ASW);
                data["ASW"].Add("RANGE", 0);
                data["ASW"].Add("FAST", 0);
                data["ASW"].Add("SEASKIMMER", 0);
            }
            else if (obj.TEMPLATE.ASW > 0)
            {
                bool sqnQualifies = obj.ACTIVATED ? obj.TORPPTS > 0 : obj.TEMPLATE.ASW > 0;
                if (obj.ASWPTS > 0 || (obj.UNITCATEGORY == "SUB" && obj.TORPPTS > 0) || (obj.UNITCATEGORY == "AIR" && sqnQualifies))
                {
                    //normal ASW
                    data.Add("ASW", new());
                    data["ASW"].Add("PTS", obj.TEMPLATE.ASW);
                    data["ASW"].Add("RANGE", obj.UNITCATEGORY == "AIR" ? 0 : 1);
                    data["ASW"].Add("FAST", 0);
                    data["ASW"].Add("SEASKIMMER", 0);
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> TORPDATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if (obj.UNITCATEGORY == "SUB" && FS.GETSUBTORP(obj) > 0)
            {
                if (obj.TORPPTS > 0)
                {
                    //normal
                    data.Add("TORP", new());
                    data["TORP"].Add("PTS", FS.GETSUBTORP(obj));
                    data["TORP"].Add("RANGE", 0);
                    data["TORP"].Add("FAST", 0);
                    data["TORP"].Add("SEASKIMMER", 0);
                    if (obj.TORPPTS >= 2)
                    {
                        //intensive
                        data.Add("INTENSIVE TORP", new());
                        data["INTENSIVE TORP"].Add("PTS", Math.Floor(obj.TEMPLATE.SPECIAL * 1.5));
                        data["INTENSIVE TORP"].Add("RANGE", 0);
                        data["INTENSIVE TORP"].Add("FAST", 0);
                        data["INTENSIVE TORP"].Add("SEASKIMMER", 0);
                        if (obj.TORPPTS >= 3)
                        {
                            //maximum
                            data.Add("MAXIMUM TORP", new());
                            data["MAXIMUM TORP"].Add("PTS", obj.TEMPLATE.SPECIAL * 2);
                            data["MAXIMUM TORP"].Add("RANGE", 0);
                            data["MAXIMUM TORP"].Add("FAST", 0);
                            data["MAXIMUM TORP"].Add("SEASKIMMER", 0);
                        }
                    }
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> AAADATA(GO obj)
        {
            Dictionary<string, Dictionary<string, double>> data = new();
            if (obj.TEMPLATE.AAA > 0)
            {
                if (obj.TYPE == "SHIP" && obj.AAPTS > 0)
                {
                    data.Add("AAA", new());
                    data["AAA"].Add("PTS", obj.TEMPLATE.AAA);
                    data["AAA"].Add("RANGE", obj.TEMPLATE.LAA ? 2 : obj.TEMPLATE.MAA ? 1 : 0);
                    data["AAA"].Add("FAST", 0);
                    data["AAA"].Add("SEASKIMMER", 0);
                }
            }
            return data;
        }
        public static List<GO> ALLSHIPSINHEX(string side, GO loc, bool surface, bool sub)
        {
            List<string> unitcategories = new();
            if (surface) { unitcategories.Add("SURFACE"); }
            if (sub) { unitcategories.Add("SUB"); }
            return [.. FS.TYPESIDELOCATION(loc.GS, "SHIP", side, loc.ID).Where(n => n.ENROUTEDELAY == 0 && unitcategories.Contains(n.UNITCATEGORY))];
        }
        public static void LOCALDETECT(List<GO> objs, bool detect)
        {
            objs.ForEach(n => n.LOCALDETECTED = detect);
            foreach (GO obj in objs.Select(LOGICALPARENT).Where(ISGROUP).Distinct())
            {
                FS.UPDATEGROUP(obj);
            }
        }
        public static void STRATDETECT(List<GO> objs, bool detect)
        {
            foreach (GO obj in objs)
            {
                obj.STRATDETECTED = detect;
                if (detect)
                {
                    obj.LOCALDETECTED = detect;
                }
            }
            foreach (GO obj in objs.Select(LOGICALPARENT).Where(ISGROUP).Distinct())
            {
                FS.UPDATEGROUP(obj);
            }
        }
        public static List<GO> GROUPSANDMEMBERS(List<GO> objs)
        {
            List<GO> returnList = new();
            foreach (GO obj in objs)
            {
                returnList.Add(obj);
                if (ISGROUP(obj)) { returnList.AddRange(GROUPMEMBERS(obj)); }
            }
            return [.. returnList.Distinct()];
        }
        public static List<GO> SSMTARGETS(GO attackingUnit, List<GO> ENEMYUNITS, Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData)
        {
            GameScenario GS = attackingUnit.GS;
            GO attackLoc = attackingUnit.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            groupMembers.RemoveAll(n => !attackData.ContainsKey(n));
            double maxRange = 0;
            foreach (GO obj in groupMembers)
            {
                if (attackData[obj].ContainsKey("SSM"))
                {
                    maxRange = Math.Max(maxRange, attackData[obj]["SSM"].Values.Max(n => n["RANGE"]));
                }
            }
            List<GO> ssmRadius = maxRange == 0 ? new() { attackLoc } : FS.FINDAIRRADIUS(attackLoc, (int)maxRange).Where(n => n.TYPE == "HEX").ToList();
            ssmRadius.RemoveAll(STORM);
            foreach (GO obj in ENEMYUNITS.Where(n =>
                ssmRadius.Contains(n.GAMELOCATION)))
            {

                if (attackingUnit.UNITCATEGORY == "AIR" || obj.GAMELOCATION == attackLoc)
                {
                    TARGETS.Add(obj);
                }
                else
                {
                    //calculate straight line, confirm it doesn't cross blocked or land hexside nor travels through restricted
                    List<FSMovement> ssmPath = FS.FINDSSMDIRECTPATH(attackLoc, obj.GAMELOCATION);
                    if (!ssmPath.Any()) { continue; }
                    if (ssmPath.Where(n => n != ssmPath.First() && n != ssmPath.Last() && n.MOVEMENTLOCATION.RESTRICTED).Any()) { continue; }
                    TARGETS.Add(obj);
                }
            }
            return TARGETS;
        }
        public static List<GO> CMTARGETS(GO attackingUnit, List<GO> ENEMYUNITS, Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData)
        {
            GO attackLoc = attackingUnit.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            groupMembers.RemoveAll(n => !attackData.ContainsKey(n));
            double maxRange = 0;
            foreach (GO obj in groupMembers)
            {
                if (attackData[obj].ContainsKey("CM"))
                {
                    maxRange = Math.Max(maxRange, attackData[obj]["CM"].Values.Max(n => n["RANGE"]));
                }
            }
            foreach (GO obj in ENEMYUNITS)
            {
                //straight line distance first.  if more than 150% immediate no, less than 90% immediate yes, otherwise calculate
                GO from = obj.GAMELOCATION;
                GO to = attackLoc;
                double x1 = to.x;
                //map wrap around
                double distance1 = attackingUnit.GS.GetDistance(from, x1, to.y) / FS.HEXDISTANCE;
                if (distance1 >= (maxRange * 1.5))
                {
                    continue;
                }
                else if (distance1 <= maxRange * 0.9)
                {
                    TARGETS.Add(obj);
                }
                else
                {
                    List<FSMovement> path = FS.FINDAIRMOVEMENTDIRECTPATH(obj.GAMELOCATION, attackLoc, (int)maxRange);
                    if (path.Any())
                    {
                        TARGETS.Add(obj);
                    }
                }
            }
            return TARGETS;
        }
        public static List<GO> ASWTARGETS(GO attackingUnit, List<GO> ENEMYUNITS)
        {
            GameScenario GS = attackingUnit.GS;
            GO attackLoc = attackingUnit.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            string actionType = attackingUnit.UNITCATEGORY;
            List<GO> candidateLocations = new() { attackLoc };
            if (actionType != "AIR")
            {
                candidateLocations.AddRange(FS.GENERATESEAMOVEMENTCONNECTIONS(attackLoc).Select(n => n.MOVEMENTLOCATION));
            }
            if (actionType != "SUB") { candidateLocations.RemoveAll(STORM); }
            foreach (GO loc in candidateLocations)
            {
                bool canTargetDocked = actionType switch
                {
                    "AIR" => false,
                    "SURFACE" => loc.PORTDAMAGELEVEL > 0,
                    _ => true
                };
                List<GO> candidates = ENEMYUNITS.Where(n => PARENTGROUPLOCATION(n) == loc).ToList();
                //area anti air prevent surface and air
                if (actionType != "SUB" && candidates.Where(n => n.UNITCATEGORY == "SURFACE").Any()) { continue; }
                List<GO> subs = candidates.Where(n => n.UNITCATEGORY == "SUB").ToList();
                if (!canTargetDocked) { subs.RemoveAll(n => n.DOCKED); }
                if (actionType == "AIR") { subs.RemoveAll(n => n.ATTACKEDBYAIR); }
                if (actionType == "SURFACE") { subs.RemoveAll(n => n.ATTACKEDBYSURFACE); }
                TARGETS.AddRange(subs);
            }
            return TARGETS;
        }
        public static List<GO> TORPTARGETS(GO attackingUnit, List<GO> ENEMYUNITS)
        {
            GameScenario GS = attackingUnit.GS;
            GO attackLoc = attackingUnit.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            string actionType = attackingUnit.UNITCATEGORY;
            List<GO> candidateLocations = new() { attackLoc };
            candidateLocations.AddRange(FS.GENERATESEAMOVEMENTCONNECTIONS(attackLoc).Select(n => n.MOVEMENTLOCATION));
            candidateLocations.RemoveAll(STORM);
            foreach (GO loc in candidateLocations)
            {
                TARGETS.AddRange(ENEMYUNITS.Where(n => n.GAMELOCATION == loc));
            }
            return TARGETS;
        }
        public static List<GO> BOMBTARGETS(GO attackingUnit, List<GO> ENEMYUNITS, Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData)
        {
            GO attackLoc = attackingUnit.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            groupMembers.RemoveAll(n => !attackData.ContainsKey(n));
            //BMB cannot bomb ships
            bool nonBMBUnits = false;
            foreach (GO obj in groupMembers)
            {
                if (attackData[obj].ContainsKey("BOMB"))
                {
                    if (obj.UNITTYPE != "BMB") { nonBMBUnits = true; }
                }
            }
            ENEMYUNITS = ENEMYUNITS.Where(n => n.GAMELOCATION == attackLoc && attackLoc.TYPE == "HEX" && LOGICALPARENT(n) == n).ToList();
            if (nonBMBUnits)
            {
                TARGETS.AddRange(ENEMYUNITS.Where(n => n.UNITCATEGORY == "SURFACE"));
            }
            if (attackLoc.SIDE == FS.ENEMY(attackingUnit.SIDE))
            {
                if ((attackLoc.PORT && !attackLoc.PORTDESTROYED) || (attackLoc.AIRFIELD && !attackLoc.AIRFIELDDESTROYED))
                {
                    TARGETS.AddRange(ENEMYUNITS.Where(n => n.UNITTYPE == "BASE"));
                }
                if (attackLoc.CLOSEDEFENSE && !attackLoc.CLOSEDEFENSEDESTROYED)
                {
                    TARGETS.AddRange(ENEMYUNITS.Where(n => n.TYPE == "CLOSEDEFENSE"));
                }
            }
            return TARGETS;
        }
        public static List<GO> CCTARGETS(GO attackingUnit, List<GO> ENEMYUNITS, Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData)
        {
            GO attackLoc = attackingUnit.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            groupMembers.RemoveAll(n => !attackData.ContainsKey(n));
            //ships with no base cc capability cannot attack bases
            bool undestroyedBase = (attackLoc.PORT && !attackLoc.PORTDESTROYED) || (attackLoc.AIRFIELD && !attackLoc.AIRFIELDDESTROYED);
            bool undestroyedCD = attackLoc.CLOSEDEFENSE && !attackLoc.CLOSEDEFENSEDESTROYED;
            bool canAttackBase = false;
            bool canAttackShips = false;
            foreach (GO obj in groupMembers)
            {
                if (attackData[obj].ContainsKey("CC"))
                {
                    canAttackShips = canAttackShips || !attackingUnit.DONESSM;
                    if (attackData[obj]["CC"].ContainsKey("BASE CC"))
                    {
                        canAttackBase = true;
                        canAttackShips = true;
                    }
                }
            }
            ENEMYUNITS = ENEMYUNITS.Where(n => FS.PARENTGROUPLOCATION(n) == attackLoc && attackLoc.TYPE == "HEX").ToList();
            TARGETS.AddRange(ENEMYUNITS.Where(n => canAttackShips && n.UNITCATEGORY == "SURFACE"));
            TARGETS.AddRange(ENEMYUNITS.Where(n => canAttackBase && undestroyedBase && n.UNITTYPE == "BASE"));
            TARGETS.AddRange(ENEMYUNITS.Where(n => canAttackBase && undestroyedCD && n.TYPE == "CLOSEDEFENSE"));
            return TARGETS;
        }
        public static List<GO> AAATARGETS(GO attackingUnit, List<GO> ENEMYUNITS, List<GO> SURFACETOAIRS, Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData)
        {
            GameScenario GS = attackingUnit.GS;
            GO attackLoc = attackingUnit.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            groupMembers.RemoveAll(n => !attackData.ContainsKey(n));
            double maxRange = 0;
            foreach (GO obj in groupMembers)
            {
                if (attackData[obj].ContainsKey("AAA"))
                {
                    maxRange = Math.Max(maxRange, attackData[obj]["AAA"].Values.Max(n => n["RANGE"]));
                }
            }
            List<GO> aaaRadius = maxRange == 0 ? new() { attackLoc } : FS.FINDAIRRADIUS(attackLoc, (int)maxRange).Where(n => n.TYPE == "HEX").ToList();
            aaaRadius.RemoveAll(STORM);
            foreach (GO obj in ENEMYUNITS.Where(n =>
                aaaRadius.Contains(n.GAMELOCATION)))
            {
                //if enemy is in same hex and restricted/fjord, not possible
                if ((attackLoc.FJORD || attackLoc.RESTRICTED) && obj.GAMELOCATION == attackLoc) { continue; }
                if (SURFACETOAIRS.Where(n => n.INTERCEPTEDGRP == obj).Any()) { continue; }
                TARGETS.Add(obj);
            }
            return TARGETS;
        }
        public static List<GO> TACCOORDTARGETS(GO attackingUnit, List<GO> ENEMYUNITS)
        {
            GameScenario GS = attackingUnit.GS;
            List<GO> TARGETS = [];
            GO attackLoc = attackingUnit.GAMELOCATION;
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            bool subsAllowed = groupMembers.Where(n => n.TEMPLATE.ASW > 0).Any();
            //SURFACE
            double maxRange = groupMembers.Max(FS.GETAIRSURFACESEARCH);
            List<GO> surfaceRadius = maxRange == 0 ? new() { attackLoc } : FS.FINDAIRRADIUS(attackLoc, (int)maxRange).Where(n => n.TYPE == "HEX").ToList();
            surfaceRadius.RemoveAll(STORM);
            TARGETS.AddRange(ENEMYUNITS.Where(n => n.UNITCATEGORY == "SURFACE" && surfaceRadius.Contains(n.GAMELOCATION) && LOGICALPARENT(n) == n));
            TARGETS.AddRange(ENEMYUNITS.Where(n => subsAllowed && n.UNITCATEGORY == "SUB" && n.GAMELOCATION == attackLoc));
            return TARGETS;
        }
        public static void DISCARDLOGIC(GO obj)
        {
            GameScenario GS = obj.GS;
            if (FS.COMBATMISSIONTYPES.Contains(obj.TYPE) && obj.GAMEPIECEID != null) { GS.DISCARD(obj.GAMEPIECE); }
            if (FS.TACCOORDMISSIONTYPES.Contains(obj.TYPE) && obj.GAMEPIECEID != null) { GS.DISCARD(obj.GAMEPIECE); }
            GS.DISCARD(obj);
        }
        public static GO CREATEALERT(GO intercepted, GO attacker, string side)
        {
            Dictionary<string, string> clonedData = new()
            {
                ["ID"] = intercepted.ID + GO.DELIM + attacker?.ID + GO.DELIM + FS.GENERATETIMESTAMP(),
                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                ["TYPE"] = "ALERT"
            };
            return new(intercepted.GS, clonedData, null, null)
            {
                ATTACKERID = attacker?.ID,
                ATTACKER = attacker,
                INTERCEPTEDGRPID = intercepted.ID,
                INTERCEPTEDGRP = intercepted,
                SIDE = side
            };
        }
        public static GO CREATECOMBATDETECTION(GO intercepted, string side, string combatType)
        {
            Dictionary<string, string> clonedData = new()
            {
                ["ID"] = intercepted.ID + GO.DELIM + combatType + "DETECTION" + GO.DELIM + FS.GENERATETIMESTAMP(),
                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                ["TYPE"] = "COMBATDETECTION"
            };
            return new(intercepted.GS, clonedData, null, null)
            {
                INTERCEPTEDGRPID = intercepted.ID,
                INTERCEPTEDGRP = intercepted,
                SIDE = side,
                LABEL = combatType
            };
        }
        public static GO CREATEAILOGICLINK(GO logic, GO unit, string side)
        {
            Dictionary<string, string> clonedData = new()
            {
                ["ID"] = logic.ID + GO.DELIM + unit?.ID + GO.DELIM + FS.GENERATETIMESTAMP(),
                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                ["TYPE"] = "AI.LOGICLINK"
            };
            return new(logic.GS, clonedData, null, null)
            {
                UNITID = unit?.ID,
                UNIT = unit,
                LOGICID = logic.ID,
                LOGIC = logic,
                SIDE = side
            };
        }
        public static void AIRDETECTION(GameScenario GS, List<GO> interceptable, bool combined)
        {
            List<GO> DETECTED = [];
            List<GO> UNDETECTED = [];
            AIRDETECTION(GS, interceptable, DETECTED, UNDETECTED);
            if (combined)
            {
                AIRVSSURFACEDETECTION(GS, DETECTED);
            }
            UNDETECTED = [.. UNDETECTED.Where(n => !DETECTED.Contains(n)).Distinct()];
            FS.GROUPSANDMEMBERS(UNDETECTED).ForEach(n => n.ADMINDETECTED = false);

            foreach (GO obj in FS.GROUPSANDMEMBERS(DETECTED).Distinct())
            {
                if (FS.LOGICALPARENT(obj) == obj && !obj.ADMINDETECTED)
                {
                    FS.CREATEALERT(obj, null, FS.ENEMY(obj.SIDE));
                }
                obj.ADMINDETECTED = true;
            }
        }
        public static void AIRDETECTION(GameScenario GS, List<GO> interceptable, List<GO> DETECTED, List<GO> UNDETECTED)
        {
            Dictionary<GO, List<GO>> ONEHEXRADIUS = new();
            Dictionary<GO, List<GO>> TWOHEXRADIUS = new();
            Dictionary<GO, List<GO>> THREEHEXRADIUS = new();
            Dictionary<GO, List<GO>> FOURHEXRADIUS = new();
            List<GO> MOBILECAP = [.. GS.TYPE("SQN").Where(n => n.ACTIVATED && !n.DONE && LOGICALPARENT(n) == n && n.NUMCOMBATS == 0 && n.INTERCEPTMODE)];
            List<GO> MOBILECAPF14 = [.. MOBILECAP.Where(n => n.MAA)];
            List<GO> INTERCEPTS = interceptable.Any() ? GS.TYPE("INTERCEPTION") : new();
            List<GO> active = [.. FS.CAPSQNS(GS, null).Where(n => !n.DONE)];
            foreach (string s in FS.SIDE_NAMES)
            {
                active.AddRange(FS.TYPESIDE(GS, "SQN", s).Where(n => n.ACTIVATED && !n.DONE && LOGICALPARENT(n) == n));
            }
            active = active.Distinct().ToList();
            foreach (GO obj in active)
            {
                GO loc = FS.PARENTGROUPLOCATION(obj);
                List<GO> EXTENDEDENEMY = new();
                bool trackDetection = FS.LOGICALPARENT(obj) == obj;
                int searchedExtended = 1;
                if (trackDetection)
                {
                    bool detected = false;
                    if (obj.ENROUTEDELAY == 0)
                    {
                        //DETECTION
                        if (!ONEHEXRADIUS.ContainsKey(loc))
                        {
                            List<GO> RADIUS = FS.FINDAIRRADIUS(loc, 1);
                            ONEHEXRADIUS.Add(loc, active.Where(n => RADIUS.Contains(FS.PARENTGROUPLOCATION(n))).ToList());
                        }
                        List<GO> NEARENEMY = ONEHEXRADIUS[loc].Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).ToList();
                        detected = NEARENEMY.Any();
                        if (!detected)
                        {
                            searchedExtended = 2;
                            if (!TWOHEXRADIUS.ContainsKey(loc))
                            {
                                List<GO> RADIUS = FS.FINDAIRRADIUS(loc, 2);
                                TWOHEXRADIUS.Add(loc, FS.GROUPSANDMEMBERS(active.Where(n => RADIUS.Contains(FS.PARENTGROUPLOCATION(n))).ToList()));
                            }
                            EXTENDEDENEMY.AddRange(TWOHEXRADIUS[loc].Where(n => n.SIDE == FS.ENEMY(obj.SIDE) && FS.GETAIRAIRSEARCH(n) >= 2));
                            detected = EXTENDEDENEMY.Any();

                            if (!detected)
                            {
                                searchedExtended = 3;
                                if (!THREEHEXRADIUS.ContainsKey(loc))
                                {
                                    List<GO> RADIUS = FS.FINDAIRRADIUS(loc, 3);
                                    THREEHEXRADIUS.Add(loc, FS.GROUPSANDMEMBERS(active.Where(n => RADIUS.Contains(FS.PARENTGROUPLOCATION(n))).ToList()));
                                }
                                EXTENDEDENEMY.AddRange(THREEHEXRADIUS[loc].Where(n => n.SIDE == FS.ENEMY(obj.SIDE) && FS.GETAIRAIRSEARCH(n) >= 3));
                                detected = EXTENDEDENEMY.Any();
                                if (!detected)
                                {
                                    searchedExtended = 4;
                                    if (!FOURHEXRADIUS.ContainsKey(loc))
                                    {
                                        List<GO> RADIUS = FS.FINDAIRRADIUS(loc, 4);
                                        FOURHEXRADIUS.Add(loc, FS.GROUPSANDMEMBERS(active.Where(n => RADIUS.Contains(FS.PARENTGROUPLOCATION(n))).ToList()));
                                    }
                                    EXTENDEDENEMY.AddRange(FOURHEXRADIUS[loc].Where(n => n.SIDE == FS.ENEMY(obj.SIDE) && FS.GETAIRAIRSEARCH(n) >= 4));
                                    detected = EXTENDEDENEMY.Any();
                                }
                            }
                        }
                    }
                    if (detected)
                    {
                        DETECTED.Add(obj);
                    }
                    else
                    {
                        UNDETECTED.Add(obj);
                    }
                }
                //INTERCEPTION
                if (interceptable.Contains(obj))
                {
                    if (searchedExtended < 4)
                    {
                        if (!FOURHEXRADIUS.ContainsKey(loc))
                        {
                            List<GO> RADIUS = FS.FINDAIRRADIUS(loc, 4);
                            FOURHEXRADIUS.Add(loc, FS.GROUPSANDMEMBERS(active.Where(n => RADIUS.Contains(FS.PARENTGROUPLOCATION(n))).ToList()));
                        }
                        EXTENDEDENEMY.AddRange(FOURHEXRADIUS[loc].Where(n => n.SIDE == FS.ENEMY(obj.SIDE) && FS.GETAIRAIRSEARCH(n) >= 4));
                    }
                    EXTENDEDENEMY.RemoveAll(n => n.AIRMISSION != "CAP");
                    if (EXTENDEDENEMY.Where(n => n.UNITTYPE == "INT").Any() && obj.AERIALREFUELING)
                    {
                        double before = FS.RESETMOVEMENTALLOWANCE(obj);
                        //if the air unit has travelled less than 10 hexes
                        if (before - obj.MOVEMENTALLOWANCE <= 10)
                        {
                            //remove aerial refueling, reduce movement allowance
                            obj.AERIALREFUELING = false;
                            double after = FS.RESETMOVEMENTALLOWANCE(obj);
                            obj.MOVEMENTALLOWANCE -= before - after;
                            MainWindow.Alert("Aerial Refueling prevented by nearby enemy INT. Bonus removed!");
                        }
                    }
                    List<GO> alreadyInterceptedThisUnit = INTERCEPTS.Where(n => n.INTERCEPTEDGRP == obj).Select(n => n.CAP).ToList();
                    EXTENDEDENEMY.RemoveAll(n => FS.PARENTGROUPLOCATION(n) == loc);
                    //remove any CAP where they have already intercepted this group
                    EXTENDEDENEMY.RemoveAll(alreadyInterceptedThisUnit.Contains);
                    //remove any CAP where no INT in their hex
                    List<GO> intLocations = EXTENDEDENEMY.Where(n => n.UNITTYPE == "INT").Select(n => n.GAMELOCATION).ToList();
                    EXTENDEDENEMY.RemoveAll(n => !intLocations.Contains(n.GAMELOCATION));
                    if (EXTENDEDENEMY.Any())
                    {
                        FS.ADDSCENARIOOBJECT(GS, "ACTION.INTERCEPTNEEDED", obj);
                    }
                }
                //MOBILE CAP INTERCEPTION
                if (interceptable.Contains(obj))
                {
                    List<GO> ACTIVATIONGROUPENEMIES = [];
                    //one hex
                    if (!ONEHEXRADIUS.ContainsKey(loc))
                    {
                        List<GO> RADIUS = FS.FINDAIRRADIUS(loc, 1);
                        ONEHEXRADIUS.Add(loc, active.Where(n => RADIUS.Contains(FS.PARENTGROUPLOCATION(n))).ToList());
                    }
                    ACTIVATIONGROUPENEMIES.AddRange(ONEHEXRADIUS[loc].Where(n => n.SIDE == FS.ENEMY(obj.SIDE) && MOBILECAPF14.Contains(n)));
                    //same hex
                    ACTIVATIONGROUPENEMIES.AddRange(MOBILECAP.Where(n => n.SIDE == FS.ENEMY(obj.SIDE) && n.GAMELOCATION == loc));
                    if (ACTIVATIONGROUPENEMIES.Any() && obj.AERIALREFUELING)
                    {
                        double before = FS.RESETMOVEMENTALLOWANCE(obj);
                        //if the air unit has travelled less than 10 hexes
                        if (before - obj.MOVEMENTALLOWANCE <= 10)
                        {
                            //remove aerial refueling, reduce movement allowance
                            obj.AERIALREFUELING = false;
                            double after = FS.RESETMOVEMENTALLOWANCE(obj);
                            obj.MOVEMENTALLOWANCE -= before - after;
                            MainWindow.Alert("Aerial Refueling prevented by nearby enemy INT. Bonus removed!");
                        }
                    }
                    if (ACTIVATIONGROUPENEMIES.Any())
                    {
                        FS.ADDSCENARIOOBJECT(GS, "ACTION.MOBILEINTERCEPTNEEDED", obj);
                    }
                }
            }
        }
        public static void AIRVSSURFACEDETECTION(GameScenario GS, List<GO> DETECTEDAIR)
        {
            if (AIRSURFACEINTERACTION)
            {
                List<GO> ALLAIRDETECTORS = FS.CAPSQNS(GS, null).Where(n => !n.DONE).ToList();
                ALLAIRDETECTORS.AddRange(GS.TYPE("SQN").Where(n => n.ACTIVATED && !n.DONE && FS.PARENTGROUPLOCATION(n).TYPE == "HEX"));
                List<GO> ALLDETECTABLESURFACE = GS.TYPE("SHIP").Where(n => n.UNITCATEGORY == "SURFACE" && FS.PARENTGROUPLOCATION(n).TYPE == "HEX" && n.ENROUTEDELAY == 0).ToList();
                foreach (string s in FS.SIDE_NAMES)
                {
                    List<GO> AIRDETECTORS = ALLAIRDETECTORS.Where(n => n.SIDE == s).ToList();
                    List<GO> SURFACEDETECTORS = ALLDETECTABLESURFACE.Where(n => n.SIDE == s).ToList();
                    List<GO> DETECTABLEAIR = ALLAIRDETECTORS.Where(n => n.SIDE == FS.ENEMY(s)).Where(n => n.GAMELOCATION.TYPE == "HEX" && LOGICALPARENT(n) == n).ToList();
                    List<GO> DETECTABLESURFACE = ALLDETECTABLESURFACE.Where(n => n.SIDE == FS.ENEMY(s)).Where(n => !n.LOCALDETECTED && n.GAMELOCATION.TYPE == "HEX" && LOGICALPARENT(n) == n).ToList();
                    List<GO> DETECTEDSURFACE = new();
                    //AIR TO SURFACE
                    List<GO> AIRLOCATIONS = AIRDETECTORS.Select(FS.PARENTGROUPLOCATION).Distinct().ToList();
                    foreach (GO loc in AIRLOCATIONS)
                    {
                        int range = (int)Math.Floor(AIRDETECTORS.Where(n => FS.PARENTGROUPLOCATION(n) == loc).Max(n => FS.GETAIRSURFACESEARCH(n) * ((FS.LOGICALPARENT(n).SEARCHMODE || n.AIRMISSION == "CAP") ? 1 : 0.5)));
                        List<GO> RADIUS = new();
                        if (range == 0)
                        {
                            RADIUS.Add(loc);
                        }
                        else
                        {
                            RADIUS.AddRange(FS.FINDAIRRADIUS(loc, range));
                        }
                        DETECTEDSURFACE.AddRange(DETECTABLESURFACE.Where(n => RADIUS.Contains(n.GAMELOCATION)));
                    }
                    foreach (GO obj in DETECTEDSURFACE.Distinct())
                    {
                        FS.CREATEALERT(obj, null, s);
                        obj.LOCALDETECTED = true;
                        FS.GROUPMEMBERS(obj).ForEach(n => n.LOCALDETECTED = true);
                    }

                    //SURFACE TO AIR
                    List<GO> SURFACELOCATIONS = SURFACEDETECTORS.Select(FS.PARENTGROUPLOCATION).Distinct().ToList();

                    foreach (GO loc in SURFACELOCATIONS)
                    {
                        List<GO> detectors = SURFACEDETECTORS.Where(n => FS.PARENTGROUPLOCATION(n) == loc).ToList();
                        bool AAA = detectors.Where(n => n.TEMPLATE.AAA > 0).Any();
                        bool LAA = detectors.Where(n => n.TEMPLATE.LAA).Any();
                        int range = LAA ? 2 : AAA ? 1 : 0;
                        Dictionary<int, List<GO>> RADIUS = new();
                        if (range == 0)
                        {
                            RADIUS.Add(0, [loc]);
                        }
                        else
                        {
                            if (range >= 1) { RADIUS.Add(1, FS.FINDAIRRADIUS(loc, 1)); }
                            if (range >= 2) { RADIUS.Add(2, FS.FINDAIRRADIUS(loc, 2)); }
                        }
                        DETECTEDAIR.AddRange(DETECTABLEAIR.Where(n => RADIUS.Values.Last().Contains(n.GAMELOCATION)));
                    }
                }
            }
        }
        public static void AIRVSSUBDETECTION(GameScenario GS)
        {
            if (AIRSURFACEINTERACTION && SUBREALTIMEDETECTION)
            {
                List<GO> ALLAIRDETECTORS = [];
                ALLAIRDETECTORS.AddRange(GS.TYPE("SQN").Where(n => n.ACTIVATED && !n.DONE && FS.PARENTGROUPLOCATION(n).TYPE == "HEX" && FS.LOGICALPARENT(n).SEARCHMODE && n.TEMPLATE.ASW > 0));
                List<GO> ALLDETECTABLESUB = GS.TYPE("SHIP").Where(n => n.UNITCATEGORY == "SUB" && !n.LOCALDETECTED && n.GAMELOCATION.TYPE == "HEX" && n.ENROUTEDELAY == 0).ToList();
                foreach (string s in FS.SIDE_NAMES)
                {
                    List<GO> AIRDETECTORS = [.. ALLAIRDETECTORS.Where(n => n.SIDE == s)];
                    List<GO> AIRLOCATIONS = [.. AIRDETECTORS.Select(FS.PARENTGROUPLOCATION).Distinct()];
                    List<GO> DETECTABLESUBS = [.. ALLDETECTABLESUB.Where(n => n.SIDE == FS.ENEMY(s) && AIRLOCATIONS.Contains(n.GAMELOCATION))];
                    List<GO> DETECTEDSUBS = new();
                    foreach (GO loc in AIRLOCATIONS)
                    {
                        List<GO> DETECTORS = [.. AIRDETECTORS.Where(n => FS.PARENTGROUPLOCATION(n) == loc)];
                        List<GO> SUBS = [.. DETECTABLESUBS.Where(n => n.GAMELOCATION == loc)];
                        foreach (GO obj in SUBS)
                        {
                            if (FS.SUBDETECTIONRESULT(obj, "REALTIME", null, DETECTORS) == "D")
                            {
                                DETECTEDSUBS.Add(obj);
                            }
                        }
                    }
                    foreach (GO obj in DETECTEDSUBS.Distinct())
                    {
                        FS.CREATEALERT(obj, null, s);
                        obj.LOCALDETECTED = true;
                    }
                }
            }
        }
        public static void SURFACEVSAIRTARGETING(GameScenario GS)
        {
            if (AIRSURFACEINTERACTION)
            {
                List<GO> ACTIVATEDAIR = GS.TYPE("SQN").Where(n => n.ACTIVATED && !n.DONE && n.GAMELOCATION.TYPE == "HEX" && LOGICALPARENT(n) == n).ToList();
                Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData =
                    FS.ATTACKDATA(
                        GS.TYPE("SHIP").Where(n =>
                        n.UNITCATEGORY == "SURFACE" &&
                        FS.PARENTGROUPLOCATION(n).TYPE == "HEX" &&
                        n.ENROUTEDELAY == 0 &&
                        n.ACTIVATED &&
                        !n.DONE &&
                        !FS.ISGROUP(n)).ToList(),
                        "AAA");
                foreach (string s in FS.SIDE_NAMES)
                {
                    List<GO> SURFACETOAIRS = GS.TYPE("SURFACETOAIR").Where(n => n.ATTACKER.SIDE == s).ToList();
                    List<GO> SURFACEATTACKERS = attackData.Keys.Where(n => n.SIDE == s).ToList();
                    List<GO> TARGETABLEAIR = ACTIVATEDAIR.Where(n => n.SIDE == FS.ENEMY(s)).ToList();
                    foreach (GO sqn in TARGETABLEAIR)
                    {
                        HashSet<GO> ALERTS = [];
                        List<GO> priorAttacks = SURFACETOAIRS.Where(n => n.INTERCEPTEDGRP == sqn).Select(n => n.ATTACKER).ToList();
                        Dictionary<int, List<GO>> RADIUSTABLE = new(){
                            {0, new(){sqn.GAMELOCATION}},
                            {1, FS.FINDAIRRADIUS(sqn.GAMELOCATION, 1)},
                            {2, FS.FINDAIRRADIUS(sqn.GAMELOCATION, 2)}
                        };
                        foreach (GO attacker in SURFACEATTACKERS.Where(n => !priorAttacks.Contains(n) && RADIUSTABLE[2].Contains(FS.PARENTGROUPLOCATION(n))))
                        {
                            int attackRange = (int)attackData[attacker]["AAA"]["AAA"]["RANGE"];
                            if (RADIUSTABLE[attackRange].Contains(FS.PARENTGROUPLOCATION(attacker)))
                            {
                                ALERTS.Add(FS.LOGICALPARENT(attacker));
                            }
                        }
                        ALERTS.ToList().ForEach(n => FS.CREATEALERT(sqn, n, n.SIDE));
                    }
                }
            }
        }
        public static void AMPHIBIOUSDROP(GO group)
        {
            GameScenario GS = group.GS;
            bool invasion = group.GAMELOCATION.SIDE != group.SIDE;
            foreach (GO obj in FS.GROUPMEMBERS(group).Where(n => FS.SURFACELADENTYPES.Contains(n.UNITTYPE)))
            {
                bool cargo = FS.SURFACECARGOTYPES.Contains(obj.UNITTYPE);
                obj.LOADING = true;
                obj.EMPTY = true;
                if (FS.LANDWAR)
                {
                    //find logistical zone marker
                    GO logisticalZone = FS.TYPESIDE(GS, "POSSESSIONFLAG", obj.GAMELOCATION.SIDE).Where(n => n.LOGISTICALZONE == obj.GAMELOCATION.LOGISTICALZONE).Single();
                    if(invasion) {
                        //find land combat
                        GO LANDCOMBAT = GS.TYPE("LANDCOMBAT").Where(n => n.SIDE == obj.SIDE && n.DEFENDER == logisticalZone && n.ATTACKER == null).FirstOrDefault();
                        if (LANDCOMBAT == null)
                        {
                            Dictionary<string, string> objData = new()
                            {
                                ["ID"] = "INVASION" + GO.DELIM + logisticalZone.ID + GO.DELIM + "LANDCOMBAT" + GO.DELIM + FS.GENERATETIMESTAMP(),
                                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                ["TYPE"] = "LANDCOMBAT"
                            };
                            LANDCOMBAT = new(GS, objData, null, null)
                            {
                                ATTACKERID = null,
                                ATTACKER = null,
                                DEFENDERID = logisticalZone.ID,
                                DEFENDER = logisticalZone,
                                SIDE = obj.SIDE
                            };
                        }
                        if (cargo)
                        {
                            LANDCOMBAT.SUPPLIES += obj.TEMPLATE.SPECIAL;
                        }
                        else
                        {
                            LANDCOMBAT.STRENGTH += obj.TEMPLATE.SPECIAL;
                        }
                    }
                    else
                    {
                        if (cargo)
                        {
                            logisticalZone.SUPPLIES += obj.TEMPLATE.SPECIAL;
                        }
                        else
                        {
                            logisticalZone.STRENGTH += obj.TEMPLATE.SPECIAL;
                        }
                    }
                }
                else if (FS.GARRISONWAR)
                {
                    //find facility
                    GO facility = FS.TYPELOCATION(GS, "FACILITY", obj.GAMELOCATIONID).Where(n => n.PORT || n.AIRFIELD).First();
                    if(invasion){
                        facility.ENEMYSTRENGTH += obj.TEMPLATE.SPECIAL;
                    }
                    else
                    {
                        facility.STRENGTH += obj.TEMPLATE.SPECIAL;
                    }
                }
            }
        }
        public static void AIRDROP(GO group)
        {
            GameScenario GS = group.GS;
            bool invasion = group.GAMELOCATION.SIDE != group.SIDE;
            foreach (GO obj in FS.GROUPMEMBERS(group).Where(n => n.UNITTYPE == "ATR" && !n.EMPTY))
            {
                bool cargo = obj.AIRMISSION == "CARGO";
                obj.EMPTY = true;
                if (FS.LANDWAR)
                {
                    //find logistical zone marker
                    GO logisticalZone = FS.TYPESIDE(GS, "POSSESSIONFLAG", obj.GAMELOCATION.SIDE).Where(n => n.LOGISTICALZONE == obj.GAMELOCATION.LOGISTICALZONE).Single();
                    if(invasion) {
                        //find land combat
                        GO LANDCOMBAT = GS.TYPE("LANDCOMBAT").Where(n => n.SIDE == obj.SIDE && n.DEFENDER == logisticalZone && n.ATTACKER == null).FirstOrDefault();
                        if (LANDCOMBAT == null)
                        {
                            Dictionary<string, string> objData = new()
                            {
                                ["ID"] = "INVASION" + GO.DELIM + logisticalZone.ID + GO.DELIM + "LANDCOMBAT" + GO.DELIM + FS.GENERATETIMESTAMP(),
                                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                ["TYPE"] = "LANDCOMBAT"
                            };
                            LANDCOMBAT = new(GS, objData, null, null)
                            {
                                ATTACKERID = null,
                                ATTACKER = null,
                                DEFENDERID = logisticalZone.ID,
                                DEFENDER = logisticalZone,
                                SIDE = obj.SIDE
                            };
                        }
                        if (cargo)
                        {
                            LANDCOMBAT.SUPPLIES += obj.TEMPLATE.SPECIAL;
                        }
                        else
                        {
                            LANDCOMBAT.STRENGTH += obj.TEMPLATE.SPECIAL;
                        }
                    }
                    else
                    {
                        if (cargo)
                        {
                            logisticalZone.SUPPLIES += obj.TEMPLATE.SPECIAL;
                        }
                        else
                        {
                            logisticalZone.STRENGTH += obj.TEMPLATE.SPECIAL;
                        }
                    }
                }
                else if (FS.GARRISONWAR)
                {
                    //find facility
                    GO facility = FS.TYPELOCATION(GS, "FACILITY", obj.GAMELOCATIONID).Where(n => n.PORT || n.AIRFIELD).First();
                    if(invasion){
                        facility.ENEMYSTRENGTH += obj.TEMPLATE.SPECIAL;
                    }
                    else
                    {
                        facility.STRENGTH += obj.TEMPLATE.SPECIAL;
                    }
                }
            }
        }
        public static int AIAGRESSION(GameScenario GS, string side)
        {
            return GS.Get("AI." + side) switch
            {
                "CAUTIOUS" => 1,
                "AGGRESSIVE" => 3,
                _ => 2
            };
        }
        public static Dictionary<GO, List<GO>> AI_CREATEGROUPINGLOGICS(GameScenario GS, List<GO> objs)
        {
            //split all units up into categories that can stack together
            List<GO> surface = [.. objs.Where(n => !FS.ISGROUP(n) && n.UNITCATEGORY == "SURFACE")];
            List<List<GO>> surfaceSegments = [[], [], []];
            //first add pc that need to go back to port
            //then add surface units that need fuel
            //then add all other surface units
            string turntype = GS.Get("TURN.TYPE");
            int turn = GS.GetInt("TURN");
            bool PCRETURN = (turntype == "NIGHT" && turn % 2 == 0) || (turntype == "PM" && turn % 2 == 1);
            foreach (GO s in surface)
            {
                if (s.UNITTYPE == "PC" && PCRETURN)
                {
                    surfaceSegments[0].Add(s);
                }
                else if (s.TEMPLATE.FUELPTS > 0 && s.FUELPTS <= 1)
                {
                    surfaceSegments[1].Add(s);
                }
                else
                {
                    surfaceSegments[2].Add(s);
                }
            }
            Dictionary<GO, List<GO>> LOCATION_UNIT_MAP = [];
            foreach (GO obj in objs)
            {
                if (!LOCATION_UNIT_MAP.TryGetValue(obj.GAMELOCATION, out List<GO> units))
                {
                    units = [];
                    LOCATION_UNIT_MAP.Add(obj.GAMELOCATION, units);
                }
                units.Add(obj);
            }
            //create GROUPING LOGICs
            foreach (GO loc in LOCATION_UNIT_MAP.Keys)
            {
                foreach (List<GO> segment in surfaceSegments)
                {
                    List<GO> SURFACE = [.. LOCATION_UNIT_MAP[loc].Intersect(segment)];
                    string label = loc.ID + GO.DELIM + "GROUPINGLOGIC" + GO.DELIM + FS.GENERATETIMESTAMP();
                    foreach (GO obj in SURFACE)
                    {
                        GO GROUPINGLOGIC = loc.GS.TYPE("GROUPINGLOGIC").Where(n => n.UNIT == obj).SingleOrDefault();
                        if (GROUPINGLOGIC == null)
                        {
                            Dictionary<string, string> objData = new()
                            {
                                ["ID"] = obj.ID + GO.DELIM + "GROUPINGLOGIC" + GO.DELIM + FS.GENERATETIMESTAMP(),
                                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                ["TYPE"] = "GROUPINGLOGIC"
                            };
                            GROUPINGLOGIC = new(loc.GS, objData, null, null)
                            {
                                UNITID = obj.ID,
                                UNIT = obj
                            };
                        }
                        GROUPINGLOGIC.LABEL = SURFACE.Count > 1 ? label : null;
                    }                    
                }
            }
            return LOCATION_UNIT_MAP;
        }
        public static void AI_DEPLOY(List<GO> objs)
        {
            if(objs.Count == 0) { return; }
            GameScenario GS = objs[0].GS;
            string side = objs[0].SIDE;
            List<GO> SQNALLOWED = [.. FS.TYPESIDE(GS, "LOCATION", side).Where(n => n.AIRFIELD || n.LOGAIR)];
            List<GO> SNALLOWED = [.. GS.LOCATIONS().Where(n => (n.TERRAIN == "SEA" || n.LOGSEA) && !n.SHOALS)];
            List<GO> SURFACEALLOWED = [.. SNALLOWED.Where(n => !n.PACKICE)];
            List<GO> SSALLOWED = [.. SURFACEALLOWED];
            //placeholder GO
            GO NULLGO = new();
            //group units by location
            Dictionary<GO, List<GO>> LOCATION_UNIT_MAP = FS.AI_CREATEGROUPINGLOGICS(GS, objs);
            //place units of side into Dictionary of LOCATION -> CHOSEN DEPLOYMENT LOGIC or NULL
            Dictionary<GO, Dictionary<GO, List<GO>>> LOCATION_LOGIC_MAP = [];
            foreach (GO loc in LOCATION_UNIT_MAP.Keys)
            {
                if (!LOCATION_LOGIC_MAP.TryGetValue(loc, out Dictionary<GO, List<GO>> logics))
                {
                    logics = [];
                    LOCATION_LOGIC_MAP.Add(loc, logics);
                }
                List<GO> processed = [];
                foreach(GO obj in LOCATION_UNIT_MAP[loc])
                {
                    if (processed.Contains(obj)) { continue; }
                    GO GROUPINGLOGIC = GS.TYPE("GROUPINGLOGIC").Where(n => n.UNIT == obj).SingleOrDefault();
                    if(GROUPINGLOGIC == null)
                    {
                        List<GO> DEPLOYMENT_CANDIDATES = [.. FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => n.LOGIC.TYPE == "DEPLOYMENTLOGIC" && n.UNIT == obj)];
                        GO DEPLOYMENT = DEPLOYMENT_CANDIDATES.Any() ? GS.RANDOMGAMEOBJECT(DEPLOYMENT_CANDIDATES).LOGIC : NULLGO;
                        if (!logics.TryGetValue(DEPLOYMENT, out List<GO> units))
                        {
                            units = [];
                            logics[DEPLOYMENT] = units;
                        }

                        units.Add(obj);
                        DEPLOYMENT_CANDIDATES.ForEach(FS.DISCARDLOGIC);
                        processed.Add(obj);
                    }
                    else
                    {
                        List<GO> groupingunits = [.. GS.TYPE("GROUPINGLOGIC").Where(n => n== GROUPINGLOGIC || (n.LABEL == GROUPINGLOGIC.LABEL && n.LABEL != null)).Select(n => n.UNIT)];
                        List<GO> DEPLOYMENT_CANDIDATES = [.. FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => n.LOGIC.TYPE == "DEPLOYMENTLOGIC" && groupingunits.Contains(n.UNIT))];
                        GO DEPLOYMENT = DEPLOYMENT_CANDIDATES.Any() ? GS.RANDOMGAMEOBJECT(DEPLOYMENT_CANDIDATES).LOGIC : NULLGO;
                        if (!logics.TryGetValue(DEPLOYMENT, out List<GO> units))
                        {
                            units = [];
                            logics[DEPLOYMENT] = units;
                        }

                        units.AddRange(groupingunits);
                        DEPLOYMENT_CANDIDATES.ForEach(FS.DISCARDLOGIC);
                        processed.AddRange(groupingunits);
                    }
                }                
            }
            //DEPLOY SUBs and AIR as individuals,  DEPLOY SURFACE together if in same block
            foreach (GO loc in LOCATION_LOGIC_MAP.Keys)
            {
                foreach (GO logic in LOCATION_LOGIC_MAP[loc].Keys.Where(n => n != NULLGO))
                {
                    List<GO> COVERAGE = [];
                    string[] coverage = logic.LOCATIONCOVERAGE != null ? logic.LOCATIONCOVERAGE.Split('|') : [logic.GAMELOCATIONID];

                    foreach (string c in coverage)
                    {
                        COVERAGE.Add(GS.LOCATION(c));
                    }
                    List<GO> ALL = LOCATION_LOGIC_MAP[loc][logic];
                    List<GO> SURFACE = [.. ALL.Where(n => n.UNITCATEGORY == "SURFACE")];
                    List<GO> SN = [.. ALL.Where(n => n.UNITCATEGORY == "SUB" && n.UNITTYPE == "SN")];
                    List<GO> SS = [.. ALL.Where(n => n.UNITCATEGORY == "SUB" && n.UNITTYPE == "SS")];
                    List<GO> AIR = [.. ALL.Where(n => n.UNITCATEGORY == "AIR")];
                    foreach(GO obj in AIR)
                    {
                        GS.CHANGELOCATION(obj, GS.RANDOMGAMEOBJECT([.. COVERAGE.Intersect(SQNALLOWED)]));
                    }
                    foreach(GO obj in SN)
                    {
                        GS.CHANGELOCATION(obj, GS.RANDOMGAMEOBJECT([.. COVERAGE.Intersect(SNALLOWED)]));
                    }
                    foreach(GO obj in SS)
                    {
                        GS.CHANGELOCATION(obj, GS.RANDOMGAMEOBJECT([.. COVERAGE.Intersect(SSALLOWED)]));
                    }
                    GO SURFACELOC = GS.RANDOMGAMEOBJECT([.. COVERAGE.Intersect(SURFACEALLOWED)]);
                    foreach(GO obj in SURFACE)
                    {
                        GS.CHANGELOCATION(obj, SURFACELOC);
                    }
                }
            }
        }
        public static void AI_COMPLETELINKS(GameScenario GS, string side)
        {
            //normally called during post action group phase
            //for groups that are 'complete' remove from group
            int aggressionfactor = GS.Get("AI." + side) switch
            {
                "CAUTIOUS" => 1,
                "AGGRESSIVE" => 3,
                _ => 2
            };
            string turntype = GS.Get("TURN.TYPE");
            int turn = GS.GetInt("TURN");
            bool PCRETURN = (turntype == "NIGHT" && turn % 2 == 0) || (turntype == "PM" && turn % 2 == 1);
            List<GO> ALLLINKS = [.. GS.TYPE("AI.LOGICLINK", "SIDE", side).Where(n => n.UNIT?.SIDE == side && n.LOGIC?.SIDE == side && n.LOGIC.TYPE == "OBJECTIVELOGIC")];
            List<GO> ACTIVELINKS = [.. ALLLINKS.Where(n => n.ACTIVE)];
            List<GO> GROUPINGLINKS = [.. ACTIVELINKS.Where(n => n.LOGIC.OBJECTIVETYPE == "GROUPING")];
            List<GO> REPLENISHMENTLINKS = [.. GS.TYPE("AI.LOGICLINK", "SIDE", side).Where(n => n.UNIT?.SIDE == side && n.LOGIC?.SIDE == side && n.LOGIC.OBJECTIVETYPE == "REPLENISH")];
            List<GO> SHIPSCANREPLENISH = [.. REPLENISHMENTLINKS.Select(n => n.UNIT)];
            //any units in this side not linked to an active link, reset
            List<GO> UNITSWITHACTIVELINK = FS.GROUPSANDMEMBERS([.. ACTIVELINKS.Select(n => n.UNIT)]);
            List<GO> UNITSWITHOUTACTIVELINK = [.. ALLLINKS.Select(n => n.UNIT).Where(n => !UNITSWITHACTIVELINK.Contains(n)).Distinct()];
            foreach (GO unit in UNITSWITHOUTACTIVELINK){
                unit.SEARCHMODE = false;
                unit.SEARCHDELAY = 0;
                unit.AIROLE = null;                
            }
            foreach(GO link in ACTIVELINKS)
            {
                GO obj = link.UNIT;
                List<GO> gms = FS.GROUPMEMBERS(obj);
                GO logic = link.LOGIC;
                link.LINKCYCLES++;
                bool completed = false;
                bool ATFOCUS = obj.GAMELOCATION == link.AIFOCUSLOCATION;
                List<GO> shipsInGroup = [.. gms.Where(n => n.UNITCATEGORY != "AIR")];
                bool NEEDFUEL = shipsInGroup.Where(n => n.TEMPLATE.FUELPTS > 0 && n.FUELPTS <= 1).Any();
                bool NEEDTORP = shipsInGroup.Where(n => n.TEMPLATE.TORPPTS > 0 && n.TORPPTS == 0).Any();
                bool NEEDASW = shipsInGroup.Where(n => n.TEMPLATE.ASWPTS > 0 && n.ASWPTS == 0).Any();
                bool NEEDSSM = shipsInGroup.Where(n => n.UNITTYPE != "PC" && n.TEMPLATE.SSMPTS > 0 && n.SSMPTS == 0).Any();
                bool NEEDSSM2 = shipsInGroup.Where(n => n.TEMPLATE.SSM2PTS > 0 && n.SSM2PTS == 0).Any();
                bool NEEDBOMB = shipsInGroup.Where(n => n.TEMPLATE.BOMBPTS > 0 && n.BOMBPTS == 0).Any();
                bool NEEDTODOCK = shipsInGroup.Where(n => n.UNITTYPE == "PC" && PCRETURN).Any();
                bool NEEDREPLENISHMENT = obj.UNITCATEGORY != "AIR" && (NEEDFUEL || NEEDASW || NEEDTORP || NEEDSSM || NEEDBOMB || NEEDTODOCK) && SHIPSCANREPLENISH.Intersect(shipsInGroup).Any();
                bool LOADING = shipsInGroup.Where(n => n.LOADING).Any();
                bool RTB = gms.Where(n => n.AIRMISSION == "RTB").Any();
                bool HASGROUPINGLINK = GROUPINGLINKS.Where(n => obj.UNITCATEGORY == "SURFACE" && n != link && n.UNIT.GAMELOCATION == obj.GAMELOCATION).Any();
                bool HASOTHERLINK = ACTIVELINKS.Where(n => obj.UNITCATEGORY == "SURFACE" && n != link && n.UNIT.GAMELOCATION == obj.GAMELOCATION).Any();
                GO focus = link.AIFOCUSLOCATION;
                List<int> COMPLETIONROLLS = [100];
                if (!(LOADING || RTB))
                {
                    switch (logic.OBJECTIVETYPE)
                    {
                        case "INSERT COMMANDOS":
                            completed = ((focus.AIRFIELD || focus.PORT || focus.CLOSEDEFENSE) && focus.SIDE == side) || gms.Where(n => n.COMMANDOPTS == 0).Any();
                            break;
                        case "LAY MINES":
                            completed = ((focus.AIRFIELD || focus.PORT || focus.CLOSEDEFENSE) && focus.SIDE == side) || gms.Where(n => n.MINEPTS == 0).Any();
                            break;
                        case "LOAD":
                            completed = focus.SIDE != side || gms.Where(n => FS.SURFACELADENTYPES.Contains(n.UNITTYPE) && !n.EMPTY).Any() || NEEDREPLENISHMENT;
                            break;
                        case "UNLOAD":
                            completed = focus.SIDE != side || gms.Where(n => FS.SURFACELADENTYPES.Contains(n.UNITTYPE) && n.EMPTY).Any() || NEEDREPLENISHMENT;
                            break;
                        case "INVADE":
                            completed = focus.SIDE == side || gms.Where(n => FS.SURFACELADENTYPES.Contains(n.UNITTYPE) && n.EMPTY).Any() || NEEDREPLENISHMENT;
                            break;
                        case "PATROL":
                            if (obj.UNITCATEGORY != "AIR")
                            {
                                if (!gms.Where(n => n.SEARCHDELAY > 0).Any())
                                {
                                    if (logic.LOCATIONCOVERAGE.Contains(obj.GAMELOCATIONID))
                                    {
                                        for (int i = 0; i < link.LINKCYCLES; i++)
                                        {
                                            COMPLETIONROLLS.Add(GS.RANDOMINT(100));
                                        }
                                    }
                                }
                            }
                            completed = COMPLETIONROLLS.Min() < 2 || NEEDREPLENISHMENT;
                            break;
                        case "REPLENISH":
                            GO replenishlocation = link.AIFOCUSLOCATION;
                            completed = focus.SIDE != side || replenishlocation.PORTDESTROYED || !NEEDREPLENISHMENT;
                            break;
                        case "DESTROY BASE":
                            GO baselocation = link.AIFOCUSLOCATION;
                            bool alldestroyed = (!baselocation.PORT || baselocation.PORTDESTROYED) && (!baselocation.AIRFIELD || baselocation.AIRFIELDDESTROYED) && (!baselocation.CLOSEDEFENSE || baselocation.CLOSEDEFENSEDESTROYED);
                            for (int i = 0; i < link.LINKCYCLES && obj.UNITCATEGORY != "AIR"; i++)
                            {
                                COMPLETIONROLLS.Add(GS.RANDOMINT(100));
                            }
                            List<string> allowedAirMissions = ["ESCORT", "BOMBING", "CRUISE MISSILE"];
                            completed = focus.SIDE == side || COMPLETIONROLLS.Min() < 2 || alldestroyed || NEEDREPLENISHMENT || (obj.UNITCATEGORY == "AIR" && !allowedAirMissions.Contains(obj.AIRMISSION));
                            break;
                        case "DESTROY AIRFIELD":
                            baselocation = link.AIFOCUSLOCATION;
                            alldestroyed = !baselocation.AIRFIELD || baselocation.AIRFIELDDESTROYED;
                            for (int i = 0; i < link.LINKCYCLES && obj.UNITCATEGORY != "AIR"; i++)
                            {
                                COMPLETIONROLLS.Add(GS.RANDOMINT(100));
                            }
                            allowedAirMissions = ["ESCORT", "BOMBING", "CRUISE MISSILE"];
                            completed = focus.SIDE == side || COMPLETIONROLLS.Min() < 2 || alldestroyed || NEEDREPLENISHMENT || (obj.UNITCATEGORY == "AIR" && !allowedAirMissions.Contains(obj.AIRMISSION));
                            break;
                        case "DESTROY PORT":
                            baselocation = link.AIFOCUSLOCATION;
                            alldestroyed = !baselocation.PORT || baselocation.PORTDESTROYED;
                            for (int i = 0; i < link.LINKCYCLES && obj.UNITCATEGORY != "AIR"; i++)
                            {
                                COMPLETIONROLLS.Add(GS.RANDOMINT(100));
                            }
                            allowedAirMissions = ["ESCORT", "BOMBING", "CRUISE MISSILE"];
                            completed = focus.SIDE == side || COMPLETIONROLLS.Min() < 2 || alldestroyed || NEEDREPLENISHMENT || (obj.UNITCATEGORY == "AIR" && !allowedAirMissions.Contains(obj.AIRMISSION));
                            break;
                        case "DESTROY CLOSEDEFENSE":
                            baselocation = link.AIFOCUSLOCATION;
                            alldestroyed = !baselocation.CLOSEDEFENSE || baselocation.CLOSEDEFENSEDESTROYED;
                            for (int i = 0; i < link.LINKCYCLES && obj.UNITCATEGORY != "AIR"; i++)
                            {
                                COMPLETIONROLLS.Add(GS.RANDOMINT(100));
                            }
                            allowedAirMissions = ["ESCORT", "BOMBING", "CRUISE MISSILE"];
                            completed = focus.SIDE == side || COMPLETIONROLLS.Min() < 2 || alldestroyed || NEEDREPLENISHMENT || (obj.UNITCATEGORY == "AIR" && !allowedAirMissions.Contains(obj.AIRMISSION));
                            break;
                        case "GROUPING":
                            for (int i = 0; i < link.LINKCYCLES; i++)
                            {
                                COMPLETIONROLLS.Add(GS.RANDOMINT(100));
                            }
                            completed = COMPLETIONROLLS.Min() < 2 || obj.GAMELOCATION == link.AIFOCUSLOCATION || NEEDREPLENISHMENT;
                            break;
                        case "TRANSIT":
                            completed = obj.GAMELOCATION == link.AIFOCUSLOCATION;
                            break;
                        default:
                            break;
                    }
                }
                if (!completed && HASGROUPINGLINK || (logic.OBJECTIVETYPE == "GROUPING" && HASOTHERLINK))
                {
                    //update the links of the groupmembers of the same logic to interrupted
                    foreach(GO gmlink in GS.TYPE("AI.LOGICLINK", "SIDE", side).Where(n => logic.OBJECTIVETYPE != "GROUPING" && n.LOGIC == logic && gms.Contains(n.UNIT))){
                        gmlink.INTERRUPTED = true;
                    }
                    completed = true;
                }
                if (completed)
                {
                    link.INTERCEPTMODE = false;
                    List<GO> groupMembers = gms;
                    FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.SEARCHMODE = false);
                    FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.SEARCHDELAY = 0);
                    FS.GROUPSANDMEMBERS([obj]).ForEach(n => n.AIROLE = null);
                    //disband group
                    if (FS.ISGROUP(obj))
                    {
                        //groupMembers.ForEach(n => FS.REMOVEFROMGROUP(n, obj));
                        List<GO> unitLinks = [.. GS.TYPE("AI.LOGICLINK", "SIDE", side).Where(n => n.UNIT == obj)];
                        unitLinks.ForEach(DISCARDLOGIC);
                    }
                    if (ATFOCUS)
                    {
                        string removeReport = "";
                        List<GO> unitLinks = [.. GS.TYPE("AI.LOGICLINK", "SIDE", side).Where(n => n.LOGIC == logic && groupMembers.Contains(n.UNIT))];
                        foreach(GO unitLink in unitLinks)
                        {
                            GO ship = unitLink.UNIT;
                            //award vp?
                            if (logic.VP_AWARD)
                            {
                                double vp = logic.VP_MULTIPLE * FS.VPVALUE(ship) * (ship.DAMAGED ? 0.5 : 1);
                                GS.IncrementDouble("VP." + ship.SIDE, vp);
                            }
                            //remove unit?
                            if (logic.REMOVEUNIT)
                            {
                                removeReport += FS.INFOLINE1(ship) + " Removed from Gameplay\n";
                                FS.DESTROY(ship);
                                FS.REMOVESCENARIOOBJECT(GS, ship, true);
                            } 
                            else if (logic.REMOVELINK)
                            {
                                FS.DISCARDLOGIC(unitLink);
                            }
                        }
                        if (removeReport != "")
                        {
                            MainWindow.Alert(removeReport);
                        }
                    }
                }
            }
        }
        public static void AI_GENERATESHIPLINKS(List<GO> all, List<GO> invalidObjectives)
        {
            //normally called during pre action group phase
            all = [.. all.Where(n => n.TYPE == "SHIP" && n.ENROUTEDELAY == 0 && n.SEARCHDELAY == 0)];
            if (all.Count == 0) { return; }
            GameScenario GS = all[0].GS;
            string side = all[0].SIDE;
            int aggressionfactor = GS.Get("AI." + side) switch
            {
                "CAUTIOUS" => 1,
                "AGGRESSIVE" => 3,
                _ => 2
            };
            List<GO> SQNALLOWED = [.. FS.TYPESIDE(GS, "LOCATION", side).Where(n => n.AIRFIELD || n.LOGAIR)];
            List<GO> SNALLOWED = [.. GS.LOCATIONS().Where(n => (n.TERRAIN == "SEA" || n.LOGSEA) && !n.SHOALS)];
            List<GO> SURFACEALLOWED = [.. SNALLOWED.Where(n => !n.PACKICE)];
            List<GO> SSALLOWED = [.. SURFACEALLOWED];

            //these should be units with no ROLE
            List<GO> objs = [..all.Where(n => !FS.ISGROUP(n) && n.AIROLE == null)];
            //group units by location
            Dictionary<GO, List<GO>> LOCATION_UNIT_MAP = FS.AI_CREATEGROUPINGLOGICS(GS,objs);

            foreach (GO loc in LOCATION_UNIT_MAP.Keys)
            {
                List<GO> processed = [];
                foreach (GO obj in LOCATION_UNIT_MAP[loc])
                {
                    if (processed.Contains(obj)) { continue; }
                    //GO currentLogicLink = FS.TYPESIDE(GS, "AI.LOGICLINK", obj.SIDE).Where(n => n.UNIT == obj && n.ACTIVE).SingleOrDefault();
                    switch (obj.UNITCATEGORY)
                    {
                        case "SUB":
                            GO LOGICLINK = FS.GETQUALIFIEDLOGICLINK(obj, invalidObjectives);
                            if (LOGICLINK == null) { continue; }
                            GO logic = LOGICLINK.LOGIC;
                            GO link = LOGICLINK;
                            List<GO> COVERAGE = FS.VALIDCOVERAGE(logic);
                            switch (obj.UNITTYPE)
                            {
                                case "SN":
                                    COVERAGE = [..COVERAGE.Intersect(SNALLOWED)];
                                    GO focus = logic.OBJECTIVETYPE == "REPLENISH" ? COVERAGE.OrderBy(n => GS.GetDistance(n, obj.GAMELOCATION.x, obj.GAMELOCATION.y)).First() : GS.RANDOMGAMEOBJECT(COVERAGE);
                                    link.AIFOCUSLOCATIONID = focus.ID;
                                    link.AIFOCUSLOCATION = focus;
                                    break;
                                case "SS":
                                    COVERAGE = [.. COVERAGE.Intersect(SSALLOWED)];
                                    focus = logic.OBJECTIVETYPE == "REPLENISH" ? COVERAGE.OrderBy(n => GS.GetDistance(n, obj.GAMELOCATION.x, obj.GAMELOCATION.y)).First() : GS.RANDOMGAMEOBJECT(COVERAGE);
                                    link.AIFOCUSLOCATIONID = focus.ID;
                                    link.AIFOCUSLOCATION = focus; 
                                    break;
                                default:
                                    break;
                            }
                            link.LINKCYCLES = 0;
                            //if the sub picks up a commando or mine objective, ensure it has the ammo
                            switch (logic.OBJECTIVETYPE)
                            {
                                case "INSERT COMMANDOS":
                                    if (obj.COMMANDOPTS == 0)
                                    {   
                                        obj.COMMANDOPTS = 1;
                                        obj.TORPPTS -= 1;
                                    }                                    
                                    break;
                                case "LAY MINES":
                                    if(obj.MINEPTS == 0)
                                    {
                                        obj.MINEPTS = 1;
                                        obj.TORPPTS -= 3;
                                    }
                                    break;
                                default:
                                    break;
                            }

                            break;
                        case "SURFACE":
                            GO activatingUnit = null;
                            FS.CREATE_TF_PHASE = true;
                            GO GROUPINGLOGIC = GS.TYPE("GROUPINGLOGIC").Where(n => n.UNIT == obj).Single();
                            List<GO> groupingunits = [.. GS.TYPE("GROUPINGLOGIC").Where(n => n == GROUPINGLOGIC || (n.LABEL == GROUPINGLOGIC.LABEL && n.LABEL != null)).Select(n => n.UNIT)];
                            List<GO> groups = [.. groupingunits.Where(n => n.GROUPID != null).Select(n => n.GROUP).Distinct()];
                            groups.AddRange(groupingunits.Where(n => n.ACTIVATIONGRPID != null).Select(n => n.ACTIVATIONGRP).Distinct());
                            if (groupingunits.Count >= 2)
                            {
                                processed.AddRange(groupingunits);
                                List<GO> allLINKS = [.. groupingunits.Select(n => FS.GETQUALIFIEDLOGICLINK(n, invalidObjectives))];
                                allLINKS.RemoveAll(n => n == null);
                                foreach (GO logiclink in allLINKS)
                                {
                                    logiclink.ACTIVE = false;
                                    logiclink.LINKCYCLES = 0;
                                }
                                groupingunits = [.. allLINKS.Select(n => n.UNIT)];
                                List<GO> filteredLINKS = allLINKS.Where(n => n.INTERRUPTED).Any() ? [.. allLINKS.Where(n => n.INTERRUPTED)] : allLINKS;
                                LOGICLINK = FS.GETOPTIMALOBJECTIVE(filteredLINKS); 
                                GO focus = null;
                                logic = LOGICLINK.LOGIC;
                                link = LOGICLINK;
                                GO group = groups.FirstOrDefault() ?? FS.CREATEGROUP(GS, groupingunits.First(), groupingunits.First().GAMELOCATIONID);
                                activatingUnit = group;
                                List<GO> currentFoci = [.. filteredLINKS.Where(n => n.LOGIC == LOGICLINK.LOGIC && n.AIFOCUSLOCATION != null).Select(n => n.AIFOCUSLOCATION)];  
                                if(currentFoci.Count > 0){
                                    focus = GS.RANDOMGAMEOBJECT(currentFoci);
                                } 
                                else
                                {
                                    COVERAGE = [.. FS.VALIDCOVERAGE(logic).Intersect(SURFACEALLOWED)];
                                    focus = logic.OBJECTIVETYPE == "REPLENISH" ? COVERAGE.OrderBy(n => GS.GetDistance(n, obj.GAMELOCATION.x, obj.GAMELOCATION.y)).First() : GS.RANDOMGAMEOBJECT(COVERAGE);
                                }
                                groups.Remove(group);
                                foreach (GO surface in groupingunits.Where(n => n.GROUP != group && n.ACTIVATIONGRP != group))
                                {
                                    surface.GROUPID = null;
                                    surface.ACTIVATIONGRPID = null;
                                    FS.ADDTOGROUP(surface, group);
                                }
                                GO grouplink = FS.TYPESIDE(GS, "AI.LOGICLINK", obj.SIDE).Where(n => n.UNIT == group).SingleOrDefault(); 
                                grouplink ??= FS.CREATEAILOGICLINK(LOGICLINK.LOGIC, group, group.SIDE);
                                grouplink.LOGIC = LOGICLINK.LOGIC;
                                grouplink.UNIT = group;
                                grouplink.ACTIVE = true;
                                grouplink.AIFOCUSLOCATIONID = focus.ID;
                                grouplink.AIFOCUSLOCATION = focus;
                                grouplink.LINKCYCLES = 0;
                                foreach(GO otherlink in FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => n != grouplink && n.LOGIC == grouplink.LOGIC && groupingunits.Contains(n.UNIT))){
                                    otherlink.AIFOCUSLOCATIONID = focus.ID;
                                    otherlink.AIFOCUSLOCATION = focus;
                                }
                                groupingunits = [.. groupingunits.OrderByDescending(n => n.TEMPLATE.DEF).ThenByDescending(n => n.TEMPLATE.CAA)];
                                foreach(GO gm in groupingunits)
                                {
                                    gm.GROUPINDEX = groupingunits.IndexOf(gm);
                                }
                            }
                            else
                            {
                                obj.GROUPID = null;
                                obj.ACTIVATIONGRPID = null;
                                processed.Add(obj);
                                LOGICLINK = FS.GETQUALIFIEDLOGICLINK(obj, invalidObjectives);
                                if (LOGICLINK == null) { continue; }
                                logic = LOGICLINK.LOGIC;
                                COVERAGE = [.. FS.VALIDCOVERAGE(logic).Intersect(SURFACEALLOWED)];
                                link = LOGICLINK;
                                GO focus = logic.OBJECTIVETYPE == "REPLENISH" ? COVERAGE.OrderBy(n => GS.GetDistance(n, obj.GAMELOCATION.x, obj.GAMELOCATION.y)).First() : GS.RANDOMGAMEOBJECT(COVERAGE);
                                link.AIFOCUSLOCATIONID = focus.ID;
                                link.AIFOCUSLOCATION = focus;
                                link.LINKCYCLES = 0;
                                activatingUnit = obj;
                            }
                            FS.CREATE_TF_PHASE = false;
                            groups.ForEach(FS.UPDATEGROUP);
                            //if we are in the activation cycle, we need to ensure unit has the things it needs like destination piece
                            if(FS.GROUPMEMBERS(activatingUnit).Where(n => n.ACTIVATED && !n.DONE).Any() && activatingUnit.DESTINATIONPIECEID == null)
                            {
                                obj.ACTIVATED = true;                                
                                obj.LOCATIONHISTORY = obj.GAMELOCATIONID;
                                obj.LOCATIONFUTURE = obj.GAMELOCATIONID;
                                //create destination marker
                                GO template = GS.PIECE("ACTION.DESTINATION");
                                Dictionary<string, string> clonedData = new(template._data);
                                clonedData["ID"] = obj.ID + GO.DELIM + "DESTINATION" + GO.DELIM + GENERATETIMESTAMP();
                                clonedData["LABEL"] = template.LABEL;
                                GO clone = new(GS, clonedData, null, null);
                                GS.CHANGELOCATION(clone, obj.GAMELOCATIONID);
                                clone.SIDE = obj.SIDE;
                                obj.DESTINATIONPIECEID = clone.ID;
                                obj.DESTINATIONPIECE = clone;
                                clone.GAMEPIECEID = obj.ID;
                                clone.GAMEPIECE = obj;
                                GS.ShuffleMarkerToBottom(clone);                                
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            FS.TYPESIDE(GS, "AI.LOGICLINK", side).ForEach(n => n.INTERRUPTED = false);
        }
        public static List<GO> VALIDCOVERAGE(GO obj)
        {
            GameScenario GS = obj.GS;
            string s = obj.SIDE;
            List<GO> COVERAGE = [.. obj.LOCATIONCOVERAGE.Split('|').Select(GS.LOCATION)];
            //if objective is linked to a trigger, and trigger is false, clear coverage
            GO LOGICLINK = obj.GS.TYPE("AI.LOGICLINK").Where(n => n.UNIT == obj).FirstOrDefault();
            if (LOGICLINK?.LOGIC.ACTIVE == false)
            {
                COVERAGE.Clear();
            }

            switch (obj.OBJECTIVETYPE)
            {
                case "DESTROY BASE":
                    return [.. COVERAGE.Where(n => n.SIDE == FS.ENEMY(s) && ((n.AIRFIELD && !n.AIRFIELDDESTROYED) || (n.PORT && !n.PORTDESTROYED) || (n.CLOSEDEFENSE && !n.CLOSEDEFENSEDESTROYED)))];
                case "DESTROY AIRFIELD":
                    return [.. COVERAGE.Where(n => n.SIDE == FS.ENEMY(s) && n.AIRFIELD && !n.AIRFIELDDESTROYED)];
                case "DESTROY PORT":
                    return [.. COVERAGE.Where(n => n.SIDE == FS.ENEMY(s) && n.PORT && !n.PORTDESTROYED)];
                case "DESTROY CLOSEDEFENSE":
                    return [.. COVERAGE.Where(n => n.SIDE == FS.ENEMY(s) && n.CLOSEDEFENSE && !n.CLOSEDEFENSEDESTROYED)];
                case "INVADE":
                    return [.. COVERAGE.Where(n => n.SIDE == FS.ENEMY(s) && (n.AIRFIELD || n.PORT || n.CLOSEDEFENSE))];
                case "UNLOAD":
                    return [.. COVERAGE.Where(n => n.SIDE == s && (n.AIRFIELD || n.PORT || n.CLOSEDEFENSE))];
                case "LOAD":
                    if (FS.GARRISONWAR)
                    {
                        return [.. COVERAGE.Where(n => n.SIDE == s && n.ENEMYSTRENGTH == 0 && n.STRENGTH > 10 && n.PORT && !n.PORTDESTROYED)];
                    }
                    else
                    {
                        return [.. COVERAGE.Where(n => n.SIDE == s && n.PORT && !n.PORTDESTROYED)];
                    }
                case "REPLENISH":
                    return [.. COVERAGE.Where(n => n.SIDE == s && n.PORT && !n.PORTDESTROYED)];
                case "INSERT COMMANDOS":
                case "LAY MINES":
                    return [..COVERAGE.Where(n => n.SIDE != s)];
                default:
                    return COVERAGE;
            }
        }
        public static void AI_UPDATEPATROLLINKS(GameScenario GS, string side)
        {
            List<GO> LOGICLINKS = [.. FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => n.ACTIVE && n.LOGIC.OBJECTIVETYPE == "PATROL")];
            List<GO> COMBATLOCATIONS = FS.SCENARIOLOCATIONS(GS, "ACTION.COMBATLOCATIONS." + side);
            if (GS.GetInt("ACTION.CYCLES") != 0 && COMBATLOCATIONS.Count == 0)
            {
                LOGICLINKS.RemoveAll(n => n.UNIT.TYPE == "SHIP");
            }
            if (LOGICLINKS.Count == 0) { return; }
            List<GO> OTHERPATROLLOGICLINKS = [.. FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => !n.ACTIVE && n.SELECTABLE && n.LOGIC.OBJECTIVETYPE == "PATROL")];
            int aggressionfactor = FS.AIAGRESSION(GS, side);
            List<GO> SNALLOWED = [.. GS.LOCATIONS().Where(n => (n.TERRAIN == "SEA" || n.LOGSEA) && !n.SHOALS)];
            List<GO> SURFACEALLOWED = [.. SNALLOWED.Where(n => !n.PACKICE)];
            List<GO> SSALLOWED = [.. SURFACEALLOWED];

            List<GO> ENEMY = [.. FS.TYPESIDE(GS, "PIECE", FS.ENEMY(side)).Where(n => (n.TYPE == "SHIP" || n.TYPE == "SQN") && n.ENROUTEDELAY == 0 && (n.STRATDETECTED || n.LOCALDETECTED || n.ADMINDETECTED) && FS.LOGICALPARENT(n) == n)];
            List<GO> ENEMYSURFACELOCATIONS = [.. ENEMY.Where(n => n.UNITCATEGORY == "SURFACE" && n.GAMELOCATION.TYPE == "HEX").Select(n => n.GAMELOCATION).Distinct()];
            List<GO> ENEMYSUBLOCATIONS = [.. ENEMY.Where(n => n.UNITCATEGORY == "SUB" && n.GAMELOCATION.TYPE == "HEX").Select(n => n.GAMELOCATION).Distinct()];
            List<GO> ENEMYAIRLOCATIONS = [.. ENEMY.Where(n => n.UNITCATEGORY == "AIR" && n.GAMELOCATION.TYPE == "HEX").Select(n => n.GAMELOCATION).Distinct()];

            //groups that need to get a new focus location

            foreach (GO LOGICLINK in LOGICLINKS)
            {
                LOGICLINK.INTERCEPTMODE = false;
                GO obj = LOGICLINK.UNIT;
                bool unitQualifies = (obj.TYPE == "SHIP" || (obj.TYPE == "SQN" && obj.ACTIVATED)) && obj.ENROUTEDELAY == 0;
                if (!unitQualifies) 
                { 
                    LOGICLINK.INTERCEPTMODE = false; 
                    continue; 
                }
                if (obj.AIRMISSION == "RTB") 
                {
                    LOGICLINK.INTERCEPTMODE = false; 
                    continue; 
                }
                double interceptChance = Math.Min(100, 50 * aggressionfactor);
                if (obj.UNITCATEGORY == "AIR" && obj.NUMCOMBATS > 0) { obj.AIRMISSION = "RECON"; }
                if (obj.UNITCATEGORY == "AIR" && obj.UNITTYPE == "BMB" && obj.AIRMISSION == "BOMBING") { obj.AIRMISSION = "RECON"; }
                if (obj.AIRMISSION == "RECON") {
                    interceptChance *= 0.5;
                }
                bool DOINTERCEPT = GS.RANDOMINT(100) < interceptChance;
                bool ATFOCUS = obj.GAMELOCATION == LOGICLINK.AIFOCUSLOCATION;
                List<GO> CURRENTENEMYLOCATIONS = [];
                CURRENTENEMYLOCATIONS.AddRange(ENEMYSURFACELOCATIONS);
                CURRENTENEMYLOCATIONS.AddRange(ENEMYSUBLOCATIONS);
                if(obj.UNITCATEGORY == "AIR")
                {
                    CURRENTENEMYLOCATIONS.AddRange(ENEMYAIRLOCATIONS);
                }
                if (CURRENTENEMYLOCATIONS.Contains(LOGICLINK.AIFOCUSLOCATION))
                {
                    LOGICLINK.INTERCEPTMODE = true;
                    DOINTERCEPT = true;
                }
                if (!(DOINTERCEPT || ATFOCUS)) { continue; }
                
                GO focus = null;
                bool INTERCEPTING = false;
                GO RESULTLOGICLINK = LOGICLINK;
                //do some basic calcs if the unit is at focus location
                if (ATFOCUS)
                {
                    List<GO> COVERAGE = [];
                    GO logic = LOGICLINK.LOGIC;
                    string[] coverage = logic.LOCATIONCOVERAGE != null ? logic.LOCATIONCOVERAGE.Split('|') : [];

                    foreach (string c in coverage)
                    {
                        COVERAGE.Add(GS.LOCATION(c));
                    }
                    switch (obj.UNITCATEGORY)
                    {
                        case "SUB":
                            switch (obj.UNITTYPE)
                            {
                                case "SN":
                                    COVERAGE = [.. COVERAGE.Intersect(SNALLOWED)];
                                    break;
                                case "SS":
                                    COVERAGE = [.. COVERAGE.Intersect(SSALLOWED)];
                                    break;
                                default:
                                    break;
                            }
                            break;
                        case "SURFACE":
                            COVERAGE = [.. COVERAGE.Intersect(SURFACEALLOWED)];
                            break;
                        default:
                            break;
                    }
                    focus = GS.RANDOMGAMEOBJECT(COVERAGE);
                }
                if (LOGICLINK.INTERCEPTMODE)
                {
                    INTERCEPTING = true;
                    focus = LOGICLINK.AIFOCUSLOCATION;
                }
                else
                {
                    List<GO> PATROLLOGICS = [];
                    PATROLLOGICS.Add(LOGICLINK);
                    if (FS.ISGROUP(obj))
                    {
                        PATROLLOGICS.AddRange(OTHERPATROLLOGICLINKS.Where(n => FS.LOGICALPARENT(n.UNIT) == obj));
                    }
                    else
                    {
                        PATROLLOGICS.AddRange(OTHERPATROLLOGICLINKS.Where(n => n.UNIT == obj));
                    }
                    Dictionary<GO, GO> INTERCEPTLOCATIONTOLOGICLINK = [];
                    Dictionary<GO, GO> COMBATLOCATIONTOLOGICLINK = [];
                    foreach (GO logiclink in PATROLLOGICS)
                    {
                        List<GO> COVERAGE = [];
                        GO logic = logiclink.LOGIC;
                        string[] coverage = logic.LOCATIONCOVERAGE != null ? logic.LOCATIONCOVERAGE.Split('|') : [];

                        foreach (string c in coverage)
                        {
                            COVERAGE.Add(GS.LOCATION(c));
                        }
                        List<GO> INTERCEPT = [];
                        switch (obj.UNITCATEGORY)
                        {
                            case "AIR":
                                if (DOINTERCEPT)
                                {
                                    if (FS.GROUPMEMBERS(obj).Where(n => n.AIRMISSION == "SSM" || n.AIRMISSION == "BOMBING").Any())
                                    {
                                        INTERCEPT.AddRange(COVERAGE.Intersect(ENEMYSURFACELOCATIONS));
                                    }
                                    if (FS.GROUPMEMBERS(obj).Where(n => n.AIRMISSION == "ASW").Any())
                                    {
                                        INTERCEPT.AddRange(COVERAGE.Intersect(ENEMYSUBLOCATIONS));
                                    }
                                    if (FS.GROUPMEMBERS(obj).Where(n => n.UNITTYPE == "INT" && (n.AIRMISSION == "AIR SUPERIORITY" || n.AIRMISSION == "ESCORT")).Any())
                                    {
                                        INTERCEPT.AddRange(COVERAGE.Intersect(ENEMYAIRLOCATIONS));
                                    }
                                }
                                break;
                            case "SUB":
                                switch (obj.UNITTYPE)
                                {
                                    case "SN":
                                        COVERAGE = [.. COVERAGE.Intersect(SNALLOWED)];
                                        break;
                                    case "SS":
                                        COVERAGE = [.. COVERAGE.Intersect(SSALLOWED)];
                                        break;
                                    default:
                                        break;
                                }
                                if (DOINTERCEPT)
                                {
                                    if (FS.GROUPMEMBERS(obj).Where(n => n.AIROLE == "ANTI-SURFACE" || n.AIROLE == "WARSHIP").Any())
                                    {
                                        INTERCEPT.AddRange(COVERAGE.Intersect(ENEMYSURFACELOCATIONS));
                                    }
                                    if (FS.GROUPMEMBERS(obj).Where(n => n.AIROLE == "ANTI-SUB" || n.AIROLE == "WARSHIP").Any())
                                    {
                                        INTERCEPT.AddRange(COVERAGE.Intersect(ENEMYSUBLOCATIONS));
                                    }
                                }
                                break;
                            case "SURFACE":
                                COVERAGE = [.. COVERAGE.Intersect(SURFACEALLOWED)];
                                if (DOINTERCEPT)
                                {
                                    if (FS.GROUPMEMBERS(obj).Where(n => n.AIROLE == "ANTI-SURFACE" || n.AIROLE == "WARSHIP").Any())
                                    {
                                        INTERCEPT.AddRange(COVERAGE.Intersect(ENEMYSURFACELOCATIONS));
                                    }
                                    if (FS.GROUPMEMBERS(obj).Where(n => n.AIROLE == "ANTI-SUB" || n.AIROLE == "WARSHIP").Any())
                                    {
                                        INTERCEPT.AddRange(COVERAGE.Intersect(ENEMYSUBLOCATIONS));
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                        if (INTERCEPT.Count > 0)
                        {
                            foreach(GO interceptlocation in INTERCEPT.Distinct())
                            {
                                if(!INTERCEPTLOCATIONTOLOGICLINK.ContainsKey(interceptlocation))
                                {
                                    INTERCEPTLOCATIONTOLOGICLINK[interceptlocation] = logiclink;
                                }
                            }
                            INTERCEPTING = true;
                        }
                        List<GO> COMBATS = [.. COVERAGE.Intersect(COMBATLOCATIONS)];
                        if(COMBATS.Count > 0)
                        {
                            foreach(GO combatlocation in COMBATS.Distinct())
                            {
                                if(!COMBATLOCATIONTOLOGICLINK.ContainsKey(combatlocation))
                                {
                                    COMBATLOCATIONTOLOGICLINK[combatlocation] = logiclink;
                                }
                            }
                            INTERCEPTING = true;
                        }
                        
                    }
                    if (INTERCEPTING)
                    {
                        GO logiclink = null;
                        if(INTERCEPTLOCATIONTOLOGICLINK.Count > 0)
                        {
                            //find closest intercept location
                            focus = INTERCEPTLOCATIONTOLOGICLINK.OrderBy(n => GS.GetDistance(n.Key, obj.GAMELOCATION.x, obj.GAMELOCATION.y)).First().Key;
                            logiclink = INTERCEPTLOCATIONTOLOGICLINK[focus];
                        }
                        else if (COMBATLOCATIONTOLOGICLINK.Count > 0)
                        {
                            //find closest combat location
                            focus = COMBATLOCATIONTOLOGICLINK.OrderBy(n => GS.GetDistance(n.Key, obj.GAMELOCATION.x, obj.GAMELOCATION.y)).First().Key;
                            logiclink = COMBATLOCATIONTOLOGICLINK[focus];
                        }
                        if (logiclink != LOGICLINK)
                        {
                            if (FS.ISGROUP(obj))
                            {
                                //swap logic on logiclink
                                LOGICLINK.INTERCEPTMODE = true;
                                LOGICLINK.ACTIVE = true;
                                LOGICLINK.LOGICID = logiclink.LOGICID;
                                LOGICLINK.LOGIC = logiclink.LOGIC;
                                LOGICLINK.LINKCYCLES = 0;
                                RESULTLOGICLINK = LOGICLINK;
                            }
                            else
                            {
                                //switch to other patrol link
                                //old logiclink
                                LOGICLINK.INTERCEPTMODE = false;
                                LOGICLINK.ACTIVE = false;
                                LOGICLINK.LINKCYCLES = 0;
                                //new logiclink
                                logiclink.INTERCEPTMODE = true;
                                logiclink.ACTIVE = true;
                                logiclink.LINKCYCLES = 0;
                                RESULTLOGICLINK = logiclink;
                            }
                        }
                    }
                }
                if (INTERCEPTING)
                {
                    RESULTLOGICLINK.INTERCEPTMODE = true;
                    if (INTERCEPTING && obj.UNITCATEGORY == "AIR")
                    {
                        //adjust focus with standoff in mind
                        bool surface = ENEMYSURFACELOCATIONS.Contains(focus);
                        bool sub = ENEMYSUBLOCATIONS.Contains(focus);
                        bool air = ENEMYAIRLOCATIONS.Contains(focus);
                        int ssmrange = (int)obj.TEMPLATE.SSMRANGE;
                        ssmrange = Math.Min(GS.RANDOMINT(ssmrange) + 1, ssmrange);
                        int airstandoff = obj.UNITTYPE switch
                        {
                            "INT" => 4,
                            "AEW" => 4,
                            "RCN" => 2,
                            _ => 1
                        };
                        int standoff = obj.AIRMISSION switch
                        {
                            "RECON" => surface ? FS.GETAIRSURFACESEARCH(obj) :
                                        air ? airstandoff : 0,
                            "AIR SUPERIORITY" => air ? 0 : FS.GETAIRSURFACESEARCH(obj),
                            "ESCORT" => air ? 0 : FS.GETAIRSURFACESEARCH(obj),
                            "SSM" => ssmrange,
                            _ => 0
                        };
                        if(standoff > 0)
                        {
                            //walk back focus to standoff
                            List<FSMovement> newPath = FS.FINDAIRMOVEMENTPATH(focus, obj.GAMELOCATION);
                            for(int i = 0; i <= standoff && i < newPath.Count; i++)
                            {
                                focus = newPath[i].MOVEMENTLOCATION;
                            }
                        }
                    }
                }
                if(INTERCEPTING || ATFOCUS)
                {
                    RESULTLOGICLINK.AIFOCUSLOCATIONID = focus.ID;
                    RESULTLOGICLINK.AIFOCUSLOCATION = focus;
                    foreach (GO otherlink in FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => n != RESULTLOGICLINK && n.LOGIC == RESULTLOGICLINK.LOGIC && FS.LOGICALPARENT(n.UNIT) == obj))
                    {
                        otherlink.AIFOCUSLOCATIONID = focus.ID;
                        otherlink.AIFOCUSLOCATION = focus;
                    }
                }
            }
        }
        public static void AI_UPDATEGROUPINGLINKS(GameScenario GS, string side)
        {
            if (GS.GetInt("ACTION.CYCLES") != 0)
            {
                return;
            }
            List<GO> LOGICLINKS = [.. FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => n.UNIT.UNITCATEGORY == "SURFACE" && n.ACTIVE && n.LOGIC.OBJECTIVETYPE == "GROUPING")];
            if (LOGICLINKS.Count == 0) { return; }
            List<GO> FRIENDLY = [.. FS.TYPESIDE(GS, "SHIP", side).Where(n => n.ENROUTEDELAY == 0 && FS.LOGICALPARENT(n) == n)];
            
            //groups that need to get a new focus location

            foreach (GO LOGICLINK in LOGICLINKS)
            {
                GO obj = LOGICLINK.UNIT;
                bool unitQualifies = obj.ENROUTEDELAY == 0;
                if (!unitQualifies) 
                { 
                    LOGICLINK.INTERCEPTMODE = false; 
                    continue; 
                }
                List<GO> GROUPINGTARGETS = [.. FRIENDLY.Where(n => n != obj && n.UNITCATEGORY == "SURFACE" && n.GAMELOCATION.TYPE == "HEX")];
                List<GO> FRIENDLYSURFACELOCATIONS = [.. GROUPINGTARGETS.Select(n => n.GAMELOCATION).Distinct()];
            
                if (FRIENDLYSURFACELOCATIONS.Contains(obj.GAMELOCATION)) 
                {
                    LOGICLINK.INTERCEPTMODE = true; 
                    continue; 
                }
                List<GO> COVERAGE = [];
                GO logic = LOGICLINK.LOGIC;
                string[] coverage = logic.LOCATIONCOVERAGE != null ? logic.LOCATIONCOVERAGE.Split('|') : [];

                foreach (string c in coverage)
                {
                    COVERAGE.Add(GS.LOCATION(c));
                }
                FRIENDLYSURFACELOCATIONS = [.. COVERAGE.Intersect(FRIENDLYSURFACELOCATIONS)];

                LOGICLINK.INTERCEPTMODE = FRIENDLYSURFACELOCATIONS.Count > 0;
                if (LOGICLINK.INTERCEPTMODE)
                {
                    GO focus = FRIENDLYSURFACELOCATIONS.OrderBy(n => GS.GetDistance(n, obj.GAMELOCATION.x, obj.GAMELOCATION.y)).First();
                    GO GROUPINGTARGET = GROUPINGTARGETS.Where(n => n.GAMELOCATION == focus).First();
                    LOGICLINK.AIFOCUSLOCATIONID = focus.ID;
                    LOGICLINK.AIFOCUSLOCATION = focus;
                    foreach(GO otherlink in FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => n != LOGICLINK && n.LOGIC == logic && FS.LOGICALPARENT(n.UNIT) == obj)){
                        otherlink.AIFOCUSLOCATIONID = focus.ID;
                        otherlink.AIFOCUSLOCATION = focus;
                    }
                }
                else
                {
                    GO focus = obj.GAMELOCATION;
                    LOGICLINK.AIFOCUSLOCATIONID = focus.ID;
                    LOGICLINK.AIFOCUSLOCATION = focus;
                    foreach (GO otherlink in FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => n != LOGICLINK && n.LOGIC == logic && FS.LOGICALPARENT(n.UNIT) == obj))
                    {
                        otherlink.AIFOCUSLOCATIONID = focus.ID;
                        otherlink.AIFOCUSLOCATION = focus;
                    }
                }
            }
        }
        public static void AI_GENERATESHIPACTIVATIONS(GameScenario GS, List<GO> ships, string side)
        {
            //called during activate stack
            //for each logical parent
            if (ships.Count != 0)
            {
                foreach (GO activatingUnit in ships)
                {
                    GO loc = FS.PARENTGROUPLOCATION(activatingUnit);
                    List<GO> activatingUnits = new();
                    if (FS.ISGROUP(activatingUnit))
                    {
                        activatingUnits.Add(activatingUnit);
                        foreach (GO obj2 in FS.GROUPMEMBERS(activatingUnit).Where(n => !n.ACTIVATED))
                        {
                            activatingUnits.Add(obj2);
                        }
                    }
                    else
                    {
                        activatingUnits.Add(activatingUnit);
                    }
                    List<GO> FULLSPEEDDETECTORS = [];
                    foreach (string s in FS.SIDE_NAMES)
                    {
                        FULLSPEEDDETECTORS.AddRange(FS.TYPESIDE(GS, "SHIP", s).Where(n => n.ENROUTEDELAY == 0 && n.GAMELOCATION.TYPE == "HEX"));
                    }
                    foreach (GO obj in activatingUnits)
                    {
                        //when activated, determine if it can react to multiple patrol objectives
                        if (!FS.ISGROUP(obj))
                        {
                            bool multipatrol = GS.RANDOMINT(100) < FS.AIAGRESSION(GS, side) * 33;
                            foreach (GO link in FS.TYPESIDE(GS, "AI.LOGICLINK", side).Where(n => n.UNIT == obj && n.LOGIC.OBJECTIVETYPE == "PATROL"))
                            {
                                link.SELECTABLE = multipatrol;
                            }
                        }

                        obj.ACTIVATED = true;
                        obj.MOVEMENTALLOWANCE = FS.RESETMOVEMENTALLOWANCE(obj);
                        obj.DOCKED = false;
                        if (FS.LOGICALPARENT(obj) == obj)
                        {
                            obj.LOCATIONHISTORY = obj.GAMELOCATIONID;
                            obj.LOCATIONFUTURE ??= obj.GAMELOCATIONID;
                            if (FS.ISGROUP(obj))
                            {
                                FS.UPDATEGROUP(obj);
                            }
                            if (obj.UNITCATEGORY == "SUB" && obj.FULLSPEED && !obj.STRATDETECTED)
                            {
                                if (FS.FINDAIRRADIUS(obj.GAMELOCATION, 5).Intersect(FULLSPEEDDETECTORS.Where(n => n.SIDE == FS.ENEMY(obj.SIDE))).Any())
                                {
                                    FS.STRATDETECT(new() { obj }, true);
                                    FS.CREATEALERT(obj, null, FS.ENEMY(obj.SIDE));
                                }
                            }
                            if (obj.DESTINATIONPIECEID == null)
                            {
                                //create destination marker
                                //add attempt marker
                                GO template = GS.PIECE("ACTION.DESTINATION");
                                Dictionary<string, string> clonedData = new(template._data);
                                clonedData["ID"] = obj.ID + GO.DELIM + "DESTINATION" + GO.DELIM + GENERATETIMESTAMP();
                                clonedData["LABEL"] = template.LABEL;
                                GO clone = new(GS, clonedData, null, null);
                                GS.CHANGELOCATION(clone, obj.GAMELOCATIONID);
                                clone.SIDE = obj.SIDE;
                                obj.DESTINATIONPIECEID = clone.ID;
                                obj.DESTINATIONPIECE = clone;
                                clone.GAMEPIECEID = obj.ID;
                                clone.GAMEPIECE = obj;
                                GS.ShuffleMarkerToBottom(clone);
                            }
                        }
                        else
                        {
                            obj.LOCATIONHISTORY = null;
                            obj.LOCATIONFUTURE = null;
                            FS.UPDATEGROUP(FS.LOGICALPARENT(obj));
                        }
                    }
                }
            }
        }
        public static void AI_GENERATESQNLINKS(List<GO> all, List<GO> invalidObjectives)
        {
            all = [.. all.Where(n => n.TYPE == "SQN" && n.ENROUTEDELAY == 0 && n.SEARCHDELAY == 0 && FS.CANLAUNCHACTIVATE(n))];
            if (all.Count == 0) { return; }
            GameScenario GS = all[0].GS;
            string side = all[0].SIDE;
            
            //these should be units with no ROLE
            List<GO> objs = [.. all.Where(n => n.AIROLE == null)];
            //group units by location
            Dictionary<GO, List<GO>> LOCATION_UNIT_MAP = FS.AI_CREATEGROUPINGLOGICS(GS,objs);

            foreach (GO loc in LOCATION_UNIT_MAP.Keys)
            {
                List<GO> processed = [];
                foreach (GO obj in LOCATION_UNIT_MAP[loc])
                {
                    if (processed.Contains(obj)) { continue; }
                    //GO currentLogicLink = FS.TYPESIDE(GS, "AI.LOGICLINK", obj.SIDE).Where(n => n.UNIT == obj && n.ACTIVE).SingleOrDefault();
                    switch (obj.UNITCATEGORY)
                    {
                        case "AIR":
                            GO LOGICLINK = FS.GETQUALIFIEDLOGICLINK(obj, invalidObjectives);
                            if (LOGICLINK == null) { continue; }
                            GO logic = LOGICLINK.LOGIC;
                            List<GO> COVERAGE = FS.VALIDCOVERAGE(logic);
                            GO link = LOGICLINK;
                            GO focus = GS.RANDOMGAMEOBJECT(COVERAGE);
                            link.AIFOCUSLOCATIONID = focus.ID;
                            link.AIFOCUSLOCATION = focus;
                            link.LINKCYCLES = 0;
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        public static void AI_GENERATESQNACTIVATIONS(GameScenario GS, List<GO> sqns, string side)
        {
            //called during activate stack
            //for each logical parent
            if (sqns.Count != 0)
            {
                Dictionary<GO, List<GO>> LOCATION_UNIT_MAP = FS.AI_CREATEGROUPINGLOGICS(GS,sqns);

                foreach (GO loc in LOCATION_UNIT_MAP.Keys)
                {
                    if (GS.RANDOMINT(100) <= 66) { continue; }
                    foreach (GO activatingUnit in LOCATION_UNIT_MAP[loc])
                    {
                        List<GO> LOGICLINKS = [.. GS.TYPE("AI.LOGICLINK", "SIDE", activatingUnit.SIDE).Where(n => n.LOGIC.TYPE == "OBJECTIVELOGIC" && n.UNIT == activatingUnit)];                       
                        GO LOGICLINK = LOGICLINKS.Where(n => n.ACTIVE).SingleOrDefault();
                        if(LOGICLINK == null)
                        {
                            continue;
                        }
                        //when activated, determine if it can react to multiple patrol objectives
                        bool multipatrol = GS.RANDOMINT(100) < FS.AIAGRESSION(GS, side) * 33;
                        foreach (GO link in LOGICLINKS.Where(n => n.LOGIC.OBJECTIVETYPE == "PATROL"))
                        {
                            link.SELECTABLE = multipatrol;
                        }
                    
                        List<string> AIRMISSIONS = [];
                        GO sqn = activatingUnit;
                        if(activatingUnit.CARRIER?.DAMAGED == true && activatingUnit.CARRIER?.ACTIVATEDAIRUNITS == 1){
                            continue;
                        }
                        List<string> facilityObjectiveTypes = ["DESTROY BASE", "DESTROY AIRFIELD", "DESTROY PORT", "DESTROY CLOSEDEFENSE"];
                        bool CANBOMB = FS.GETAIRBOMB(sqn) > 0 && (sqn.CARRIERID == null || sqn.CARRIER.BOMBPTS > 0) && (sqn.UNITTYPE != "BMB" || facilityObjectiveTypes.Contains(LOGICLINK.LOGIC.OBJECTIVETYPE));
                        bool CANSSM = FS.GETAIRSSM(sqn) > 0 && ((sqn.CARRIERID == null && !sqn.TEMPLATE.LIMITEDSSM) || sqn.CARRIER?.AIRSSMPTS >= sqn.TEMPLATE.AIRSSMCOST) && !facilityObjectiveTypes.Contains(LOGICLINK.LOGIC.OBJECTIVETYPE);
                        bool CANCM = sqn.CMPTS > 0 && facilityObjectiveTypes.Contains(LOGICLINK.LOGIC.OBJECTIVETYPE);
                        bool CANTORP = sqn.TEMPLATE.ASW > 0 && !facilityObjectiveTypes.Contains(LOGICLINK.LOGIC.OBJECTIVETYPE);
                        switch (sqn.UNITTYPE)
                        {
                            case "INT":
                                AIRMISSIONS.Add("ESCORT");
                                break;
                            case "EW":
                                AIRMISSIONS.Add("ESCORT");
                                break;
                            case "RCN":
                                if (CANTORP) { AIRMISSIONS.Add("ASW"); }
                                break;
                            default:
                                break;
                        }
                        if (CANBOMB) { AIRMISSIONS.Add("BOMBING"); }
                        if (CANSSM) { AIRMISSIONS.Add("SSM"); }
                        if (CANCM) { AIRMISSIONS.Add("CRUISE MISSILE"); }
                        if (FS.GETAIRSURFACESEARCH(sqn) > 0 && FS.AIRSURFACEINTERACTION && AIRMISSIONS.Count == 0) { AIRMISSIONS.Add("RECON"); }

                        if(AIRMISSIONS.Count == 0) { continue; }
                        foreach(string am in AIRMISSIONS.Where(n => n == sqn.AIPRIMARYROLE).ToList())
                        {
                            AIRMISSIONS.Add(am);
                            AIRMISSIONS.Add(am);
                        }
                        sqn.AIRMISSION = AIRMISSIONS[GS.RANDOMINT(AIRMISSIONS.Count)];
                        List<GO> activatingUnits = new();
                        GO homebase = activatingUnit.CARRIER ?? activatingUnit.GAMELOCATION;
                        activatingUnit.HOMEBASEID = homebase.ID;
                        activatingUnit.HOMEBASE = homebase;
                        if (activatingUnit.CARRIER != null)
                        {
                            activatingUnit.HOMEBASE.ACTIVATEDAIRUNITS++;
                            FS.REMOVEFROMGROUP(activatingUnit, activatingUnit.CARRIER);
                        }
                        if (activatingUnit.UNITTYPE == "INT")
                        {
                            activatingUnit.ROLE = activatingUnit.AIRMISSION == "SSM" || activatingUnit.AIRMISSION == "BOMBING" ? "BOMBER" : "FIGHTER";
                        }
                        switch (activatingUnit.AIRMISSION)
                        {
                            case "CRUISE MISSILE":
                                activatingUnit.CM = activatingUnit.TEMPLATE.CM;
                                break;
                            case "SSM":
                                activatingUnit.SSM = FS.GETAIRSSM(activatingUnit);
                                activatingUnit.SSMPTS = Math.Max(1, activatingUnit.TEMPLATE.AIRSSMCOST);
                                if (!activatingUnit.HOMEBASE.AIRFIELD)
                                {
                                    activatingUnit.HOMEBASE.AIRSSMPTS -= activatingUnit.SSMPTS;
                                }
                                break;
                            case "AIR SUPERIORITY":
                            case "ESCORT":
                                if (activatingUnit.UNITTYPE == "INT")
                                {
                                    if (activatingUnit.COUNTRY == "USA" && activatingUnit.LABEL.StartsWith("F-14"))
                                    {
                                        activatingUnit.MAA = true;
                                    }
                                    activatingUnit.ROLE = "FIGHTER";
                                }
                                break;
                            case "MINING":
                                activatingUnit.MINEPTS = 1;
                                break;
                            case "ASW":
                                activatingUnit.TORPPTS = 1;
                                break;
                            case "BOMBING":
                                activatingUnit.SPECIAL = FS.GETAIRBOMB(activatingUnit);
                                activatingUnit.BOMBPTS = 1;
                                if (!activatingUnit.HOMEBASE.AIRFIELD)
                                {
                                    activatingUnit.HOMEBASE.BOMBPTS -= activatingUnit.BOMBPTS;
                                }
                                break;
                            case "TROOPS":
                            case "CARGO":
                                FS.CANATR(activatingUnit, activatingUnit.AIRMISSION == "CARGO", true);
                                break;
                            default:
                                break;
                        }
                        activatingUnits.Add(activatingUnit);
                        foreach (GO obj in activatingUnits)
                        {
                            obj.ACTIVATED = true;
                            obj.MOVEMENTALLOWANCE = FS.RESETMOVEMENTALLOWANCE(obj);
                            obj.DOCKED = false;
                            if (FS.LOGICALPARENT(obj) == obj)
                            {
                                obj.LOCATIONHISTORY = obj.GAMELOCATIONID;
                                obj.LOCATIONFUTURE ??= obj.GAMELOCATIONID;
                                if (FS.ISGROUP(obj))
                                {
                                    FS.UPDATEGROUP(obj);
                                }
                                if (obj.DESTINATIONPIECEID == null)
                                {
                                    //create destination marker
                                    //add attempt marker
                                    GO template = GS.PIECE("ACTION.DESTINATION");
                                    Dictionary<string, string> clonedData = new(template._data);
                                    clonedData["ID"] = obj.ID + GO.DELIM + "DESTINATION" + GO.DELIM + GENERATETIMESTAMP();
                                    clonedData["LABEL"] = template.LABEL;
                                    GO clone = new(GS, clonedData, null, null);
                                    GS.CHANGELOCATION(clone, obj.GAMELOCATIONID);
                                    clone.SIDE = obj.SIDE;
                                    obj.DESTINATIONPIECEID = clone.ID;
                                    obj.DESTINATIONPIECE = clone;
                                    clone.GAMEPIECEID = obj.ID;
                                    clone.GAMEPIECE = obj;
                                    GS.ShuffleMarkerToBottom(clone);
                                }
                            }
                            else
                            {
                                obj.LOCATIONHISTORY = null;
                                obj.LOCATIONFUTURE = null;
                                FS.UPDATEGROUP(FS.LOGICALPARENT(obj));
                            }
                        }
                    }
                }
            }
        }
        public static GO GETQUALIFIEDLOGICLINK(GO obj, List<GO> invalidObjectives)
        {
            GameScenario GS = obj.GS;
            int turn = GS.GetInt("TURN");
            bool init = turn == 1 && GS.GetInt("ACTION.CYCLES") == 0 && GS.GetInt("ACTION.ROUNDS") == 0;
            string role = obj.AIPRIMARYROLE;
            List<GO> OBJECTIVE_CANDIDATES = [.. obj.GS.TYPE("AI.LOGICLINK", "SIDE", obj.SIDE).Where(n => n.LOGIC.TYPE == "OBJECTIVELOGIC" && n.UNIT == obj && !invalidObjectives.Contains(n.LOGIC))];
            bool HASREPLENISHMENTLINK = OBJECTIVE_CANDIDATES.Where(n => n.LOGIC.OBJECTIVETYPE == "REPLENISH").Any();
            bool commandoINIT = init && OBJECTIVE_CANDIDATES.Where(n => n.LOGIC.OBJECTIVETYPE == "INSERT COMMANDOS").Any();
            bool mineINIT = init && OBJECTIVE_CANDIDATES.Where(n => n.LOGIC.OBJECTIVETYPE == "LAY MINES").Any();
            bool NEEDFUEL = obj.TEMPLATE.FUELPTS > 0 && obj.FUELPTS <= 1;
            if(obj.UNITTYPE == "PC")
            {
                string turntype = GS.Get("TURN.TYPE");
                NEEDFUEL = (turntype == "NIGHT" && turn % 2 == 0) || (turntype == "PM" && turn % 2 == 1);
            }
            Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA([obj]);
            bool SSMCAPABLE = attackData.ContainsKey(obj) && attackData[obj].ContainsKey("SSM");
            bool TORPCAPABLE = attackData.ContainsKey(obj) && attackData[obj].ContainsKey("TORP");
            bool ASWCAPABLE = attackData.ContainsKey(obj) && attackData[obj].ContainsKey("ASW");
            bool CMCAPABLE = attackData.ContainsKey(obj) && attackData[obj].ContainsKey("CM");
            bool CCCAPABLE = attackData.ContainsKey(obj) && attackData[obj].ContainsKey("CC");
            bool BOMBCAPABLE = attackData.ContainsKey(obj) && attackData[obj].ContainsKey("BOMB");

            List<GO> QUALIFYING_CANDIDATES = [.. OBJECTIVE_CANDIDATES.Where(n => n.INTERRUPTED)];
            if (QUALIFYING_CANDIDATES.Count == 0)
            {
                foreach (GO link in OBJECTIVE_CANDIDATES)
                {
                    bool qualifies = false;
                    switch (link.LOGIC.OBJECTIVETYPE)
                    {
                        case "LOAD":
                            qualifies = obj.EMPTY;
                            break;
                        case "UNLOAD":
                        case "INVADE":
                            qualifies = !obj.EMPTY;
                            break;
                        case "PATROL":
                            switch (obj.UNITCATEGORY)
                            {
                                case "SURFACE":
                                case "SUB":
                                    switch (role)
                                    {
                                        case "TRANSPORT":
                                            qualifies = true;
                                            break;
                                        case "ANTI-SURFACE":
                                            qualifies = (SSMCAPABLE || TORPCAPABLE) && !NEEDFUEL;
                                            break;
                                        case "ANTI-SUB":
                                            qualifies = ASWCAPABLE && !NEEDFUEL;
                                            break;
                                        case "WARSHIP":
                                            qualifies = (SSMCAPABLE || TORPCAPABLE || ASWCAPABLE) && !NEEDFUEL;
                                            break;
                                        default:
                                            qualifies = false;
                                            break;
                                    }
                                    break;
                                case "AIR":
                                    qualifies = true;
                                    break;
                                default:
                                    qualifies = false;
                                    break;
                            }
                            qualifies = !HASREPLENISHMENTLINK || qualifies;
                            break;
                        case "REPLENISH":
                            switch (role)
                            {
                                case "TRANSPORT":
                                    qualifies = false;
                                    break;
                                case "ANTI-SURFACE":
                                    qualifies = (!SSMCAPABLE && !TORPCAPABLE && obj.BOMBPTS == 0) || NEEDFUEL;
                                    break;
                                case "ANTI-SUB":
                                    qualifies = !ASWCAPABLE || NEEDFUEL;
                                    break;
                                case "WARSHIP":
                                    qualifies = !(SSMCAPABLE || TORPCAPABLE || obj.BOMBPTS > 0 || ASWCAPABLE) || NEEDFUEL;
                                    break;
                                case "SUPPORT":
                                    qualifies = (obj.APTS == 0 && obj.TEMPLATE.APTS > 0) || (obj.FPTS == 0 && obj.TEMPLATE.FPTS > 0);
                                    break;
                                default:
                                    qualifies = false;
                                    break;
                            }
                            break;
                        case "DESTROY BASE":
                        case "DESTROY AIRFIELD":
                        case "DESTROY PORT":
                        case "DESTROY CLOSEDEFENSE":
                            bool validMission = false;
                            if (obj.UNITCATEGORY == "AIR" && (obj.AIRMISSION != null))
                            {
                                List<string> allowedAirMissions = ["ESCORT", "BOMBING", "CRUISE MISSILE"];
                                validMission = allowedAirMissions.Contains(obj.AIRMISSION);

                            }
                            qualifies = ((CMCAPABLE || CCCAPABLE || BOMBCAPABLE || validMission) && (!NEEDFUEL || !HASREPLENISHMENTLINK));
                            break;
                        case "GROUPING":
                            qualifies = !HASREPLENISHMENTLINK || !NEEDFUEL;
                            break;
                        case "TRANSIT":
                            qualifies = true;
                            break;
                        case "INSERT COMMANDOS":
                            qualifies = obj.COMMANDOPTS > 0 || commandoINIT;
                            break;
                        case "LAY MINES":
                            qualifies = obj.MINEPTS > 0 || mineINIT;
                            break;
                        default:
                            break;
                    }

                    if (qualifies)
                    {
                        QUALIFYING_CANDIDATES.Add(link);
                    }
                }
            }
            GO LOGICLINK = QUALIFYING_CANDIDATES.Count != 0 ? GETOPTIMALOBJECTIVE(QUALIFYING_CANDIDATES) : null;
            OBJECTIVE_CANDIDATES.ForEach(n => n.ACTIVE = n == LOGICLINK);
            if (LOGICLINK == null)
            {
                return null;
            }
            LOGICLINK.LINKCYCLES = 0;
            obj.AIROLE = role ?? "DEFAULT";
            return LOGICLINK;
        }
        public static GO GETOPTIMALOBJECTIVE(List<GO> LOGICLINKS)
        {
            if (LOGICLINKS.Count == 0) { return null; }
            GameScenario GS = LOGICLINKS[0].GS;
            string side = LOGICLINKS[0].SIDE;
            double strategy = GS.Get("AI." + side) switch
            {
                "CAUTIOUS" => 1,
                "AGGRESSIVE" => 3,
                _ => 2
            };
            Dictionary<GO, double> WEIGHTS = [];
            Dictionary<GO, double> AWARD_WEIGHTS = [];
            List<GO> ALL = [];
            foreach (GO LOGICLINK in LOGICLINKS)
            {
                double vpfactor = Math.Max(0.1, LOGICLINK.LOGIC.VP_MULTIPLE);
                double unitfactor = FS.VPVALUE(LOGICLINK.UNIT);
                double utility = vpfactor * unitfactor;
                if (!WEIGHTS.TryGetValue(LOGICLINK, out double val))
                {
                    WEIGHTS.Add(LOGICLINK, 0);
                }
                WEIGHTS[LOGICLINK] += utility;
                if (LOGICLINK.LOGIC.VP_AWARD)
                {
                    if (!AWARD_WEIGHTS.TryGetValue(LOGICLINK, out double aval))
                    {
                        AWARD_WEIGHTS.Add(LOGICLINK, 0);
                    }
                    AWARD_WEIGHTS[LOGICLINK] += utility;
                }
            }
            if (AWARD_WEIGHTS.Count > 0)
            {
                List<GO> PRIORITYLINKS = [.. AWARD_WEIGHTS.Keys];
                double smallest = PRIORITYLINKS.Min(n => AWARD_WEIGHTS[n]);
                foreach (GO link in PRIORITYLINKS)
                {
                    for (double i = 0; i < AWARD_WEIGHTS[link]; i += Math.Min(smallest, 1))
                    {
                        ALL.Add(link);
                    }
                }
            }
            else if (WEIGHTS.Count > 0)
            {
                List<GO> PRIORITYLINKS = [.. WEIGHTS.Keys];
                double smallest = PRIORITYLINKS.Min(n => WEIGHTS[n]);
                foreach (GO link in PRIORITYLINKS)
                {
                    for (double i = 0; i < WEIGHTS[link]; i += Math.Min(smallest, 1))
                    {
                        ALL.Add(link);
                    }
                }
            }
            GO WINNER = GS.RANDOMGAMEOBJECT(ALL);
            /*string report = "";
            List<GO> rLOGICS = [.. ALL.Select(n => n.LOGIC).Distinct()];
            if (rLOGICS.Count > 1)
            {
                foreach (GO unit in ALL.Select(n => n.UNIT).Distinct())
                {
                    report += FS.INFOLINE1(unit) + "\n";
                }
                foreach (GO logic in ALL.Select(n => n.LOGIC).Distinct())
                {
                    report += "\n" + logic.OBJECTIVETYPE + " " + (int)((double)ALL.Where(n => n.LOGIC == logic).Count() / (double)ALL.Count * 100) + "%" + (WINNER.LOGIC == logic ? "*" : "");
                }
                MainWindow.Alert(report);
            }*/
            return WINNER;
        }
        public override void GOLabelChange(GO obj)
        {
            if (obj != null)
            {
                if (FS.SIDE_MODE.Contains(obj.SIDE))
                {
                    if (obj == SelectedMarker)
                    {
                        LabelChangeDialog labelChangeDialog = new LabelChangeDialog(SelectedMarker);
                        labelChangeDialog.ShowDialog();
                        _Window.ActionContext = ["CLICKED"];
                        _Window.RefreshScenario();
                    }
                    else if (obj == ClickedMarker)
                    {
                        LabelChangeDialog labelChangeDialog = new LabelChangeDialog(ClickedMarker);
                        labelChangeDialog.ShowDialog();
                        _Window.ClickMarker(ClickedMarker, true);
                    }
                }
            }
        }
    }
    public class ScenarioCombined : FS
    {
        public ScenarioCombined(string pid, MainWindow pwindow){
            data.ID = pid;
            AddChildPhase(new SetupSegment("SETUP", null, this));
            AddChildPhase(new TurnLoop("*TURN", null, this));
            _Window = pwindow;
            //commit countries
            foreach(string side in ALIGNEDCOUNTRIES.Keys){
                foreach(string country in ALIGNEDCOUNTRIES[side]){Set(country + ".SIDE", side);}
            }
            Set("ACTIVE.SIDE", "SOV");
            Set("ACTIVE.SIDE1", "SOV");
            SetBoolean("AI.MENUINFO", true);
            //SetInt("SY.INFLUENCE", 2);
            //NAVALMOVES
            //SetBoolean("NATO.NORTH", true);
            //SetInt("NATO.ATR.MAX", 17);
            WorldSize = 35352;
            MarkerSize = 80;
            _Window.XY_MARKER_OFFSET = 1;
            //450 miles/day
            //land combat
            //ATTACKING: 
            //probably going to need a LOGIC object with FROM -> TO and which faucets are on
            //this N can be multiplied by attacking from multiple locations
            //any location where strength from both sides automatic battle, you are in charge of whether you reinforce
            //COMBAT: N*3 sized chunks, each turn, strength totals compare.  each side given percentage of total
            //half of each sides percentage => enemy loses 1
            //SUPPLIES:  each AM turn supplies go down per chunk
            //each battle supplies go down per chunk
            //when supplies reach 0, chance of damage enemy reduced in half

        }
        public override void Finish()
        {
            if(!GetBoolean("WAR") && GetInt("TURN") == 99){
                Set("RESULT", "NATO Decisive Victory at Peace Turn 99!");
            }
            else
            {
                Set("RESULT", "No Result");
            }
        }
    }
}