using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Windows.Documents;
using System.Configuration;
using System.ComponentModel;

namespace CWApp.FS
{
    public class SetupSegment : GamePhaseGroup
    {
        public SetupSegment(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            //AddGamePhase(new SetupHexesAndConnectors("Setup Hexes and Connectors", this, GS));
            AddGamePhase(new SetupBases("Setup Bases And Allegiences", this, GS));
            AddGamePhase(new SetupForces("Setup Forces", this, GS));
            AddGamePhase(new DeploymentLoop("Loop", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
    }
    public class SetupHexesAndConnectors : GamePhaseInteractive
    {
        Dictionary<String, System.Windows.Media.SolidColorBrush> TypeColorMap= new(){
            {"SEA", System.Windows.Media.Brushes.Blue},
            {"COASTAL", System.Windows.Media.Brushes.Gray},
            {"LAND", System.Windows.Media.Brushes.Black},
            {"AIR", System.Windows.Media.Brushes.White},
            {"OMAF", System.Windows.Media.Brushes.White}
        };
        public string GOMode = null;
        public string ClipBoardCountry = null;
        public string ClipBoardZone = null;
        public string ClipBoardHexType = null;
        public string ClipBoardIceType = null;
        public string ClipBoardConnectorType = null;
        public Boolean CopyCountryMode = false;
        public Boolean CopyZoneMode = false;
        public SetupHexesAndConnectors(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            MapClick = true;
        }
        public override void Execute(Boolean init){
            if(GS.Get("_CONFIG_HEXSETUP_THEATERS") == null){GS.Advance(this); return;}
            List<string> instructions = new();
            if(init){
                List<string> theaters = GS.Get("_CONFIG_HEXSETUP_THEATERS").Split(',').ToList();
                ClipBoardCountry = null;
                ClipBoardZone = null;
                ClipBoardIceType = null;
                ClipBoardHexType = null;
                ClipBoardConnectorType = null;
                GOMode = null;
                CopyCountryMode = false;
                CopyZoneMode = false;
                //INIT HEXTYPES
                foreach(GO hex in GS.TYPE("HEX").Where(n => theaters.Contains(n.ORGLEVEL1))){
                    Ellipse clicked = GS.GetIndicator(hex, true, hex.COUNTRY != null ? 40 : 20);
                    Canvas.SetZIndex(clicked, MainWindow.Z_LOCATION_INDICATOR);
                    if(hex.TERRAIN == "COASTAL"){hex.TERRAIN = "SEA";}
                    clicked.Fill = TypeColorMap[hex.TERRAIN];
                }

                //INIT CONNECTORS
                foreach(GO nearestLocation in GS.TYPE("HEX").Where(n => theaters.Contains(n.ORGLEVEL1))){
                    foreach(GO otherLocation in GS.TYPE("HEX").Where(n => n != nearestLocation && MainWindow.GetDistance(n, nearestLocation.x, nearestLocation.y) < 100)){
                        GO conn = GS.CONNECTOR(nearestLocation, otherLocation, "NATO");
                        if(conn == null){
                            string connectionTerrain = "SEA";
                            if(nearestLocation.TERRAIN == "OMAF" || otherLocation.TERRAIN == "OMAF"){connectionTerrain = "AIR";}
                            else if(nearestLocation.TERRAIN == "LAND" && otherLocation.COUNTRY == null || otherLocation.TERRAIN == "LAND" && nearestLocation.COUNTRY == null){connectionTerrain = "AIR";}
                            else if(nearestLocation.TERRAIN == "LAND" || otherLocation.TERRAIN == "LAND"){connectionTerrain = "LAND";}
                            else if(nearestLocation.TERRAIN == "SEA" && otherLocation.TERRAIN == "SEA" && nearestLocation.COUNTRY != null && otherLocation.COUNTRY != null){connectionTerrain = "COASTAL";}
                            Dictionary<string, string> newConnData = new();
                            newConnData.Add("ID",nearestLocation.ID + "." + otherLocation.ID);
                            newConnData.Add("DOMAIN", GO.DOMAIN_CONNECTOR);
                            newConnData.Add("CONNECTORLOCATIONID", nearestLocation.ID);
                            newConnData.Add("CONNECTORLOCATION2ID", otherLocation.ID);
                            newConnData.Add("TERRAIN", connectionTerrain);
                            conn = new GO(GS, newConnData, newConnData, newConnData);
                            Dictionary<string, string> newConnData2 = new();
                            newConnData2.Add("ID",otherLocation.ID + "." + nearestLocation.ID);
                            newConnData2.Add("DOMAIN", conn.DOMAIN);
                            newConnData2.Add("CONNECTORLOCATIONID", otherLocation.ID);
                            newConnData2.Add("CONNECTORLOCATION2ID", nearestLocation.ID);
                            newConnData2.Add("TERRAIN", conn.TERRAIN);
                            conn = new GO(GS, newConnData2, newConnData2, newConnData2);
                        }
                        Line clickedLine = GS.GetLine(conn, true);
                        Canvas.SetZIndex(clickedLine, MainWindow.Z_CONNECTOR_INDICATOR);
                        Boolean error = false;
                        if((conn.TERRAIN == "COASTAL" || conn.TERRAIN == "LAND") && (nearestLocation.COUNTRY == null || otherLocation.COUNTRY == null)){error = true;}
                        if((conn.TERRAIN == "COASTAL" || conn.TERRAIN == "SEA") && (nearestLocation.TERRAIN == "LAND" || otherLocation.TERRAIN == "LAND")){error = true;}
                        clickedLine.Stroke = error ? System.Windows.Media.Brushes.Red : TypeColorMap[conn.TERRAIN];
                        clickedLine.StrokeThickness = 5;
                    }
                }
            }
            GO map = GS.TYPE("MAP").First();
            if(CopyCountryMode){
                instructions.Add("CLICK A HEX TO COPY COUNTRY TO CLIPBOARD");
            } else if(CopyZoneMode){
                instructions.Add("CLICK A HEX TO COPY ZONE TO CLIPBOARD");
            }else {
                if(GOMode != "HEX"){GS.AddAction(map, "EDIT HEXES");}
                if(GOMode != "CONNECTOR"){GS.AddAction(map, "EDIT CONNECTORS");}
                string clipboard = "";
                if(GOMode == "HEX"){
                    switch(ClipBoardHexType){
                        case "LAND":
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "SEA":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "SHALLOW":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "RESTRICTED":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "FJORD":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "SHOALS":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                        case "OMAF":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            break;
                        default:
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "SHALLOW To ClipBoard");
                            GS.AddAction(map, "RESTRICTED To ClipBoard");
                            GS.AddAction(map, "FJORD To ClipBoard");
                            GS.AddAction(map, "SHOALS To ClipBoard");
                            GS.AddAction(map, "OMAF To ClipBoard");
                            break;
                    }
                    switch(ClipBoardIceType){
                        case "DRIFTICE":
                            GS.AddAction(map, "PACKICE To ClipBoard");
                            GS.AddAction(map, "REMOVE-ICE To ClipBoard");
                            break;
                        case "PACKICE":
                            GS.AddAction(map, "DRIFTICE To ClipBoard");
                            GS.AddAction(map, "REMOVE-ICE To ClipBoard");
                            break;
                        case "REMOVE-ICE":
                            GS.AddAction(map, "DRIFTICE To ClipBoard");
                            GS.AddAction(map, "PACKICE To ClipBoard");
                            break;
                        default:
                            GS.AddAction(map, "DRIFTICE To ClipBoard");
                            GS.AddAction(map, "PACKICE To ClipBoard");
                            GS.AddAction(map, "REMOVE-ICE To ClipBoard");
                            break;
                    }
                    if(ClipBoardCountry != null){clipboard+="|" + ClipBoardCountry + "|"; GS.AddAction(map, "CLEAR COUNTRY FROM CLIPBOARD");} else {GS.AddAction(map, "COPY COUNTRY FROM NEXT CLICK"); GS.AddAction(map, "REMOVE-COUNTRY To ClipBoard");}
                    if(ClipBoardZone != null){clipboard+="|" + ClipBoardZone + "|"; GS.AddAction(map, "CLEAR ZONE FROM CLIPBOARD");} else {GS.AddAction(map, "COPY ZONE FROM NEXT CLICK");}
                    if(ClipBoardHexType != null){clipboard+="|" + ClipBoardHexType + "|"; GS.AddAction(map, "CLEAR HEX TYPE FROM CLIPBOARD");}
                    if(ClipBoardIceType != null){clipboard+="|" + ClipBoardIceType + "|"; GS.AddAction(map, "CLEAR ICE TYPE FROM CLIPBOARD");}
                }
                if(GOMode == "CONNECTOR"){
                    switch(ClipBoardConnectorType){
                        case "LAND":
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "COASTAL To ClipBoard");
                            GS.AddAction(map, "AIR To ClipBoard");
                            break;
                        case "SEA":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "COASTAL To ClipBoard");
                            GS.AddAction(map, "AIR To ClipBoard");
                            break;
                        case "COASTAL":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "AIR To ClipBoard");
                            break;
                        case "AIR":
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "COASTAL To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            break;
                        default:
                            GS.AddAction(map, "LAND To ClipBoard");
                            GS.AddAction(map, "SEA To ClipBoard");
                            GS.AddAction(map, "COASTAL To ClipBoard");
                            GS.AddAction(map, "AIR To ClipBoard");
                            break;
                    }
                    if(ClipBoardConnectorType != null){clipboard+="|" + ClipBoardConnectorType + "|"; GS.AddAction(map, "CLEAR CONNECTOR TYPE FROM CLIPBOARD");}
                }
                if(clipboard.Length > 0){instructions.Add("CLIPBOARD: " + clipboard);}
                instructions.Add("RIGHT CLICK MAP FOR OPTIONS");
            }         
            FS.SETINSTRUCTIONS(GS, instructions);
            //INDIAN   
            //=18506+(B38905+0.5-79-(0.5*MOD(A38905,2)))*81.462-(A38905-45)*-41.289
            //=9741+(B38905+0.5-79-(0.5*MOD(A38905,2)))*47.077-(A38905-45)*71.526
            //PACIFIC
            //=19159+(B38905+0.5-1-(0.5*MOD(A38905,2)))*47+(A38905-13)*70.976
            //=8622+(B38905+0.5-1-(0.5*MOD(A38905,2)))*-81.375+(A38905-13)*41
        }
        public override void Update(string pData){
            if(pData == null){
                Start(false);
            } else if(pData == "NEXT"){
                //HIDE CONNECTORS
                foreach(GO conn in GS.CONNECTORS()){
                    Line clicked = GS.GetLine(conn, true);
                    Canvas.SetZIndex(clicked, MainWindow.Z_HIDDEN);
                    clicked.Stroke = System.Windows.Media.Brushes.Transparent;
                }
                foreach(GO hex in GS.TYPE("HEX")){
                    Ellipse clicked = GS.GetIndicator(hex, true);
                    Canvas.SetZIndex(clicked, MainWindow.Z_HIDDEN);
                    clicked.Stroke = System.Windows.Media.Brushes.White;
                    clicked.Fill = System.Windows.Media.Brushes.Black;
                    clicked.Width = 20 * Window().MapZoomLevel;
                    clicked.Height = 20 * Window().MapZoomLevel;
                }
                GS.Advance(this); 
            } else if(pData == "EDIT HEXES"){
                GOMode = "HEX";
                Start(false);
            } else if(pData == "EDIT CONNECTORS"){
                GOMode = "CONNECTOR";
                Start(false);
            } else if(pData.Contains("To ClipBoard")){
                if(GOMode == "HEX"){
                    string[] pDataParts = pData.Split(' ');
                    string clip = pDataParts[0];
                    if(clip.Contains("ICE")){
                        ClipBoardIceType = clip;
                    } else if(clip.Contains("COUNTRY")){
                        ClipBoardCountry = clip;
                    } else {
                        ClipBoardHexType = clip;
                    }
                } else if(GOMode == "CONNECTOR"){
                    string[] pDataParts = pData.Split(' ');
                    ClipBoardConnectorType = pDataParts[0];
                }
                Start(false);
            } else if(pData.StartsWith("COPY COUNTRY")){
                CopyCountryMode = true;
                Start(false);
            } else if(pData.StartsWith("CLEAR COUNTRY")){
                ClipBoardCountry = null;
                Start(false);
            } else if(pData.StartsWith("COPY ZONE")){
                CopyZoneMode = true;
                Start(false);
            } else if(pData.StartsWith("CLEAR ZONE")){
                ClipBoardZone = null;
                Start(false);
            } else if(pData.StartsWith("CLEAR HEX TYPE")){
                ClipBoardHexType = null;
                Start(false);
            } else if(pData.StartsWith("CLEAR CONNECTOR TYPE")){
                ClipBoardConnectorType = null;
                Start(false);
            } else {
                Start(false);  
            }
        }
        public override void Update(double realX, double realY)
        {
            base.Update(realX, realY);
            GO hex = GS.TYPE("HEX").OrderBy(x => MainWindow.GetDistance(x, realX, realY)).FirstOrDefault();
            if(GOMode == "HEX"){
                if(hex != null){
                    if(CopyCountryMode){
                        ClipBoardCountry = hex.COUNTRY;
                    } else if(CopyZoneMode){
                        ClipBoardZone = hex.ZONE;
                    }else {
                        if(ClipBoardCountry != null){
                            hex.COUNTRY = ClipBoardCountry == "REMOVE-COUNTRY" ? null : ClipBoardCountry;
                            Ellipse clicked = GS.GetIndicator(hex, true, hex.COUNTRY != null ? 40 : 20);
                            Canvas.SetZIndex(clicked, MainWindow.Z_CONNECTOR_INDICATOR);                    
                        }
                        if(ClipBoardZone != null){
                            hex.ZONE = ClipBoardZone;
                        }
                        if(ClipBoardHexType != null){
                            Ellipse clicked = GS.GetIndicator(hex, true, hex.COUNTRY != null ? 40 : 20);
                            Canvas.SetZIndex(clicked, MainWindow.Z_CONNECTOR_INDICATOR);                    
                            hex.TERRAIN = ClipBoardHexType == "LAND" || ClipBoardHexType == "OMAF" ? ClipBoardHexType : "SEA";
                            hex.SHALLOW = ClipBoardHexType == "SHALLOW";
                            hex.RESTRICTED = ClipBoardHexType == "RESTRICTED";
                            hex.FJORD = ClipBoardHexType == "FJORD";
                            hex.SHOALS = ClipBoardHexType == "SHOALS";
                            clicked.Fill = TypeColorMap[hex.TERRAIN];
                        }
                        if(ClipBoardIceType != null && hex.TERRAIN == "SEA"){
                            Ellipse clicked = GS.GetIndicator(hex, true, hex.COUNTRY != null ? 40 : 20);
                            Canvas.SetZIndex(clicked, MainWindow.Z_CONNECTOR_INDICATOR);                    
                            hex.DRIFTICE = ClipBoardIceType == "DRIFTICE";
                            hex.PACKICE = ClipBoardIceType == "PACKICE";
                        }
                        Window().SaveLocations();
                    }
                }
            } else if(GOMode == "CONNECTOR"){
                List<GO> locations = GS.TYPE("HEX").OrderBy(x => MainWindow.GetDistance(x, realX, realY)).ToList();
                if(locations.Count >= 2){
                    GO nearestLocation = locations[0];
                    GO otherLocation = locations[1];
                    GO conn = GS.CONNECTOR(nearestLocation, otherLocation, "NATO");
                    if(conn != null){
                        if(ClipBoardConnectorType != null){
                            Line clickedLine = GS.GetLine(conn, false);
                            Canvas.SetZIndex(clickedLine, MainWindow.Z_CONNECTOR_INDICATOR);
                            foreach(GO connector in GS.CONNECTORS().Where(n => n.lineIndicator == clickedLine || n.lineIndicator2 == clickedLine)){
                                connector.TERRAIN = ClipBoardConnectorType;
                            }
                            clickedLine.Stroke = TypeColorMap[ClipBoardConnectorType];
                            Window().SaveConnectors();
                        }
                    }
                }
            }
            CopyCountryMode = false;
            CopyZoneMode = false;
            string info = "X: " + Math.Round(realX, 0) + " Y: " + Math.Round(realY, 0);
            if(hex != null){
                info += " " + hex.ID + " TERRAIN: " + hex.TERRAIN + "\n" +
                    (hex?.COUNTRY != null ? " COUNTRY: " + hex.COUNTRY : "") + (hex?.ZONE != null ? " ZONE: " + hex.ZONE : "") + "\n" +
                    (hex?.SHALLOW == true ? "SHALLOW " : "") + 
                    (hex?.RESTRICTED == true ? "RESTRICTED " : "") + 
                    (hex?.SHOALS == true ? "SHOALS " : "") +
                    (hex?.FJORD == true ? "FJORD " : "") +
                    (hex?.DRIFTICE == true ? "DRIFTICE " : "") +
                    (hex?.PACKICE == true ? "PACKICE " : "");
            }
            ((TextBlock)Window().FindName("txtClickedMarkerInfo")).Text = info;
            Start(false);
        }        
    }
    public class SetupBases : GamePhaseInteractive
    {
        List<string> NONEDITABLE = new(){"USSR", "USA"};
        public SetupBases(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            zoomLevel = 1;
        }
        public override void Execute(Boolean init){
            if(init){
                FS.SETINSTRUCTIONS(GS, new(){"RIGHT CLICK FLAGS FOR OPTIONS"});
                GS.HELPTEXT = "The world map is composed of logic zones that represent the different countries and regions in the game.  Each logic zone represents either a base or group of bases on the proper hex map areas, or a singular area representing certain offmap areas.\n\n" + 
                "Use this phase to align countries and bases to either ALLIES, SOV, or NEUT.\n\n" +
                "Setting a logic zone to a side doesn't necessarily mean there are additional units awarded to the side, some areas have no units and alignment simply allows for usage of the base by a side.\n\n" +
                "If an area is set to be NEUT, in the game, the SOV side can attack these to either gain VPs for each base or to allow connectivity with an area beyond.  Example,  SOV player may declare war on Costa Rica to allow access to Panama via land combat.\n\n" +
                "Off map sea travel is not affected by alignment, for example, any side can move ships through South Africa no matter what side its aligned to. However, air transfers are affected by alignment, and air units can only end a transfer in an area aligned to that side.";
                //add flags to each base
                foreach(GO baseLocation in GS.LOCATIONS().Where(n => n.LOGISTICALBASE)){
                    string baseSide = GS.Get(baseLocation.COUNTRY + ".SIDE");
                    baseSide ??= "NEUT";
                    GO flagTemplate = FS.FLAGTEMPLATES.Where(n => n.ID == "FLAG." + baseSide + "." + baseSide).Single();
                    GO flagClone = FS.TYPELOCATION(GS, "POSSESSIONFLAG", baseLocation.ID).FirstOrDefault();
                    //if clone doesn't already exists, create here
                    if(flagClone == null){
                        flagClone = FS.CLONE(GS, flagTemplate, baseLocation.ID);
                        flagClone.LABEL = flagTemplate.LABEL;
                        flagClone.LABEL ??= baseLocation.LABEL;
                        flagClone.COUNTRY ??= baseLocation.COUNTRY;
                        flagClone.SIDE = baseSide;
                    }
                    if(!NONEDITABLE.Contains(flagClone.COUNTRY)){
                        GS.InteractionMap.Add(flagClone, new());
                    }
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                GS.Advance(this);
                return;
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.SIDE != "ALLIES" && !FS.ALIGNEDCOUNTRIES["SOV"].Contains(obj.COUNTRY)){GS.AddAction(obj, "Set Alignment to ALLIES");}
                if(obj.SIDE != "NEUT"){GS.AddAction(obj, "Set Alignment to NEUT");}
                if(obj.SIDE != "SOV" && !FS.ALIGNEDCOUNTRIES["ALLIES"].Contains(obj.COUNTRY)){GS.AddAction(obj, "Set Alignment to SOV");}
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            if(pData == "NEXT"){
                Dictionary<string, string> countrySides = new()
                {
                    { "APW", "ALLIES" },
                    { "USA", "ALLIES" },
                    { "SPW", "SOV" },
                    { "USSR", "SOV" },
                    { "NPW", "NEUT" }
                };
                foreach(GO obj in GS.InteractionMap.Keys){
                    GS.Set(obj.COUNTRY + ".SIDE", obj.SIDE);
                    if(!countrySides.ContainsKey(obj.COUNTRY)){
                        countrySides.Add(obj.COUNTRY,obj.SIDE);
                    }
                }

                foreach(GO hex in GS.LOCATIONS().Where(n => n.COUNTRY != null)){
                    string newSide = countrySides.ContainsKey(hex.COUNTRY) ? countrySides[hex.COUNTRY] : "NEUT";
                    hex.INITSIDE = FS.ALIGNEDCOUNTRIES["ALLIES"].Contains(hex.COUNTRY) ? "ALLIES" : FS.ALIGNEDCOUNTRIES["SOV"].Contains(hex.COUNTRY) ? "SOV" : "NEUT";
                    FS.CHANGEPOSSESSION(GS, hex, newSide);
                    if((hex.PORT || hex.AIRFIELD) && hex.GAMEPIECEID == null){
                        FS.CREATEBASE(FS.FACILITYTEMPLATES.Where(n => n.ID == newSide + (hex.PORT ? ".PORT" : "") + (hex.AIRFIELD ? ".AIRFIELD" : "")).Single(), hex);
                    }
                }
                foreach(GO obj in GS.PIECES().Where(n => n.COUNTRY != null && n.SIDE != null)){
                    string newSide = countrySides.ContainsKey(obj.COUNTRY) ? countrySides[obj.COUNTRY] : "NEUT";
                    obj.SIDE = newSide;
                    if(obj.TEMPLATEID != null){
                        if(FS.GENERICCOUNTRIES.Contains(obj.TEMPLATE.COUNTRY)){
                            List<string> ss = obj.TEMPLATE.ID.Split('.').ToList();
                            ss[0] = obj.SIDE;
                            obj.TEMPLATEID = string.Join('.', ss);
                        }
                    }
                    if((obj.TYPE == "SQN" || obj.TYPE == "SHIP") && obj.GAMELOCATIONID != "TEMP"){
                        GS.CHANGELOCATION(obj, "UNUSED");
                    }
                }
                GS.Advance(this); 
            } else if(pData == null) {
                Start(false);  
            } else if(pData.StartsWith("Set Alignment to ")){
                GO obj = GS.SelectedMarker;
                string newSide = pData.Split(' ').Last();
                foreach(GO flag in GS.InteractionMap.Keys.Where(n => n.COUNTRY == obj.COUNTRY).ToList()){
                    GO flagTemplate = FS.FLAGTEMPLATES.Where(n => n.ID == "FLAG." + newSide + "." + newSide).Single();
                    GO flagClone = FS.CLONE(GS, flagTemplate, flag.GAMELOCATIONID);
                    flagClone.LABEL = flag.LABEL;
                    flagClone.COUNTRY = flag.COUNTRY;
                    flagClone.SIDE = newSide;
                    GS.InteractionMap.Add(flagClone, new());
                    if(obj == flag){
                        GS.SelectedMarker = flagClone;
                    }
                    GS.DISCARD(flag);
                }
                Start(false);
            }
        }
    }
    public class SetupForces : GamePhaseInteractive
    {
        List<string> CLONEABLEMARKERTYPES = new(){"FC", "SC", "TK"};
        List<GO> SQNALLOWED = new();
        List<GO> SHIPALLOWED = new();
        string UNITCATEGORY = null;
        string COUNTRY = null;
        string UNITTYPE = null;
        List<GO> UNUSED = new();
        List<GO> CANDIDATES = new();
        GO baseMarker = null;
        public SetupForces(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            ManualAdvance = true;
            InProgressSave = true;
            ShowExpandedMenu = true;
        }
        public override void Execute(Boolean init){
            if(init){
                SQNALLOWED = GS.LOCATIONS().Where(n => n.AIRFIELD || n.LOGAIR).ToList();
                SHIPALLOWED = GS.LOCATIONS().Where(n => n.PORT || n.LOGSEA).ToList();       
                FS.SETINSTRUCTIONS(GS, new(){"ADD UNITS TO GAME"});
                GS.HELPTEXT = 
                "This phase is your opportunity to add units to the scenario\n\n" + 
                "Units can only be added to bases.  In the DEPLOYMENT phase you can do final adjustments to the units starting position\n\n" +
                "Convoy units like SC, FC, and TK are not limited.  However, all other units are limited by what is pre-setup in the data files\n\n" +
                "Additionally, for each marker added to the map, you can perform several actions by choosing from the pop-up menu attached to the unit.\n\n" + 
                "When done with your setup you can click the NEXT button.  Stacking restrictions won't be enforced until the DEPLOYMENT phase\n\n" + 
                "Additionally, at any point, you can hit the button on the top tool bar to create a BRANCH.  This will COPY THE CURRENT SETUP into a new folder in the Saved Games dir.  You can use this to create templates for future setups.  You are fully able to edit the names of the Branch FOLDER NAME ONLY for easier organization.\n\n" + 
                "NOTE: If you see a white box in the lower left corner of the marker, that unit is an EXPANSION unit, meaning it wasn't in the physical game.  The EXPANSION tag on all units will be cleared after this phase, since its only use is notational for this phase specifically\n\n" +
                "NOTE: LEFT DOUBLE CLICK GROUPS to open/close a pop-up showing the group members.  This will work for TF, TG, activation groups, and Carriers\n\n" +
                "NOTE: RIGHT DOUBLE CLICK on markers to see all units in a hex\n\n" +
                "NOTE: The popup that shows all units in hex is not movable, but the other ones are, just drag the popup.  Pick an area of the popup not covered by a unit marker";                
                foreach(GO unit in GS.PIECES().Where(n => (n.TYPE == "SHIP" || n.TYPE == "SQN") && n.GAMELOCATION != null && !n.GAMELOCATION.HIDDEN)){
                    GS.InteractionMap.Add(unit, new());
                }
                foreach(GO unit in GS.PIECES().Where(n => (n.TYPE == "FACILITY" || n.TYPE == "POSSESSIONFLAG") && (SQNALLOWED.Contains(n.GAMELOCATION) || SHIPALLOWED.Contains(n.GAMELOCATION)) && !n.GAMELOCATION.HIDDEN)){
                    GS.InteractionMap.Add(unit, new());
                }
                UNUSED.AddRange(FS.TYPELOCATION(GS, "PIECE", "UNUSED"));
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(baseMarker != obj){
                    baseMarker = obj;
                    UNITCATEGORY = null;
                    COUNTRY = null;
                    UNITTYPE = null;
                }
                if(obj.TYPE == "SQN" || obj.TYPE == "SHIP"){
                    GS.InteractionMap[obj].Clear();
                    GS.InteractionMap[obj].AddRange(obj.UNITCATEGORY == "AIR" ? SQNALLOWED.Where(n => n.SIDE == obj.SIDE) : SHIPALLOWED.Where(n => n.SIDE == obj.SIDE));
                    GS.InteractionMap[obj].Remove(obj.GAMELOCATION);
                    int classAvailable = UNUSED.Where(n => n.COUNTRY == obj.COUNTRY && n.TEMPLATE == obj.TEMPLATE).Count();
                    int typeAvailable = UNUSED.Where(n => n.COUNTRY == obj.COUNTRY && n.UNITTYPE == obj.UNITTYPE).Count();
                    if(classAvailable > 0){
                        GS.AddAction(obj, "ADD ANOTHER OF THIS CLASS : " + classAvailable);
                    }
                    if(typeAvailable > 0 || CLONEABLEMARKERTYPES.Contains(obj.UNITTYPE)){
                        GS.AddAction(obj, "ADD ANOTHER OF THIS TYPE : " + (typeAvailable == 0 ? "unlim" : typeAvailable));
                    }
                    GS.AddAction(obj, "REMOVE");
                }
                if(UNITCATEGORY == null){
                    foreach(string uc in new List<string>{"AIR", "SURFACE", "SUB"}){
                        List<GO> tmp = UNUSED.Where(n => n.UNITCATEGORY == uc && n.SIDE == obj.SIDE && (n.COUNTRY == obj.COUNTRY || n.COUNTRY == "USA" || n.COUNTRY == "USSR")).ToList();
                        bool canClone = uc == "SURFACE" && obj.SIDE != "NEUT";
                        bool canAdd = uc == "AIR" ? SQNALLOWED.Contains(obj.GAMELOCATION) : SHIPALLOWED.Contains(obj.GAMELOCATION);
                        if(canAdd && (tmp.Any() || canClone)){
                            GS.AddAction(obj, ">>" + uc);
                        }
                    }
                } else if(COUNTRY == null){
                    GS.AddAction(obj, "<<BACK");
                    int countryAvailable = CANDIDATES.Where(n => n.COUNTRY == obj.COUNTRY).Count();
                    if(countryAvailable > 0){GS.AddAction(obj, obj.COUNTRY + " : " + countryAvailable);}
                    if(obj.SIDE == "SOV"){
                        countryAvailable = CANDIDATES.Where(n => n.COUNTRY == "USSR").Count();
                        if(obj.COUNTRY != "USSR" && countryAvailable > 0){GS.AddAction(obj, "USSR : " + countryAvailable);}
                        if(UNITCATEGORY == "SURFACE"){GS.AddAction(obj, "SPW : unlim");}
                    } else if(obj.SIDE == "ALLIES"){
                        countryAvailable = CANDIDATES.Where(n => n.COUNTRY == "USA").Count();
                        if(obj.COUNTRY != "USA" && countryAvailable > 0){GS.AddAction(obj, "USA : " + countryAvailable);}
                        if(UNITCATEGORY == "SURFACE"){GS.AddAction(obj, "APW : unlim");}
                    }
                } else if(UNITTYPE == null){
                    GS.AddAction(obj, "<<BACK");
                    if(FS.GENERICCOUNTRIES.Contains(COUNTRY)){
                        if(obj.SIDE == "SOV"){
                            GS.AddAction(obj, "SC");
                        } else {
                            foreach(string ut in CLONEABLEMARKERTYPES.Order()){
                                GS.AddAction(obj, ut);
                            }
                        }
                    } else {
                        foreach(string ut in CANDIDATES.Select(n => n.UNITTYPE).Distinct().Order()){
                            int typeAvailable = CANDIDATES.Where(n => n.UNITTYPE == ut).Count();
                            GS.AddAction(obj, ut + " : " + typeAvailable);
                        }
                    }
                } else {
                    GS.AddAction(obj, "<<BACK");
                    GS.AddAction(obj, "RANDOM : " + CANDIDATES.Count);
                    foreach(string ut in CANDIDATES.Select(n => n.TEMPLATE.LABEL).Distinct().Order()){
                        int classAvailable = CANDIDATES.Where(n => n.TEMPLATE.LABEL == ut).Count();
                        GS.AddAction(obj, ut + " : " + classAvailable);
                    }
                }
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case ">>AIR":
                case ">>SURFACE":
                case ">>SUB":
                    pData = pData.Replace(">>","");
                    FILTERBYUNITCATEGORY(gp, pData);
                    if(CANDIDATES.Any()){
                        UNITCATEGORY = pData;
                    }
                    Start(false);
                    break;
                case "ADD ANOTHER OF THIS CLASS":
                    List<GO> tmpobjs = UNUSED.Where(n => n.COUNTRY == gp.COUNTRY && n.TEMPLATE == gp.TEMPLATE).ToList();
                    GO tmpobj = GS.RANDOMGAMEOBJECT(tmpobjs);
                    GS.CHANGELOCATION(tmpobj, gp.GAMELOCATIONID);
                    UNUSED.Remove(tmpobj);
                    GS.InteractionMap.Add(tmpobj, new());
                    GS.SelectedMarker = tmpobj;
                    Start(false);
                    break;
                case "ADD ANOTHER OF THIS TYPE":
                    if(CLONEABLEMARKERTYPES.Contains(gp.UNITTYPE)){
                        tmpobj = FS.CREATECONVOY(gp, gp.UNITTYPE, gp.GAMELOCATIONID);
                    } else {
                        tmpobjs = UNUSED.Where(n => n.COUNTRY == gp.COUNTRY && n.UNITTYPE == gp.UNITTYPE).ToList();
                        tmpobj = GS.RANDOMGAMEOBJECT(tmpobjs);
                        GS.CHANGELOCATION(tmpobj, gp.GAMELOCATIONID);
                        UNUSED.Remove(tmpobj);
                    }
                    GS.InteractionMap.Add(tmpobj, new());
                    GS.SelectedMarker = tmpobj;
                    Start(false);
                    break;
                case "RANDOM":
                    tmpobjs = UNUSED.Where(n => n.COUNTRY == COUNTRY && n.UNITTYPE == UNITTYPE).ToList();
                    tmpobj = GS.RANDOMGAMEOBJECT(tmpobjs);
                    GS.CHANGELOCATION(tmpobj, gp.GAMELOCATIONID);
                    UNUSED.Remove(tmpobj);
                    GS.InteractionMap.Add(tmpobj, new());
                    GS.SelectedMarker = tmpobj;
                    Start(false);
                    break;
                case "REMOVE":
                    GS.SelectedMarker = GS.InteractionMap.Keys.Where(n => n.GAMELOCATION == gp.GAMELOCATION && n != gp).FirstOrDefault();
                    GS.REMOVEINTERACTIVE(gp);
                    if(CLONEABLEMARKERTYPES.Contains(gp.UNITTYPE)){
                        GS.DISCARD(gp);
                    } else {
                        UNUSED.Add(gp);
                        GS.CHANGELOCATION(gp, "UNUSED");
                    }
                    Start(false);
                    break;
                case "NEXT":
                    List<GO> setup = new();
                    foreach(GO obj in GS.InteractionMap.Keys.Where(n => n.TYPE == "SQN" || n.TYPE == "SHIP")){
                        setup.Add(obj);
                        if(obj.TEMPLATE.AIRUNITS != null){
                            setup.AddRange(FS.GROUPMEMBERS(obj));
                        }
                    }
                    foreach(GO obj in setup){
                        obj.EXPANSION = false;
                        if(obj.TEMPLATEID != null){
                            //logistics
                            obj.FUELPTS = obj.TEMPLATE.FUELPTS;
                            obj.SSMPTS = obj.TEMPLATE.SSMPTS;
                            obj.SSM2PTS = obj.TEMPLATE.SSM2PTS;
                            obj.TORPPTS = obj.TEMPLATE.TORPPTS;
                            obj.CMPTS = obj.TEMPLATE.CMPTS;
                            obj.ASWPTS = obj.TEMPLATE.ASWPTS;
                            obj.AAPTS = obj.TEMPLATE.AAPTS;
                            obj.BOMBPTS = obj.TEMPLATE.BOMBPTS;
                            obj.AIRSSMPTS = obj.TEMPLATE.AIRSSMPTS;
                            obj.APTS = obj.TEMPLATE.APTS;
                            obj.FPTS = obj.TEMPLATE.FPTS;
                            obj.MOVEMENTALLOWANCE = obj.TEMPLATE.MOVEMENTALLOWANCE;
                        }
                    }
                    foreach(GO obj in UNUSED){
                        obj.SIDE = null;
                        if(obj.TEMPLATE.AIRUNITS != null){
                            FS.GROUPMEMBERS(obj).ForEach(n => n.SIDE = null);
                        }
                    }
                    SetBoolean("SETUP", false);
                    GS.Advance(this);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                case "<<BACK":
                    if(COUNTRY == null){
                        UNITCATEGORY = null;
                        Start(false);
                    } else if(UNITTYPE == null){
                        COUNTRY = null;
                        FILTERBYUNITCATEGORY(gp, UNITCATEGORY);
                        Start(false);
                    } else {
                        UNITTYPE = null;
                        FILTERBYUNITCATEGORY(gp, UNITCATEGORY);
                        FILTERBYCOUNTRY(COUNTRY);
                        Start(false);
                    }
                    break;
                default:
                    if(pData.StartsWith("ADD ANOTHER OF THIS CLASS")){
                        Update("ADD ANOTHER OF THIS CLASS");
                        break;
                    }
                    if(pData.StartsWith("ADD ANOTHER OF THIS TYPE")){
                        Update("ADD ANOTHER OF THIS TYPE");
                        break;
                    }
                    if(pData.StartsWith("RANDOM")){
                        Update("RANDOM");
                        break;
                    }
                    if(UNITCATEGORY != null){
                        if(COUNTRY == null){
                            string tmp = pData.Split(':').First().Trim();
                            FILTERBYCOUNTRY(tmp);
                            COUNTRY = tmp;
                        } else if(UNITTYPE == null){
                            string tmp = pData.Split(':').First().Trim();
                            if(FS.GENERICCOUNTRIES.Contains(COUNTRY)){
                                GO obj = FS.CREATECONVOY(gp, tmp, gp.GAMELOCATIONID);
                                GS.InteractionMap.Add(obj, new());
                                GS.SelectedMarker = obj;
                            } else {
                                FILTERBYUNITTYPE(tmp);
                                UNITTYPE = tmp;
                            }
                        } else {
                            string lbl = pData.Split(':').First().Trim();
                            List<GO> tmp = CANDIDATES.Where(n => n.TEMPLATE.LABEL == lbl).ToList();
                            GO obj = GS.RANDOMGAMEOBJECT(tmp);
                            GS.CHANGELOCATION(obj, gp.GAMELOCATIONID);
                            UNUSED.Remove(obj);
                            GS.InteractionMap.Add(obj, new());
                            GS.SelectedMarker = obj;
                        }
                    }
                    Start(false);
                    break;
            }            
        }
        private void FILTERBYUNITCATEGORY(GO gp, string pData){
            CANDIDATES = UNUSED.Where(n => n.UNITCATEGORY == pData && n.SIDE == gp.SIDE && (n.COUNTRY == gp.COUNTRY || n.COUNTRY == "USA" || n.COUNTRY == "USSR")).ToList();
        }
        private void FILTERBYCOUNTRY(string pData){
            CANDIDATES = CANDIDATES.Where(n => n.COUNTRY == pData).ToList();
        }
        private void FILTERBYUNITTYPE(string pData){
            CANDIDATES = CANDIDATES.Where(n => n.UNITTYPE == pData).ToList();
        }
    }
    public class DeploymentLoop : GamePhaseLoopLogic
    {
        public DeploymentLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new Deployment("Deployment", this, GS));
        }
        public override Boolean ProcessCheck(){return !GS.GetBoolean("DEPLOYMENT.DONE");}
        public override void Init()
        {
            //throw new NotImplementedException();
        }
        public override void End()
        {
            string side = Get("ACTIVE.SIDE");
            if(side == GS.Get("SIDE1")){
                Set("ACTIVE.SIDE", FS.ENEMY(side));
            } else {
                Set("SIDE1", side);
                SetBoolean("DEPLOYMENT.DONE", true);
            }
        }
    }

    public class Deployment : GamePhaseInteractive
    {
        string side = null;
        List<GO> SQNALLOWED = new();
        List<GO> SHIPALLOWED = new();
        public Deployment(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            ManualAdvance = true;
            NoShowLocationIndicators = true;
            UniversalDrop = true;
            InProgressSave = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.ADMIN = true;
                SQNALLOWED = FS.TYPESIDE(GS, "LOCATION", side).Where(n => n.AIRFIELD || n.LOGAIR).ToList();
                SHIPALLOWED = GS.LOCATIONS().Where(n => n.TERRAIN == "SEA" || n.LOGSEA).ToList();       
                FS.SETINSTRUCTIONS(GS, new(){"PLACE UNITS IN STARTING LOCATION", "CREATE TF/TG"});
                GS.HELPTEXT = 
                "**SIDE MODE HAS BEGUN.  From now on you will only see ships you own or have detected!\n\n" + 
                "This is your final Opportunity to adjust Deployment before game starts\n\n" + 
                "To move units around, just drag the unit to where you would like the unit to start the scenario.  For Air units, this can only be AIRFIELD or off-map base.  For Sea units this can be any sea hex, port, or off map base.  You can also move air units and ship units to open Group Displays \n\n" +
                "Additionally, for each marker, you can perform several actions by choosing from the menu.\n\n" + 
                "- create TF/TG in hex\n" +
                "- Drag Unit in pop-ups to adjust position in the group. You can also drag the unit out of the pop-up to remove it from its group.\n" +
                "- DELAY.  Units with a delay don't show up at that position until a certain amount of turns.  This can simulate reinforcements or unit enroute to a theater.  Either increase the delay by 3 turns (representing a day) or remove the delay, making the unit appear at the start.  NOTE:  units can only be set to an arrival delay if they are either in a port, airfield, logistical base, or in an enroute location.  (Units with a delay are shown with a large Yellow square in the lower left of the marker)\n\n" +                
                "When done with your setup you can click the NEXT button.  STACKING restrictions will prevent the game from advancing. Units arriving at a future turn do not count against the stacking limit\n\n" +
                "NOTE: LEFT DOUBLE CLICK GROUPS to open/close a pop-up showing the group members.  This will work for TF, TG, activation groups, and Carriers\n\n" +
                "NOTE: RIGHT DOUBLE CLICK on markers to see all units in a hex\n\n" +
                "NOTE: The popup that shows all units in hex is not movable, but the other ones are, just drag the popup.  Pick an area of the popup not covered by a unit marker";                               
                foreach(GO obj in FS.TYPESIDE(GS, "PIECE", side).Where(n => n.TYPE == "SHIP" || n.TYPE == "SQN")){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(FS.ISGROUP(obj)){
                    GS.AddAction(obj, "DISBAND");
                }
                if(obj.UNITCATEGORY == "SURFACE" && obj.SIDE != "NEUT" && !FS.ISGROUP(obj)){
                    if(obj.GAMELOCATION.TYPE != "TRAYLOCATION"){
                        GS.AddAction(obj, "CREATE TF/TG");
                    }
                }
                GO loc = FS.PARENTGROUPLOCATION(obj);
                if(obj.ENROUTEDELAY > 0){GS.AddAction(obj, "DELAY: RESET");}
                if(obj.SIDE != "NEUT" && (loc.TYPE == "ENROUTE" || loc.PORT || loc.AIRFIELD || loc.LOGISTICALBASE)){
                    GS.AddAction(obj, "DELAY: INCREASE");
                    GS.AddAction(obj, "DELAY: INCREASE + 3");
                }
            }
            if(init){FS.SETVIEW(GS);}
        }
        private List<GO> DROPTARGETS(GO obj){
            List<GO> SHIPTRAYLOCATIONS = GS.TYPE("TRAYLOCATION").Where(n => n.PARENTSHEET.SHEETPARENTPIECE != null && n.XCOORD < n.PARENTSHEET.IMAGEWIDTH && n.YCOORD < n.PARENTSHEET.IMAGEHEIGHT).ToList();
            List<GO> targets = new();
            if(obj.TYPE == "SHIP"){
                targets.AddRange(SHIPALLOWED);
                if(obj.UNITCATEGORY != "SUB" && obj.SIDE != "NEUT" && !FS.ISGROUP(obj)){
                    targets.AddRange(SHIPTRAYLOCATIONS.Where(n => n.PARENTSHEET == FS.GRPSHEET && n.PARENTSHEET.SHEETPARENTPIECE.SIDE == obj.SIDE));
                }
            } else if(obj.TYPE == "SQN") {
                targets.AddRange(SHIPTRAYLOCATIONS.Where(n => n.PARENTSHEET == FS.CVSHEET && n.PARENTSHEET.SHEETPARENTPIECE.COUNTRY == obj.COUNTRY));
                targets.AddRange(SQNALLOWED);
            }
            return targets;            
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "CREATE TF/TG":
                    GO createdTG = FS.CREATEGROUP(GS, gp, gp.GAMELOCATIONID);
                    GS.InteractionMap.Add(createdTG, new());
                    Start(false);
                    break;
                case "DISBAND":
                    GO firstMember = GS.TYPE(gp.TYPE, "GROUPID", gp.ID).FirstOrDefault();
                    FS.GROUPMEMBERS(gp).ForEach(n => GS.CHANGELOCATION(n, gp.GAMELOCATION));
                    FS.REMOVEGROUP(gp);
                    GS.REMOVEINTERACTIVE(gp);
                    if(firstMember != null){GS.SelectedMarker = firstMember;}
                    Start(false);
                    break;
                case "DELAY: INCREASE":
                    gp.ENROUTEDELAY++;
                    if(FS.ISGROUP(gp)){
                        FS.GROUPMEMBERS(gp).First().ENROUTEDELAY++;
                        FS.UPDATEGROUP(gp);
                    } else if(gp.GROUPID != null){
                        FS.UPDATEGROUP(gp.GROUP);
                    }
                    Start(false);
                    break;
                case "DELAY: INCREASE + 3":
                    gp.ENROUTEDELAY += 3;
                    if(FS.ISGROUP(gp)){
                        FS.GROUPMEMBERS(gp).First().ENROUTEDELAY += 3;
                        FS.UPDATEGROUP(gp);
                    } else if(gp.GROUPID != null){
                        FS.UPDATEGROUP(gp.GROUP);
                    }
                    Start(false);
                    break;
                case "DELAY: RESET":
                    gp.ENROUTEDELAY = 0;
                    if(FS.ISGROUP(gp)){
                        FS.GROUPMEMBERS(gp).ForEach(n => n.ENROUTEDELAY = 0);
                        FS.UPDATEGROUP(gp);
                    } else if(gp.GROUPID != null){
                        FS.GROUPMEMBERS(gp.GROUP).ForEach(n => n.ENROUTEDELAY = 0);
                        FS.UPDATEGROUP(gp.GROUP);
                    }
                    Start(false);
                    break;
                case "NEXT":
                    bool validSetup = true;
                    GO errorGO = null;
                    foreach(GO unit in GS.InteractionMap.Keys){
                        if(!FS.ISGROUP(unit) && unit.ENROUTEDELAY > 0){
                            GO loc = FS.PARENTGROUPLOCATION(unit);
                            if(loc.TYPE != "ENROUTE" && !loc.PORT && !loc.AIRFIELD && !loc.LOGISTICALBASE){
                                gp.ENROUTEDELAY = 0;
                                if(gp.GROUPID != null){FS.UPDATEGROUP(gp.GROUP);}
                            }
                        }                                                
                        if(unit.TYPE == "SQN"){
                            if(unit.CARRIERID != null){
                                GO parent = unit.CARRIER;
                                if(!parent.TEMPLATE.AIRUNITS.Contains(unit.TEMPLATE.LABEL)){
                                    MainWindow.Alert("SQN type is not allowed on this ship.");
                                    errorGO = parent.GROUPID == null ? parent : parent.GROUP;
                                    validSetup = false;
                                    break;
                                }
                            } else if(!unit.GAMELOCATION.AIRFIELD && !unit.GAMELOCATION.LOGISTICALBASE){
                                MainWindow.Alert("SQN must be at an AIRFIELD or LOGISTICALBASE");
                                errorGO = unit;
                                validSetup = false;
                                break;
                            }
                        } else {
                            GO unitLoc = unit.GROUPID == null ? unit.GAMELOCATION : unit.GROUP.GAMELOCATION;
                            if(unitLoc.SHOALS && !new List<string>{"PC, CO"}.Contains(unit.UNITTYPE)){
                                MainWindow.Alert("Illegal unit type in SHOALS");
                                errorGO = unit.GROUPID == null ? unit : unit.GROUP;
                                validSetup = false;
                                break;
                            } else if(unitLoc.TERRAIN != "SEA" && !unitLoc.LOGSEA){
                                MainWindow.Alert("Illegal placement of ship in non-sea location");
                                errorGO = unit.GROUPID == null ? unit : unit.GROUP;
                                validSetup = false;
                                break;
                            }
                        }
                    }
                    if(validSetup){
                        foreach(GO parent in GS.InteractionMap.Keys.Where(n => n.TYPE == "SQN" && n.CARRIERID != null).Select(n => n.CARRIER).Distinct()){
                            if(!FS.CANSTACKONCARRIER(GS, parent, GS.TYPE("SQN", "CARRIERID", parent.ID))){
                                MainWindow.Alert("Stacking Violation on Parent Ship");
                                errorGO = parent.GROUPID == null ? parent : parent.GROUP;
                                validSetup = false;
                                break;
                            }
                        }
                    }
                    if(validSetup){
                        foreach(GO location in GS.InteractionMap.Keys.Where(n => n.GAMELOCATIONID != "TEMP").Select(n => n.GAMELOCATION).Distinct()){
                            List<GO> unitsAtLocation = FS.TYPELOCATION(GS, "PIECE", location.ID).Where(n => n.SIDE != null).ToList();
                            if(!FS.CANSTACKSURFACE(unitsAtLocation.Where(n => n.UNITCATEGORY == "SURFACE").ToList())){
                                MainWindow.Alert("Stacking Violation:  Surface Ships");
                                errorGO = unitsAtLocation.First();
                                validSetup = false;
                                break;
                            }
                            if(!FS.CANSTACKAIR(unitsAtLocation.Where(n => n.UNITCATEGORY == "AIR").ToList())){
                                MainWindow.Alert("Stacking Violation:  Air");
                                errorGO = unitsAtLocation.First();
                                validSetup = false;
                                break;
                            }
                            if(unitsAtLocation.Select(n => n.SIDE).Distinct().Count() > 1){
                                MainWindow.Alert("Stacking Violation:  Sides");
                                errorGO = unitsAtLocation.First();
                                validSetup = false;
                                break;
                            }
                        }
                    }
                    //enforce rules
                    if(validSetup){
                        FS.ADMIN = false;
                        foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.GRPTYPE == "TFTGGRP")){
                            FS.UPDATEGROUP(obj);
                        }
                        GS.Advance(this);
                    } else {
                        GS.SelectedMarker = errorGO;
                        Start(false);
                    }
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GO newloc = GS.LOCATION(gp.TEMPLOCATIONID);
                        if(DROPTARGETS(gp).Contains(newloc)){
                            GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                            if(oldloc.TYPE != "TRAYLOCATION" && newloc.TYPE == "TRAYLOCATION"){
                                GO newsheet = newloc.PARENTSHEET;
                                GO newgroup = newsheet.SHEETPARENTPIECE;
                                FS.ADDTOGROUP(gp, newgroup);
                            } else if(oldloc.TYPE == "TRAYLOCATION" && newloc.TYPE != "TRAYLOCATION"){
                                gp.PARENTSHEETID = null;
                                GO oldsheet = oldloc.PARENTSHEET;
                                GO oldgroup = oldsheet.SHEETPARENTPIECE;
                                FS.REMOVEFROMGROUP(gp, oldgroup);
                            } else if(oldloc.TYPE == "TRAYLOCATION" && newloc.TYPE == "TRAYLOCATION" && newloc.PARENTSHEET == FS.GRPSHEET){
                                GO newsheet = newloc.PARENTSHEET;
                                List<GO> grouptraylocations = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", newsheet.ID);
                                int oldindex = grouptraylocations.IndexOf(oldloc);
                                int newindex = grouptraylocations.IndexOf(newloc);
                                for(int i = 0; i < Math.Abs(oldindex - newindex); i++){
                                    if(oldindex < newindex){
                                        FS.MOVEDOWNINGROUP(GS, gp, gp.GROUP);
                                    } else {
                                        FS.MOVEUPINGROUP(GS, gp, gp.GROUP);
                                    }
                                }
                            }
                        } else {
                            GS.CHANGELOCATION(gp, oldloc);
                        }
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
}