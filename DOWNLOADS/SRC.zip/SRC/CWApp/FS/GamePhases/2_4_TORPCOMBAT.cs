using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
using System.ComponentModel.DataAnnotations;
namespace CWApp.FS
{    
    public class ActionTORPCombat : GamePhaseLoopLogic
    {
        public ActionTORPCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionTORPCombatLoadTrays("Load Trays", this, GS));
            AddGamePhase(new ActionTORPCombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionCombatAllocation("Allocation", this, GS, "TORP"));
            AddGamePhase(new ActionTORPCombatResolution("Resolution", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOLOGICS(GS, "ACTION.TORPCOMBAT").Any();}
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.TORPCOMBAT");
            GO combat = combats.First();
            GO attackingUnit = combat.ATTACKER;
            Set("ACTIVE.SIDE", attackingUnit.SIDE);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIONING", new(){attackingUnit});
            Set("ACTION.TYPE", attackingUnit.UNITCATEGORY);
            combats.Remove(combat);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.TORPCOMBAT", combats);
            List<GO> defenders = FS.TYPESIDELOCATION(GS, "SHIP", FS.ENEMY(attackingUnit.SIDE), combat.DEFENDERLOCATIONID).Where(n => 
                n.ENROUTEDELAY == 0 &&
                !n.DOCKED && 
                n.UNITCATEGORY == "SURFACE" &&
                (n.STRATDETECTED || n.LOCALDETECTED)).ToList();
            
            List<GO> attackers = new();
            if(defenders.Any() && !FS.STORM(combat.DEFENDERLOCATION)){
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", defenders);
                attackers.Add(attackingUnit);       
                if(attackers.Any()){
                    attackingUnit.NUMCOMBATS++;   
                }
            }
            string reason = "";
            if(!attackers.Any()){reason = "no units able to attack";}
            if(!defenders.Any()){reason = "no viable targets in target location";}
            if(reason != ""){
                MainWindow.Alert("Planned " + combat.TYPE + " combat (" + combat.SIDE + " vs " + FS.ENEMY(combat.SIDE) + ") not possible: " + reason);
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", attackers);
            FS.DISCARDLOGIC(combat);
        }
        public override void End()
        {
            foreach(GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID)){
                GS.CHANGELOCATION(obj, obj.HOMEBASE);
                obj.HOMEBASEID = null;
            }
            GS.CHANGELOCATION(FS.DEFENDSHEET.SHEETPARENTPIECE, "TEMP");
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionTORPCombatLoadTrays : GamePhaseAutomated
    {
        public ActionTORPCombatLoadTrays(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            if(FS.SCENARIOUNITS(GS, "ACTION.ATTACKER").Any()){
                List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Where(n => !FS.ISGROUP(n)).ToList();
                defenders.AddRange(FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Where(FS.ISGROUP));
                foreach(GO obj in defenders){
                    obj.HOMEBASEID = obj.GAMELOCATIONID;
                    obj.HOMEBASE = obj.GAMELOCATION;
                }
                FS.DISPLAYCOMBATSHEET(GS, defenders);
            }
            GS.Advance(this);           
        }
    }
    public class ActionTORPCombatDeclaration : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, Dictionary<string, double>> ATTACKS = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = new();
        public ActionTORPCombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                ATTACKS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE UNITS THAT WILL PARTICIPATE"});
                GS.HELPTEXT = 
                "TORPEDO COMBAT.  Declare which units you will attack with\n\n" + 
                "When done with your allocation you can click the NEXT button";                
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ATTACKER")){
                    GS.InteractionMap.Add(obj, new());
                }
                attackData = FS.ATTACKDATA(GS.InteractionMap.Keys.ToList());
            }
            FS.SETINSTRUCTIONS(GS, new(){"ALLOCATE TORP POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"])});
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(attackData.ContainsKey(obj)){
                    if(attackData[obj].ContainsKey("TORP")){
                        foreach(string attackType in attackData[obj]["TORP"].Keys){
                            GS.AddAction(obj, "USE " + attackType);
                        }
                    }
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(ATTACKS.Any() || !GS.InteractionMap.Any()){
                        //collect attack data
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.TTACKER", ATTACKS.Keys.ToList());
                        GS.Advance(this);
                    } else {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE TORP":
                    gp.TORPPTS--;
                    ATTACKS.Add(gp, attackData[gp]["TORP"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE INTENSIVE TORP":
                    gp.TORPPTS -= 2;
                    ATTACKS.Add(gp, attackData[gp]["TORP"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE MAXIMUM TORP":
                    gp.TORPPTS -= 3;
                    ATTACKS.Add(gp, attackData[gp]["TORP"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionTORPCombatResolution : GamePhaseAutomated
    {
        public ActionTORPCombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            if(defenders.Any()){
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                GO attackLocation = FS.PARENTGROUPLOCATION(FS.SCENARIOUNITS(GS, "ACTION.ATTACKER").First());
                GO defenseLocation = defenders.First().HOMEBASE ?? FS.LOGICALPARENT(defenders.First()).HOMEBASE;
                string report = "TORP COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                List<GO> defensiveCandidates = FS.ALLSHIPSINHEX(defendingSide, defenseLocation, true, true).Where(n => n.ASWPTS > 0).OrderByDescending(n => n.TEMPLATE.ASW).ToList();
                int maxShipsToPick = defensiveCandidates.Where(n => FS.SURFACECOMBATTYPES.Contains(n.UNITTYPE)).Count() >= 8 ? 4 : 3;
                int defenseModifier = 0;
                int rollModifier = 0;
                //combine ASW values
                int combinedASWValue = 0;
                for(int i = 0; i < maxShipsToPick && i < defensiveCandidates.Count; i++){
                    GO obj = defensiveCandidates[i];
                    double val = obj.TEMPLATE.ASW;
                    combinedASWValue += (int)val;
                    report += obj.UNITTYPE + " " + obj.LABEL + " ASW=" + obj.TEMPLATE.AAA + " contributes " + val + "\n";
                }
                report += "TOTAL DEF ASW = " + combinedASWValue + "\n\n";
                if(combinedASWValue > 0){
                    if(defenders.Where(n => n.GROUP?.UNITTYPE == "TF").Any()){
                        rollModifier += 2;
                        report += "TF: Roll +2\n";
                    }
                    if(!defenders.Where(n => n.GROUP != null).Any()){
                        rollModifier -= 4;
                        report += "NO TG/TF: Roll -4\n";
                    }
                    GO activatedUnit = FS.SCENARIOUNITS(GS, "ACTION.ATTACKER").First();
                    if(attackLocation.FJORD || attackLocation.RESTRICTED || (activatedUnit.UNITTYPE != "SS" && attackLocation.SHALLOW)){
                        rollModifier += 2;
                        report += "RESTRICTED/FJORD/SHALLOW SN: Roll +2\n";
                    }
                    if(activatedUnit.LOCALDETECTED || activatedUnit.STRATDETECTED){
                        rollModifier += 2;
                        report += "ATTACKER DETECTED: Roll +2\n";
                    }
                    report += "DEFENSE ROLL MODIFIER: " + rollModifier + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + rollModifier) + "\n";
                    dieRoll += rollModifier;
                    defenseModifier = FS.COMBATRESULTSTABLE(false, dieRoll, combinedASWValue);
                }
                report += "DEFENSE MODIFIER: " + defenseModifier + "\n\n";
                rollModifier = -defenseModifier;
                if(FS.ALLSHIPSINHEX(defendingSide, defenseLocation, true, false).Where(n => n.TACCOORDPIECEID != null).Any()){
                    rollModifier += 2;
                    report += "TAC COORD: Roll +2\n";
                }
                foreach(GO obj in defenders){
                    int objRollModifer = rollModifier;
                    report += "\nATTACK ON " + obj.UNITTYPE + " " + obj.LABEL + " with " + obj.ATK + " pts:\n";
                    if(new List<string>{"MS", "PC"}.Contains(obj.UNITTYPE)){
                        objRollModifer -= 3;
                        report += obj.UNITTYPE + ": Roll -3\n";
                    }
                    if(obj.TEMPLATE.DECOYS){
                        objRollModifer -= 1;
                        report += "DECOYS: Roll -1\n";
                    }
                    report += "ATTACK ROLL MODIFIER: " + objRollModifer + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + objRollModifer) + "\n";
                    dieRoll += objRollModifer;
                    double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)obj.ATK);
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    //compare to ship defense
                    double defense = FS.GETDEFENSE(obj);
                    if(attackResult >= defense){
                        //FS.DESTROY(obj);
                        obj.UNAPPLIEDDAMAGE += 2;
                        report += "Target Destroyed\n";
                    } else if(attackResult >= defense * 0.5){
                        //FS.DAMAGE(obj);
                        obj.UNAPPLIEDDAMAGE++;
                        if((obj.DAMAGED ? 1 : 0) + obj.UNAPPLIEDDAMAGE >= 2){
                            report += "Target Destroyed\n";
                        } else {
                            report += "Target Damaged\n";
                        }
                    } else {
                        report += "No effect\n";
                    }
                }         
                //local detection
                List<GO> adjacent = new();
                foreach(GO loc in FS.FINDAIRRADIUS(attackLocation, 1)){
                    adjacent.AddRange(FS.ALLSHIPSINHEX(defendingSide, loc, true, true));
                }
                adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)) && n.UNITCATEGORY == "SURFACE");
                if(adjacent.Any()){
                    foreach(GO obj in FS.GROUPSANDMEMBERS(FS.SCENARIOUNITS(GS, "ACTION.ACTIONING"))){
                        if(FS.SUBDETECTIONRESULT(obj, "ACTION", "TORP", adjacent) == "D"){
                            IncrementInt("ACTION.DETECTIONS", 1);
                            FS.LOCALDETECT(new(){obj}, true);
                        }
                    }
                }
                if(report != ""){
                    MainWindow.Alert(report);
                }
            }
            GS.Advance(this);           
        }
    }
}
