using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
namespace CWApp.FS
{    
    public class ActionBOMBCombat : GamePhaseLoopLogic
    {
        public ActionBOMBCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionBOMBCombatLoadTrays("Load Trays", this, GS));
            AddGamePhase(new ActionBOMBCombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionBOMBCombatDefenderSetup("Defender Setup", this, GS));
            AddGamePhase(new ActionCombatAllocation("Allocation", this, GS, "BOMB"));
            AddGamePhase(new ActionBOMBCombatDefensiveFire("Defensive Fire", this, GS));
            AddGamePhase(new ActionBOMBCombatDefensePicksCasualties("Pick Casualties", this, GS));
            AddGamePhase(new ActionBOMBCombatReAllocation("Re-Allocation", this, GS));
            AddGamePhase(new ActionBOMBCombatResolution("Resolution", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOLOGICS(GS, "ACTION.BOMBCOMBAT").Any();}
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.BOMBCOMBAT");
            GO combat = combats.First();
            GO attackingUnit = combat.ATTACKER;
            Set("ACTIVE.SIDE", attackingUnit.SIDE);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIONING", new(){attackingUnit});
            Set("ACTION.TYPE", attackingUnit.UNITCATEGORY);
            combats.Remove(combat);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.BOMBCOMBAT", combats);
            List<GO> defenders = new();
            if(combat.DEFENDER != null){
                GO facility = combat.DEFENDER;
                if((combat.LABEL == "PORT" && facility.PORT && !facility.PORTDESTROYED) || (combat.LABEL == "AIRFIELD" && facility.AIRFIELD && !facility.AIRFIELDDESTROYED)){
                    defenders.Add(facility);
                }
            } else {
                defenders.AddRange(FS.TYPESIDELOCATION(GS, "SHIP", FS.ENEMY(attackingUnit.SIDE), combat.DEFENDERLOCATIONID).Where(n => 
                    n.ENROUTEDELAY == 0 &&
                    n.UNITCATEGORY == "SURFACE" &&
                    (n.STRATDETECTED || n.LOCALDETECTED)));
            }
            List<GO> attackers = new();
            if(defenders.Any() && !FS.STORM(combat.DEFENDERLOCATION)){
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", defenders);
                //determine which attackers can reach this range
                List<GO> groupMembers = FS.GROUPMEMBERS(attackingUnit);
                groupMembers.ForEach(n => n.ADMINDETECTED = true);
                Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers);
                bool ships = combat.DEFENDER == null;
                foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                    if(attackData[obj].ContainsKey("BOMB") && (obj.UNITTYPE != "BMB" || !ships)){
                        attackers.Add(obj);
                    }
                }
                if(attackers.Any()){
                    attackingUnit.NUMCOMBATS++;
                }
                Set("ACTION.TARGET", combat.LABEL); 
            }
            string reason = "";
            if(!attackers.Any()){reason = "no units able to attack";}
            if(!defenders.Any()){reason = "no viable targets in target location";}
            if(reason != ""){
                MainWindow.Alert("Planned " + combat.TYPE + " combat (" + combat.SIDE + " vs " + FS.ENEMY(combat.SIDE) + ") not possible: " + reason);
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", attackers);
            FS.DISCARDLOGIC(combat);                       
        }
        public override void End()
        {
            foreach(GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID)){
                GS.CHANGELOCATION(obj, obj.HOMEBASE);
                obj.HOMEBASEID = null;
            }
            GS.CHANGELOCATION(FS.DEFENDSHEET.SHEETPARENTPIECE, "TEMP");
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionBOMBCombatLoadTrays : GamePhaseAutomated
    {
        public ActionBOMBCombatLoadTrays(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            if(FS.SCENARIOUNITS(GS, "ACTION.ATTACKER").Any()){
                List<GO> tagged = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Where(n => n.TYPE != "FACILITY").ToList();
                List<GO> defenders = tagged.Where(n => !FS.ISGROUP(n) && !n.DOCKED).ToList();
                defenders.AddRange(tagged.Where(n => !FS.ISGROUP(n) && n.DOCKED));
                defenders.AddRange(tagged.Where(n => FS.ISGROUP(n)));
                foreach(GO obj in defenders){
                    obj.HOMEBASEID = obj.GAMELOCATIONID;
                    obj.HOMEBASE = obj.GAMELOCATION;
                }
                if(defenders.Any()){
                    FS.DISPLAYCOMBATSHEET(GS, defenders);                        
                }
            }
            GS.Advance(this);           
        }
    }
    public class ActionBOMBCombatDeclaration : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, Dictionary<string, double>> ATTACKS = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = new();
        public ActionBOMBCombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                ATTACKS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE AIR UNITS THAT WILL PARTICIPATE"});
                GS.HELPTEXT = 
                "BOMB COMBAT DECLARATION.  Declare which units you will attack with\n\n" + 
                "When done with your allocation you can click the NEXT button.  The Defender will be given a chance to reposition forces in the target hex.";                
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ATTACKER")){
                    GS.InteractionMap.Add(obj, new());
                }
                attackData = FS.ATTACKDATA(GS.InteractionMap.Keys.ToList());
            }
            FS.SETINSTRUCTIONS(GS, new(){"ALLOCATE BOMB POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"])});
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "USE BOMB");
                if(GS.InteractionMap.Count == 1 && !ATTACKS.Any()){
                    Update("USE BOMB");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(ATTACKS.Any() || !GS.InteractionMap.Any()){
                        //collect attack data
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", ATTACKS.Keys.ToList());
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        GS.Advance(this);
                    } else {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE BOMB":
                    if(gp.HOMEBASE.BOMBPTS > 0){gp.HOMEBASE.BOMBPTS--;}
                    ATTACKS.Add(gp, attackData[gp]["BOMB"]["BOMB"]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionBOMBCombatDefenderSetup : GamePhaseInteractive
    {
        string side = null;
        List<string> groupingOrder = new();
        List<GO> GROUPTRAYLOCATIONS = new();
        List<GO> DOCKEDTRAYLOCATIONS = new();
        List<GO> UNDOCKEDTRAYLOCATIONS = new();
        public ActionBOMBCombatDefenderSetup(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = FS.ENEMY(Get("ACTIVE.SIDE"));
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG OR RIGHT-CLICK TO REARRANGE SHIP IN STACK"});
                GS.HELPTEXT = 
                "Adjust Defender Positioning. This will determine which units provide Close AA assistance\n\n" + 
                "- You can arrange units within a TF/TG\n" +
                "- You can arrange units within the hex by group and then within group\n" +
                "- All UNDOCKED ships not in TF/TG will always be grouped together.  All DOCKED ships not in TF/TG will always be grouped together. Use right-click options to move up/down the grouping as a whole\n" + 
                "- Dragging ships within a group will only rearrange the ships within the group, the grouping will not move.  Grouping position is only determined with right-click options\n\n" +
                "When done with your setup you can click the NEXT button.  The attacking player will then be allowed to allocate pts prior to combat resolution.";   
                List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Where(n => n.TYPE != "FACILITY").ToList();
                if(!defenders.Any()){
                    Update("NEXT");
                    return;
                }
                foreach(GO obj in defenders){
                    GS.InteractionMap.Add(obj, new());
                    if(FS.ISGROUP(obj)){
                        foreach(GO obj2 in FS.GROUPMEMBERS(obj)){
                            GS.InteractionMap.Add(obj2, new());
                        }
                    }
                }
                //determine initial grouping
                HashSet<string> groupings = new();
                foreach(GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).OrderBy(n => n.GAMELOCATIONID)){
                    if(FS.ISGROUP(obj)){
                        groupings.Add(obj.ID);
                    } else if(obj.DOCKED){
                        groupings.Add("DOCKED");
                    } else {
                        groupings.Add("UNDOCKED");
                    }
                }
                groupingOrder = groupings.ToList();
            }
            GROUPTRAYLOCATIONS = GS.TYPE("PIECE", "PARENTSHEETID", FS.GRPSHEET.ID).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).ToList();
            DOCKEDTRAYLOCATIONS = GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).Where(n => !FS.ISGROUP(n) && n.DOCKED).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).ToList();
            UNDOCKEDTRAYLOCATIONS = GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).Where(n => !FS.ISGROUP(n) && !n.DOCKED).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).ToList();
            foreach(GO obj in GS.InteractionMap.Keys){
                List<GO> targets = GS.InteractionMap[obj];
                targets.Clear();
                if(obj.HOMEBASE != null){
                    if(!FS.ISGROUP(obj)){
                        targets.AddRange(obj.DOCKED ? DOCKEDTRAYLOCATIONS.Where(n => n != obj.GAMELOCATION) : UNDOCKEDTRAYLOCATIONS.Where(n => n != obj.GAMELOCATION));
                    }
                } else {
                    targets.AddRange(GROUPTRAYLOCATIONS.Where(n => n != obj.GAMELOCATION));
                }
                if(obj.HOMEBASE != null){
                    int index = groupingOrder.IndexOf(FS.ISGROUP(obj) ? obj.ID : obj.DOCKED ? "DOCKED" : "UNDOCKED");
                    if(index > 0){GS.AddAction(obj, "MOVE GROUP UP");}
                    if(index < groupingOrder.Count - 1){GS.AddAction(obj, "MOVE GROUP DOWN");}
                }                                     
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){}
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        private void ARRANGEUNITS(GO gp, bool left){
            //always keep non TF/TG grouped together
            GO newsheet = FS.DEFENDSHEET;
            List<GO> grouptraylocations = GS.TYPE("PIECE", "PARENTSHEETID", newsheet.ID).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).Distinct().ToList();
            List<GO> groupMembers = new();
            List<GO> tfs = new();
            List<GO> docked = new();
            List<GO> undocked = new();
            foreach(GO loc in grouptraylocations){
                List<GO> unitsAtLoc = FS.TYPELOCATION(GS, "PIECE", loc.ID);
                if(unitsAtLoc.Any()){
                    if(unitsAtLoc.Count == 1){
                        GO u = unitsAtLoc.First();
                        if(FS.ISGROUP(u)){
                            tfs.Add(u);
                        } else if(u.DOCKED){
                            docked.Add(u);
                        } else {
                            undocked.Add(u);
                        }
                    } else {
                        if(left){
                            if(gp.DOCKED){
                                docked.Add(gp);
                            } else {
                                undocked.Add(gp);
                            }
                        }
                        GO u = unitsAtLoc.Where(n => n != gp).Single();
                        if(FS.ISGROUP(u)){
                            tfs.Add(u);
                        } else if(u.DOCKED){
                            docked.Add(u);
                        } else {
                            undocked.Add(u);
                        }
                        if(!left){
                            if(gp.DOCKED){
                                docked.Add(gp);
                            } else {
                                undocked.Add(gp);
                            }
                        }
                    }
                }
            }
            foreach(string grouping in groupingOrder){
                switch(grouping){
                    case "UNDOCKED":
                        groupMembers.AddRange(undocked);
                        break;
                    case "DOCKED":
                        groupMembers.AddRange(docked);
                        break;
                    default:
                        groupMembers.Add(tfs.Where(n => n.ID == grouping).Single());
                        break;
                }
            }
            FS.DISPLAYCOMBATSHEET(GS, groupMembers);
        }
        private void REORDERGROUPINGS(GO gp, bool up){
            string key = FS.ISGROUP(gp) ? gp.ID : gp.DOCKED ? "DOCKED" : "UNDOCKED";
            int index = groupingOrder.IndexOf(key);
            groupingOrder.Remove(key);
            if(up){
                groupingOrder.Insert(index - 1, key);
            } else {
                if(index >= groupingOrder.Count - 1){
                    groupingOrder.Add(key);
                } else {
                    groupingOrder.Insert(index + 1, key);
                }
            }
            ARRANGEUNITS(gp, true);
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    GS.Advance(this);
                    break;
                case "MOVE GROUP UP":
                    REORDERGROUPINGS(gp, true);
                    Start(false);
                    break;
                case "MOVE GROUP DOWN":
                    REORDERGROUPINGS(gp, false);
                    Start(false);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        GO newloc = gp.GAMELOCATION;                        
                        if(oldloc.PARENTSHEET == FS.GRPSHEET && newloc.PARENTSHEET == FS.GRPSHEET){
                            GO newsheet = newloc.PARENTSHEET;
                            int oldindex = GROUPTRAYLOCATIONS.IndexOf(oldloc);
                            int newindex = GROUPTRAYLOCATIONS.IndexOf(newloc);
                            for(int i = 0; i < Math.Abs(oldindex - newindex); i++){
                                if(oldindex < newindex){
                                    FS.MOVEDOWNINGROUP(GS, gp, gp.GROUP);
                                } else {
                                    FS.MOVEUPINGROUP(GS, gp, gp.GROUP);
                                }
                            }
                        }
                        if(oldloc.PARENTSHEET == FS.DEFENDSHEET && newloc.PARENTSHEET == FS.DEFENDSHEET){
                            if(DOCKEDTRAYLOCATIONS.Contains(oldloc)){
                                int oldindex = DOCKEDTRAYLOCATIONS.IndexOf(oldloc);
                                int newindex = DOCKEDTRAYLOCATIONS.IndexOf(newloc);
                                ARRANGEUNITS(gp, oldindex > newindex);
                            } else {
                                int oldindex = UNDOCKEDTRAYLOCATIONS.IndexOf(oldloc);
                                int newindex = UNDOCKEDTRAYLOCATIONS.IndexOf(newloc);
                                ARRANGEUNITS(gp, oldindex > newindex);
                            }
                        }
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionBOMBCombatDefensiveFire : GamePhaseAutomated
    {
        public ActionBOMBCombatDefensiveFire(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            SetInt("ACTION.DEFENSEMODIFIER", 0);
            //any losses to attacking aircraft
            SetInt("ACTION.ATTACKERLOSSES", 0);
            SetInt("ACTION.DEFENDERLOSSES", 0);
            string facilityBeingAttacked = Get("ACTION.TARGET");    
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            if(defenders.Any()){
                bool baseTarget = defenders.First().TYPE == "FACILITY";
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                GO attackingUnit = FS.SCENARIOUNITS(GS, "ACTION.ACTIONING").First();
                GO attackLocation = FS.PARENTGROUPLOCATION(attackingUnit);
                GO firstDefender = defenders.First();
                GO defenseLocation = baseTarget ? firstDefender.GAMELOCATION : firstDefender.HOMEBASE ?? FS.LOGICALPARENT(firstDefender).HOMEBASE;
                string report = "BOMB COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                //look back group overflight
                Set("ACTION.OVERFLIGHT", attackingUnit.LOCATIONHISTORY);
                List<GO> bombPath = FS.SCENARIOLOCATIONS(GS, "ACTION.OVERFLIGHT");
                Set("ACTION.OVERFLIGHT", null);
                List<GO> dockedShips = new();
                List<GO> undockedShips = new();
                //put defenders in groups
                foreach(GO loc in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).Select(n => n.GAMELOCATION).OrderBy(n => n.ID)){
                    GO obj = FS.TYPELOCATION(GS, "PIECE", loc.ID).SingleOrDefault();
                    if(obj != null){
                        if(!FS.ISGROUP(obj)){
                            if(obj.DOCKED){
                                dockedShips.Add(obj);
                            } else {
                                undockedShips.Add(obj);
                            }                            
                        }
                    }
                }
                //create Dict of targets to ships beneath them
                Dictionary<GO, GO> targetsAndBeneath = new();
                foreach(GO defender in defenders.Where(n => n.TYPE != "FACILITY")){
                    if(defender.HOMEBASE != null){
                        int position1 = defender.DOCKED ? dockedShips.IndexOf(defender) : undockedShips.IndexOf(defender);
                        int position2 = defender.DOCKED ? (position1 + 1) % dockedShips.Count : (position1 + 1) % undockedShips.Count;
                        GO beneath = defender.DOCKED ? dockedShips[position2] : undockedShips[position2];
                        if(beneath == defender || defenders.Contains(beneath)){
                            beneath = null;
                        }
                        targetsAndBeneath.Add(defender, beneath);
                    } else {
                        GO group = FS.LOCATIONPARENT(defender);
                        List<GO> groupMembers = FS.GROUPMEMBERS(group).OrderBy(n => n.GROUPINDEX).ToList();
                        int position1 = groupMembers.IndexOf(defender);
                        int position2 = (position1 + 1) % groupMembers.Count;
                        GO beneath = groupMembers[position2];
                        if(beneath == defender || defenders.Contains(beneath)){
                            beneath = null;
                        }
                        targetsAndBeneath.Add(defender, beneath);
                    }
                }
                //combine AA values
                int combinedAAValue = 0;
           
                //AAA in target hex
                if(!(defenseLocation.RESTRICTED || defenseLocation.FJORD) && !baseTarget){
                    foreach(GO obj in FS.ALLSHIPSINHEX(defendingSide, defenseLocation, true, false).Where(n => n.AAPTS > 0)){
                        obj.AAPTS--;
                        double val = obj.TEMPLATE.AAA;
                        combinedAAValue += (int)val;
                        report += obj.UNITTYPE + " " + obj.LABEL + " AAA=" + obj.TEMPLATE.AAA + " contributes " + val + "\n";
                    }
                }
                //CAA of targets
                double targetCAA = 0;
                if(!baseTarget){
                    foreach(GO obj in defenders){
                        targetCAA += obj.TEMPLATE.CAA;
                        report += obj.UNITTYPE + " " + obj.LABEL + " CAA=" + obj.TEMPLATE.CAA + "\n";
                    }
                }
                //CAA of base
                if(baseTarget || defenders.Where(n => n.DOCKED).Any()){
                    GO facility = baseTarget ? defenders.First() : defenseLocation.GAMEPIECE;
                    double baseCAA = FS.GETFACILITYCAA(facility, baseTarget ? facilityBeingAttacked : "PORT");
                    targetCAA += baseCAA;
                    report += (baseTarget ? facilityBeingAttacked : "PORT") + " CAA=" + baseCAA + "\n";
                }
                //CAA of beneath
                foreach(GO obj in targetsAndBeneath.Values.Where(n => n != null)){
                    targetCAA += obj.TEMPLATE.CAA;
                    report += obj.UNITTYPE + " " + obj.LABEL + " CAA=" + obj.TEMPLATE.CAA + "\n";
                }
                report += "contributes " + targetCAA + "\n";
                combinedAAValue += (int)targetCAA;  
                //AAA of outside hex
                List<GO> aaaLoc = new();
                List<GO> laaLoc = new();
                List<GO> ships = new();
                foreach(GO location in bombPath){
                    aaaLoc.Add(location);
                    FS.FINDAIRRADIUS(location, 2).ForEach(laaLoc.Add);
                }
                laaLoc.RemoveAll(aaaLoc.Contains);
                aaaLoc.Remove(defenseLocation);
                foreach(GO loc in aaaLoc.Distinct()){
                    foreach(GO obj in FS.ALLSHIPSINHEX(defendingSide, loc, true, false).Where(n => n.AAPTS > 0)){
                        obj.AAPTS--;
                        double val = obj.TEMPLATE.AAA;
                        val = Math.Floor(val);
                        combinedAAValue += (int)val;
                        report += obj.UNITTYPE + " " + obj.LABEL + " AAA=" + obj.TEMPLATE.AAA + " contributes " + val + "\n";
                    }
                }
                foreach(GO loc in laaLoc.Distinct()){
                    foreach(GO obj in FS.ALLSHIPSINHEX(defendingSide, loc, true, false).Where(n => n.AAPTS > 0)){
                        obj.AAPTS--;
                        double val = obj.TEMPLATE.AAA;
                        val = Math.Floor(val);
                        combinedAAValue += (int)val;
                        report += obj.UNITTYPE + " " + obj.LABEL + " AAA=" + obj.TEMPLATE.AAA + " contributes " + val + "\n";
                    }
                }
                report += "TOTAL AA = " + combinedAAValue + "\n\n";
                int defenseModifier = 0;
                int rollModifier = 0;
                if(combinedAAValue > 0){
                    if(defenders.Where(n => n.GROUP?.UNITTYPE == "TF").Any()){
                        rollModifier += 2;
                        report += "TF: Roll +2\n";
                    }
                    if(!baseTarget && !defenders.Where(n => n.GROUP != null).Any()){
                        rollModifier -= 4;
                        report += "NO TG/TF: Roll -4\n";
                    }
                    if(FS.GROUPMEMBERS(attackingUnit).Where(n => n.UNITTYPE == "EW").Any()){
                        rollModifier -= 2;
                        report += "EW: Roll -2\n";
                    }
                    if(FS.GROUPMEMBERS(attackingUnit).Where(n => n.HIGHMISSIONPROFILE).Any()){
                        rollModifier += 2;
                        report += "HIGH MISSION PROFILE: Roll + 2\n";
                    }
                    report += "DEFENSE ROLL MODIFIER: " + rollModifier + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + rollModifier) + "\n";
                    dieRoll += rollModifier;
                    defenseModifier = FS.COMBATRESULTSTABLE(false, dieRoll, combinedAAValue);
                }
                report += "DEFENSE MODIFIER: " + defenseModifier + "\n\n";
                
                SetInt("ACTION.DEFENSEMODIFIER", defenseModifier);
                int losses = 0;
                if(defenseModifier >= 7){
                    int roll1 = FS.DIEROLL();
                    int roll2 = FS.DIEROLL();
                    losses = (roll1 % 2 == 0 ? 1 : 0) + (roll2 % 2 == 0 ? 1 : 0);
                    SetInt("ACTION.ATTACKERLOSSES", losses);
                } else if(defenseModifier >= 4){
                    int roll1 = FS.DIEROLL();
                    losses = roll1 % 2 == 0 ? 1 : 0;
                    SetInt("ACTION.ATTACKERLOSSES", losses);
                }
                report += "**Attacking Air take " + losses + " steps lost**";
            
                MainWindow.Alert(report);
            }
            GS.Advance(this);           
        }
    }
    public class ActionBOMBCombatDefensePicksCasualties : GamePhaseInteractive
    {
        int stepLosses = 0;
        string side = null;
        List<GO> CONTRIBUTINGBOMBERS = new();
        List<GO> CASUALTIES = new();
        public ActionBOMBCombatDefensePicksCasualties(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                CASUALTIES.Clear();
                int attackerLosses = GetInt("ACTION.ATTACKERLOSSES");
                if(attackerLosses == 0){
                    Update("NEXT");
                    return;
                }
                List<GO> bombers = FS.GROUPSANDMEMBERS(FS.SCENARIOUNITS(GS, "ACTION.ACTIONING"));
                CONTRIBUTINGBOMBERS = FS.SCENARIOUNITS(GS, "ACTION.ATTACKER");
                side = FS.ENEMY(Get("ACTIVE.SIDE"));
                stepLosses = attackerLosses;
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "Choose the ENEMY squadrons to apply losses to. You must choose ATK/BMB or INT in the BOMBER or FIGHTER-BOMBER ROLE.\n\n" +
                "When all step losses have been applied, the phase will end.  The owner of the bombers will then have the ability to re-allocate bomb pts if losses impact the bombing points\n\n"; 
                foreach(GO obj in bombers.Where(n => n.UNITTYPE == "ATK" || n.UNITTYPE == "BMB" || n.ROLE == "BOMBER" || n.ROLE == "FIGHTER-BOMBER")){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(stepLosses == 0 || !GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            FS.SETINSTRUCTIONS(GS, new(){"APPLY LOSSES: STEPS REMAINING TO SELECT = " + stepLosses});
            foreach(GO obj in GS.InteractionMap.Keys){
                GS.AddAction(obj, "APPLY LOSS");
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){}
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    SetInt("ACTION.ATTACKERLOSSES", 0);
                    //if one of the casualties was actually attacking (likely) then reset the attack allocations for next step
                    if(CONTRIBUTINGBOMBERS.Intersect(CASUALTIES).Any()){
                        List<GO> attackers = FS.SCENARIOUNITS(GS, "ACTION.ATTACKER");
                        List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
                        if(attackers.Any()){
                            double available = attackers.Sum(FS.GETAIRBOMB);
                            SetInt("ACTION.PTS", (int)available);
                            FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", attackers.Any() ? defenders : new());
                        } else {
                            defenders.ForEach(n => n.ATK = 0);
                            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
                        }
                    }
                    GS.Advance(this);
                    break;
                case "APPLY LOSS":
                    CASUALTIES.Add(gp);
                    FS.DAMAGE(gp);
                    stepLosses--;
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionBOMBCombatReAllocation : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, int> ALLOCATIONS = new();
        public ActionBOMBCombatReAllocation(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                ALLOCATIONS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "RE-Allocate BOMB Points due to losses by defensive fire. Reduce Overages\n\n" + 
                "- You MUST keep at least 1 point allocated to each defender prior targeted, assuming you have enough points for that\n" +
                "- Right click enemy units to de-allocate.  You cannot reduce an allocation to 0 unless you don't have enough points to cover all targets\n\n" +
                "When done with your allocation you can click the NEXT button.  The Combat will then be resolved";                
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Where(n => !FS.ISGROUP(n))){
                    GS.InteractionMap.Add(obj, new());
                    ALLOCATIONS.Add(obj, (int)obj.ATK);
                }
                if(GetInt("ACTION.PTS") == 0){
                    Update("NEXT");
                    return;
                }
            }
            int ptsToReduce = ALLOCATIONS.Values.Sum() - GetInt("ACTION.PTS");
            bool atMinimum = ALLOCATIONS.Values.Where(n => n == 1).Count() == ALLOCATIONS.Count;
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(atMinimum){
                    GS.AddAction(obj, "REMOVE TARGET");
                } else {
                    int maxReduce = Math.Min(ptsToReduce, ALLOCATIONS[obj] - 1);
                    if(maxReduce > 0){
                        GS.AddAction(obj, "DE-ALLOCATE 1 PT");
                        if(maxReduce >= 5){
                            GS.AddAction(obj, "DE-ALLOCATE 5 PT");
                            if(maxReduce >= 10){
                                GS.AddAction(obj, "DE-ALLOCATE 10 PT");
                            }
                        }
                    }
                }
                if(GS.InteractionMap.Count == 1 && ptsToReduce > 0){
                    ALLOCATIONS[obj] -= ptsToReduce;
                    Update("NEXT");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any() || ptsToReduce == 0){
                Update("NEXT");
                return;
            }
            if(GS.SelectedMarker?.TYPE == "FACILITY"){
                ALLOCATIONS[GS.SelectedMarker] = GetInt("ACTION.PTS");
                Update("NEXT");
                return;
            }
            int currentAllocation = 0;
            if(GS.SelectedMarker != null){
                if(ALLOCATIONS.ContainsKey(GS.SelectedMarker)){
                    currentAllocation = ALLOCATIONS[GS.SelectedMarker];
                }
            }
            FS.SETINSTRUCTIONS(GS, new(){"BOMB PTS ASSIGNED TO THIS UNIT: " + currentAllocation, "TOTAL LEFT TO DE-ALLOCATE: " + ptsToReduce});
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    foreach(GO obj in ALLOCATIONS.Keys){
                        obj.ATK = ALLOCATIONS[obj];
                    }
                    FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", ALLOCATIONS.Keys.ToList());
                    SetInt("ACTION.PTS", 0);
                    GS.Advance(this);
                    break;
                case "REMOVE TARGET":
                    gp.ATK = 0;
                    ALLOCATIONS.Remove(gp);
                    Start(false);
                    break;
                case "DE-ALLOCATE 1 PT":
                    ALLOCATIONS[gp] -= 1;
                    Start(false);
                    break;
                case "DE-ALLOCATE 5 PT":
                    ALLOCATIONS[gp] -= 5;
                    Start(false);
                    break;
                case "DE-ALLOCATE 10 PT":
                    ALLOCATIONS[gp] -= 10;
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionBOMBCombatResolution : GamePhaseAutomated
    {
        public ActionBOMBCombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            string facilityBeingAttacked = Get("ACTION.TARGET");    
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            if(defenders.Any()){
                bool baseTarget = defenders.First().TYPE == "FACILITY";
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                List<GO> attackers = FS.SCENARIOUNITS(GS, "ACTION.ATTACKER");
                GO attackLocation = FS.PARENTGROUPLOCATION(attackers.First());
                GO firstDefender = defenders.First();
                GO defenseLocation = baseTarget ? firstDefender.GAMELOCATION : firstDefender.HOMEBASE ?? FS.LOGICALPARENT(firstDefender).HOMEBASE;
                string report = "";
                int defenseModifier = GetInt("ACTION.DEFENSEMODIFIER");
                int rollModifier = -defenseModifier;
                if(FS.ALLSHIPSINHEX(defendingSide, defenseLocation, true, false).Where(n => n.TACCOORDPIECEID != null).Any()){
                    rollModifier += 2;
                    report += "TAC COORD: Roll +2\n";
                }
                if((defenseLocation.RESTRICTED || defenseLocation.FJORD) && !baseTarget){
                    rollModifier += 4;
                    report += "RESTRICTED/FJORD: Roll +4\n";
                }
                if(GetBoolean("TURN.DARKNESS")){
                    if(!attackers.Where(n => n.TEMPLATE.NIGHTBOMBING).Any()){
                        rollModifier -= 3;
                        report += "NIGHT: Roll -3\n";
                    }
                }
                if(baseTarget){
                    GO facility = defenders.First();
                    report += "\nATTACK ON " + facilityBeingAttacked + " " + facility.LABEL + " with " + facility.ATK + " pts:\n";
                    int objRollModifer = rollModifier;
                    report += "ATTACK ROLL MODIFIER: " + objRollModifer + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + objRollModifer) + "\n";
                    dieRoll += objRollModifer;
                    double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)facility.ATK);
                    facility.ATK = 0;
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    GO bombedBase = defenseLocation;
                    string increase = "";
                    if(attackResult >= 11){
                        //FS.DESTROYBASE(bombedBase, facilityBeingAttacked);
                        if(facilityBeingAttacked == "AIRFIELD"){
                            bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 4;                        
                        } else {
                            bombedBase.UNAPPLIEDPORTDAMAGE += 4;                        
                        }
                        report += facilityBeingAttacked + " Destroyed\n";
                        increase = "4";
                    } else if(attackResult >= 10){
                        //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                        //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                        //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                        if(facilityBeingAttacked == "AIRFIELD"){
                            bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 3;                        
                        } else {
                            bombedBase.UNAPPLIEDPORTDAMAGE += 3;                        
                        }
                        increase = "3";
                    } else if(attackResult >= 8){
                        //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                        //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                        if(facilityBeingAttacked == "AIRFIELD"){
                            bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 2;                        
                        } else {
                            bombedBase.UNAPPLIEDPORTDAMAGE += 2;                        
                        }
                        increase = "2";
                    } else if(attackResult >= 4){
                        //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                        if(facilityBeingAttacked == "AIRFIELD"){
                            bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 1;                        
                        } else {
                            bombedBase.UNAPPLIEDPORTDAMAGE += 1;                        
                        }
                        increase = "1";
                    } else {
                        report += "No effect\n";
                    }
                    if(increase != ""){
                        switch(facilityBeingAttacked){
                            case "PORT":
                                if(bombedBase.PORTDAMAGELEVEL + bombedBase.UNAPPLIEDPORTDAMAGE >= 4){
                                    report += facilityBeingAttacked + " Destroyed\n";
                                } else {
                                    report += facilityBeingAttacked + " Damaged Level increases by " + increase + "\n";
                                }
                                break;
                            case "AIRFIELD":
                                if(bombedBase.AIRFIELDDAMAGELEVEL + bombedBase.UNAPPLIEDAIRFIELDDAMAGE >= 4){
                                    report += facilityBeingAttacked + " Destroyed\n";
                                } else {
                                    report += facilityBeingAttacked + " Damaged Level increases by " + increase + "\n";
                                }
                                break;
                            default:
                                break;
                        }
                    }
                } else {               
                    foreach(GO obj in defenders){
                        int objRollModifer = rollModifier;
                        report += "\nATTACK ON " + obj.UNITTYPE + " " + obj.LABEL + " with " + obj.ATK + " pts:\n";
                        if(obj.DOCKED){
                            if(defenseLocation.RESTRICTED || defenseLocation.FJORD){
                                objRollModifer += 2;
                                report += "DOCKED: Roll +2\n";
                            } else {
                                objRollModifer += 6;
                                report += "DOCKED: Roll +6\n";
                            }
                        }
                        if(obj.UNITTYPE == "PC"){
                            objRollModifer -= 3;
                            report += "PC: Roll -3\n";
                        }
                        report += "ATTACK ROLL MODIFIER: " + objRollModifer + "\n";
                        int dieRoll = FS.DIEROLL();
                        report += "ROLL: " + dieRoll + " => " + (dieRoll + objRollModifer) + "\n";
                        dieRoll += objRollModifer;
                        double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)obj.ATK);
                        obj.ATK = 0;
                        report += "ATTACK RESULT: " + attackResult + "\n";
                        //compare to ship defense
                        double defense = FS.GETDEFENSE(obj);
                        if(attackResult >= defense){
                            //FS.DESTROY(obj);
                            obj.UNAPPLIEDDAMAGE += 2;
                            report += "Target Destroyed\n";
                        } else if(attackResult >= defense * 0.5){
                            //FS.DAMAGE(obj);
                            obj.UNAPPLIEDDAMAGE++;
                            if((obj.DAMAGED ? 1 : 0) + obj.UNAPPLIEDDAMAGE >= 2){
                                report += "Target Destroyed\n";
                            } else {
                                report += "Target Damaged\n";
                            }
                        } else {
                            report += "No effect\n";
                        }
                    }
                }
                MainWindow.Alert(report);         
            }
            GS.Advance(this);           
        }
    }
}
