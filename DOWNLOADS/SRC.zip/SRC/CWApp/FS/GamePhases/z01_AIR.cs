using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;
using System.Windows.Documents;
namespace CWApp.FS
{
    public class ActionAirINTRole : GamePhaseInteractive
    {
        string side = null;
        public ActionAirINTRole(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"SELECT ROLE"});

                GS.HELPTEXT = 
                "INT unit Role Designation.\n" + 
                "- Fighter.  Bombing and SSM values go to 0\n" +
                "- Bomber.  Anti-Air value goes to 1\n" + 
                "- Fighter/Bomber.  All values are halved";
                foreach(GO obj in FS.GETTAGGEDUNITS(GS, "ACTION.ACTIVATING").Where(n => n.UNITTYPE == "INT" && n.ROLE == null)){
                    if(obj.TEMPLATE.SPECIAL == 0 && obj.TEMPLATE.SSM == 0){continue;}
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "FIGHTER");
                GS.AddAction(obj, "BOMBER");
                GS.AddAction(obj, "FIGHTER-BOMBER");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "FIGHTER":
                case "BOMBER":
                case "FIGHTER-BOMBER":
                    gp.ROLE = pData;
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "NEXT":
                    GS.Advance(this);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirEnemyInterceptionLoop : GamePhaseLoopLogic
    {
        public ActionAirEnemyInterceptionLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionAirEnemyInterception("Intercept", this, GS));
            AddGamePhase(new ActionAirFriendlyAssistance("Friendly Assist", this, GS));
            AddGamePhase(new ActionAirInterceptionCombat("Air To Air Combat Resolution", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.GETTAGGEDUNITS(GS, "ACTION.INTERCEPTNEEDED").Any();}
        public override void Init()
        {
            List<GO> objs = FS.GETTAGGEDUNITS(GS, "ACTION.INTERCEPTNEEDED");
            GO obj = objs.First();
            FS.SETTAGGED(GS, "ACTION.INTERCEPTED", new List<GO>{obj});
            objs.Remove(obj);
            FS.SETTAGGED(GS, "ACTION.INTERCEPTNEEDED", objs);
        }
        public override void End()
        {
            //RTB
            foreach(GO obj in FS.GETTAGGEDUNITS(GS, "ACTION.RTB")){
                switch(obj.GRPTYPE){
                    case "ACTIVATIONGRP":
                        List<GO> groupMembers = FS.GROUPMEMBERS(obj);
                        foreach(GO sqn in groupMembers){
                            FS.REMOVEFROMGROUP(sqn, obj);
                            FS.RETURNTOHOMEBASE(sqn);
                            FS.REMOVETAGGED(GS, sqn);
                            sqn.DONE = true;
                        }                        
                        FS.DISCARDTAGGED(obj);
                        break;
                    case null:
                        obj.DONE = true;
                        FS.REMOVETAGGED(GS, obj);
                        break;
                    default:
                        break;
                }
            }
        }
    }
    public class ActionAirEnemyInterception : GamePhaseInteractive
    {
        GO interceptedUnit = null;
        List<GO> INTERCEPTINGUNITS = new();
        string side = null;
        public ActionAirEnemyInterception(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                interceptedUnit = FS.GETTAGGEDUNITS(GS, "ACTION.INTERCEPTED").Single();
                side = FS.ENEMY(interceptedUnit.SIDE);
                INTERCEPTINGUNITS.Clear();
                FS.SIDE_MODE = FS.ENEMY(side);
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE CAP MISION(S) TO INTERCEPT"});

                GS.HELPTEXT = 
                "Intercept Air Group.  Select all CAP units you'd like to intercept at this location\n\n" +
                "NOTE: To skip, hit NEXT Button";
                List<GO> alreadyIntercepted = GS.TYPE("INTERCEPTION").Where(n => n.INTERCEPTEDGRP == interceptedUnit).Select(n => n.CAP).ToList();
                List<GO> friendlyRadius = FS.FINDAIRRADIUS(interceptedUnit.GAMELOCATION, 4);
                friendlyRadius.Remove(interceptedUnit.GAMELOCATION);
                List<GO> CAPMISSIONS = FS.CAPSQNS(GS, FS.ENEMY(side)).Where(n => !alreadyIntercepted.Contains(n) && !n.DONE && friendlyRadius.Contains(n.GAMELOCATION)).ToList();
                foreach(GO obj in CAPMISSIONS){
                    if(CAPMISSIONS.Where(n => n.GAMELOCATION == obj.GAMELOCATION && n.UNITTYPE == "INT").Any()){
                        GS.InteractionMap.Add(obj, new());
                    }
                }
                GS.InteractionMap.Add(interceptedUnit, new());
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, obj.SIDE == side ? "ASSIGN ALL CAP IN THIS HEX TO INTERCEPT" : "COMMIT ASSIGNMENTS");
            }
            if(!GS.InteractionMap.Keys.Where(n => n.SIDE == side).Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "COMMIT ASSIGNMENTS":
                case "NEXT":
                    FS.SETTAGGED(GS, "ACTION.INTERCEPTING", INTERCEPTINGUNITS);                        
                    if(INTERCEPTINGUNITS.Any()){
                        foreach(GO obj in INTERCEPTINGUNITS){
                            Dictionary<string, string> clonedData = new()
                            {
                                ["ID"] = obj.ID + GO.DELIM + interceptedUnit.ID + GO.DELIM + FS.GENERATETIMESTAMP(),
                                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                ["TYPE"] = "INTERCEPTION"
                            };
                            GO interception = new(GS, clonedData, null, null)
                            {
                                CAPID = obj.ID,
                                CAP = obj,
                                INTERCEPTEDGRPID = interceptedUnit.ID,
                                INTERCEPTEDGRP = interceptedUnit
                            };
                        }
                    } else {
                        FS.CLEARTAGGED(GS, "ACTION.INTERCEPTED");
                    }
                    GS.Advance(this);
                    break;
                case "ASSIGN ALL CAP IN THIS HEX TO INTERCEPT":
                    foreach(GO obj in GS.InteractionMap.Keys.ToList().Where(n => n.SIDE == gp.SIDE && n.GAMELOCATION == gp.GAMELOCATION && n != gp)){
                        INTERCEPTINGUNITS.Add(obj);
                        GS.REMOVEINTERACTIVE(obj);
                    }
                    INTERCEPTINGUNITS.Add(gp);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirFriendlyAssistance : GamePhaseInteractive
    {
        GO interceptedUnit = null;
        List<GO> INTERCEPTINGUNITS = new();
        string side = null;
        public ActionAirFriendlyAssistance(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                interceptedUnit = FS.GETTAGGEDUNITS(GS, "ACTION.INTERCEPTED").FirstOrDefault();
                if(interceptedUnit != null){
                    side = interceptedUnit.SIDE;
                    INTERCEPTINGUNITS.Clear();
                    FS.SIDE_MODE = side;
                    FS.SETINSTRUCTIONS(GS, new(){"CHOOSE CAP MISSION(S) TO DEFEND"});

                    GS.HELPTEXT = 
                    "Defend active air unit at its current location.  Select all CAP units you'd like to assist at this location\n\n" +
                    "NOTE: To skip, hit NEXT Button";
                    List<GO> friendlyRadius = FS.FINDAIRRADIUS(interceptedUnit.GAMELOCATION, 4);
                    foreach(GO obj in FS.CAPSQNS(GS, side).Where(n => n.NUMCOMBATS == 0 && !n.DONE && friendlyRadius.Contains(n.GAMELOCATION))){
                        GS.InteractionMap.Add(obj, new());
                    }
                    GS.InteractionMap.Add(interceptedUnit, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, obj != interceptedUnit ? "ASSIGN ALL CAP IN THIS HEX TO DEFEND" : "COMMIT ASSIGNMENTS");
            }
            if(!GS.InteractionMap.Keys.Where(n => n != interceptedUnit).Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "COMMIT ASSIGNMENTS":
                case "NEXT":
                    FS.SETTAGGED(GS, "ACTION.DEFENDING", INTERCEPTINGUNITS);
                    GS.Advance(this);
                    break;
                case "ASSIGN ALL CAP IN THIS HEX TO DEFEND":
                    foreach(GO obj in GS.InteractionMap.Keys.ToList().Where(n => n.SIDE == gp.SIDE && n.GAMELOCATION == gp.GAMELOCATION && n != gp)){
                        INTERCEPTINGUNITS.Add(obj);
                        GS.REMOVEINTERACTIVE(obj);
                    }
                    INTERCEPTINGUNITS.Add(gp);
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirInterceptionCombat : GamePhaseAutomated
    {
        public ActionAirInterceptionCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            SetInt("ACTION.ATTACKERLOSSES", 0);
            SetInt("ACTION.DEFENDERLOSSES", 0);
            FS.CLEARTAGGED(GS, "ACTION.RTB");
            GO interceptedUnit = FS.GETTAGGEDUNITS(GS, "ACTION.INTERCEPTED").FirstOrDefault();
            if(interceptedUnit != null){
                interceptedUnit.ADMINDETECTED = true;
                GO combatLocation = interceptedUnit.GAMELOCATION;
                string defendingSide = Get("ACTIVE.SIDE");
                string attackingSide = FS.ENEMY(defendingSide);
                List<GO> interceptedUnits = FS.GROUPMEMBERS(interceptedUnit);
                interceptedUnits.ForEach(n => n.ADMINDETECTED = true);
                List<GO> combatants = new(interceptedUnits);
                Dictionary<GO, double> CAPModifiers = new();
                interceptedUnits.ForEach(n => CAPModifiers.Add(n, 1));
                List<GO> interceptors = FS.GETTAGGEDUNITS(GS, "ACTION.INTERCEPTING");
                bool atkEW = interceptors.Where(n => n.UNITTYPE == "EW").Any();
                bool fromAirfield = interceptors.Where(n => n.HOMEBASE.AIRFIELD).Any();
                bool USAEW = interceptors.Where(n => n.COUNTRY == "USA" && n.UNITTYPE == "AEW").Any();
                bool AEW = interceptors.Where(n => n.UNITTYPE == "AEW").Any();                        
                foreach(GO obj in interceptors){
                    obj.ADMINDETECTED = true;
                    combatants.Add(obj);
                    double modifier = 0;
                    if(fromAirfield){
                        modifier = 1;
                    } else {
                        int distance = FS.GETAIRMOVEMENTDISTANCE(FS.FINDAIRMOVEMENTPATH(obj.GAMELOCATION, interceptedUnit.GAMELOCATION));
                        if(distance <= 1){
                            modifier = 1;
                        } else if(distance <= 2){
                            modifier = AEW ? 1 : 0.5;
                        } else if(distance <= 3){
                            modifier = USAEW ? 0.5 : 0.25;
                        } else if(distance <= 4){
                            modifier = USAEW ? 0.25 : 0.125;
                        }
                    }
                    CAPModifiers.Add(obj, modifier);
                }
                List<GO> defendCaps = FS.GETTAGGEDUNITS(GS, "ACTION.DEFENDING");
                bool defEW = interceptedUnits.Where(n => n.UNITTYPE == "EW").Any() || defendCaps.Where(n => n.UNITTYPE == "EW").Any();
                fromAirfield = defendCaps.Where(n => n.HOMEBASE.AIRFIELD).Any();
                USAEW = defendCaps.Where(n => n.COUNTRY == "USA" && n.UNITTYPE == "AEW").Any();
                AEW = defendCaps.Where(n => n.UNITTYPE == "AEW").Any();                        
                foreach(GO obj in defendCaps){
                    obj.ADMINDETECTED = true;
                    combatants.Add(obj);
                    double modifier = 0;
                    if(fromAirfield){
                        modifier = 1;
                    } else {
                        int distance = FS.GETAIRMOVEMENTDISTANCE(FS.FINDAIRMOVEMENTPATH(obj.GAMELOCATION, interceptedUnit.GAMELOCATION));
                        if(distance <= 1){
                            modifier = 1;
                        } else if(distance <= 2){
                            modifier = AEW ? 1 : 0.5;
                        } else if(distance <= 3){
                            modifier = USAEW ? 0.5 : 0.25;
                        } else if(distance <= 4){
                            modifier = USAEW ? 0.25 : 0.125;
                        }
                    }
                    CAPModifiers.Add(obj, modifier);
                }
                List<GO> attackers = combatants.Where(n => n.SIDE == attackingSide).ToList();
                List<GO> defenders = combatants.Where(n => n.SIDE == defendingSide).ToList();
                string report = "CAP COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                double atkAArating = 0;
                foreach(GO obj in attackers){
                    double rating = FS.GETAIRCAA(obj);
                    double modifier = CAPModifiers[obj];
                    atkAArating += Math.Max(Math.Floor(rating * modifier), 1);
                }
                double defAArating = 0;
                foreach(GO obj in defenders){
                    double rating = FS.GETAIRCAA(obj);
                    double modifier = CAPModifiers[obj];
                    defAArating += Math.Max(Math.Floor(rating * modifier), 1);
                }
                if(defAArating == 0){
                    SetInt("ACTION.DEFENDERLOSSES", 99999);
                    report += "RESULTS: Defender has 0 ATA rating.  DEFENDER ELIMINATED";
                    MainWindow.Alert(report);
                } else {
                    double ratio = atkAArating / defAArating;
                    double columnRatio = FS.INTERCEPTIONCOLUMNS.Keys.Where(n => n <= ratio).Any() ? FS.INTERCEPTIONCOLUMNS.Keys.Where(n => n <= ratio).Last() : FS.INTERCEPTIONCOLUMNS.Keys.Order().First();
                    string columnHeader = FS.INTERCEPTIONCOLUMNHEADER(columnRatio);
                    report += "COLUMN: " + columnHeader + "\n";
                    int rollmodifier = (atkEW ? 2 : 0) + (defEW ? -2 : 0);
                    List<int> attacksperhex = interceptors.Select(n => n.GAMELOCATION).Distinct().Select(n => interceptors.Where(n2 => n2.GAMELOCATION == n).Max(n => n.NUMCOMBATS)).ToList();
                    int sumPriorAttacks = Math.Min(attacksperhex.Sum(), 2);
                    rollmodifier -= sumPriorAttacks;
                                    

                    report += "ROLL modifier: " + rollmodifier + "\n";
                    int dieRoll = Math.Min(9, Math.Max(0, FS.DIEROLL() + rollmodifier));
                    report += "ROLL: " + dieRoll + "\n";
                    List<string> results = FS.INTERCEPTIONRESULTS(columnHeader, dieRoll);
                    report += "RESULTS: " + results[0] + "/" + results[1];
                    MainWindow.Alert(report);
                    string atkResult = results[0];
                    List<GO> RTB = new();
                    if(atkResult.Contains("R")){
                        atkResult = atkResult.Replace("R","");
                        RTB.AddRange(interceptors);      
                    }
                    Set("ACTION.ATTACKERLOSSES", atkResult);
                    
                    string defResult = results[1];
                    if(defResult.Contains("R")){
                        defResult = defResult.Replace("R","");
                        RTB.Add(interceptedUnit);
                        RTB.AddRange(defendCaps);      
                    }
                    Set("ACTION.DEFENDERLOSSES", defResult);
                    FS.SETTAGGED(GS, "ACTION.RTB", RTB);
                }
                //increment
                foreach(GO obj in interceptors){
                    obj.NUMCOMBATS++;
                }
                foreach(GO obj in defendCaps){
                    obj.NUMCOMBATS++;
                }
            }
            GS.Advance(this);           
        }
    }
    public class ActionAirInterceptionPickCasualties : GamePhaseInteractive
    {
        GO interceptedUnit = null;
        int stepLosses = 0;
        string side = null;
        public ActionAirInterceptionPickCasualties(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                interceptedUnit = FS.GETTAGGEDUNITS(GS, "ACTION.INTERCEPTED").FirstOrDefault();
                if(interceptedUnit == null){
                    Update("NEXT");
                    return;
                }
                List<GO> interceptors = FS.GETTAGGEDUNITS(GS, "ACTION.INTERCEPTING");
                List<GO> defendCaps = FS.GETTAGGEDUNITS(GS, "ACTION.DEFENDING");
                int attackerLosses = GetInt("ACTION.ATTACKERLOSSES");
                int defenderLosses = GetInt("ACTION.DEFENDERLOSSES");
                side = attackerLosses > 0 ? interceptedUnit.SIDE : FS.ENEMY(interceptedUnit.SIDE);
                stepLosses = attackerLosses > 0 ? attackerLosses : defenderLosses;
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "Choose the ENEMY squadrons to apply losses to. You must choose INTs first before other types.\n\n" +
                "When all step losses have been applied, the phase will end.  Any retreats will be carried out automatically at the end of this phase.\n\n" +
                "NOTE: You will be temporarily able to see ENEMY squadrons for rest of this action segment."; 
                List<GO> combatants = new();
                if(side == interceptedUnit.SIDE){
                    interceptors.ForEach(n => combatants.AddRange(FS.GROUPMEMBERS(n)));
                } else {
                    combatants.AddRange(FS.GROUPMEMBERS(interceptedUnit));
                    defendCaps.ForEach(n => combatants.AddRange(FS.GROUPMEMBERS(n)));
                }
                foreach(GO obj in combatants){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(stepLosses == 0 || !GS.InteractionMap.Keys.Any()){
                bool activeSide = side == interceptedUnit.SIDE;
                if(activeSide){
                    GS.advanced = true;
                    SetInt("ACTION.ATTACKERLOSSES", 0);
                    GS.ResetBetweenUpdates();
                    GS.ResetBetweenPhases();
                    Start(true);
                } else {
                    SetInt("ACTION.DEFENDERLOSSES", 0);
                    Update("NEXT");
                }
                return;
            }
            FS.SETINSTRUCTIONS(GS, new(){"RIGHT CLICK UNIT TO APPLY LOSSES: STEPS REMAINING TO SELECT = " + stepLosses});
            bool INTPRESENT = GS.InteractionMap.Keys.Where(n => n.UNITTYPE == "INT").Any();
            foreach(GO obj in GS.InteractionMap.Keys){
                if(obj.UNITTYPE == "INT" || !INTPRESENT){GS.AddAction(obj, "APPLY LOSS");}
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){}
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    SetInt("ACTION.ATTACKERLOSSES", 0);
                    SetInt("ACTION.DEFENDERLOSSES", 0);                    
                    FS.CLEARTAGGED(GS, "ACTION.INTERCEPTED");
                    FS.CLEARTAGGED(GS, "ACTION.INTERCEPTING");
                    FS.CLEARTAGGED(GS, "ACTION.DEFENDING");
                    break;
                case "APPLY LOSS":
                    FS.DAMAGE(gp);
                    stepLosses--;
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionAirCombat : GamePhaseGroupLogic
    {
        public ActionAirCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionGenerateCombats("Calculate", this, GS, "AIR"));
            AddGamePhase(new ActionBOMBCombat("BOMB", this, GS));
            AddGamePhase(new ActionASWCombat("ASW", this, GS));
            AddGamePhase(new ActionSSMCombat("SSM", this, GS));
            AddGamePhase(new ActionCMCombat("CM", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init()
        {
            //throw new NotImplementedException();
        }
        public override void End()
        {
            //apply damages
            foreach(GO obj in GS.PIECES().Where(n => !n.DESTROYED && n.UNAPPLIEDDAMAGE > 0)){
                for(int i = 0; i < obj.UNAPPLIEDDAMAGE; i++){
                    obj.UNAPPLIEDDAMAGE--;
                    FS.DAMAGE(obj);
                }
            }
            foreach(GO obj in GS.LOCATIONS().Where(n => !n.PORTDESTROYED && n.UNAPPLIEDPORTDAMAGE > 0)){
                for(int i = 0; i < obj.UNAPPLIEDPORTDAMAGE; i++){
                    obj.UNAPPLIEDPORTDAMAGE--;
                    FS.DAMAGEBASE(obj, "PORT");
                }
            }
            foreach(GO obj in GS.LOCATIONS().Where(n => !n.AIRFIELDDESTROYED && n.UNAPPLIEDAIRFIELDDAMAGE > 0)){
                int num = obj.UNAPPLIEDAIRFIELDDAMAGE;
                for(int i = 0; i < num; i++){
                    obj.UNAPPLIEDAIRFIELDDAMAGE--;
                    FS.DAMAGEBASE(obj, "AIRFIELD");
                }
            }
        }
    }
    public class ActionAirMovement : GamePhaseLoopLogic
    {
        public ActionAirMovement(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionAirMove("Movement", this, GS));
            AddGamePhase(new ActionAirEnemyInterceptionLoop("CAP INTERCEPT", this, GS));
            AddGamePhase(new ActionAirCombat("AIR COMBAT MISSIONS", this, GS));
        }
        public override Boolean ProcessCheck(){return GetInt("ACTION.AIRHEXES") < 5;}
        public override void Init()
        {
            
        }
        public override void End()
        {
            IncrementInt("ACTION.AIRHEXES", 1);
            FS.CLEARDESTINATIONS(GS);
        }
    }
    public class ActionAirMove : GamePhaseAutomated
    {
        public ActionAirMove(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            //find all activated air units with movements to do
            //move all one hex
            //auto land if needed
            //destroy if out of fuel
            //designate intercepts
            List<GO> checkInterception = new();
            foreach(GO obj in FS.GETTAGGEDUNITS(GS, "ACTION.ACTIVATED").Where(n => n.UNITCATEGORY == "AIR")){
                List<GO> groupMembers = FS.GROUPMEMBERS(obj);
                List<string> past_locations = obj.LOCATIONHISTORY.Split('|').ToList();
                List<string> future_locations = obj.LOCATIONFUTURE.Split('|').ToList();
                if(obj.ENROUTEDELAY > 0){
                    IncrementInt("ACTION.MOVES." + obj.SIDE, 1);
                    groupMembers.ForEach(n => n.ENROUTEDELAY--);
                    obj.ENROUTEDELAY--;
                    groupMembers.ForEach(n => n.MOVEMENTALLOWANCE--);
                    obj.MOVEMENTALLOWANCE--;                
                } else if(future_locations.Count > 1){
                    //get next connector
                    string oldLocId = future_locations[0];
                    GO newLocation = GS.LOCATION(future_locations[1]);
                    GS.CHANGELOCATION(obj, newLocation);
                    IncrementInt("ACTION.MOVES." + obj.SIDE, 1);
                    past_locations.Add(newLocation.ID);
                    future_locations.Remove(oldLocId);
                    GO connector = GS.TYPE("UNITMOVEMENT" , "CONNECTORLOCATIONID", oldLocId).Where(n => n.CONNECTORLOCATION2ID == newLocation.ID).First();
                    int movementCost = Math.Max(connector.DISTANCE, 1);
                    if(movementCost > 1){
                        groupMembers.ForEach(n => n.ENROUTEDELAY = movementCost - 1);
                        obj.ENROUTEDELAY = movementCost - 1;
                    }
                    groupMembers.ForEach(n => n.MOVEMENTALLOWANCE--);
                    obj.MOVEMENTALLOWANCE--;                
                    obj.LOCATIONHISTORY = string.Join('|', past_locations);
                    obj.LOCATIONFUTURE = string.Join('|', future_locations);
                }
                bool oofuel = obj.MOVEMENTALLOWANCE <= 0;
                //drop off any groupmembers that are over their homebase
                if(obj.ENROUTEDELAY == 0){
                    foreach(GO groupMember in groupMembers.Where(n => n.MOVEMENTALLOWANCE >= 0)){
                        GO homebase = groupMember.HOMEBASE;
                        if(homebase.DOMAIN == GO.DOMAIN_LOCATION){
                            if(homebase == obj.GAMELOCATION){
                                GS.CHANGELOCATION(groupMember, homebase);
                                groupMember.HOMEBASEID = null;
                                groupMember.DONE = true;
                                FS.REMOVEFROMGROUP(groupMember, obj);
                                FS.REMOVETAGGED(GS, groupMember);
                            }
                        } else {
                            if(FS.PARENTGROUPLOCATION(homebase) == obj.GAMELOCATION){
                                groupMember.HOMEBASEID = null;
                                groupMember.DONE = true;
                                FS.REMOVEFROMGROUP(groupMember, obj);
                                FS.ADDTOGROUP(groupMember, homebase);                                                
                                FS.REMOVETAGGED(GS, groupMember);
                            }
                        }
                    }
                }
                if(oofuel){
                    List<GO> destroyGOs = groupMembers.Where(n => n.MOVEMENTALLOWANCE <= 0).ToList();
                    if(destroyGOs.Any()){
                        MainWindow.Alert("Air Groups running out of fuel have been eliminated: " + string.Join(',', destroyGOs.Select(n => n.UNITTYPE + " " + n.LABEL)));
                    }
                    foreach(GO groupMember in destroyGOs){
                        FS.REMOVEFROMGROUP(groupMember, obj);
                        FS.DESTROY(groupMember);
                    }
                }
                if(obj.RECYCLED){continue;}
                //check interception
                if(obj.ENROUTEDELAY == 0){
                    checkInterception.Add(obj);
                }
            }
            if(checkInterception.Any()){
                //designate intercepts
                List<GO> INTERCEPTS = GS.TYPE("INTERCEPTION");
                Dictionary<string, List<GO>> CAPTABLE = new();
                foreach(string s in FS.SIDE_NAMES){
                    List<GO> capAir = FS.CAPSQNS(GS, s).Where(n => !n.DONE).ToList();
                    List<GO> intLocations = capAir.Where(n => n.UNITTYPE == "INT").Select(n => n.GAMELOCATION).ToList();
                    CAPTABLE.Add(s, capAir.Where(n => intLocations.Contains(n.GAMELOCATION)).ToList());
                }            
                foreach(GO obj in checkInterception){
                    List<GO> alreadyInterceptedThisUnit = INTERCEPTS.Where(n => n.INTERCEPTEDGRP == obj).Select(n => n.CAP).ToList();
                    List<GO> friendlyRadius = FS.FINDAIRRADIUS(obj.GAMELOCATION, 4);
                    friendlyRadius.Remove(obj.GAMELOCATION);
                    if(CAPTABLE[FS.ENEMY(obj.SIDE)].Where(n => !alreadyInterceptedThisUnit.Contains(n) && friendlyRadius.Contains(n.GAMELOCATION)).Any()){
                        FS.ADDTAGGED(GS, "ACTION.INTERCEPTNEEDED", obj);
                    }
                }
            }
            GS.Advance(this);
        }
    }
    public class ActionAirTacCoordReassignmentLoop : GamePhaseLoopLogic
    {
        public ActionAirTacCoordReassignmentLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionAirTacCoordReassignment("Reassignment", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.GETTAGGEDUNITS(GS, "ACTION.TACCOORDREASSIGN.NEEDED").Any();}
        public override void Init()
        {
            List<GO> objs = FS.GETTAGGEDUNITS(GS, "ACTION.TACCOORDREASSIGN.NEEDED");
            GO obj = objs.First();
            FS.SETTAGGED(GS, "ACTION.TACCOORDREASSIGN", new List<GO>{obj});
            objs.Remove(obj);
            FS.SETTAGGED(GS, "ACTION.TACCOORDREASSIGN.NEEDED", objs);
        }
        public override void End()
        {
        }
    }
    public class ActionAirTacCoordReassignment : GamePhaseInteractive
    {
        GO activatedUnit = null;
        List<GO> TRACKEDSHIPS = new();
        string side = null;
        public ActionAirTacCoordReassignment(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                activatedUnit = FS.GETTAGGEDUNITS(GS, "ACTION.TACCOORDREASSIGN").First();    
                side = activatedUnit.SIDE;       
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"REASSIGN AFTER SPLIT"});

                GS.HELPTEXT = 
                "The units designated by a Tac Coordination air unit have split up.  Choose which surface stack to follow";  
                TRACKEDSHIPS = FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => n.TACCOORDPIECE == activatedUnit).ToList();
                foreach(GO obj in TRACKEDSHIPS){
                    obj.ADMINDETECTED = true;
                    GO parent = FS.LOGICALPARENT(obj);
                    parent.ADMINDETECTED = true;
                    if(!GS.InteractionMap.ContainsKey(obj)){
                        GS.InteractionMap.Add(obj, new());
                    }
                    if(!GS.InteractionMap.ContainsKey(parent)){
                        GS.InteractionMap.Add(parent, new());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "FOLLOW UNITS IN THIS HEX");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    foreach(GO obj in GS.InteractionMap.Keys){
                        obj.ADMINDETECTED = false;
                    }
                    GS.Advance(this);
                    break;
                case "FOLLOW UNITS IN THIS HEX":
                    GO followLocation = FS.PARENTGROUPLOCATION(gp);
                    foreach(GO ship in GS.InteractionMap.Keys.Where(n => FS.PARENTGROUPLOCATION(n) == followLocation)){
                        ship.TACCOORDPIECEID = activatedUnit.ID;
                        ship.TACCOORDPIECE = activatedUnit;
                    }
                    foreach(GO ship in TRACKEDSHIPS.Where(n => FS.PARENTGROUPLOCATION(n) != followLocation)){
                        ship.TACCOORDPIECEID = null;
                    }
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
}