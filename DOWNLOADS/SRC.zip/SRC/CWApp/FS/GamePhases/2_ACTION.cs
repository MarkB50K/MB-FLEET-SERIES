using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Controls;
using System.Reflection.Metadata.Ecma335;
namespace CWApp.FS
{
    public class ActionCycle : GamePhaseGroupLogic
    {
        public ActionCycle(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new CAPAir("Allocate CAP", this, GS));
            AddGamePhase(new ReplenishmentBASE("At-Base Replenishment", this, GS));
            AddGamePhase(new ReplenishmentSEA("At-Sea Replenishment", this, GS));
            AddGamePhase(new LocalDetection("Local Detection", this, GS));
            AddGamePhase(new StrategicAirTacCoordinationLoop("Tactical Coordination", this, GS));
            AddGamePhase(new ActionGroupUnGroup("Pre-Action Phase Group Management", this, GS));
            AddGamePhase(new ActionSurfaceFullSpeed("High Speed", this, GS));
            AddGamePhase(new ActionLoop("Loop", this, GS));
            AddGamePhase(new ActionSurfaceOverstacking("Overstacking", this, GS));
            AddGamePhase(new RemoveLocalDetection("Remove Local Detection", this, GS));
            AddGamePhase(new ActionGroupUnGroup("Post-Action Phase Group Management", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init()
        {
            FS.SIDE_NAMES.ForEach(n => SetBoolean("ACTION." + n, false));
            SetBoolean("ACTION.TACCOORD", false);
        }
        public override void End()
        {
            foreach(GO obj in GS.TYPE("PIECE").Where(n => FS.SIDE_NAMES.Contains(n.SIDE))){
                obj.ACTIVATED = false;
                obj.DONE = false;
                obj.REPLENISHING = false;
                obj.ACTIVATEDAIRUNITS = 0;
                obj.LOCATIONHISTORY = null;
                if(!FS.ISGROUP(obj) && obj.UNITCATEGORY != "SUB"){
                    obj.LOCATIONFUTURE = null;
                }
                obj.NUMCOMBATS = 0; 
                obj.DONEASW = false;
                obj.DONESSM = false;
                obj.DONECM = false;
                obj.ADMINDETECTED = false;
                obj.ROLE = null;
                //reset movement allowance
                obj.MOVEMENTALLOWANCE = obj.OUTOFFUEL || obj.DEEPMODE ? 1 : obj.TEMPLATE != null ? obj.TEMPLATE.MOVEMENTALLOWANCE : 0;
                obj.USEDFUEL = obj.USEDFUEL || obj.HEXESTRAVELLED > 2;
                obj.HEXESTRAVELLED = 0;
                obj.ATTACKEDBYAIR = false;
                obj.ATTACKEDBYSURFACE = false; 
                obj.DETECTIONATTEMPTED = false;
                obj.TACCOORDPIECEID = null;           
            }
            GS.TYPE("INTERCEPTION").ForEach(FS.DISCARDLOGIC);
            GS.TYPE("COMBAT").ForEach(FS.DISCARDLOGIC);
            string report = "";
            foreach(GO obj in FS.CAPSQNS(GS, null)){
                obj.AIRMISSION = null;
                FS.RETURNTOHOMEBASE(obj);
                if(obj.DESTROYED){
                    report += obj.UNITTYPE + " " + obj.LABEL + " destroyed due to destroyed carrier\n";
                }
            }
            if(report != ""){
                MainWindow.Alert(report);
            }
        }
    }
    public class CAPAir : GamePhaseInteractive
    {
        string side = null;
        List<GO> ELIGIBLELIST = new();
        List<GO> CAPMISSIONS = new();
        public CAPAir(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                CAPMISSIONS.Clear();
                ELIGIBLELIST.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"ASSIGN AIR UNITS TO CAP"});
                GS.HELPTEXT = 
                "Allocate Air Units to CAP to the current Hex.  The game will enforce max 4 INT per airfield or carrier.\n\n" +
                "When done with your setup you can click the NEXT button.\n\n" +
                "NOTE: Due to complexity issues, this game will not use CAP markers.  The game will track all the units on CAP and consider all units in the same hex as on the same mission.  " + 
                "The physical game, using a marker to keep track of attacks left alot of loopholes when carriers are on the move and markers are breaking up and combining, so attacks are tracked per squadron, " + 
                "and the max number of attacks for a squadron in a stack is considered the stacks number.  Carrier based CAP squadrons will follow the ships as they move in the automated cycles";                
                foreach(GO obj in FS.TYPESIDE(GS, "SQN", side)){
                    if(!FS.CANLAUNCHCAP(GS, obj)){continue;}
                    GS.InteractionMap.Add(obj, new());
                    ELIGIBLELIST.Add(obj);
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.AIRMISSION == null){
                    GS.AddAction(obj, "ASSIGN TO CAP");
                } else {
                    GS.AddAction(obj, "UNDO");
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        private void ADDTOCAP(GO gp, GO presentLoc){
            if(gp.CARRIERID != null){
                //if homebase is carrier, and carrier is damaged, move all other air units out of IM
                if(gp.CARRIER.DAMAGED){
                    foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.CARRIER)){
                        GS.REMOVEINTERACTIVE(obj);
                    }
                }
                gp.HOMEBASEID = gp.CARRIERID;
                gp.HOMEBASE = gp.CARRIER;
                FS.REMOVEFROMGROUP(gp, gp.HOMEBASE);
            } else if(gp.HOMEBASEID == null){
                gp.HOMEBASEID = gp.GAMELOCATIONID;
                gp.HOMEBASE = gp.GAMELOCATION;
            }
            GS.CHANGELOCATION(gp, presentLoc);
            CAPMISSIONS.Add(gp);
            gp.AIRMISSION = "CAP";
            //if 4 INT from homebase are in this group, move all other air units out of IM
            if(CAPMISSIONS.Where(n => n.UNITTYPE == "INT" && n.HOMEBASE == gp.HOMEBASE).Count() == 4){
                foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.HOMEBASE && n.UNITTYPE == "INT")){
                    GS.REMOVEINTERACTIVE(obj);
                }
            }
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case "UNDO":
                    CAPMISSIONS.Remove(gp);
                    GO homeBase = gp.HOMEBASE;
                    if(homeBase != gp.GAMELOCATION){
                        //if homebase is carrier, and carrier is damaged, move all other air units back to interaction map
                        if(gp.HOMEBASE.DAMAGED){
                            foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.HOMEBASE)){
                                GS.InteractionMap.Add(obj, new());
                            }
                        //if now 3 INT from homebase are in this group, move all other air units back to IM
                        } else if(gp.UNITTYPE == "INT" && CAPMISSIONS.Where(n => n.UNITTYPE == "INT" && n.HOMEBASE == gp.HOMEBASE).Count() == 3){
                            foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.HOMEBASE && n.UNITTYPE == "INT")){
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                        FS.ADDTOGROUP(gp, homeBase);
                    }                    
                    gp.HOMEBASEID = null;
                    gp.AIRMISSION = null;
                    Start(false);
                    break;
                case "ASSIGN TO CAP":
                    GO presentLoc = FS.PARENTGROUPLOCATION(gp);
                    ADDTOCAP(gp, presentLoc);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ReplenishmentBASE : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, List<GO>> PORTREPLENISHMENTASSIGNMENTS = new();
        Dictionary<GO, List<GO>> AIRFIELDREPLENISHMENTASSIGNMENTS = new();
        public ReplenishmentBASE(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                PORTREPLENISHMENTASSIGNMENTS.Clear();
                AIRFIELDREPLENISHMENTASSIGNMENTS.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"REPLENISH AT BASE"});
                GS.HELPTEXT = 
                "Replenishment, in-port.  The game enforces rules below:\n" + 
                "- Only docked ships can replenish\n" +
                "- Weather impacts.  No at-base replenishment in storm\n" +
                "- Max 4 ships can replenish at base per turn (max 1 CV or replenishment ship)\n" +
                "- CVs can replenish AIR SSM pts from port\n" +
                "- Damaged bases cannot replenish\n\n" +
                "NOTE: A configuration variable in the scenario file can be used to set when Cruise Missile reloads are available.  Every n turns, etc.\n" +
                "NOTE: Units giving or receiving replenishment will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Bases.                
                foreach(GO loc in FS.TYPESIDE(GS, "LOCATION", side).Where(n => (n.PORT || n.LOGSEA) && n.PORTDAMAGELEVEL == 0 && !FS.STORM(n))){
                    PORTREPLENISHMENTASSIGNMENTS.Add(loc, new());
                }
                //add airfields if CM reloads
                if(GetInt("CMRELOADS") > 0){
                    foreach(GO loc in FS.TYPESIDE(GS, "LOCATION", side).Where(n => (n.AIRFIELD || n.LOGAIR) && n.AIRFIELDDAMAGELEVEL == 0 && !FS.STORM(n))){
                        AIRFIELDREPLENISHMENTASSIGNMENTS.Add(loc, new());
                    }                
                    foreach(GO obj in FS.TYPESIDE(GS, "SQN", side).Where(n => n.ENROUTEDELAY == 0 &&
                        n.AIRMISSION == null &&
                        n.CMPTS < n.TEMPLATE.CMPTS)){
                        GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                        if(AIRFIELDREPLENISHMENTASSIGNMENTS.ContainsKey(locationToCheck)){
                            AIRFIELDREPLENISHMENTASSIGNMENTS[locationToCheck].Add(obj);
                            GS.InteractionMap.Add(obj, new());
                        }
                    }
                }                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.DOCKED && n.ENROUTEDELAY == 0)){
                    if(obj.UNITCATEGORY == "SUB"){
                        if(PORTREPLENISHMENTASSIGNMENTS.ContainsKey(obj.GAMELOCATION)){
                            if( obj.SSMPTS < obj.TEMPLATE.SSMPTS ||
                                obj.SSM2PTS < obj.TEMPLATE.SSM2PTS ||
                                obj.TORPPTS < obj.TEMPLATE.TORPPTS ||
                                (obj.CMPTS < obj.TEMPLATE.CMPTS && obj.CMRELOADS < GetInt("CMRELOADS"))){

                                PORTREPLENISHMENTASSIGNMENTS[obj.GAMELOCATION].Add(obj);
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    } else { 
                        GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                        if(PORTREPLENISHMENTASSIGNMENTS.ContainsKey(locationToCheck)){
                            if( obj.FUELPTS < obj.TEMPLATE.FUELPTS ||
                                obj.SSMPTS < obj.TEMPLATE.SSMPTS ||
                                obj.SSM2PTS < obj.TEMPLATE.SSM2PTS ||
                                obj.ASWPTS < obj.TEMPLATE.ASWPTS ||
                                obj.AAPTS < obj.TEMPLATE.AAPTS ||
                                obj.BOMBPTS < obj.TEMPLATE.BOMBPTS ||
                                obj.AIRSSMPTS < obj.TEMPLATE.AIRSSMPTS ||
                                obj.APTS < obj.TEMPLATE.APTS ||
                                obj.FPTS < obj.TEMPLATE.FPTS ||
                                (obj.CMPTS < obj.TEMPLATE.CMPTS && obj.CMRELOADS < GetInt("CMRELOADS"))){
                                
                                PORTREPLENISHMENTASSIGNMENTS[locationToCheck].Add(obj);
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    }
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys.ToList()){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "REPLENISH");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    foreach(GO loc in AIRFIELDREPLENISHMENTASSIGNMENTS.Keys){
                        loc.REPLENISHMENTPTSUSED = 0;
                        loc.LARGEUNITREPLENISHED = false;
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case "REPLENISH":
                    GO replenishmentBase = FS.PARENTGROUPLOCATION(gp);
                    replenishmentBase.REPLENISHMENTPTSUSED++;
                    gp.REPLENISHING = true;
                    if(gp.UNITCATEGORY == "AIR"){
                        int numCM = Math.Min(GetInt("CMRELOADS") - gp.CMPTS, gp.TEMPLATE.CMPTS);
                        gp.CMPTS += numCM;
                        gp.CMRELOADS += numCM;
                        //once we reach 4 no more from this base
                        if(replenishmentBase.REPLENISHMENTPTSUSED == 4){
                            foreach(GO obj in AIRFIELDREPLENISHMENTASSIGNMENTS[replenishmentBase].Where(n => n != gp)){
                                GS.REMOVEINTERACTIVE(obj);
                            }
                        }
                        GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    } else {
                        if(gp.TEMPLATE.APTS > 0 || gp.TEMPLATE.FPTS > 0){replenishmentBase.LARGEUNITREPLENISHED = true;}
                        int numCM = Math.Min(GetInt("CMRELOADS") - gp.CMPTS, gp.TEMPLATE.CMPTS);
                        gp.CMPTS += numCM;
                        gp.CMRELOADS += numCM;
                        gp.FUELPTS = gp.TEMPLATE.FUELPTS;
                        gp.SSMPTS = gp.TEMPLATE.SSMPTS;
                        gp.SSM2PTS = gp.TEMPLATE.SSM2PTS;
                        gp.ASWPTS = gp.TEMPLATE.ASWPTS;
                        gp.AAPTS = gp.TEMPLATE.AAPTS;
                        gp.TORPPTS = gp.TEMPLATE.TORPPTS;
                        gp.BOMBPTS = gp.TEMPLATE.BOMBPTS;
                        gp.AIRSSMPTS = gp.TEMPLATE.AIRSSMPTS;
                        gp.APTS = gp.TEMPLATE.APTS;
                        gp.FPTS = gp.TEMPLATE.FPTS;
                        //once we do a large no more large from this base
                        if(replenishmentBase.LARGEUNITREPLENISHED){
                            foreach(GO obj in PORTREPLENISHMENTASSIGNMENTS[replenishmentBase].Where(n => n != gp && (n.TEMPLATE.APTS > 0 || n.TEMPLATE.FPTS > 0))){
                                GS.REMOVEINTERACTIVE(obj);
                            }
                        }
                        //once we reach 4 no more from this base
                        if(replenishmentBase.REPLENISHMENTPTSUSED == 4){
                            foreach(GO obj in PORTREPLENISHMENTASSIGNMENTS[replenishmentBase].Where(n => n != gp)){
                                GS.REMOVEINTERACTIVE(obj);
                            }
                        }
                        GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                        //replenishing ships are not part of any TF/TG
                        if(gp.GROUP != null){
                            GS.CHANGELOCATION(gp, gp.GROUP.GAMELOCATION);
                            FS.REMOVEFROMGROUP(gp, gp.GROUP);
                        }                        
                    }
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ReplenishmentSEA : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, List<GO>> FUELREPLENISHMENTASSIGNMENTS = new();
        Dictionary<GO, List<GO>> AMMOREPLENISHMENTASSIGNMENTS = new();
        public ReplenishmentSEA(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FUELREPLENISHMENTASSIGNMENTS.Clear();
                AMMOREPLENISHMENTASSIGNMENTS.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE REPLENISHMENT OPTIONS"});
                GS.HELPTEXT = 
                "Replenishment, at-sea.  The game enforces rules below:\n" + 
                "- If a ship can replenish a certain type of ammo at-sea\n" +
                "- Weather impacts.  No at-sea in squall.\n" +
                "- Max total of 6 AP/FP pts a replenishment ship can provide in one phase.\n" +
                "- Use of BBs and US CVs as oilers\n" +
                "- Subs cannot replenish at sea.\n\n" +
                "NOTE: Units giving or receiving replenishment will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Ships.                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.ENROUTEDELAY == 0 && !n.DOCKED && !n.REPLENISHING && Get(n.GAMELOCATION.ZONE + ".WEATHER") == "CLEAR" &&
                    (n.FPTS > 0 || n.APTS > 0))){
                        
                    if(obj.FPTS > 0){
                        FUELREPLENISHMENTASSIGNMENTS.Add(obj, new());
                    }
                    if(obj.APTS > 0){
                        AMMOREPLENISHMENTASSIGNMENTS.Add(obj, new());
                    }
                }
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n =>n.UNITCATEGORY == "SURFACE" && n.ENROUTEDELAY == 0 && !n.DOCKED && !n.REPLENISHING)){
                    GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                    foreach(GO replenishment in FUELREPLENISHMENTASSIGNMENTS.Keys.Where(n => FS.PARENTGROUPLOCATION(n) == locationToCheck)){                                
                        if( (obj.FUELPTS < obj.TEMPLATE.FUELPTS && replenishment.FPTS > 0) ||
                            (obj.FPTS < obj.TEMPLATE.FPTS && replenishment.FPTS > 0)){
                            
                            FUELREPLENISHMENTASSIGNMENTS[replenishment].Add(obj);
                            if(!GS.InteractionMap.ContainsKey(obj)){
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    }
                    foreach(GO replenishment in AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => FS.PARENTGROUPLOCATION(n) == locationToCheck)){                                
                        if( (!obj.TEMPLATE.SSMPORTONLY && obj.SSMPTS < obj.TEMPLATE.SSMPTS && replenishment.APTS > 0) ||
                            (!obj.TEMPLATE.SSM2PORTONLY && obj.SSM2PTS < obj.TEMPLATE.SSM2PTS && replenishment.APTS > 0) ||
                            (obj.ASWPTS < obj.TEMPLATE.ASWPTS && replenishment.APTS > 0) ||
                            (obj.AAPTS < obj.TEMPLATE.AAPTS && replenishment.APTS > 0) ||
                            (obj.BOMBPTS < obj.TEMPLATE.BOMBPTS && replenishment.APTS > 0) ||
                            (obj.AIRSSMPTS < obj.TEMPLATE.AIRSSMPTS && replenishment.APTS > 0) ||
                            (obj.APTS < obj.TEMPLATE.APTS && replenishment.APTS > 0)){
                            
                            AMMOREPLENISHMENTASSIGNMENTS[replenishment].Add(obj);
                            if(!GS.InteractionMap.ContainsKey(obj)){
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    }
                }
            }
            //for FP, can replenish all FUELPTS on a single ship
            //for FP, can replenish one FPT on a single ship
            //for AP, can replenish all non BOMB ammo
            //for AP, can replenish 1 BOMB pt
            //for AP, can replenish 1 AP pt 
            foreach(GO obj in GS.InteractionMap.Keys.ToList()){
                //check if obj is still in any assignment group
                Boolean presentInGroup = false;
                foreach(GO replenishment in FUELREPLENISHMENTASSIGNMENTS.Keys.Where(n => FUELREPLENISHMENTASSIGNMENTS[n].Contains(obj))){
                    presentInGroup = true;

                    GS.AddAction(obj, "FUEL/FP FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                }                    
                foreach(GO replenishment in AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => AMMOREPLENISHMENTASSIGNMENTS[n].Contains(obj))){
                    presentInGroup = true;
                    if( (!obj.TEMPLATE.SSMPORTONLY && obj.SSMPTS < obj.TEMPLATE.SSMPTS && replenishment.APTS > 0) ||
                        (!obj.TEMPLATE.SSM2PORTONLY && obj.SSM2PTS < obj.TEMPLATE.SSM2PTS && replenishment.APTS > 0) ||
                        (obj.ASWPTS < obj.TEMPLATE.ASWPTS && replenishment.APTS > 0) ||
                        (obj.AAPTS < obj.TEMPLATE.AAPTS && replenishment.APTS > 0) ||
                        (obj.AIRSSMPTS < obj.TEMPLATE.AIRSSMPTS && replenishment.APTS > 0)){

                        GS.AddAction(obj, "AMMO FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                    }

                    if( obj.BOMBPTS < obj.TEMPLATE.BOMBPTS && replenishment.APTS > 0){
                        GS.AddAction(obj, "1 BOMB PT FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                    }
                    if( obj.APTS < obj.TEMPLATE.APTS && replenishment.APTS > 0){
                        GS.AddAction(obj, "1 AP FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                    }
                }                    
                if(!presentInGroup){
                    GS.InteractionMap.Remove(obj);
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case null:
                    Start(false);
                    break;
                case "NEXT":
                    foreach(GO obj in FUELREPLENISHMENTASSIGNMENTS.Keys){
                        obj.REPLENISHMENTPTSUSED = 0;
                    }
                    foreach(GO obj in AMMOREPLENISHMENTASSIGNMENTS.Keys){
                        obj.REPLENISHMENTPTSUSED = 0;
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                default:
                    gp.REPLENISHING = true;
                    string rID = null;
                    GO replenishmentShip = null;
                    if(pData.StartsWith("FUEL/FP FROM : ")){
                        rID = pData.Replace("FUEL/FP FROM : ", "");
                        replenishmentShip = FUELREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            FUELREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        if(gp.TEMPLATE.FPTS > 0){
                            gp.FPTS++;
                        } else {
                            gp.FUELPTS = gp.TEMPLATE.FUELPTS;
                        }
                        replenishmentShip.FPTS--;
                    } else if(pData.StartsWith("AMMO FROM : ")){
                        rID = pData.Replace("AMMO FROM : ", "");
                        replenishmentShip = AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            AMMOREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        if(!gp.TEMPLATE.SSMPORTONLY){
                            gp.SSMPTS = gp.TEMPLATE.SSMPTS;
                        }
                        if(!gp.TEMPLATE.SSM2PORTONLY){
                            gp.SSM2PTS = gp.TEMPLATE.SSM2PTS;
                        }
                        gp.ASWPTS = gp.TEMPLATE.ASWPTS;
                        gp.AAPTS = gp.TEMPLATE.AAPTS;
                        gp.AIRSSMPTS = gp.TEMPLATE.AIRSSMPTS;
                        replenishmentShip.APTS--;
                    } else if(pData.StartsWith("1 BOMB PT FROM : ")){
                        rID = pData.Replace("1 BOMB PT FROM : ", "");
                        replenishmentShip = AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            AMMOREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        gp.BOMBPTS++;
                        replenishmentShip.APTS--;
                    } else if(pData.StartsWith("1 AP FROM : ")){
                        rID = pData.Replace("1 AP FROM : ", "");
                        replenishmentShip = AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            AMMOREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        gp.APTS++;
                        replenishmentShip.APTS--;
                    }
                    if(AMMOREPLENISHMENTASSIGNMENTS.ContainsKey(replenishmentShip) && (replenishmentShip.APTS == 0 || replenishmentShip.REPLENISHMENTPTSUSED == 6)){
                        AMMOREPLENISHMENTASSIGNMENTS[replenishmentShip].Clear();
                    }
                    if(FUELREPLENISHMENTASSIGNMENTS.ContainsKey(replenishmentShip) && (replenishmentShip.FPTS == 0 || replenishmentShip.REPLENISHMENTPTSUSED == 6)){
                        FUELREPLENISHMENTASSIGNMENTS[replenishmentShip].Clear();
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    //replenishing ships are not part of any TF/TG
                    if(gp.GROUP != null){
                        GS.CHANGELOCATION(gp, gp.GROUP.GAMELOCATION);
                        FS.REMOVEFROMGROUP(gp, gp.GROUP);
                    }                        
                    if(replenishmentShip.GROUP != null){
                        GS.CHANGELOCATION(replenishmentShip, replenishmentShip.GROUP.GAMELOCATION);
                        FS.REMOVEFROMGROUP(replenishmentShip, replenishmentShip.GROUP);
                    }                        
                    Start(false);
                    break;
            }
        }
    }
    public class LocalDetection : GamePhaseAutomated
    {
        public LocalDetection(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            Dictionary<GO, List<List<GO>>> DetectionRadius = FS.DETECTIONRADIUSTABLE(GS);
            //now detect
            foreach(GO obj in DetectionRadius.Keys){
                if(obj.LOCALDETECTED){continue;}
                GO loc = FS.PARENTGROUPLOCATION(obj);
                if(obj.UNITCATEGORY == "SURFACE"){
                    if(DetectionRadius.Keys.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Where(n => DetectionRadius[n][0].Contains(loc)).Any()){
                        FS.LOCALDETECT(FS.ALLSHIPSINHEX(obj.SIDE, loc, true, false), true);
                    }
                } else {
                    List<GO> detectors = DetectionRadius.Keys.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Where(n => DetectionRadius[n][1].Contains(loc)).ToList();
                    if(detectors.Sum(n => n.TEMPLATE.ASW) >= 6){
                        if(FS.SUBDETECTIONRESULT(obj, "LOCALDETECT", null, detectors) == "D"){
                            FS.LOCALDETECT(new(){obj}, true);
                        }
                    }
                }
            }
            GS.Advance(this);
        }
    }
    public class StrategicAirTacCoordinationLoop : GamePhaseLoop
    {
        public StrategicAirTacCoordinationLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new StrategicAirTacCoordination("Assignment", this, GS));
            AddGamePhase(new StrategicAirTacCoordinationChoice("Choose Target", this, GS));
            
        }
        public override Boolean ProcessCheck(){return !GetBoolean("ACTION.TACCOORD");}
    }
    public class StrategicAirTacCoordination : GamePhaseInteractive
    {
        string side = null;
        public StrategicAirTacCoordination(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            DragDrop = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG AIR UNIT TO TARGET HEX"});

                GS.HELPTEXT = 
                "Perform tactical coordination missions.  In this phase, drag eligible air units to detected enemy surface stacks or individual submarines in the aircraft's zone.\n\n" + 
                "For subs, the mission will be limited to a single sub, and the game will ask you to choose which sub, if there are multiple in the hex.\n" + 
                "-To assign to a submarine, the aircraft to have an ASW factor > 0\n" + 
                "-Enemy units within 4 hexes of friendly INT on non-damaged airfield will not be selectable\n\n" +
                "NOTE: After assigning the aircraft to a mission, instead of the air unit following the enemy around, the enemy units will have a black indicator on the left side of the marker to show the unit is the target of a tac coord mission.\n" +
                "NOTE: When selecting a unit, available locations on the map will have an indicator."; 
                List<GO> missionSQNs = FS.TYPESIDE(GS, "SQN", side).Where(n => n.GAMELOCATION.AIRMISSION == "STRATTACCOORD").ToList();
                List<string> missionZones = missionSQNs.Select(n => n.GAMELOCATION.ZONE).Distinct().ToList();
                //detected enemy
                List<GO> detectedEnemy = FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => (n.STRATDETECTED || n.LOCALDETECTED) && n.TACCOORDPIECEID == null).ToList();
                List<GO> missionLocs = detectedEnemy.Select(n => n.GAMELOCATION).Where(n => missionZones.Contains(n.ZONE)).Distinct().ToList();
                List<GO> missionLocsNoASW = detectedEnemy.Where(n => n.UNITCATEGORY == "SURFACE").Select(n => n.GAMELOCATION).Where(n => missionZones.Contains(n.ZONE)).Distinct().ToList();
                //find INTs on non-damaged airfields 
                List<GO> enemyINTLocations = new(); 
                foreach(GO obj in FS.TYPESIDE(GS, "SQN", FS.ENEMY(side)).Where(n =>
                n.UNITTYPE == "INT" && 
                n.ENROUTEDELAY == 0 &&
                (n.GAMELOCATION.AIRFIELD || n.HOMEBASE?.AIRFIELD == true) &&
                !(n.GAMELOCATION.AIRFIELDDAMAGELEVEL > 0 || n.HOMEBASE?.AIRFIELDDAMAGELEVEL > 0))){
                    enemyINTLocations.Add(FS.PARENTGROUPLOCATION(obj));
                }
                enemyINTLocations = enemyINTLocations.Distinct().ToList();
                foreach(GO loc in missionLocs.ToList()){
                    if(FS.FINDAIRRADIUS(loc, 4).Intersect(enemyINTLocations).Any()){
                        missionLocs.Remove(loc);
                        missionLocsNoASW.Remove(loc);
                    }
                }
                foreach(GO obj in missionSQNs){
                    if(obj.TEMPLATE.ASW > 0){
                        GS.InteractionMap.Add(obj, missionLocs.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList());
                    } else {
                        GS.InteractionMap.Add(obj, missionLocsNoASW.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(side != Get("SIDE1")){SetBoolean("ACTION.TACCOORD", true);}
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, GS.TYPE("STRATRTBLOCATION", "ZONE", oldloc.ZONE).Single());
                        GO newloc = GS.LOCATION(gp.TEMPLOCATIONID);
                        Set("ACTION.TACCOORD.LOCATION", newloc.ID);
                        Set("ACTION.TACCOORD.UNIT", gp.ID);
                        GS.Advance(this);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class StrategicAirTacCoordinationChoice : GamePhaseInteractive
    {
        GO activatedUnit = null;
        string side = null;
        public StrategicAirTacCoordinationChoice(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                string activatedUnitId = Get("ACTION.TACCOORD.UNIT");
                if(activatedUnitId == null){
                    Update("NEXT");
                    return;
                }
                activatedUnit = GS.PIECE(activatedUnitId);              
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE TARGET"});

                GS.HELPTEXT = 
                "Choose which marker to assign the Tac Coordination air unit to.  Submarines are tracked individually.  Surface are tracked per hex, so all will be assigned.";  
                //detected enemy
                List<GO> detectedEnemy = FS.TYPESIDELOCATION(GS, "SHIP", FS.ENEMY(side), Get("ACTION.TACCOORD.LOCATION")).Where(n => (n.STRATDETECTED || n.LOCALDETECTED) && n.TACCOORDPIECE == null).ToList();
                List<GO> surfaceChoices = detectedEnemy.Where(n => n.UNITCATEGORY == "SURFACE").ToList();
                List<GO> subChoices = activatedUnit.TEMPLATE.ASW > 0 ? detectedEnemy.Where(n => n.UNITCATEGORY == "SUB").ToList() : new();

                if(surfaceChoices.Any() && !subChoices.Any()){
                    foreach(GO ship in surfaceChoices){
                        ship.TACCOORDPIECEID = activatedUnit.ID;
                        ship.TACCOORDPIECE = activatedUnit;
                        if(FS.ISGROUP(ship)){
                            foreach(GO ship2 in FS.GROUPMEMBERS(ship)){
                                ship2.TACCOORDPIECEID = activatedUnit.ID;
                                ship2.TACCOORDPIECE = activatedUnit;
                            }
                        }
                    }
                } else if(!surfaceChoices.Any() && subChoices.Count == 1){
                    GO ship = subChoices.First();
                    ship.TACCOORDPIECEID = activatedUnit.ID;
                    ship.TACCOORDPIECE = activatedUnit;
                } else {
                    foreach(GO ship in surfaceChoices){
                        GS.InteractionMap.Add(ship, new());
                    }
                    foreach(GO ship in subChoices){
                        GS.InteractionMap.Add(ship, new());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.UNITCATEGORY == "SUB"){
                    GS.AddAction(obj, "ASSIGN TO THIS SUB");
                } else {
                    GS.AddAction(obj, "ASSIGN TO ALL SURFACE UNITS IN THIS HEX");
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    Set("ACTION.TACCOORD.UNIT", null);
                    Set("ACTION.TACCOORD.LOCATION", null);
                    if(activatedUnit != null){
                        GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", activatedUnit.GAMELOCATION.ZONE).Single();
                        GS.CHANGELOCATION(activatedUnit, RTBLocation);
                    }
                    GS.Advance(this);
                    break;
                case "ASSIGN TO THIS SUB":
                    gp.TACCOORDPIECEID = activatedUnit.ID;
                    gp.TACCOORDPIECE = activatedUnit;
                    Update("NEXT");
                    break;
                case "ASSIGN TO ALL SURFACE UNITS IN THIS HEX":
                    foreach(GO ship in GS.InteractionMap.Keys.Where(n => n.UNITCATEGORY == "SURFACE")){
                        ship.TACCOORDPIECEID = activatedUnit.ID;
                        ship.TACCOORDPIECE = activatedUnit;
                        if(FS.ISGROUP(ship)){
                            foreach(GO ship2 in FS.GROUPMEMBERS(ship)){
                                ship2.TACCOORDPIECEID = activatedUnit.ID;
                                ship2.TACCOORDPIECE = activatedUnit;
                            }
                        }
                    }
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionGroupUnGroup : GamePhaseInteractive
    {
        string side = null;
        public ActionGroupUnGroup(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                FS.ADMIN = true;
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"MANAGE TF/TGs"});
                GS.HELPTEXT = 
                "This phase is your opportunity to combine, disband, and create TF/TGs\n\n" + 
                "- Units cannot be moved outside of their hex.\n" +
                "- Docked units cannot be merged with Un-docked units.\n" +
                "When done with your setup you can click the NEXT button";                
                foreach(GO unit in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.UNITCATEGORY == "SURFACE" && FS.CANSHIPACTIVATE(GS, n))){
                    GS.InteractionMap.Add(unit, new());
                }
            }
            List<GO> SHIPTRAYLOCATIONS = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", FS.GRPSHEET.ID).Where(n => n.XCOORD < n.PARENTSHEET.IMAGEWIDTH && n.YCOORD < n.PARENTSHEET.IMAGEHEIGHT).ToList();
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                List<GO> targets = GS.InteractionMap[obj];
                targets.Clear();
                if(FS.ISGROUP(obj)){
                    GS.AddAction(obj, "DISBAND");
                } else {
                    targets.AddRange(SHIPTRAYLOCATIONS.Where(n => n.PARENTSHEET.SHEETPARENTPIECE?.GAMELOCATION == FS.PARENTGROUPLOCATION(obj) && n.PARENTSHEET.SHEETPARENTPIECE?.DOCKED == obj.DOCKED));
                    if(obj.GROUPID != null){
                        targets.Add(FS.PARENTGROUPLOCATION(obj));
                        GS.AddAction(obj, "LEAVE TF/TG");
                    } else {
                        GS.AddAction(obj, "CREATE TF/TG");
                    }
                }                                     

            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "CREATE TF/TG":
                    GO createdTG = FS.CREATEGROUP(GS, gp, gp.GAMELOCATIONID);
                    GS.InteractionMap.Add(createdTG, new());
                    createdTG.DOCKED = gp.DOCKED;
                    Start(false);
                    break;
                case "DISBAND":
                    GO firstMember = GS.TYPE(gp.TYPE, "GROUPID", gp.ID).FirstOrDefault();
                    FS.GROUPMEMBERS(gp).ForEach(n => GS.CHANGELOCATION(n, gp.GAMELOCATION));
                    FS.REMOVEGROUP(gp);
                    GS.REMOVEINTERACTIVE(gp);
                    if(firstMember != null){GS.SelectedMarker = firstMember;}
                    Start(false);
                    break;
                case "LEAVE TF/TG":
                    GS.CHANGELOCATION(gp, FS.PARENTGROUPLOCATION(gp));
                    FS.REMOVEFROMGROUP(gp, gp.GROUP);
                    Start(false);
                    break;
                case "NEXT":
                    FS.ADMIN = false;
                    foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.GRPTYPE == "TFTGGRP")){
                        FS.UPDATEGROUP(obj);
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        GO newloc = gp.GAMELOCATION;                        
                        if(oldloc.TYPE != "TRAYLOCATION" && newloc.TYPE == "TRAYLOCATION"){
                            GO newsheet = newloc.PARENTSHEET;
                            GO newgroup = newsheet.SHEETPARENTPIECE;
                            FS.ADDTOGROUP(gp, newgroup);
                        } else if(oldloc.TYPE == "TRAYLOCATION" && newloc.TYPE != "TRAYLOCATION"){
                            gp.PARENTSHEETID = null;
                            GO oldsheet = oldloc.PARENTSHEET;
                            GO oldgroup = oldsheet.SHEETPARENTPIECE;
                            FS.REMOVEFROMGROUP(gp, oldgroup);
                        } else if(oldloc.TYPE == "TRAYLOCATION" && newloc.TYPE == "TRAYLOCATION" && newloc.PARENTSHEET == FS.GRPSHEET){
                            GO newsheet = newloc.PARENTSHEET;
                            List<GO> grouptraylocations = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", newsheet.ID);
                            int oldindex = grouptraylocations.IndexOf(oldloc);
                            int newindex = grouptraylocations.IndexOf(newloc);
                            for(int i = 0; i < Math.Abs(oldindex - newindex); i++){
                                if(oldindex < newindex){
                                    FS.MOVEDOWNINGROUP(GS, gp, gp.GROUP);
                                } else {
                                    FS.MOVEUPINGROUP(GS, gp, gp.GROUP);
                                }
                            }
                        }
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionLoop : GamePhaseLoopLogic
    {
        public ActionLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionActivation("ACTIVATION", this, GS));
            AddGamePhase(new ActionAirEnemyInterceptionLoop("CAP INTERCEPT", this, GS));
            AddGamePhase(new ActionCombined("COMBINED ORDERS", this, GS));
            AddGamePhase(new ActionAirMovement("1st AIR", this, GS));
            AddGamePhase(new ActionShipMovement("SHIP", this, GS));
            AddGamePhase(new ActionAir("AIR ORDERS", this, GS));
            AddGamePhase(new ActionAirMovement("2nd AIR", this, GS));            
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION." + n)).Any();}
        public override void Init()
        {
            foreach(string s in FS.SIDE_NAMES){
                SetBoolean("ACTION.ACTIVATION." + s, false);
                SetInt("ACTION.MOVES." + s, 0);
                SetInt("ACTION.COMBATS." + s, 0);
            }
        }
        public override void End()
        {
            foreach(GO obj in GS.PIECES().Where(n => n.ADMINDETECTED && (n.HOMEBASE?.TYPE == "SHIP" || n.CARRIER != null))){
                obj.ADMINDETECTED = false;
            }
            foreach(string s in FS.SIDE_NAMES){
                int numMoves = GetInt("ACTION.MOVES." + s);
                int numCombats = GetInt("ACTION.COMBATS." + s);
                GS.SetBoolean("ACTION." + s, numMoves == 0 && numCombats == 0);
            }
            if(!FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION." + n)).Any()){
                //remove any activation groups that may remain
                foreach(string s in FS.SIDE_NAMES){
                    foreach(GO group in FS.ACTIVATIONMARKERS(GS, s)){
                        FS.GROUPMEMBERS(group).ForEach(n => GS.CHANGELOCATION(n, group.GAMELOCATION));
                        FS.REMOVEGROUP(group);
                    }
                }
            }
        }
    }
    public class ActionActivation : GamePhaseLoop
    {
        public ActionActivation(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionActivationLoop("Loop", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION.ACTIVATION." + n)).Any();}
        public override void Init(){}
        public override void End()
        {
            string side = Get("ACTIVE.SIDE");
            if(side == GS.Get("SIDE1")){
                Set("ACTIVE.SIDE", FS.ENEMY(side));
            } else {
                Set("SIDE1", side);
                List<GO> alreadyActivated = FS.GETTAGGEDUNITS(GS, "ACTION.ACTIVATED");
                List<GO> activated = GS.PIECES().Where(n => n.ACTIVATED && !n.DONE && (FS.ISGROUP(n) || n.UNITCATEGORY == "SUB")).ToList();
                FS.SETTAGGED(GS, "ACTION.ACTIVATED", activated);
                List<GO> checkInterception = activated.Where(n => !alreadyActivated.Contains(n) && n.TYPE == "SQN").ToList();
                if(checkInterception.Any()){
                    //designate intercepts
                    List<GO> INTERCEPTS = GS.TYPE("INTERCEPTION").ToList();
                    Dictionary<string, List<GO>> CAPTABLE = new();
                    foreach(string s in FS.SIDE_NAMES){
                        List<GO> capAir = FS.CAPSQNS(GS, s).Where(n => !n.DONE).ToList();
                        List<GO> intLocations = capAir.Where(n => n.UNITTYPE == "INT").Select(n => n.GAMELOCATION).ToList();
                        CAPTABLE.Add(s, capAir.Where(n => intLocations.Contains(n.GAMELOCATION)).ToList());
                    }            
                    foreach(GO obj in checkInterception){
                        List<GO> alreadyInterceptedThisUnit = INTERCEPTS.Where(n => n.INTERCEPTEDGRP == obj).Select(n => n.CAP).ToList();
                        List<GO> friendlyRadius = FS.FINDAIRRADIUS(obj.GAMELOCATION, 4);
                        friendlyRadius.Remove(obj.GAMELOCATION);
                        if(CAPTABLE[FS.ENEMY(obj.SIDE)].Where(n => !alreadyInterceptedThisUnit.Contains(n) && friendlyRadius.Contains(n.GAMELOCATION)).Any()){
                            FS.ADDTAGGED(GS, "ACTION.INTERCEPTNEEDED", obj);
                        }
                    }
                }
            }
        }
    }  

    public class ActionActivationLoop : GamePhaseLoopLogic
    {
        public ActionActivationLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionActivateStack("Activate Stack", this, GS)); 
            AddGamePhase(new ActionAirINTRole("INT Role", this, GS));
            AddGamePhase(new ActionSubFullSpeed("SUB Full Speed", this, GS));
        }
        public override Boolean ProcessCheck(){return !GetBoolean("ACTION.ACTIVATION." + Get("ACTIVE.SIDE"));}
        public override void Init(){}
        public override void End(){
            List<GO> FULLSPEEDDETECTORS = GS.TYPE("SHIP").Where(n => n.SIDE != null && n.GAMELOCATION.TYPE == "HEX").ToList();
            foreach(GO obj in FS.GETTAGGEDUNITS(GS, "ACTION.ACTIVATING")){
                obj.ACTIVATED = true;
                FS.RESETMOVEMENTALLOWANCE(obj);
                if(FS.ISGROUP(obj) || obj.UNITCATEGORY == "SUB"){
                    obj.LOCATIONHISTORY = obj.GAMELOCATIONID;
                    obj.LOCATIONFUTURE ??= obj.GAMELOCATIONID;
                    if(FS.ISGROUP(obj)){
                        FS.UPDATEGROUP(obj);
                        obj.DOCKED = false;
                        FS.GROUPMEMBERS(obj).ForEach(n => n.DOCKED = false);
                    }
                    if(obj.UNITCATEGORY == "SUB" && obj.FULLSPEED && !obj.STRATDETECTED){
                        if(FS.FINDAIRRADIUS(obj.GAMELOCATION, 5).Intersect(FULLSPEEDDETECTORS.Where(n => n.SIDE == FS.ENEMY(obj.SIDE))).Any()){
                            FS.STRATDETECT(new(){obj}, true);
                        }
                    }
                    //create destination marker
                    //add attempt marker
                    GO template = GS.PIECE("ACTION.DESTINATION");
                    GO clone = FS.CLONE(GS, template, obj.GAMELOCATIONID);
                    clone.SIDE = obj.SIDE;
                    obj.DESTINATIONPIECEID = clone.ID;
                    obj.DESTINATIONPIECE = clone;
                    clone.GAMEPIECEID = obj.ID;
                    clone.GAMEPIECE = obj;
                    GS.ShuffleMarkerToBottom(clone);
                }
            }
            FS.CLEARTAGGED(GS, "ACTION.ACTIVATING");
        }
    }            
    public class ActionActivateStack : GamePhaseInteractive
    {
        List<GO> ACTIVATIONCANDIDATES = new();
        GO activatingUnit = null;
        GO activationGroup = null;
        string side = null;
        public ActionActivateStack(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                activatingUnit = null;
                activationGroup = null;
                ACTIVATIONCANDIDATES.Clear();
                FS.SETINSTRUCTIONS(GS, new(){"ADD UNITS TO ACTIVATION GROUP", "ACTIVATE UNITS"});

                GS.HELPTEXT = 
                "Activation.  In this phase, you will select the unit(s) that you want to activate.  Options:\n\n" + 
                "- SURFACE:  If its a TF/TG, all you can do is ACTIVATE it\n" +
                "- SURFACE:  If a free Ship, Game will continue to allow you to add units from the same hex, max 12 combat units, then ACTIVATE the group\n" +
                "- SUB:  all you can do is ACTIVATE\n" +
                "- AIR:  Game will continue to allow you to add units from the same hex, then ACTIVATE the group.  Max 4 INT/ATK/BMB\n\n" +
                "NOTE: You do NOT have to do all activations at this time.  the Game will allow you to activate more groups after these groups being moving/attacking\n\n" +
                "NOTE: You'll notice some DESTINATION markers being created as you activate units.  These will be used during the Orders phase to give units a path to go on\n\n" +
                "NOTE: To skip or whenever finished activating, hit NEXT Button\n\n" +
                "ENDING THE ACTION PHASE:  The open-ended Action Phase this game uses now has no distinct end.  You aren't forced to activate all your units at the beginning, and you could intentionally pause orders to wait to see what the enemy does.  " + 
                "So, the Action Phase will AUTOMATICALLY END when all activated units have no more movement points or no standing orders. So if you are activating units but not giving them someplace to go or something to do, the Action Phase may end, so keep that in mind\n\n";
                ACTIVATIONCANDIDATES.AddRange(FS.TYPESIDE(GS, "SQN", side).Where(n => FS.CANLAUNCHACTIVATE(GS, n)));
                ACTIVATIONCANDIDATES.AddRange(FS.TYPESIDE(GS, "SHIP", side).Where(n => n.GROUPID == null && FS.CANSHIPACTIVATE(GS, n)));

                List<GO> activationGrps = ACTIVATIONCANDIDATES.Where(n => n.GRPTYPE == "ACTIVATIONGRP" && !n.ACTIVATED).ToList();
                if(activationGrps.Any()){
                    GO group = activationGrps.First();
                    GS.InteractionMap.Add(group, new());
                    activationGroup = group;
                    foreach(GO obj in ACTIVATIONCANDIDATES.Where(n => !n.ACTIVATED && n.UNITCATEGORY == group.UNITCATEGORY && !FS.ISGROUP(n) && FS.PARENTGROUPLOCATION(n) == group.GAMELOCATION)){
                        GS.InteractionMap.Add(obj, new());
                    }
                } else {
                    foreach(GO obj in ACTIVATIONCANDIDATES.Where(n => !n.ACTIVATED)){
                        GS.InteractionMap.Add(obj, new());
                    }
                }
            }
            FS.GETNEXTSELECTED(GS);
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, FS.ISGROUP(obj) || obj.UNITCATEGORY == "SUB" ? "ACTIVATE" : activationGroup == null ? "CREATE ACTIVATION GROUP" : "ADD TO ACTIVATION GROUP");
                if(obj.GRPTYPE == "ACTIVATIONGRP" && GS.InteractionMap.Count == 1){
                    Update("ACTIVATE");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    bool valid = true;
                    if(activatingUnit != null){
                        //check validity of units
                        if(activatingUnit.UNITCATEGORY == "AIR"){
                            if(activatingUnit.CARRIER?.DAMAGED == true && activatingUnit.CARRIER?.ACTIVATEDAIRUNITS == 1){
                                MainWindow.Alert("Exceeding max number of air units activated from damaged Carrier.");
                                valid = false;
                            }
                        }
                        if(valid){
                            GO obj = activatingUnit;
                            List<GO> activatingUnits = new();
                            if(FS.ISGROUP(obj)){
                                activatingUnits.Add(obj);
                                foreach(GO obj2 in FS.GROUPMEMBERS(obj).Where(n => !n.ACTIVATED)){
                                    activatingUnits.Add(obj2);
                                }
                            } else if(obj.UNITCATEGORY == "SUB"){
                                activatingUnits.Add(obj);
                            } else {
                                if(obj.UNITCATEGORY == "AIR"){
                                    GO homebase = obj.CARRIER ?? obj.GAMELOCATION;
                                    obj.HOMEBASEID = homebase.ID;
                                    obj.HOMEBASE = homebase;
                                    if(obj.CARRIER != null){
                                        obj.HOMEBASE.ACTIVATEDAIRUNITS++;
                                        FS.REMOVEFROMGROUP(obj, obj.CARRIER);
                                    }
                                }
                                if(activationGroup == null){
                                    FS.CREATEACTIVATIONGROUP(obj, FS.PARENTGROUPLOCATION(obj).ID);
                                } else {
                                    FS.ADDTOGROUP(obj, activationGroup);
                                }
                                activatingUnits.Add(obj);
                            }
                            FS.SETTAGGED(GS, "ACTION.ACTIVATING", activatingUnits);
                            SetBoolean("ACTION.ACTIVATION." + side, false);
                            FS.SETNEXTSELECTED(GS.NEXT(ACTIVATIONCANDIDATES.Where(n => !n.ACTIVATED).ToList(), gp));
                            GS.Advance(this);
                        } else {
                            GS.SelectedMarker = GS.REMOVEINTERACTIVE(activatingUnit);
                            activatingUnit = null;
                            Start(false);
                        }
                    } else if(activationGroup != null){
                        activatingUnit = activationGroup;
                        Update("NEXT");
                    } else {
                        //pass
                        SetBoolean("ACTION.ACTIVATION." + side, true);
                        FS.SETNEXTSELECTED(GS.NEXT(ACTIVATIONCANDIDATES.Where(n => !n.ACTIVATED).ToList(), gp));
                        GS.Advance(this);
                    }
                    break;
                case "ACTIVATE":
                    activatingUnit = gp;
                    Update("NEXT");
                    break;
                case "CREATE ACTIVATION GROUP":
                case "ADD TO ACTIVATION GROUP":
                    activatingUnit = gp;
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionGenerateCombats : GamePhaseAutomated
    {
        string mode = null;
        public ActionGenerateCombats(string pid, GamePhase pparent, GameScenario pscenario, string pmode) : base(pid, pparent, pscenario) {
            mode = pmode;
        }            
        public override void Execute(Boolean init){
            List<GO> combats = new();
            foreach(GO obj in FS.GETTAGGEDUNITS(GS, "ACTION.ACTIVATED")){
                bool isAir = obj.UNITCATEGORY == "AIR";
                bool isDetected = obj.LOCALDETECTED || obj.STRATDETECTED;
                if(mode == "AIR" && !isAir){continue;}
                if(mode == "UNDETECTED" && (isDetected || isAir)){continue;}
                if(mode == "DETECTED" && (!isDetected || isAir)){continue;}
                GO combat = GS.LOGICS().Where(n => FS.COMBATMISSIONTYPES.Contains(n.TYPE)).Where(n => n.ATTACKER == obj && n.ATTACKERLOCATION == obj.GAMELOCATION).SingleOrDefault();
                if(combat != null){
                    combats.Add(combat);
                    IncrementInt("ACTION.COMBATS." + obj.SIDE, 1);
                }
            }
            FS.COMBATMISSIONTYPES.ForEach(n => FS.SETTAGGED(GS, "ACTION." + n + "COMBAT", combats.Where(n2 => n2.TYPE == n).Select(n2 => (GO)n2).ToList()));
            GS.Advance(this);           
        }
    }
    public class ActionCombined : GamePhaseGroupLogic
    {
        public ActionCombined(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionCombinedOrdersLoop("Loop", this, GS));
            AddGamePhase(new ActionAirCombat("AIR COMBAT MISSIONS", this, GS));
            AddGamePhase(new ActionUndetectedCombat("UNDETECTED COMBAT MISSIONS", this, GS));
            AddGamePhase(new ActionDetectedCombat("DETECTED COMBAT MISSIONS", this, GS));
            //do combats
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init(){
            FS.SIDE_NAMES.ForEach(n => SetBoolean("ACTION.ORDERS." + n, false));
        }
        public override void End()
        {
            SetInt("ACTION.AIRHEXES", 0);
            FS.CLEARDESTINATIONS(GS);
        }
    }  
    public class ActionCombinedOrdersLoop : GamePhaseLoopLogic
    {
        public ActionCombinedOrdersLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionOrders("Orders", this, GS, true));
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION.ORDERS." + n)).Any();}
        public override void Init()
        {
            //throw new NotImplementedException();
        }
        public override void End()
        {
            string side = Get("ACTIVE.SIDE");
            if(side == GS.Get("SIDE1")){
                Set("ACTIVE.SIDE", FS.ENEMY(side));
            } else {
                Set("SIDE1", side);
            }
            SetBoolean("ACTION.ORDERS." + side, true);
        }
    }
    public class ActionAir : GamePhaseGroupLogic
    {
        public ActionAir(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionAirOrdersLoop("Loop", this, GS));
            AddGamePhase(new ActionAirCombat("AIR COMBAT MISSIONS", this, GS));
            //do combats
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init(){
            FS.SIDE_NAMES.ForEach(n => SetBoolean("ACTION.ORDERS." + n, false));
        }
        public override void End()
        {
            SetInt("ACTION.AIRHEXES", 0);
            FS.CLEARDESTINATIONS(GS);
        }
    }  
    public class ActionAirOrdersLoop : GamePhaseLoopLogic
    {
        public ActionAirOrdersLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionOrders("Orders", this, GS, true));
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION.ORDERS." + n)).Any();}
        public override void Init()
        {
            //throw new NotImplementedException();
        }
        public override void End()
        {
            string side = Get("ACTIVE.SIDE");
            if(side == GS.Get("SIDE1")){
                Set("ACTIVE.SIDE", FS.ENEMY(side));
            } else {
                Set("SIDE1", side);
            }
            SetBoolean("ACTION.ORDERS." + side, true);
        }
    }
    public class ActionOrders : GamePhaseInteractive
    {
        bool combined = false;
        List<GO> ACTIONABLE = new();
        List<GO> ENEMYUNITS = new();
        Dictionary<string, List<GO>> TARGETS = new();
        List<GO> SSMSCOPE = new();
        List<GO> BOMBSCOPE = new();
        List<GO> CMSCOPE = new();
        List<GO> ASWSCOPE = new();
        List<GO> TORPSCOPE = new();
        List<GO> COMBATS = new();
        string COMBATMODE = null;
        GO attackingUnit = null;
        Dictionary<GO, List<FSMovement>> MOVEMENTFUTURES = new();
        Dictionary<GO, List<FSMovement>> MOVEMENTCHOICES = new();
        string side = null;
        public ActionOrders(string pid, GamePhase pparent, GameScenario pscenario, bool pcombined) : base(pid, pparent, pscenario) {
            DragDrop = true;
            DragOver = true;
            combined = pcombined;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                FS.ORDERS = true;
                side = Get("ACTIVE.SIDE");
                ACTIONABLE.Clear();
                ENEMYUNITS.Clear();
                COMBATS.Clear();
                TARGETS.Clear();
                FS.COMBATMISSIONTYPES.ForEach(n => TARGETS.Add(n, new()));
                COMBATMODE = null;
                attackingUnit = null;
                MOVEMENTFUTURES.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG UNIT TO GIVE MOVEMENT ORDERS", "DESIGNATE ATTACKS ALONG THE WAY"});
                GS.HELPTEXT = 
                "Give orders to units, which will be EXECUTED AFTERWARDS by automation.  These automation cycles will rotate between a Combined cyle (where you can give orders to all units) and Air cycle (where you can only give orders to air units)\n\n" + 
                "- Trace the path that will be followed by the unit. Each automation cycle will move the air unit up to 5 hexes and sub/ship will move 1 (if its a combined cycle), but you can trace a longer path than that.  The remainder of the path will continue to be followed by automation.  Every 5 hexes you'll be able to adjust or change the path\n" + 
                "- Along the path, you can designate attacks.  The game will allow you to designate the target hex/unit/facility only.  Further combat actions like allocations will be given at run-time during the automation cycle\n" +
                "- AIR units can only execute at most 1 attack during their mission.  SUB can execute at most 1 attack per TURN.  SURFACE can execute up to 2 different types of attacks per TURN\n" + 
                "- AIR Landing:  during the automation, if the unit flies over it's homebase, it will automatically land. You CAN choose to land the air unit at another base, if the air unit is actually over the base currently.  Only non-carrier units can do this and after landing they have to go through " +
                "a delay of " + GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER") + " turns (configurable)\n" +
                "- DOCKING: only can be done at the units actual location.  If the surface/sub unit is in a port and all units have enough movement points\n" +
                "- STACKING (AIR): you won't be able to land on an airbase where the current amount of air units based there, either on the ground or on missions, plus your aircraft violates the 4 INT/ATK/BMB limit\n" +
                "- STACKING (SURFACE):  since ships are constantly moving, stacking will be enforced after all movements are completed in the turn. " + 
                "IF surface ships violate the Stacking Limit (max of 12 combat units per hex), you will have to destroy units to get under the limit.  Each cycle of automation will warn you of hexes that are overstacked." + 
                " Ensure that by the end of all activations and movements, no hexes are in violation\n" +
                "- Be careful on your path.  During automation, your air units will be interrupted by enemy CAP, or if your path is too long, any air units with 0 allowance remaining will be lost\n\n" + 
                "NOTE: Attacks that are planned in advance will only execute if they are still possible, like if the target sub of a ASW attack is still in the target hex, so keep in mind that air units will be able to travel 5 hexes before surface/subs move.  Obviously, attacks against immobile targets like bases can be planned pretty far in advance\n\n" +
                "NOTE: The game will place a Destination marker where you give orders for a unit to move.  This marker can be used to both trace the path the unit will take and plan out attacks along the route\n\n" +
                "ENDING THE ACTION PHASE:  The open-ended Action Phase this game uses now has no distinct end.  You aren't forced to activate all your units at the beginning, and you could intentionally pause orders to wait to see what the enemy does.  " + 
                "So, the Action Phase will AUTOMATICALLY END when all activated units have no more movement points or no standing orders. So if you are activating units but not giving them someplace to go or something to do, the Action Phase may end, so keep that in mind\n\n" + 
                "NO AIR LOITERING:  Air units must always have orders, so the game will require you to give all active air units a path to fly each time around the cycle\n\n" +
                "CONTINUING ORDERS: TF/TGs will keep record of their destination into the next turn, so long routes will be remembered.  Temporary Activation Groups will disband at the end of the Action Phase";  
                List<GO> objs = FS.GETTAGGEDUNITS(GS, "ACTION.ACTIVATED").Where(n => 
                    n.SIDE == side).ToList();
                List<GO> inscope = objs.Where(n => n.TYPE == "SQN").ToList();
                if(combined){
                    inscope.AddRange(objs.Where(n => n.TYPE == "SHIP" && !n.LOCALDETECTED && !n.STRATDETECTED));
                    inscope.AddRange(objs.Where(n => n.TYPE == "SHIP" && (n.LOCALDETECTED || n.STRATDETECTED)));
                }
                foreach(GO obj in inscope){
                    ACTIONABLE.Add(obj);
                    GS.InteractionMap.Add(obj, new());
                    MOVEMENTCHOICES.Add(obj, new());
                    ACTIONABLE.Add(obj.DESTINATIONPIECE);
                    GS.InteractionMap.Add(obj.DESTINATIONPIECE, new());
                    MOVEMENTCHOICES.Add(obj.DESTINATIONPIECE, new());
                }
                ENEMYUNITS.AddRange(FS.TYPESIDE(GS, "PIECE", FS.ENEMY(side)).Where(n => n.ENROUTEDELAY == 0 && (n.STRATDETECTED || n.LOCALDETECTED || (n.UNITTYPE == "BASE" && !FS.STORM(n.GAMELOCATION) && ((n.PORT && !n.PORTDESTROYED) || (n.AIRFIELD && !n.AIRFIELDDESTROYED))))));
                SSMSCOPE = ENEMYUNITS.Where(n => !n.DOCKED && n.UNITCATEGORY == "SURFACE").ToList();
                BOMBSCOPE = ENEMYUNITS.Where(n => n.UNITCATEGORY == "SURFACE" || (n.UNITTYPE == "BASE" && n.GAMELOCATION.TYPE == "HEX")).ToList();
                CMSCOPE = ENEMYUNITS.Where(n => n.UNITTYPE == "BASE").ToList();
                ASWSCOPE = ENEMYUNITS.Where(n => (n.UNITCATEGORY == "SURFACE" && n.TEMPLATE.AAA > 0) || n.UNITTYPE == "SUB").ToList();
                TORPSCOPE = ENEMYUNITS.Where(n => !n.DOCKED && n.UNITCATEGORY == "SURFACE").ToList();
                COMBATS = GS.LOGICS().Where(n => FS.COMBATMISSIONTYPES.Contains(n.TYPE)).ToList();
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.SIDE == side){
                    GO actualUnit = obj.TYPE == "DESTINATION" ? obj.GAMEPIECE : obj;
                    GO destinationMarker = obj.TYPE == "DESTINATION" ? obj : obj.DESTINATIONPIECE;
                    if(obj != attackingUnit){GS.AddAction(obj, obj == actualUnit ? ">>DESTINATION" : ">>ACTUAL");}
                    if(!MOVEMENTFUTURES.ContainsKey(actualUnit)){
                        string[] locations = actualUnit.LOCATIONFUTURE.Split('|');
                        //generate futures
                        List<FSMovement> ms = new(){
                            new(){
                                MOVEMENTLOCATIONID = locations[0],
                                MOVEMENTLOCATION = GS.LOCATION(locations[0])
                            }
                        };
                        for(int i = 1; i < locations.Length; i++){
                            string f = locations[i - 1];
                            string t = locations[i];
                            GO connector = GS.TYPE("UNITMOVEMENT" , "CONNECTORLOCATIONID", f).Where(n => n.CONNECTORLOCATION2ID == t).FirstOrDefault();
                            ms.Add(
                                new(){
                                    MOVEMENTLOCATIONID = locations[i],
                                    MOVEMENTLOCATION = GS.LOCATION(locations[i]),
                                    MOVEMENTCONNECTORID = connector.ID,
                                    MOVEMENTCONNECTOR = connector,
                                    DISTANCE = Math.Max(1, connector.DISTANCE)
                                }
                            );
                        }
                        MOVEMENTFUTURES.Add(actualUnit, ms);
                    }
                    List<FSMovement> movements = MOVEMENTFUTURES[actualUnit];
                    double plannedDistance = movements.Where(n => n.MOVEMENTCONNECTOR != null).Sum(n => n.DISTANCE);
                    double delay = actualUnit.ENROUTEDELAY;
                    
                    double remaining = actualUnit.MOVEMENTALLOWANCE - plannedDistance - delay;
                    remaining = actualUnit.UNITCATEGORY switch{
                        "AIR" => remaining,
                        _ => Math.Max(0, remaining)
                    };
                    actualUnit.REMAININGMOVEMENT = actualUnit.DRAGGING? remaining : actualUnit.MOVEMENTALLOWANCE;
                    destinationMarker.REMAININGMOVEMENT = remaining;
                    //show future moves as they are being added
                    if(movements.Count > 1){
                        string color = destinationMarker.REMAININGMOVEMENT < 0 ? "RED" : "WHITE";
                        for(int i = 1; i < movements.Count; i++){
                            FSMovement movement = movements[i];
                            movement.MOVEMENTCONNECTOR.MakeLineVisible(color, true);
                        }
                    }
                    GO actualLocation = movements.First().MOVEMENTLOCATION;
                    if(attackingUnit == obj){
                        GS.AddAction(obj, "CANCEL ATTACK");
                        switch(COMBATMODE){
                            case "BOMB":
                                if(TARGETS[COMBATMODE].Where(n => n.UNITCATEGORY == "SURFACE").Any()){GS.AddAction(obj, "TARGET SHIPS");}
                                if(TARGETS[COMBATMODE].Where(n => n.AIRFIELD && !n.AIRFIELDDESTROYED).Any()){GS.AddAction(obj, "TARGET AIRFIELD");}
                                if(TARGETS[COMBATMODE].Where(n => n.PORT && !n.PORTDESTROYED).Any()){GS.AddAction(obj, "TARGET PORT");}
                                break;
                            default:
                                break;
                        }
                    } else {
                        List<GO> groupMembers = FS.GROUPMEMBERS(actualUnit);
                        GS.InteractionMap[obj].Clear();
                        if(obj == destinationMarker || (obj.GAMELOCATION == destinationMarker.GAMELOCATION && movements.Count == 1) || obj.DRAGGING){
                            List<FSMovement> choices = actualUnit.UNITCATEGORY switch {
                                "AIR" => FS.FINDAIRMOVEMENTS(obj.GAMELOCATION),
                                "SUB" => FS.FINDSUBMOVEMENTS(obj, obj.GAMELOCATION),
                                "SURFACE" => FS.FINDSURFACEMOVEMENTS(obj, obj.GAMELOCATION),
                                _ => new()
                            }; 
                            MOVEMENTCHOICES[obj] = choices;                       
                            GS.InteractionMap[obj].AddRange(choices.Select(n => n.MOVEMENTLOCATION));
                            foreach(FSMovement m in choices){
                                if(m.MOVEMENTLOCATION.TYPE == "OM"){
                                    m.LABEL = "To Off Map Airfield";
                                    GS.AddAction(obj, m.LABEL);
                                }
                                if(m.MOVEMENTLOCATION.TERRAIN == "OMAF"){
                                    m.LABEL = "To " + m.MOVEMENTLOCATION.ZONE + " ZONE";
                                    GS.AddAction(obj, m.LABEL);
                                }
                            }
                        }
                        if(!obj.DRAGGING){
                            if(obj.GAMELOCATION == actualLocation && obj == actualUnit){
                                if(actualUnit.UNITCATEGORY == "AIR"){
                                    if(groupMembers.Where(n => n.HOMEBASE.AIRFIELD && n.HOMEBASE != obj.GAMELOCATION).Any()){
                                        if(actualLocation.SIDE == actualUnit.SIDE && actualLocation.AIRFIELD && actualLocation.AIRFIELDDAMAGELEVEL == 0){
                                            GS.AddAction(obj, "TRANSFER NON-CARRIER UNITS TO THIS AIRFIELD");
                                        }
                                    }
                                } else {
                                    if(actualLocation.SIDE == actualUnit.SIDE && actualLocation.PORT){
                                        if(!groupMembers.Where(n => !FS.CANDOCK(n)).Any()){
                                            GS.AddAction(obj, "DOCK");
                                        }
                                    }
                                }
                            }
                            List<GO> combats = COMBATS.Where(n => n.ATTACKER == actualUnit).ToList();
                            Dictionary<string, bool> allowable = new()
                            {
                                {
                                    "SSM",
                                    actualUnit.UNITCATEGORY switch
                                    {
                                        "SURFACE" => !(actualUnit.DONESSM || combats.Where(n => n.TYPE == "SSM").Any()),
                                        _ => !combats.Any()
                                    }
                                },
                                {
                                    "CM",
                                    actualUnit.UNITCATEGORY switch
                                    {
                                        "SURFACE" => !(actualUnit.DONECM || combats.Where(n => n.TYPE == "CM").Any()),
                                        _ => !combats.Any()
                                    }
                                },
                                {
                                    "ASW",
                                    actualUnit.UNITCATEGORY switch
                                    {
                                        "SURFACE" => !(actualUnit.DONEASW || combats.Where(n => n.TYPE == "ASW").Any()),
                                        _ => !combats.Any()
                                    }
                                },
                                {
                                    "BOMB",
                                    actualUnit.UNITCATEGORY switch
                                    {
                                        "AIR" => !combats.Any(),
                                        _ => false
                                    }
                                },
                                {
                                    "TORP",
                                    actualUnit.UNITCATEGORY switch
                                    {
                                        "SUB" => !combats.Any(),
                                        _ => false
                                    }
                                }
                            };
                            if(allowable.Values.Where(n => n).Any() && !FS.STORM(obj.GAMELOCATION)){
                                Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers);
                                foreach(string ct in FS.COMBATMISSIONTYPES.Where(n => allowable[n])){
                                    if(attackData.Values.Where(n => n.ContainsKey(ct)).Any()){
                                        TARGETS[ct] = GETTARGETS(actualUnit, obj, ct);
                                        if(TARGETS[ct].Any()){
                                            GS.AddAction(obj, ct + " ATTACK");
                                        }
                                    }
                                }
                            }
                            if(combats.Any() || movements.Count > 1){
                                GS.AddAction(obj, "RESET ORDERS");
                            }
                        }
                    }
                } else {
                    switch(COMBATMODE){
                        case "SSM":
                        case "TORP":
                            GS.AddAction(obj, "TARGET THIS LOCATION");
                            break;
                        case "CM":
                            if(obj.AIRFIELD && !obj.AIRFIELDDESTROYED){GS.AddAction(obj, "TARGET AIRFIELD");}
                            if(obj.PORT && !obj.PORTDESTROYED){GS.AddAction(obj, "TARGET PORT");}
                            break;
                        case "ASW":
                            GS.AddAction(obj, "TARGET");
                            break;
                        default:
                            break;
                    }

                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            GO actualUnit = gp.TYPE == "DESTINATION" ? gp.GAMEPIECE : gp;
            GO destinationMarker = gp.TYPE == "DESTINATION" ? gp : gp.DESTINATIONPIECE;
            if(attackingUnit != null){
                actualUnit = attackingUnit.TYPE == "DESTINATION" ? attackingUnit.GAMEPIECE : attackingUnit;
                destinationMarker = attackingUnit.TYPE == "DESTINATION" ? attackingUnit : attackingUnit.DESTINATIONPIECE;
            }
            switch(pData){
                case ">>DESTINATION":
                case ">>ACTUAL":
                    GS.SelectedMarker = gp == actualUnit ? destinationMarker : actualUnit;
                    Start(false);
                    break;
                case "NEXT":
                    if(attackingUnit != null){
                        MainWindow.Alert("You must either choose your attack or cancel first");
                        Start(false);
                    } else {
                        //confirm all active air units have a planned path
                        List<GO> INACTIVEAIR = GS.InteractionMap.Keys
                            .Where(n => n.UNITCATEGORY == "AIR" && n.ENROUTEDELAY == 0)
                            .Where(n => !MOVEMENTFUTURES.ContainsKey(n) || MOVEMENTFUTURES[n].Count == 1).ToList();

                        if(INACTIVEAIR.Any()){
                            MainWindow.Alert("All activated air units must have orders");
                            GS.SelectedMarker = INACTIVEAIR.First();
                            Start(false);
                        } else {
                            FS.ORDERS = false;
                            GS.Advance(this);
                        }
                    }
                    break;
                case "DOCK":
                    CLEARORDERS(actualUnit);
                    actualUnit.DONE = true;
                    bool isActivationGrp = actualUnit.GRPTYPE == "ACTIVATIONGRP";
                    foreach(GO obj in FS.GROUPMEMBERS(actualUnit)){
                        obj.DOCKED = true;
                        obj.DONE = true;
                        FS.REMOVETAGGED(GS, obj);
                        if(isActivationGrp){
                            FS.REMOVEFROMGROUP(obj, actualUnit);
                        }
                    }
                    if(!isActivationGrp){
                        actualUnit.DOCKED = true;
                        FS.REMOVETAGGED(GS, actualUnit);                    
                    }
                    actualUnit.DESTINATIONPIECE.GAMEPIECEID = null;
                    GS.DISCARD(actualUnit.DESTINATIONPIECE);
                    actualUnit.DESTINATIONPIECEID = null;
                    break;
                case "TARGET SHIPS":
                case "TARGET AIRFIELD":
                case "TARGET PORT":
                    Dictionary<string, string> objData = new()
                    {
                        ["ID"] = actualUnit.ID + GO.DELIM + COMBATMODE + GO.DELIM + FS.GENERATETIMESTAMP(),
                        ["DOMAIN"] = GO.DOMAIN_LOGIC,
                        ["TYPE"] = COMBATMODE
                    };
                    GO combat = new(GS, objData, null, null)
                    {
                        ATTACKERID = actualUnit.ID,
                        ATTACKER = actualUnit,
                        ATTACKERLOCATIONID = attackingUnit.GAMELOCATIONID,
                        ATTACKERLOCATION = attackingUnit.GAMELOCATION,
                        DEFENDERLOCATIONID = attackingUnit.GAMELOCATIONID,
                        DEFENDERLOCATION = attackingUnit.GAMELOCATION,
                        LABEL = pData.Replace("TARGET ", ""),
                        SIDE = actualUnit.SIDE
                    };
                    if(COMBATMODE == "BOMB"){
                        if(combat.LABEL != "SHIPS"){
                            GO target = TARGETS[COMBATMODE].Where(n => n.UNITTYPE == "BASE").Single();
                            combat.DEFENDERID = target.ID;
                            combat.DEFENDER = target;
                        }
                    } else {
                        GO target = gp;
                        combat.DEFENDERID = target.ID;
                        combat.DEFENDER = target;
                    }
                    GO template = GS.PIECE("ACTION.TARGET");
                    GO clone = FS.CLONE(GS, template, attackingUnit.GAMELOCATIONID);
                    clone.LABEL = COMBATMODE;
                    clone.SIDE = side;
                    combat.GAMEPIECEID = clone.ID;
                    combat.GAMEPIECE = clone;
                    COMBATS.Add(combat);
                    Update("RETURN TO MOVE MODE");
                    break;
                case "TARGET THIS LOCATION":
                    objData = new()
                    {
                        ["ID"] = actualUnit.ID + GO.DELIM + COMBATMODE + GO.DELIM + FS.GENERATETIMESTAMP(),
                        ["DOMAIN"] = GO.DOMAIN_LOGIC,
                        ["TYPE"] = COMBATMODE
                    };
                    combat = new(GS, objData, null, null)
                    {
                        ATTACKERID = actualUnit.ID,
                        ATTACKER = actualUnit,
                        ATTACKERLOCATIONID = attackingUnit.GAMELOCATIONID,
                        ATTACKERLOCATION = attackingUnit.GAMELOCATION,
                        DEFENDERLOCATIONID = gp.GAMELOCATIONID,
                        DEFENDERLOCATION = gp.GAMELOCATION,
                        DISTANCE = FS.GETAIRMOVEMENTDISTANCE(FS.FINDAIRMOVEMENTPATH(attackingUnit.GAMELOCATION, gp.GAMELOCATION)),
                        SIDE = actualUnit.SIDE
                    };
                    template = GS.PIECE("ACTION.TARGET");
                    clone = FS.CLONE(GS, template, attackingUnit.GAMELOCATIONID);
                    clone.LABEL = COMBATMODE;
                    clone.SIDE = side;
                    combat.GAMEPIECEID = clone.ID;
                    combat.GAMEPIECE = clone;
                    COMBATS.Add(combat);
                    GS.ShuffleMarkerToBottom(clone);
                    Update("RETURN TO MOVE MODE");
                    break;
                case "TARGET":
                    objData = new()
                    {
                        ["ID"] = actualUnit.ID + GO.DELIM + COMBATMODE + GO.DELIM + FS.GENERATETIMESTAMP(),
                        ["DOMAIN"] = GO.DOMAIN_LOGIC,
                        ["TYPE"] = COMBATMODE
                    };
                    combat = new(GS, objData, null, null)
                    {
                        ATTACKERID = actualUnit.ID,
                        ATTACKER = actualUnit,
                        ATTACKERLOCATIONID = attackingUnit.GAMELOCATIONID,
                        ATTACKERLOCATION = attackingUnit.GAMELOCATION,
                        DEFENDERLOCATIONID = gp.GAMELOCATIONID,
                        DEFENDERLOCATION = gp.GAMELOCATION,
                        DEFENDERID = gp.ID,
                        DEFENDER = gp,
                        SIDE = actualUnit.SIDE
                    };
                    template = GS.PIECE("ACTION.TARGET");
                    clone = FS.CLONE(GS, template, attackingUnit.GAMELOCATIONID);
                    clone.LABEL = COMBATMODE;
                    clone.SIDE = side;
                    combat.GAMEPIECEID = clone.ID;
                    combat.GAMEPIECE = clone;
                    COMBATS.Add(combat);
                    Update("RETURN TO MOVE MODE");
                    break;
                case "RESET ORDERS":
                    CLEARORDERS(actualUnit);
                    Start(false);
                    break;
                case "CANCEL ATTACK":
                case "RETURN TO MOVE MODE":
                    GS.InteractionMap.Clear();
                    ACTIONABLE.ForEach(n => GS.InteractionMap.Add(n, new()));
                    GS.SelectedMarker = attackingUnit;
                    COMBATMODE = null;
                    attackingUnit = null;
                    TARGETS.Clear();
                    Start(false);
                    break;
                case "SSM ATTACK":
                case "CM ATTACK":
                case "TORP ATTACK":
                case "ASW ATTACK":
                    COMBATMODE = pData.Replace(" ATTACK","");
                    attackingUnit = gp;
                    GS.InteractionMap.Clear();
                    TARGETS[COMBATMODE].ForEach(n => GS.InteractionMap.Add(n, new()));
                    GS.InteractionMap.Add(gp, new());
                    GS.SelectedMarker = TARGETS[COMBATMODE].First();
                    Start(false);
                    break;
                case "BOMB ATTACK":
                    COMBATMODE = pData.Replace(" ATTACK","");
                    attackingUnit = gp;
                    GS.InteractionMap.Clear();
                    GS.InteractionMap.Add(gp, new());
                    Start(false);
                    break;
                case "TRANSFER NON-CARRIER UNITS TO THIS AIRFIELD":
                    CLEARORDERS(actualUnit);
                    List<GO> landingAir = FS.GROUPMEMBERS(actualUnit).Where(n => n.HOMEBASE.AIRFIELD).ToList();
                    //attempt to land, if no room throw error
                    GO airfield = actualUnit.GAMELOCATION;
                    if(landingAir.Where(n => !FS.STRATEGICCOUNTRIES[airfield.ORGLEVEL1].Contains(n.COUNTRY) && n.COUNTRY != airfield.COUNTRY).Any()){
                        MainWindow.Alert("Air Units are not able to land in this country");
                        Start(false);
                        break;
                    }
                    List<GO> airUnits = FS.TYPESIDELOCATION(GS, "SQN", actualUnit.SIDE, airfield.ID);
                    airUnits.AddRange(FS.TYPESIDE(GS, "SQN", actualUnit.SIDE).Where(n => n.HOMEBASE == airfield));
                    airUnits.AddRange(landingAir);
                    if(FS.CANSTACKAIR(airUnits)){
                        foreach(GO obj in landingAir){
                            if(airfield != obj.HOMEBASE){
                                //transfer, so add delay
                                obj.ENROUTEDELAY = GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER");
                            }
                            GS.CHANGELOCATION(obj, airfield);
                            obj.HOMEBASEID = null;
                            obj.DONE = true;
                            FS.REMOVEFROMGROUP(obj, actualUnit);
                            FS.REMOVETAGGED(GS, obj);
                        }
                        Start(false);
                    } else {
                        MainWindow.Alert("Airbase does not have enough capacity");
                        Start(false);
                    }
                    break;
                case null:
                    if(gp.DRAGGING){
                        if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                            GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                            GO newloc = gp.GAMELOCATION;
                            //construct tmp array until you hit the new loc
                            List<FSMovement> movementPath = MOVEMENTFUTURES[actualUnit];
                            movementPath.Add(MOVEMENTCHOICES[gp].Where(n => n.MOVEMENTLOCATION == newloc).Single());
                        }
                        Start(false);
                    } else if(actualUnit.SIDE == side){
                        FSMovement firstMovement = MOVEMENTFUTURES[actualUnit].First();
                        GO initialLocation = firstMovement.MOVEMENTLOCATION;
                        if(gp.GAMELOCATION != initialLocation){
                            if(gp == actualUnit){
                                GS.CHANGELOCATION(destinationMarker, gp.GAMELOCATION);
                                GS.CHANGELOCATION(actualUnit, initialLocation);
                                GS.SelectedMarker = destinationMarker;
                            }
                            actualUnit.LOCATIONFUTURE = string.Join('|', MOVEMENTFUTURES[actualUnit].Select(n => n.MOVEMENTLOCATIONID));
                        }
                        Start(false);
                    }
                    break;
                default:
                    FSMovement immediateMovement = MOVEMENTCHOICES[gp].Where(n => n.LABEL == pData).SingleOrDefault();
                    if(immediateMovement != null){
                        if(gp == actualUnit){
                            FSMovement firstMovement = MOVEMENTFUTURES[actualUnit].First();
                            GO initialLocation = firstMovement.MOVEMENTLOCATION;
                            GS.CHANGELOCATION(destinationMarker, immediateMovement.MOVEMENTLOCATION);
                            GS.CHANGELOCATION(actualUnit, initialLocation);
                            GS.SelectedMarker = destinationMarker;
                        } else {
                            GS.CHANGELOCATION(gp, immediateMovement.MOVEMENTLOCATION);
                        }
                        //construct tmp array until you hit the new loc
                        List<FSMovement> movementPath = MOVEMENTFUTURES[actualUnit];
                        movementPath.Add(immediateMovement);
                        actualUnit.LOCATIONFUTURE = string.Join('|', MOVEMENTFUTURES[actualUnit].Select(n => n.MOVEMENTLOCATIONID));                        
                    }
                    Start(false);
                    break;
            }            
        }
        private List<GO> GETTARGETS(GO actualUnit, GO destinationMarker, string combatType){
            return combatType switch{
                "SSM" => FS.SSMTARGETS(actualUnit, destinationMarker, SSMSCOPE),
                "CM" => FS.CMTARGETS(actualUnit, destinationMarker, CMSCOPE),
                "BOMB" => FS.BOMBTARGETS(actualUnit, destinationMarker, BOMBSCOPE),
                "TORP" => FS.TORPTARGETS(actualUnit, destinationMarker, TORPSCOPE),
                "ASW" => FS.ASWTARGETS(actualUnit, destinationMarker, ASWSCOPE),
                _ => new()
            };
        }
        private void CLEARORDERS(GO actualUnit){
            foreach(GO obj in COMBATS.Where(n => n.ATTACKER == actualUnit).ToList()){
                FS.DISCARDLOGIC(obj);
                COMBATS.Remove(obj);
            }
            FSMovement firstMovement = MOVEMENTFUTURES[actualUnit].First();
            GS.CHANGELOCATION(actualUnit.DESTINATIONPIECE, firstMovement.MOVEMENTLOCATION);
            actualUnit.LOCATIONFUTURE = firstMovement.MOVEMENTLOCATIONID;
            MOVEMENTFUTURES[actualUnit] = new(){firstMovement};
        }
    }
}