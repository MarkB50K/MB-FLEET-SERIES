using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Controls;
using System.Reflection.Metadata.Ecma335;
namespace CWApp.FS
{
    public class ActionCycle : GamePhaseGroupLogic
    {
        public ActionCycle(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new CAPAir("Allocate CAP", this, GS));
            AddGamePhase(new ReplenishmentBASE("At-Base Replenishment", this, GS));
            AddGamePhase(new ReplenishmentSEA("At-Sea Replenishment", this, GS));
            AddGamePhase(new Loading("Load Troops/Supplies", this, GS));
            AddGamePhase(new Unloading("UnLoad Troops/Supplies", this, GS));
            AddGamePhase(new LocalDetection("Local Detection", this, GS));
            AddGamePhase(new StrategicAirTacCoordinationLoop("Tactical Coordination", this, GS));
            AddGamePhase(new ActionGroupUnGroup("Pre-Action Phase Group Management", this, GS));
            AddGamePhase(new ActionSurfaceFullSpeed("High Speed", this, GS));
            AddGamePhase(new ActionLoop("Loop", this, GS));
            AddGamePhase(new ActionSurfaceOverstacking("Overstacking", this, GS));
            AddGamePhase(new RemoveLocalDetection("Remove Local Detection", this, GS));
            AddGamePhase(new ActionGroupUnGroup("Post-Action Phase Group Management", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init()
        {
            FS.SIDE_NAMES.ForEach(n => SetBoolean("ACTION." + n, false));
            SetBoolean("ACTION.TACCOORD", false);
        }
        public override void End()
        {
            string report = "";
            foreach(GO obj in FS.CAPSQNS(GS, null)){
                obj.AIRMISSION = null;
                FS.RETURNTOHOMEBASE(obj);
                if(obj.DESTROYED){
                    report += obj.UNITTYPE + " " + obj.LABEL + " destroyed due to destroyed carrier or airfield\n";
                }
            }
            if(report != ""){
                MainWindow.Alert(report);
            }
        }
    }
    public class CAPAir : GamePhaseInteractive
    {
        string side = null;
        List<GO> ELIGIBLELIST = new();
        List<GO> CAPMISSIONS = new();
        public CAPAir(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                CAPMISSIONS.Clear();
                ELIGIBLELIST.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"ASSIGN AIR UNITS TO CAP"});
                GS.HELPTEXT = 
                "Allocate Air Units to CAP to the current Hex.  The game will enforce max 4 INT per airfield or carrier.\n\n" +
                "When done with your setup you can click the NEXT button.\n\n" +
                "NOTE: Due to complexity issues, this game will not use CAP markers.  The game will track all the units on CAP and consider all units in the same hex as on the same mission.  " + 
                "The physical game, using a marker to keep track of attacks left alot of loopholes when carriers are on the move and markers are breaking up and combining, so attacks are tracked per squadron, " + 
                "and the max number of attacks for a squadron in a stack is considered the stacks number.  Carrier based CAP squadrons will follow the ships as they move in the automated cycles";                
                foreach(GO obj in FS.TYPESIDE(GS, "SQN", side)){
                    if(!FS.CANLAUNCHCAP(obj)){continue;}
                    GS.InteractionMap.Add(obj, new());
                    ELIGIBLELIST.Add(obj);
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.AIRMISSION == null){
                    GS.AddAction(obj, "ASSIGN TO CAP");
                } else {
                    GS.AddAction(obj, "UNDO");
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        private void ADDTOCAP(GO gp, GO presentLoc){
            if(gp.CARRIERID != null){
                //if homebase is carrier, and carrier is damaged, move all other air units out of IM
                if(gp.CARRIER.DAMAGED){
                    foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.CARRIER)){
                        GS.REMOVEINTERACTIVE(obj);
                    }
                }
                gp.HOMEBASEID = gp.CARRIERID;
                gp.HOMEBASE = gp.CARRIER;
                FS.REMOVEFROMGROUP(gp, gp.HOMEBASE);
            } else if(gp.HOMEBASEID == null){
                gp.HOMEBASEID = gp.GAMELOCATIONID;
                gp.HOMEBASE = gp.GAMELOCATION;
            }
            GS.CHANGELOCATION(gp, presentLoc);
            CAPMISSIONS.Add(gp);
            gp.AIRMISSION = "CAP";
            //if 4 INT from homebase are in this group, move all other air units out of IM
            if(CAPMISSIONS.Where(n => n.UNITTYPE == "INT" && n.HOMEBASE == gp.HOMEBASE).Count() == 4){
                foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.HOMEBASE && n.UNITTYPE == "INT")){
                    GS.REMOVEINTERACTIVE(obj);
                }
            }
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    //do detections on assigned CAP
                    if(side != Get("ACTIVE.SIDE1")){
                        FS.AIRDETECTION(GS, new());
                        FS.AIRVSSURFACEDETECTION(GS);
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case "UNDO":
                    CAPMISSIONS.Remove(gp);
                    GO homeBase = gp.HOMEBASE;
                    if(homeBase != gp.GAMELOCATION){
                        //if homebase is carrier, and carrier is damaged, move all other air units back to interaction map
                        if(gp.HOMEBASE.DAMAGED){
                            foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.HOMEBASE)){
                                GS.InteractionMap.Add(obj, new());
                            }
                        //if now 3 INT from homebase are in this group, move all other air units back to IM
                        } else if(gp.UNITTYPE == "INT" && CAPMISSIONS.Where(n => n.UNITTYPE == "INT" && n.HOMEBASE == gp.HOMEBASE).Count() == 3){
                            foreach(GO obj in ELIGIBLELIST.Where(n => n.CARRIER == gp.HOMEBASE && n.UNITTYPE == "INT")){
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                        FS.ADDTOGROUP(gp, homeBase);
                    }                    
                    gp.HOMEBASEID = null;
                    gp.AIRMISSION = null;
                    Start(false);
                    break;
                case "ASSIGN TO CAP":
                    GO presentLoc = FS.PARENTGROUPLOCATION(gp);
                    ADDTOCAP(gp, presentLoc);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ReplenishmentBASE : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, List<GO>> PORTREPLENISHMENTASSIGNMENTS = new();
        Dictionary<GO, List<GO>> AIRFIELDREPLENISHMENTASSIGNMENTS = new();
        public ReplenishmentBASE(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                PORTREPLENISHMENTASSIGNMENTS.Clear();
                AIRFIELDREPLENISHMENTASSIGNMENTS.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"REPLENISH AT BASE"});
                GS.HELPTEXT = 
                "Replenishment, in-port.  The game enforces rules below:\n" + 
                "- Only docked ships can replenish\n" +
                "- Weather impacts.  No at-base replenishment in storm\n" +
                "- Max 4 ships can replenish at base per turn (max 1 CV or replenishment ship)\n" +
                "- CVs can replenish AIR SSM pts from port\n" +
                "- Damaged bases cannot replenish\n\n" +
                "NOTE: A configuration variable in the scenario file can be used to set when Cruise Missile reloads are available.  Every n turns, etc.\n\n" +
                "NOTE: Units giving or receiving replenishment will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Bases.                
                foreach(GO loc in FS.TYPESIDE(GS, "LOCATION", side).Where(n => (n.PORT || n.LOGSEA) && n.PORTDAMAGELEVEL == 0 && !FS.STORM(n))){
                    PORTREPLENISHMENTASSIGNMENTS.Add(loc, new());
                }
                //add airfields if CM reloads
                if(GetInt("CMRELOADS") > 0){
                    foreach(GO loc in FS.TYPESIDE(GS, "LOCATION", side).Where(n => (n.AIRFIELD || n.LOGAIR) && n.AIRFIELDDAMAGELEVEL == 0 && !FS.STORM(n))){
                        AIRFIELDREPLENISHMENTASSIGNMENTS.Add(loc, new());
                    }                
                    foreach(GO obj in FS.TYPESIDE(GS, "SQN", side).Where(n => n.ENROUTEDELAY == 0 &&
                        n.AIRMISSION == null &&
                        n.CMPTS < n.TEMPLATE.CMPTS)){
                        GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                        if(AIRFIELDREPLENISHMENTASSIGNMENTS.ContainsKey(locationToCheck)){
                            AIRFIELDREPLENISHMENTASSIGNMENTS[locationToCheck].Add(obj);
                            GS.InteractionMap.Add(obj, new());
                        }
                    }
                }                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.DOCKED && n.ENROUTEDELAY == 0)){
                    if(obj.UNITCATEGORY == "SUB"){
                        if(PORTREPLENISHMENTASSIGNMENTS.ContainsKey(obj.GAMELOCATION)){
                            if( obj.SSMPTS < obj.TEMPLATE.SSMPTS ||
                                obj.SSM2PTS < obj.TEMPLATE.SSM2PTS ||
                                obj.TORPPTS < obj.TEMPLATE.TORPPTS ||
                                (obj.CMPTS < obj.TEMPLATE.CMPTS && obj.CMRELOADS < GetInt("CMRELOADS"))){

                                PORTREPLENISHMENTASSIGNMENTS[obj.GAMELOCATION].Add(obj);
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    } else { 
                        GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                        if(PORTREPLENISHMENTASSIGNMENTS.ContainsKey(locationToCheck)){
                            if( obj.FUELPTS < obj.TEMPLATE.FUELPTS ||
                                obj.SSMPTS < obj.TEMPLATE.SSMPTS ||
                                obj.SSM2PTS < obj.TEMPLATE.SSM2PTS ||
                                obj.ASWPTS < obj.TEMPLATE.ASWPTS ||
                                obj.AAPTS < obj.TEMPLATE.AAPTS ||
                                obj.BOMBPTS < obj.TEMPLATE.BOMBPTS ||
                                obj.AIRSSMPTS < obj.TEMPLATE.AIRSSMPTS ||
                                obj.APTS < obj.TEMPLATE.APTS ||
                                obj.FPTS < obj.TEMPLATE.FPTS ||
                                (obj.CMPTS < obj.TEMPLATE.CMPTS && obj.CMRELOADS < GetInt("CMRELOADS"))){
                                
                                PORTREPLENISHMENTASSIGNMENTS[locationToCheck].Add(obj);
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    }
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys.ToList()){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "REPLENISH");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    foreach(GO loc in AIRFIELDREPLENISHMENTASSIGNMENTS.Keys){
                        loc.REPLENISHMENTPTSUSED = 0;
                        loc.LARGEUNITREPLENISHED = false;
                    }
                    foreach(GO loc in PORTREPLENISHMENTASSIGNMENTS.Keys){
                        loc.REPLENISHMENTPTSUSED = 0;
                        loc.LARGEUNITREPLENISHED = false;
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case "REPLENISH":
                    GO replenishmentBase = FS.PARENTGROUPLOCATION(gp);
                    replenishmentBase.REPLENISHMENTPTSUSED++;
                    gp.REPLENISHING = true;
                    if(gp.UNITCATEGORY == "AIR"){
                        int numCM = Math.Min(GetInt("CMRELOADS") - gp.CMPTS, gp.TEMPLATE.CMPTS);
                        gp.CMPTS += numCM;
                        gp.CMRELOADS += numCM;
                        //once we reach 4 no more from this base
                        if(replenishmentBase.REPLENISHMENTPTSUSED == 4){
                            foreach(GO obj in AIRFIELDREPLENISHMENTASSIGNMENTS[replenishmentBase].Where(n => n != gp)){
                                GS.REMOVEINTERACTIVE(obj);
                            }
                        }
                        GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    } else {
                        if(gp.TEMPLATE.APTS > 0 || gp.TEMPLATE.FPTS > 0){replenishmentBase.LARGEUNITREPLENISHED = true;}
                        int numCM = Math.Min(GetInt("CMRELOADS") - gp.CMPTS, gp.TEMPLATE.CMPTS);
                        gp.CMPTS += numCM;
                        gp.CMRELOADS += numCM;
                        gp.FUELPTS = gp.TEMPLATE.FUELPTS;
                        gp.SSMPTS = gp.TEMPLATE.SSMPTS;
                        gp.SSM2PTS = gp.TEMPLATE.SSM2PTS;
                        gp.ASWPTS = gp.TEMPLATE.ASWPTS;
                        gp.AAPTS = gp.TEMPLATE.AAPTS;
                        gp.TORPPTS = gp.TEMPLATE.TORPPTS;
                        gp.BOMBPTS = gp.TEMPLATE.BOMBPTS;
                        gp.AIRSSMPTS = gp.TEMPLATE.AIRSSMPTS;
                        gp.APTS = gp.TEMPLATE.APTS;
                        gp.FPTS = gp.TEMPLATE.FPTS;
                        //once we do a large no more large from this base
                        if(replenishmentBase.LARGEUNITREPLENISHED){
                            foreach(GO obj in PORTREPLENISHMENTASSIGNMENTS[replenishmentBase].Where(n => n != gp && (n.TEMPLATE.APTS > 0 || n.TEMPLATE.FPTS > 0))){
                                GS.REMOVEINTERACTIVE(obj);
                            }
                        }
                        //once we reach 4 no more from this base
                        if(replenishmentBase.REPLENISHMENTPTSUSED == 4){
                            foreach(GO obj in PORTREPLENISHMENTASSIGNMENTS[replenishmentBase].Where(n => n != gp)){
                                GS.REMOVEINTERACTIVE(obj);
                            }
                        }
                        GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    }
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ReplenishmentSEA : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, List<GO>> FUELREPLENISHMENTASSIGNMENTS = new();
        Dictionary<GO, List<GO>> AMMOREPLENISHMENTASSIGNMENTS = new();
        public ReplenishmentSEA(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FUELREPLENISHMENTASSIGNMENTS.Clear();
                AMMOREPLENISHMENTASSIGNMENTS.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE REPLENISHMENT OPTIONS"});
                GS.HELPTEXT = 
                "Replenishment, at-sea.  The game enforces rules below:\n" + 
                "- If a ship can replenish a certain type of ammo at-sea\n" +
                "- Weather impacts.  No at-sea in squall.\n" +
                "- Max total of 6 AP/FP pts a replenishment ship can provide in one phase.\n" +
                "- Use of BBs and US CVs as oilers\n" +
                "- Subs cannot replenish at sea.\n\n" +
                "NOTE: Units giving or receiving replenishment will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Ships.                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.ENROUTEDELAY == 0 && !n.DOCKED && !n.REPLENISHING && Get(n.GAMELOCATION.ZONE + ".WEATHER") == "CLEAR" &&
                    (n.FPTS > 0 || n.APTS > 0))){
                        
                    if(obj.FPTS > 0){
                        FUELREPLENISHMENTASSIGNMENTS.Add(obj, new());
                    }
                    if(obj.APTS > 0){
                        AMMOREPLENISHMENTASSIGNMENTS.Add(obj, new());
                    }
                }
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.UNITCATEGORY == "SURFACE" && n.ENROUTEDELAY == 0 && !n.DOCKED && !n.REPLENISHING)){
                    GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                    foreach(GO replenishment in FUELREPLENISHMENTASSIGNMENTS.Keys.Where(n => FS.PARENTGROUPLOCATION(n) == locationToCheck)){                                
                        if( (obj.FUELPTS < obj.TEMPLATE.FUELPTS && replenishment.FPTS > 0) ||
                            (obj.FPTS < obj.TEMPLATE.FPTS && replenishment.FPTS > 0)){
                            
                            FUELREPLENISHMENTASSIGNMENTS[replenishment].Add(obj);
                            if(!GS.InteractionMap.ContainsKey(obj)){
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    }
                    foreach(GO replenishment in AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => FS.PARENTGROUPLOCATION(n) == locationToCheck)){                                
                        if( (!obj.TEMPLATE.SSMPORTONLY && obj.SSMPTS < obj.TEMPLATE.SSMPTS && replenishment.APTS > 0) ||
                            (!obj.TEMPLATE.SSM2PORTONLY && obj.SSM2PTS < obj.TEMPLATE.SSM2PTS && replenishment.APTS > 0) ||
                            (obj.ASWPTS < obj.TEMPLATE.ASWPTS && replenishment.APTS > 0) ||
                            (obj.AAPTS < obj.TEMPLATE.AAPTS && replenishment.APTS > 0) ||
                            (obj.BOMBPTS < obj.TEMPLATE.BOMBPTS && replenishment.APTS > 0) ||
                            (obj.AIRSSMPTS < obj.TEMPLATE.AIRSSMPTS && replenishment.APTS > 0) ||
                            (obj.APTS < obj.TEMPLATE.APTS && replenishment.APTS > 0)){
                            
                            AMMOREPLENISHMENTASSIGNMENTS[replenishment].Add(obj);
                            if(!GS.InteractionMap.ContainsKey(obj)){
                                GS.InteractionMap.Add(obj, new());
                            }
                        }
                    }
                }
            }
            //for FP, can replenish all FUELPTS on a single ship
            //for FP, can replenish one FPT on a single ship
            //for AP, can replenish all non BOMB ammo
            //for AP, can replenish 1 BOMB pt
            //for AP, can replenish 1 AP pt 
            foreach(GO obj in GS.InteractionMap.Keys.ToList()){
                //check if obj is still in any assignment group
                Boolean presentInGroup = false;
                foreach(GO replenishment in FUELREPLENISHMENTASSIGNMENTS.Keys.Where(n => FUELREPLENISHMENTASSIGNMENTS[n].Contains(obj))){
                    presentInGroup = true;

                    GS.AddAction(obj, "FUEL/FP FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                }                    
                foreach(GO replenishment in AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => AMMOREPLENISHMENTASSIGNMENTS[n].Contains(obj))){
                    presentInGroup = true;
                    if( (!obj.TEMPLATE.SSMPORTONLY && obj.SSMPTS < obj.TEMPLATE.SSMPTS && replenishment.APTS > 0) ||
                        (!obj.TEMPLATE.SSM2PORTONLY && obj.SSM2PTS < obj.TEMPLATE.SSM2PTS && replenishment.APTS > 0) ||
                        (obj.ASWPTS < obj.TEMPLATE.ASWPTS && replenishment.APTS > 0) ||
                        (obj.AAPTS < obj.TEMPLATE.AAPTS && replenishment.APTS > 0) ||
                        (obj.AIRSSMPTS < obj.TEMPLATE.AIRSSMPTS && replenishment.APTS > 0)){

                        GS.AddAction(obj, "AMMO FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                    }

                    if( obj.BOMBPTS < obj.TEMPLATE.BOMBPTS && replenishment.APTS > 0){
                        GS.AddAction(obj, "1 BOMB PT FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                    }
                    if( obj.APTS < obj.TEMPLATE.APTS && replenishment.APTS > 0){
                        GS.AddAction(obj, "1 AP FROM : " + replenishment.UNITTYPE + " " + replenishment.LABEL);
                    }
                }                    
                if(!presentInGroup){
                    GS.InteractionMap.Remove(obj);
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case null:
                    Start(false);
                    break;
                case "NEXT":
                    foreach(GO obj in FUELREPLENISHMENTASSIGNMENTS.Keys){
                        obj.REPLENISHMENTPTSUSED = 0;
                    }
                    foreach(GO obj in AMMOREPLENISHMENTASSIGNMENTS.Keys){
                        obj.REPLENISHMENTPTSUSED = 0;
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                default:
                    gp.REPLENISHING = true;
                    string rID = null;
                    GO replenishmentShip = null;
                    if(pData.StartsWith("FUEL/FP FROM : ")){
                        rID = pData.Replace("FUEL/FP FROM : ", "");
                        replenishmentShip = FUELREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            FUELREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        if(gp.TEMPLATE.FPTS > 0){
                            gp.FPTS++;
                        } else {
                            gp.FUELPTS = gp.TEMPLATE.FUELPTS;
                        }
                        replenishmentShip.FPTS--;
                    } else if(pData.StartsWith("AMMO FROM : ")){
                        rID = pData.Replace("AMMO FROM : ", "");
                        replenishmentShip = AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            AMMOREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        if(!gp.TEMPLATE.SSMPORTONLY){
                            gp.SSMPTS = gp.TEMPLATE.SSMPTS;
                        }
                        if(!gp.TEMPLATE.SSM2PORTONLY){
                            gp.SSM2PTS = gp.TEMPLATE.SSM2PTS;
                        }
                        gp.ASWPTS = gp.TEMPLATE.ASWPTS;
                        gp.AAPTS = gp.TEMPLATE.AAPTS;
                        gp.AIRSSMPTS = gp.TEMPLATE.AIRSSMPTS;
                        replenishmentShip.APTS--;
                    } else if(pData.StartsWith("1 BOMB PT FROM : ")){
                        rID = pData.Replace("1 BOMB PT FROM : ", "");
                        replenishmentShip = AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            AMMOREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        gp.BOMBPTS++;
                        replenishmentShip.APTS--;
                    } else if(pData.StartsWith("1 AP FROM : ")){
                        rID = pData.Replace("1 AP FROM : ", "");
                        replenishmentShip = AMMOREPLENISHMENTASSIGNMENTS.Keys.Where(n => 
                            AMMOREPLENISHMENTASSIGNMENTS[n].Contains(gp) &&
                            (n.UNITTYPE + " " + n.LABEL) == rID).First();

                        replenishmentShip.REPLENISHMENTPTSUSED++;
                        replenishmentShip.REPLENISHING = true;
                        gp.APTS++;
                        replenishmentShip.APTS--;
                    }
                    if(AMMOREPLENISHMENTASSIGNMENTS.ContainsKey(replenishmentShip) && (replenishmentShip.APTS == 0 || replenishmentShip.REPLENISHMENTPTSUSED == 6)){
                        AMMOREPLENISHMENTASSIGNMENTS[replenishmentShip].Clear();
                    }
                    if(FUELREPLENISHMENTASSIGNMENTS.ContainsKey(replenishmentShip) && (replenishmentShip.FPTS == 0 || replenishmentShip.REPLENISHMENTPTSUSED == 6)){
                        FUELREPLENISHMENTASSIGNMENTS[replenishmentShip].Clear();
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);               
                    Start(false);
                    break;
            }
        }
    }
    public class Loading : GamePhaseInteractive
    {
        string side = null;
        public Loading(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"LOAD SHIPS"});
                GS.HELPTEXT = 
                "LOADING TROOPS/CARGO\n\n" + 
                "- Only docked ships can load\n" +
                "- Troops can be loaded in storms.  Supplies cannot\n" +
                "- Troops can be loaded from damaged bases.  Supplies cannot\n\n" +
                "NOTE: A configuration variable in the scenario file can be used to track troops/supplies at bases.  Currently it is set to FALSE and the logic to establish starting levels at locations is not built yet, so leave FALSE for now\n\n" +
                "NOTE: Units loading/unloading will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Bases.                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(FS.CANSHIPLOAD)){                            
                    GS.InteractionMap.Add(obj, new());
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys.ToList()){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "LOAD");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case "LOAD":
                    gp.LOADING = true;
                    gp.EMPTY = false;                    
                    GO replenishmentBase = FS.PARENTGROUPLOCATION(gp);
                    GO logisticalZone = GS.TYPE("POSSESSIONFLAG").Where(n => n.LOGISTICALZONE == replenishmentBase.LOGISTICALZONE).Single();
                    GO LANDCOMBAT = GS.TYPE("LANDCOMBAT").Where(n => n.SIDE == gp.SIDE && n.ATTACKER == null && n.DEFENDER == logisticalZone).SingleOrDefault();
                    if(FS.LANDWAR){
                        //find logistical zone marker
                        if(logisticalZone.SIDE == gp.SIDE){
                            if(FS.SURFACECARGOTYPES.Contains(gp.UNITTYPE)){
                                logisticalZone.SUPPLIES -= gp.TEMPLATE.SPECIAL;
                            } else {
                                logisticalZone.STRENGTH -= gp.TEMPLATE.SPECIAL;
                            }
                        } else {
                            //evac
                            LANDCOMBAT.STRENGTH -= gp.TEMPLATE.SPECIAL;
                        }
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class Unloading : GamePhaseInteractive
    {
        string side = null;
        public Unloading(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"UNLOAD SHIPS"});
                GS.HELPTEXT = 
                "UNLOADING TROOPS/CARGO\n\n" + 
                "- Troops can be unloaded in storms.  Supplies cannot\n\n" +
                "*Units loading/unloading will have a black bar indicator on the bottom of the marker";
                //get list of replenishment points.  Bases.                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(FS.CANSHIPUNLOAD)){                            
                    GS.InteractionMap.Add(obj, new());                    
                }
            }
            //foreach(GO obj in GS.InteractionMap.Keys.ToList()){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "UNLOAD");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case "UNLOAD":
                    GO unloadingPort = FS.PARENTGROUPLOCATION(gp);
                    gp.LOADING = true;
                    gp.EMPTY = true;
                    //find logistical zone marker
                    GO logisticalZone = FS.TYPESIDE(GS, "POSSESSIONFLAG", unloadingPort.SIDE).Where(n => n.LOGISTICALZONE == unloadingPort.LOGISTICALZONE).Single();
                    if(FS.SURFACECARGOTYPES.Contains(gp.UNITTYPE)){
                        if(logisticalZone.SIDE == gp.SIDE){
                            logisticalZone.SUPPLIES += gp.TEMPLATE.SPECIAL;
                        } else {
                            //find land combat
                            GO LANDCOMBAT = GS.TYPE("LANDCOMBAT").Where(n => n.SIDE == gp.SIDE && n.DEFENDER == logisticalZone && n.ATTACKER == null).FirstOrDefault();
                            if(LANDCOMBAT == null){
                                Dictionary<string, string> objData = new()
                                {
                                    ["ID"] = "INVASION" + GO.DELIM + logisticalZone.ID + GO.DELIM + "LANDCOMBAT" + GO.DELIM + FS.GENERATETIMESTAMP(),
                                    ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                    ["TYPE"] = "LANDCOMBAT"
                                };
                                LANDCOMBAT = new(GS, objData, null, null)
                                {
                                    ATTACKERID = null,
                                    ATTACKER = null,
                                    DEFENDERID = logisticalZone.ID,
                                    DEFENDER = logisticalZone,
                                    SIDE = gp.SIDE
                                };                    
                            }
                            LANDCOMBAT.SUPPLIES += gp.TEMPLATE.SPECIAL;
                        }
                    } else {
                        if(logisticalZone.SIDE == gp.SIDE){
                            logisticalZone.STRENGTH += gp.TEMPLATE.SPECIAL;
                        } else {
                            //find land combat
                            GO LANDCOMBAT = GS.TYPE("LANDCOMBAT").Where(n => n.SIDE == gp.SIDE && n.DEFENDER == logisticalZone && n.ATTACKER == null).FirstOrDefault();
                            if(LANDCOMBAT == null){
                                Dictionary<string, string> objData = new()
                                {
                                    ["ID"] = "INVASION" + GO.DELIM + logisticalZone.ID + GO.DELIM + "LANDCOMBAT" + GO.DELIM + FS.GENERATETIMESTAMP(),
                                    ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                    ["TYPE"] = "LANDCOMBAT"
                                };
                                LANDCOMBAT = new(GS, objData, null, null)
                                {
                                    ATTACKERID = null,
                                    ATTACKER = null,
                                    DEFENDERID = logisticalZone.ID,
                                    DEFENDER = logisticalZone,
                                    SIDE = gp.SIDE
                                };                    
                            }
                            LANDCOMBAT.STRENGTH += gp.TEMPLATE.SPECIAL;
                        }
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class LocalDetection : GamePhaseAutomated
    {
        public LocalDetection(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            Dictionary<GO, List<List<GO>>> DetectionRadius = FS.DETECTIONRADIUSTABLE(GS);
            //now detect
            foreach(GO obj in DetectionRadius.Keys){
                if(obj.LOCALDETECTED){continue;}
                GO loc = FS.PARENTGROUPLOCATION(obj);
                if(obj.UNITCATEGORY == "SURFACE"){
                    if(DetectionRadius.Keys.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Where(n => DetectionRadius[n][1].Contains(loc)).Any()){
                        FS.LOCALDETECT(FS.ALLSHIPSINHEX(obj.SIDE, loc, true, false), true);
                    }
                } else {
                    List<GO> detectors = DetectionRadius.Keys.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Where(n => DetectionRadius[n][2].Contains(loc)).ToList();
                    if(detectors.Sum(n => n.TEMPLATE.ASW) >= 6){
                        if(FS.SUBDETECTIONRESULT(obj, "LOCALDETECT", null, detectors) == "D"){
                            FS.LOCALDETECT(new(){obj}, true);
                        }
                    }
                }
            }
            GS.Advance(this);
        }
    }
    public class StrategicAirTacCoordinationLoop : GamePhaseLoop
    {
        public StrategicAirTacCoordinationLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new StrategicAirTacCoordination("Assignment", this, GS));
            AddGamePhase(new StrategicAirTacCoordinationChoice("Choose Target", this, GS));
            
        }
        public override Boolean ProcessCheck(){return !GetBoolean("ACTION.TACCOORD");}
    }
    public class StrategicAirTacCoordination : GamePhaseInteractive
    {
        string side = null;
        public StrategicAirTacCoordination(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            DragDrop = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG AIR UNIT TO TARGET HEX"});

                GS.HELPTEXT = 
                "Perform tactical coordination missions.  In this phase, drag eligible air units to detected enemy surface stacks or individual submarines in the aircraft's zone.\n\n" + 
                "For subs, the mission will be limited to a single sub, and the game will ask you to choose which sub, if there are multiple in the hex.\n" + 
                "-To assign to a submarine, the aircraft to have an ASW factor > 0\n" + 
                "-Enemy units within 4 hexes of friendly INT on non-damaged airfield will not be selectable\n\n" +
                "NOTE: After assigning the aircraft to a mission, instead of the air unit following the enemy around, the enemy units will have a black indicator on the left side of the marker to show the unit is the target of a tac coord mission.\n" +
                "NOTE: When selecting a unit, available locations on the map will have an indicator."; 
                List<GO> missionSQNs = FS.TYPESIDE(GS, "SQN", side).Where(n => n.GAMELOCATION.AIRMISSION == "STRATTACCOORD").ToList();
                List<string> missionZones = missionSQNs.Select(n => n.GAMELOCATION.ZONE).Distinct().ToList();
                //detected enemy
                List<GO> detectedEnemy = FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => (n.STRATDETECTED || n.LOCALDETECTED) && n.TACCOORDPIECEID == null).ToList();
                List<GO> missionLocs = detectedEnemy.Select(n => n.GAMELOCATION).Where(n => missionZones.Contains(n.ZONE)).Distinct().ToList();
                List<GO> missionLocsNoASW = detectedEnemy.Where(n => n.UNITCATEGORY == "SURFACE").Select(n => n.GAMELOCATION).Where(n => missionZones.Contains(n.ZONE)).Distinct().ToList();
                //find INTs on non-damaged airfields 
                List<GO> enemyINTLocations = new(); 
                foreach(GO obj in FS.TYPESIDE(GS, "SQN", FS.ENEMY(side)).Where(n =>
                n.UNITTYPE == "INT" && 
                n.ENROUTEDELAY == 0 &&
                (n.GAMELOCATION.AIRFIELD || n.HOMEBASE?.AIRFIELD == true) &&
                !(n.GAMELOCATION.AIRFIELDDAMAGELEVEL > 0 || n.HOMEBASE?.AIRFIELDDAMAGELEVEL > 0))){
                    enemyINTLocations.Add(FS.PARENTGROUPLOCATION(obj));
                }
                enemyINTLocations = enemyINTLocations.Distinct().ToList();
                foreach(GO loc in missionLocs.ToList()){
                    if(FS.FINDAIRRADIUS(loc, 4).Intersect(enemyINTLocations).Any()){
                        missionLocs.Remove(loc);
                        missionLocsNoASW.Remove(loc);
                    }
                }
                foreach(GO obj in missionSQNs){
                    if(obj.TEMPLATE.ASW > 0){
                        GS.InteractionMap.Add(obj, missionLocs.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList());
                    } else {
                        GS.InteractionMap.Add(obj, missionLocsNoASW.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(side != Get("ACTIVE.SIDE1")){SetBoolean("ACTION.TACCOORD", true);}
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, GS.TYPE("STRATRTBLOCATION", "ZONE", oldloc.ZONE).Single());
                        GO newloc = GS.LOCATION(gp.TEMPLOCATIONID);
                        Set("ACTION.TACCOORD.LOCATION", newloc.ID);
                        Set("ACTION.TACCOORD.UNIT", gp.ID);
                        GS.Advance(this);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class StrategicAirTacCoordinationChoice : GamePhaseInteractive
    {
        GO activatedUnit = null;
        string side = null;
        public StrategicAirTacCoordinationChoice(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                string activatedUnitId = Get("ACTION.TACCOORD.UNIT");
                if(activatedUnitId == null){
                    Update("NEXT");
                    return;
                }
                activatedUnit = GS.PIECE(activatedUnitId);              
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE TARGET"});

                GS.HELPTEXT = 
                "Choose which marker to assign the Tac Coordination air unit to.  Submarines are tracked individually.  Surface are tracked per hex, so all will be assigned.";  
                //detected enemy
                List<GO> detectedEnemy = FS.TYPESIDELOCATION(GS, "SHIP", FS.ENEMY(side), Get("ACTION.TACCOORD.LOCATION")).Where(n => (n.STRATDETECTED || n.LOCALDETECTED) && n.TACCOORDPIECE == null).ToList();
                List<GO> surfaceChoices = detectedEnemy.Where(n => n.UNITCATEGORY == "SURFACE").ToList();
                List<GO> subChoices = activatedUnit.TEMPLATE.ASW > 0 ? detectedEnemy.Where(n => n.UNITCATEGORY == "SUB").ToList() : new();

                if(surfaceChoices.Any() && !subChoices.Any()){
                    foreach(GO ship in surfaceChoices){
                        ship.TACCOORDPIECEID = activatedUnit.ID;
                        ship.TACCOORDPIECE = activatedUnit;
                        if(FS.ISGROUP(ship)){
                            foreach(GO ship2 in FS.GROUPMEMBERS(ship)){
                                ship2.TACCOORDPIECEID = activatedUnit.ID;
                                ship2.TACCOORDPIECE = activatedUnit;
                            }
                        }
                    }
                } else if(!surfaceChoices.Any() && subChoices.Count == 1){
                    GO ship = subChoices.First();
                    ship.TACCOORDPIECEID = activatedUnit.ID;
                    ship.TACCOORDPIECE = activatedUnit;
                } else {
                    foreach(GO ship in surfaceChoices){
                        GS.InteractionMap.Add(ship, new());
                    }
                    foreach(GO ship in subChoices){
                        GS.InteractionMap.Add(ship, new());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.UNITCATEGORY == "SUB"){
                    GS.AddAction(obj, "ASSIGN TO THIS SUB");
                } else {
                    GS.AddAction(obj, "ASSIGN TO ALL SURFACE UNITS IN THIS HEX");
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    Set("ACTION.TACCOORD.UNIT", null);
                    Set("ACTION.TACCOORD.LOCATION", null);
                    if(activatedUnit != null){
                        GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", activatedUnit.GAMELOCATION.ZONE).Single();
                        GS.CHANGELOCATION(activatedUnit, RTBLocation);
                    }
                    GS.Advance(this);
                    break;
                case "ASSIGN TO THIS SUB":
                    gp.TACCOORDPIECEID = activatedUnit.ID;
                    gp.TACCOORDPIECE = activatedUnit;
                    Update("NEXT");
                    break;
                case "ASSIGN TO ALL SURFACE UNITS IN THIS HEX":
                    foreach(GO ship in GS.InteractionMap.Keys.Where(n => n.UNITCATEGORY == "SURFACE")){
                        ship.TACCOORDPIECEID = activatedUnit.ID;
                        ship.TACCOORDPIECE = activatedUnit;
                        if(FS.ISGROUP(ship)){
                            foreach(GO ship2 in FS.GROUPMEMBERS(ship)){
                                ship2.TACCOORDPIECEID = activatedUnit.ID;
                                ship2.TACCOORDPIECE = activatedUnit;
                            }
                        }
                    }
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionGroupUnGroup : GamePhaseInteractive
    {
        string side = null;
        public ActionGroupUnGroup(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                FS.ADMIN = true;
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"MANAGE TF/TGs"});
                GS.HELPTEXT = 
                "This phase is your opportunity to combine, disband, and create TF/TGs\n\n" + 
                "- Units cannot be moved outside of their hex.\n" +
                "- Docked units cannot be merged with Un-docked units.\n" +
                "When done with your setup you can click the NEXT button";                
                foreach(GO unit in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.UNITCATEGORY == "SURFACE" && FS.CANSHIPGROUPUP(n))){
                    GS.InteractionMap.Add(unit, new());
                }
            }
            List<GO> SHIPTRAYLOCATIONS = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", FS.GRPSHEET.ID).Where(n => n.XCOORD < n.PARENTSHEET.IMAGEWIDTH && n.YCOORD < n.PARENTSHEET.IMAGEHEIGHT).ToList();
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                List<GO> targets = GS.InteractionMap[obj];
                targets.Clear();
                if(FS.ISGROUP(obj)){
                    GS.AddAction(obj, "DISBAND");
                } else {
                    targets.AddRange(SHIPTRAYLOCATIONS.Where(n => n.PARENTSHEET.SHEETPARENTPIECE?.GAMELOCATION == FS.PARENTGROUPLOCATION(obj) && n.PARENTSHEET.SHEETPARENTPIECE?.DOCKED == obj.DOCKED));
                    if(obj.GROUPID != null){
                        targets.Add(FS.PARENTGROUPLOCATION(obj));
                        GS.AddAction(obj, "LEAVE TF/TG");
                    } else {
                        GS.AddAction(obj, "CREATE TF/TG");
                    }
                }                                     

            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "CREATE TF/TG":
                    GO createdTG = FS.CREATEGROUP(GS, gp, gp.GAMELOCATIONID);
                    GS.InteractionMap.Add(createdTG, new());
                    createdTG.DOCKED = gp.DOCKED;
                    Start(false);
                    break;
                case "DISBAND":
                    GO firstMember = GS.TYPE(gp.TYPE, "GROUPID", gp.ID).FirstOrDefault();
                    FS.GROUPMEMBERS(gp).ForEach(n => GS.CHANGELOCATION(n, gp.GAMELOCATION));
                    FS.GROUPMEMBERS(gp).ForEach(n => FS.REMOVEFROMGROUP(n, gp));
                    FS.DISCARDTAGGED(gp);
                    if(firstMember != null){GS.SelectedMarker = firstMember;}
                    Start(false);
                    break;
                case "LEAVE TF/TG":
                    GS.CHANGELOCATION(gp, FS.PARENTGROUPLOCATION(gp));
                    FS.REMOVEFROMGROUP(gp, gp.GROUP);
                    Start(false);
                    break;
                case "NEXT":
                    FS.ADMIN = false;
                    foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.GRPTYPE == "TFTGGRP")){
                        FS.UPDATEGROUP(obj);
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        GO newloc = gp.GAMELOCATION;                        
                        if(oldloc.TYPE != "TRAYLOCATION" && newloc.TYPE == "TRAYLOCATION"){
                            GO newsheet = newloc.PARENTSHEET;
                            GO newgroup = newsheet.SHEETPARENTPIECE;
                            FS.ADDTOGROUP(gp, newgroup);
                        } else if(oldloc.TYPE == "TRAYLOCATION" && newloc.TYPE != "TRAYLOCATION"){
                            gp.PARENTSHEETID = null;
                            GO oldsheet = oldloc.PARENTSHEET;
                            GO oldgroup = oldsheet.SHEETPARENTPIECE;
                            FS.REMOVEFROMGROUP(gp, oldgroup);
                        } else if(oldloc.TYPE == "TRAYLOCATION" && newloc.TYPE == "TRAYLOCATION" && newloc.PARENTSHEET == FS.GRPSHEET){
                            GO newsheet = newloc.PARENTSHEET;
                            List<GO> grouptraylocations = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", newsheet.ID);
                            int oldindex = grouptraylocations.IndexOf(oldloc);
                            int newindex = grouptraylocations.IndexOf(newloc);
                            for(int i = 0; i < Math.Abs(oldindex - newindex); i++){
                                if(oldindex < newindex){
                                    FS.MOVEDOWNINGROUP(GS, gp, gp.GROUP);
                                } else {
                                    FS.MOVEUPINGROUP(GS, gp, gp.GROUP);
                                }
                            }
                        }
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionLoop : GamePhaseLoopLogic
    {
        public ActionLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionActivation("ACTIVATION", this, GS));
            AddGamePhase(new ActionAirEnemyInterceptionLoop("CAP INTERCEPT", this, GS));
            AddGamePhase(new ActionSegment("SEGMENT", this, GS));         
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION." + n)).Any();}
        public override void Init()
        {
            foreach(string s in FS.SIDE_NAMES){
                SetBoolean("ACTION.ACTIVATION." + s, false);
                SetInt("ACTION.MOVES." + s, 0);
                SetInt("ACTION.COMBATS." + s, 0);
            }
            SetInt("ACTION.CYCLES", 0);
        }
        public override void End()
        {
            foreach(string s in FS.SIDE_NAMES){
                int numMoves = GetInt("ACTION.MOVES." + s);
                int numCombats = GetInt("ACTION.COMBATS." + s);
                GS.SetBoolean("ACTION." + s, numMoves == 0 && numCombats == 0);
            }
            if(!ProcessCheck()){
                //remove any activation groups that may remain
                foreach(string s in FS.SIDE_NAMES){
                    foreach(GO group in FS.ACTIVATIONMARKERS(GS, s)){
                        FS.GROUPMEMBERS(group).ForEach(n => GS.CHANGELOCATION(n, group.GAMELOCATION));
                        FS.GROUPMEMBERS(group).ForEach(n => FS.REMOVEFROMGROUP(n, group));
                        FS.DISCARDTAGGED(group);
                    }
                }
                foreach(GO obj in GS.TYPE("PIECE").Where(n => (n.TYPE == "SHIP" || n.TYPE == "SQN") && FS.SIDE_NAMES.Contains(n.SIDE))){
                    FS.REMOVESCENARIOOBJECT(GS, obj, false);
                    obj.ACTIVATED = false;
                    obj.DONE = false;
                    obj.REPLENISHING = false;
                    obj.LOADING = false;
                    obj.ACTIVATEDAIRUNITS = 0;
                    obj.LOCATIONHISTORY = null;
                    if(!(FS.ISGROUP(obj) || obj.UNITCATEGORY == "SUB")){
                        obj.LOCATIONFUTURE = null;
                    }
                    obj.NUMCOMBATS = 0; 
                    obj.DONEASW = false;
                    obj.DONESSM = false;
                    obj.DONECM = false;
                    obj.ADMINDETECTED = false;
                    obj.ROLE = null;
                    //reset movement allowance
                    obj.USEDFUEL = obj.USEDFUEL || obj.HEXESTRAVELLED > 2;
                    obj.HEXESTRAVELLED = 0;
                    obj.ATTACKEDBYAIR = false;
                    obj.ATTACKEDBYSURFACE = false; 
                    obj.DETECTIONATTEMPTED = false;
                    obj.TACCOORDPIECEID = null;  
                    obj.EXTENDEDRANGE = false;
                    obj.HIGHMISSIONPROFILE = false;
                    obj.AERIALREFUELING = false; 
                    if(obj.UNITCATEGORY == "AIR"){ 
                        //reset air unit ammo
                        obj.CM = 0;
                        obj.SSM = 0;
                        obj.SSMPTS = 0;
                        obj.SPECIAL = 0;
                        obj.BOMBPTS = 0;    
                    }
                    if(obj.UNITCATEGORY == "SUB" || Get("TURN.TYPE") == "NIGHT"){
                        obj.FULLSPEED = false;
                    }
                }
                GS.LOGICS().ForEach(FS.DISCARDLOGIC);
                MainWindow.Alert("No units with orders or movement points remaining.  Action Segment is over.");
            }
        }
    }
    public class ActionActivation : GamePhaseLoop
    {
        public ActionActivation(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionActivationLoop("Loop", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION.ACTIVATION." + n)).Any();}
        public override void Init(){}
        public override void End()
        {
            string side = Get("ACTIVE.SIDE");
            if(side == GS.Get("ACTIVE.SIDE1")){
                Set("ACTIVE.SIDE", FS.ENEMY(side));
            } else {
                Set("ACTIVE.SIDE1", side);
                List<GO> alreadyActivated = FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED");
                List<GO> activated = GS.PIECES().Where(n => n.SIDE != null && n.ACTIVATED && !n.DONE && (FS.ISGROUP(n) || n.UNITCATEGORY == "SUB")).ToList();
                FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIVATED", activated);
                List<GO> checkInterception = activated.Where(n => !alreadyActivated.Contains(n) && n.TYPE == "SQN").ToList();
                FS.AIRDETECTION(GS, checkInterception);
                FS.AIRVSSURFACEDETECTION(GS);
                FS.SURFACEVSAIRTARGETING(GS);
            }
        }
    }  

    public class ActionActivationLoop : GamePhaseLoopLogic
    {
        public ActionActivationLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionActivateStack("Activate Stack", this, GS)); 
            AddGamePhase(new ActionAirINTRole("AIR INT Role", this, GS));
            AddGamePhase(new ActionAirMidAirRefueling("AIR Assign Mid-Air Refueling", this, GS));
            AddGamePhase(new ActionAirFlightOptions("AIR Range Options", this, GS));
            AddGamePhase(new ActionAirAmmoSelection("AIR Ammo Selection", this, GS));
            AddGamePhase(new ActionSubFullSpeed("SUB Full Speed", this, GS));
        }
        public override Boolean ProcessCheck(){return !GetBoolean("ACTION.ACTIVATION." + Get("ACTIVE.SIDE"));}
        public override void Init(){}
        public override void End(){
            List<GO> FULLSPEEDDETECTORS = GS.TYPE("SHIP").Where(n => n.SIDE != null && n.GAMELOCATION.TYPE == "HEX").ToList();
            foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATING")){
                obj.ACTIVATED = true;
                obj.MOVEMENTALLOWANCE = FS.RESETMOVEMENTALLOWANCE(obj);
                if(FS.ISGROUP(obj) || obj.UNITCATEGORY == "SUB"){
                    obj.LOCATIONHISTORY = obj.GAMELOCATIONID;
                    obj.LOCATIONFUTURE ??= obj.GAMELOCATIONID;
                    if(FS.ISGROUP(obj)){
                        FS.UPDATEGROUP(obj);
                        obj.DOCKED = false;
                        FS.GROUPMEMBERS(obj).ForEach(n => n.DOCKED = false);
                    }
                    if(obj.UNITCATEGORY == "SUB" && obj.FULLSPEED && !obj.STRATDETECTED){
                        if(FS.FINDAIRRADIUS(obj.GAMELOCATION, 5).Intersect(FULLSPEEDDETECTORS.Where(n => n.SIDE == FS.ENEMY(obj.SIDE))).Any()){
                            FS.STRATDETECT(new(){obj}, true);
                        }
                    }
                    if(obj.DESTINATIONPIECEID == null){
                        //create destination marker
                        //add attempt marker
                        GO template = GS.PIECE("ACTION.DESTINATION");
                        GO clone = FS.CLONE(GS, template, obj.GAMELOCATIONID);
                        clone.SIDE = obj.SIDE;
                        obj.DESTINATIONPIECEID = clone.ID;
                        obj.DESTINATIONPIECE = clone;
                        clone.GAMEPIECEID = obj.ID;
                        clone.GAMEPIECE = obj;
                        GS.ShuffleMarkerToBottom(clone);
                    }
                } else if(FS.LOGICALPARENT(obj) != obj){
                    FS.UPDATEGROUP(FS.LOGICALPARENT(obj));
                }
            }
            FS.CLEARSCENARIOVAR(GS, "ACTION.ACTIVATING");
        }
    }            
    public class ActionActivateStack : GamePhaseInteractive
    {
        List<GO> ACTIVATIONCANDIDATES = new();
        GO activatingUnit = null;
        GO activationGroup = null;
        string side = null;
        public ActionActivateStack(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                activatingUnit = null;
                activationGroup = null;
                ACTIVATIONCANDIDATES.Clear();
                FS.SETINSTRUCTIONS(GS, new(){"ADD UNITS TO ACTIVATION GROUP", "ACTIVATE UNITS"});

                GS.HELPTEXT = 
                "Activation.  In this phase, you will select the unit(s) that you want to activate.  Options:\n\n" + 
                "- SURFACE:  If its a TF/TG, all you can do is ACTIVATE it\n" +
                "- SURFACE:  If a free Ship, Game will continue to allow you to add units from the same hex, max 12 combat units, then ACTIVATE the group\n" +
                "- SUB:  all you can do is ACTIVATE\n" +
                "- AIR:  Game will continue to allow you to add units from the same hex, then ACTIVATE the group.  Max 4 INT/ATK/BMB\n\n" +
                "NOTE: You do NOT have to do all activations at this time.  the Game will allow you to activate more groups after these groups being moving/attacking\n\n" +
                "NOTE: You'll notice some DESTINATION markers being created as you activate units.  These will be used during the Orders phase to give units a path to go on\n\n" +
                "NOTE: To skip or whenever finished activating, hit NEXT Button\n\n" +
                "ENDING THE ACTION PHASE:  The open-ended Action Phase this game uses now has no distinct end.  You aren't forced to activate all your units at the beginning, and you could intentionally pause orders to wait to see what the enemy does.  " + 
                "So, the Action Phase will AUTOMATICALLY END when all activated units have no more movement points or no standing orders. So if you are activating units but not giving them someplace to go or something to do, the Action Phase may end, so keep that in mind\n\n";
                ACTIVATIONCANDIDATES.AddRange(FS.TYPESIDE(GS, "SQN", side).Where(n => FS.CANLAUNCHACTIVATE(n)));
                ACTIVATIONCANDIDATES.AddRange(FS.TYPESIDE(GS, "SHIP", side).Where(n => FS.CANSHIPACTIVATE(n) && n.GROUPID == null));

                List<GO> activationGrps = ACTIVATIONCANDIDATES.Where(n => n.GRPTYPE == "ACTIVATIONGRP" && !n.ACTIVATED).ToList();
                if(activationGrps.Any()){
                    GO group = activationGrps.First();
                    GS.InteractionMap.Add(group, new());
                    activationGroup = group;
                    foreach(GO obj in ACTIVATIONCANDIDATES.Where(n => !n.ACTIVATED && n.UNITCATEGORY == group.UNITCATEGORY && !FS.ISGROUP(n) && FS.PARENTGROUPLOCATION(n) == group.GAMELOCATION)){
                        GS.InteractionMap.Add(obj, new());
                    }
                } else {
                    foreach(GO obj in ACTIVATIONCANDIDATES.Where(n => !n.ACTIVATED)){
                        GS.InteractionMap.Add(obj, new());
                    }
                }
            }
            FS.GETNEXTSELECTED(GS);
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, FS.ISGROUP(obj) || obj.UNITCATEGORY == "SUB" ? "ACTIVATE" : activationGroup == null ? "CREATE ACTIVATION GROUP" : "ADD TO ACTIVATION GROUP");
                if(obj.GRPTYPE == "ACTIVATIONGRP" && GS.InteractionMap.Count == 1){
                    Update("ACTIVATE");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    bool valid = true;
                    if(activatingUnit != null){
                        //check validity of units
                        if(activatingUnit.UNITCATEGORY == "AIR"){
                            if(activatingUnit.CARRIER?.DAMAGED == true && activatingUnit.CARRIER?.ACTIVATEDAIRUNITS == 1){
                                MainWindow.Alert("Exceeding max number of air units activated from damaged Carrier.");
                                valid = false;
                            }
                        }
                        if(valid){
                            GO obj = activatingUnit;
                            GO loc = FS.PARENTGROUPLOCATION(obj);
                            List<GO> activatingUnits = new();
                            if(FS.ISGROUP(obj)){
                                activatingUnits.Add(obj);
                                foreach(GO obj2 in FS.GROUPMEMBERS(obj).Where(n => !n.ACTIVATED)){
                                    activatingUnits.Add(obj2);
                                }
                            } else if(obj.UNITCATEGORY == "SUB"){
                                activatingUnits.Add(obj);
                            } else {
                                if(obj.UNITCATEGORY == "AIR"){
                                    GO homebase = obj.CARRIER ?? obj.GAMELOCATION;
                                    obj.HOMEBASEID = homebase.ID;
                                    obj.HOMEBASE = homebase;
                                    if(obj.CARRIER != null){
                                        obj.HOMEBASE.ACTIVATEDAIRUNITS++;
                                        FS.REMOVEFROMGROUP(obj, obj.CARRIER);
                                    }
                                }
                                if(activationGroup == null){
                                    FS.CREATEACTIVATIONGROUP(obj, loc.ID);
                                } else {
                                    FS.ADDTOGROUP(obj, activationGroup);
                                }
                                activatingUnits.Add(obj);
                            }
                            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIVATING", activatingUnits);
                            SetBoolean("ACTION.ACTIVATION." + side, false);
                            FS.SETNEXTSELECTED(GS.NEXT(ACTIVATIONCANDIDATES.Where(n => !n.ACTIVATED).ToList(), gp));
                            GS.Advance(this);
                        } else {
                            GS.SelectedMarker = GS.REMOVEINTERACTIVE(activatingUnit);
                            activatingUnit = null;
                            Start(false);
                        }
                    } else if(activationGroup != null){
                        activatingUnit = activationGroup;
                        Update("NEXT");
                    } else {
                        //pass
                        SetBoolean("ACTION.ACTIVATION." + side, true);
                        FS.SETNEXTSELECTED(GS.NEXT(ACTIVATIONCANDIDATES.Where(n => !n.ACTIVATED).ToList(), gp));
                        GS.Advance(this);
                    }
                    break;
                case "ACTIVATE":
                    activatingUnit = gp;
                    Update("NEXT");
                    break;
                case "CREATE ACTIVATION GROUP":
                case "ADD TO ACTIVATION GROUP":
                    activatingUnit = gp;
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionGenerateCombats : GamePhaseAutomated
    {
        public ActionGenerateCombats(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }            
        public override void Execute(Boolean init){
            List<GO> combats = new();
            foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED")){
                GO combat = GS.LOGICS().Where(n => FS.COMBATMISSIONTYPES.Contains(n.TYPE)).Where(n => n.ATTACKER == obj && n.ATTACKERLOCATION == obj.GAMELOCATION).SingleOrDefault();
                if(combat != null){
                    combats.Add(combat);
                    IncrementInt("ACTION.COMBATS." + obj.SIDE, 1);
                }
            }
            FS.COMBATMISSIONTYPES.ForEach(n => FS.SETSCENARIOOBJECTS(GS, "ACTION." + n + "COMBAT", combats.Where(n2 => n2.TYPE == n).ToList()));
            GS.Advance(this);           
        }
    }
    public class ActionSegment : GamePhaseLoopLogic
    {
        public ActionSegment(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionOrdersLoop("Loop", this, GS));
            AddGamePhase(new ActionCombat("COMBAT MISSIONS", this, GS));
            AddGamePhase(new ActionAirMovement("AIR", this, GS));
            AddGamePhase(new ActionShipMovement("SHIP", this, GS));
            
        }
        public override Boolean ProcessCheck(){return GetInt("ACTION.CYCLES") < 10;}
        public override void Init(){
            FS.SIDE_NAMES.ForEach(n => SetBoolean("ACTION.ORDERS." + n, false));
        }
        public override void End()
        {            
            IncrementInt("ACTION.CYCLES", 1);
        }
    }  
    public class ActionOrdersLoop : GamePhaseLoopLogic
    {
        public ActionOrdersLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionOrders("Orders", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION.ORDERS." + n)).Any();}
        public override void Init()
        {
            //throw new NotImplementedException();
        }
        public override void End()
        {
            string side = Get("ACTIVE.SIDE");
            if(side == GS.Get("ACTIVE.SIDE1")){
                Set("ACTIVE.SIDE", FS.ENEMY(side));
            } else {
                Set("ACTIVE.SIDE1", side);
            }
            SetBoolean("ACTION.ORDERS." + side, true);
        }
    }
    public class ActionOrders : GamePhaseInteractive
    {
        List<GO> ACTIONABLE = new();
        List<GO> ENEMYUNITS = new();
        Dictionary<GO, Dictionary<string, List<GO>>> TARGETS = new();
        List<GO> SSMSCOPE = new();
        List<GO> BOMBSCOPE = new();
        List<GO> CMSCOPE = new();
        List<GO> ASWSCOPE = new();
        List<GO> TORPSCOPE = new();
        List<GO> AAASCOPE = new();
        List<GO> CCSCOPE = new();
        List<GO> COMBATS = new();
        List<GO> SURFACETOAIRS = new();
        string COMBATMODE = null;
        GO attackingUnit = null;
        Dictionary<GO, List<FSMovement>> MOVEMENTFUTURES = new();
        Dictionary<GO, List<FSMovement>> MOVEMENTCHOICES = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> ATTACKDATA = new();                                    
        string side = null;
        bool firstCycle = false;
        public ActionOrders(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            DragOver = true;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                FS.ORDERS = true;
                side = Get("ACTIVE.SIDE");
                ACTIONABLE.Clear();
                ENEMYUNITS.Clear();
                COMBATS.Clear();
                TARGETS.Clear();
                ATTACKDATA.Clear();
                COMBATMODE = null;
                attackingUnit = null;
                MOVEMENTFUTURES.Clear();
                MOVEMENTCHOICES.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG UNIT TO GIVE MOVEMENT ORDERS", "DESIGNATE ATTACKS ALONG THE WAY"});
                GS.HELPTEXT = 
                "ORDERS\n\n" + 
                "Give orders to units, which will be EXECUTED AFTERWARDS by automation. A total of 10 automated cycles will run after this phase.  During those, the automation will move air units a hex at a time.  Halfway through those, the surface/sub units will move.  The automation will continue until either a new enemy detection occurs or an air unit reaches its current destination\n\n" + 
                "Trace the path that will be followed by the unit. You can make it as long as you like.  Units will remember this path and you'll have opportunities to adjust it after the automation runs.  If not interrupted as described above, up to 10 air hexes and/or 1 surface/sub hex will be processed\n\n" + 
                "At the units current location, you can designate attacks.  The game will allow you to designate the target hex/unit/facility only.  Further combat actions like allocations will be given at run-time during the automation cycle. AIR/SUBs can only execute at most 1 attack.  SURFACE can execute up to 2 different types of attacks per TURN (not counting AAA attacks if that option is enabled)\n\n" + 
                "LANDING AIR:  during the automation, if the unit flies over it's homebase, it will automatically land. You CAN choose to land the air unit at another base, if the air unit is actually over the base currently.  Only non-carrier units can do this and after landing they have to go through " +
                "a delay of " + GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER") + " turns (configurable)\n\n" +
                "DOCKING: only can be done at the units actual location.  If the surface/sub unit is in a port and all units have enough movement points\n\n" +
                "STACKING: AIR rules are enforced at real-time. SURFACE is handled slightly differently. Since ships are constantly moving, stacking will be enforced after all movements are completed in the turn. " + 
                "IF surface ships violate the Stacking Limit (max of 12 combat units per hex), you will have to destroy units to get under the limit.  The automation will interrupt to warn you of hexes that are overstacked." + 
                " Ensure that by the end of all activations and movements, no hexes are in violation\n\n" +
                "Be careful on your path.  During automation, your air units will be interrupted by enemy CAP, or if your path is too long, any air units with 0 allowance remaining will be lost\n\n" + 
                "*DESTINATION markers: The game will place a Destination marker where you give orders for a unit to move.  This marker can be used to both trace the path the unit will take\n\n" +
                "ENDING THE ACTION PHASE:  The open-ended Action Phase this game uses now has no distinct end.  You aren't forced to activate all your units at the beginning, and you could intentionally pause orders to wait to see what the enemy does.  " + 
                "So, the Action Phase will AUTOMATICALLY END when all activated units have no more movement points or no standing orders. So if you are activating units but not giving them someplace to go or something to do, the Action Phase may end, so keep that in mind\n\n" + 
                "NO AIR LOITERING:  Air units must always have orders, so the game will require you to give all active air units a path to fly each time around the cycle\n\n" +
                "CONTINUING ORDERS: TF/TGs will keep record of their destination into the next turn, so long routes will be remembered.  Temporary Activation Groups will disband at the end of the Action Phase";  
                List<GO> objs = FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED").Where(n => 
                    n.SIDE == side).ToList();
                ENEMYUNITS.AddRange(FS.TYPESIDE(GS, "PIECE", FS.ENEMY(side)).Where(n => n.ENROUTEDELAY == 0 && (n.STRATDETECTED || n.LOCALDETECTED || (n.UNITTYPE == "BASE" && !FS.STORM(n.GAMELOCATION) && ((n.PORT && !n.PORTDESTROYED) || (n.AIRFIELD && !n.AIRFIELDDESTROYED))))));
                AAASCOPE = FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED").Where(n => 
                    n.SIDE == FS.ENEMY(side) && n.UNITCATEGORY == "AIR" && n.ADMINDETECTED).ToList();
                SURFACETOAIRS = GS.TYPE("SURFACETOAIR").Where(n => n.ATTACKER.SIDE == side).ToList();                
                foreach(GO obj in objs){
                    ACTIONABLE.Add(obj);
                    GS.InteractionMap.Add(obj, new());
                    MOVEMENTCHOICES.Add(obj, new());
                    ACTIONABLE.Add(obj.DESTINATIONPIECE);
                    GS.InteractionMap.Add(obj.DESTINATIONPIECE, new());
                    MOVEMENTCHOICES.Add(obj.DESTINATIONPIECE, new());
                    GENERATEFUTURES(obj);
                }
                SSMSCOPE = ENEMYUNITS.Where(n => !n.DOCKED && n.UNITCATEGORY == "SURFACE").ToList();
                BOMBSCOPE = ENEMYUNITS.Where(n => n.UNITCATEGORY == "SURFACE" || (n.UNITTYPE == "BASE" && n.GAMELOCATION.TYPE == "HEX")).ToList();
                CMSCOPE = ENEMYUNITS.Where(n => n.UNITTYPE == "BASE").ToList();
                CCSCOPE = ENEMYUNITS.Where(n => n.UNITCATEGORY == "SURFACE" || n.UNITTYPE == "BASE").ToList();
                ASWSCOPE = ENEMYUNITS.Where(n => (n.UNITCATEGORY == "SURFACE" && n.TEMPLATE.AAA > 0) || n.UNITCATEGORY == "SUB").ToList();
                TORPSCOPE = ENEMYUNITS.Where(n => !n.DOCKED && n.UNITCATEGORY == "SURFACE").ToList();
                COMBATS = GS.LOGICS().Where(n => FS.COMBATMISSIONTYPES.Contains(n.TYPE)).ToList();
                firstCycle = GetInt("ACTION.CYCLES") == 0;
            }
            if(init){
                bool interrupt = GS.GetBoolean("ACTION.DINTERRUPT." + side) || GS.GetBoolean("ACTION.AAINTERRUPT." + side);
                if(!firstCycle){
                    //attempt to auto through
                    GS.SelectedMarker = CANADVANCE(false);
                    bool moveOn = GS.SelectedMarker == null && !interrupt;
                    if(moveOn){
                        FS.ORDERS = false;
                        GS.Advance(this);
                        return;
                    } else if(GS.SelectedMarker != null){
                        FS.ORDERSINTERRUPT(GS, side, true);
                    }
                }
            }
            FS.SETINSTRUCTIONS(GS, new(){"CYCLE:" + GetInt("ACTION.CYCLES"), "DRAG UNIT TO GIVE MOVEMENT ORDERS", "GIVE OTHER ORDERS FROM UNIT CURRENT LOCATION"});
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.SIDE == side){
                    GO actualUnit = obj.TYPE == "DESTINATION" ? obj.GAMEPIECE : obj;
                    GO destinationMarker = obj.TYPE == "DESTINATION" ? obj : obj.DESTINATIONPIECE;
                    if(obj != attackingUnit){GS.AddAction(obj, obj == actualUnit ? ">>DESTINATION" : ">>ACTUAL");}
                    List<GO> combats = COMBATS.Where(n => n.ATTACKER == actualUnit).ToList();
                    int numCombats = combats.Where(n => n.TYPE != "AAA").Count() + actualUnit.NUMCOMBATS;
                    bool qualifiesForDone = obj.UNITCATEGORY switch{
                        "AIR" => false,
                        "SUB" => actualUnit.NUMCOMBATS > 0 && actualUnit.MOVEMENTALLOWANCE == 0,
                        "SURFACE" => actualUnit.NUMCOMBATS > 1 && actualUnit.MOVEMENTALLOWANCE == 0,
                        _ => false
                    };
                    List<FSMovement> movements = MOVEMENTFUTURES[actualUnit];
                    double plannedDistance = movements.Where(n => n.MOVEMENTCONNECTOR != null).Sum(n => n.DISTANCE);
                    double delay = actualUnit.ENROUTEDELAY;
                    
                    double remaining = actualUnit.MOVEMENTALLOWANCE - plannedDistance - delay;
                    remaining = actualUnit.UNITCATEGORY switch{
                        "AIR" => remaining,
                        _ => Math.Max(0, remaining)
                    };
                    actualUnit.REMAININGMOVEMENT = actualUnit.DRAGGING? remaining : actualUnit.MOVEMENTALLOWANCE;
                    destinationMarker.REMAININGMOVEMENT = remaining;
                    //show future moves as they are being added
                    if(movements.Count > 1){
                        string color = destinationMarker.REMAININGMOVEMENT < 0 ? "RED" : "WHITE";
                        for(int i = 1; i < movements.Count; i++){
                            FSMovement movement = movements[i];
                            movement.MOVEMENTCONNECTOR.MakeLineVisible(color, true);
                        }
                    }
                    GO actualLocation = movements.First().MOVEMENTLOCATION;
                    if(attackingUnit == obj){
                        GS.AddAction(obj, "CANCEL ATTACK");
                        switch(COMBATMODE){
                            case "BOMB":
                            case "CC":
                                if(TARGETS[obj][COMBATMODE].Where(n => n.UNITCATEGORY == "SURFACE").Any()){GS.AddAction(obj, "TARGET SHIPS");}
                                if(TARGETS[obj][COMBATMODE].Where(n => n.AIRFIELD && !n.AIRFIELDDESTROYED).Any()){GS.AddAction(obj, "TARGET AIRFIELD");}
                                if(TARGETS[obj][COMBATMODE].Where(n => n.PORT && !n.PORTDESTROYED).Any()){GS.AddAction(obj, "TARGET PORT");}
                                break;
                            default:
                                break;
                        }
                    } else {
                        List<GO> groupMembers = FS.GROUPMEMBERS(actualUnit);
                        GS.InteractionMap[obj].Clear();
                        if(obj == destinationMarker || (obj.GAMELOCATION == destinationMarker.GAMELOCATION && movements.Count == 1) || obj.DRAGGING){
                            List<FSMovement> choices = actualUnit.UNITCATEGORY switch {
                                "AIR" => FS.FINDAIRMOVEMENTS(obj.GAMELOCATION),
                                "SUB" => FS.FINDSUBMOVEMENTS(obj, obj.GAMELOCATION),
                                "SURFACE" => FS.FINDSURFACEMOVEMENTS(obj, obj.GAMELOCATION),
                                _ => new()
                            }; 
                            MOVEMENTCHOICES[obj] = choices;                       
                            GS.InteractionMap[obj].AddRange(choices.Select(n => n.MOVEMENTLOCATION));
                            foreach(FSMovement m in choices){
                                if(m.MOVEMENTLOCATION.TYPE == "OM"){
                                    m.LABEL = "To Off Map Airfield";
                                    GS.AddAction(obj, m.LABEL);
                                }
                                if(m.MOVEMENTLOCATION.TERRAIN == "OMAF"){
                                    m.LABEL = "To " + m.MOVEMENTLOCATION.ZONE + " ZONE";
                                    GS.AddAction(obj, m.LABEL);
                                }
                                if(obj.UNITCATEGORY == "AIR" && obj.RECONMODE && m.DISTANCE == 1){
                                    m.DISTANCE *= (int)Math.Floor(Math.Max(1, GetDouble("_CONFIG_AIR_RECON_MODE_MOVE_COST_MULTIPLIER")));
                                }
                            }
                        }
                        if(!obj.DRAGGING){
                            if(obj.GAMELOCATION == actualLocation && obj == actualUnit){
                                if(actualUnit.UNITCATEGORY == "AIR"){
                                    if(groupMembers.Where(n => n.HOMEBASE.AIRFIELD && n.HOMEBASE != obj.GAMELOCATION).Any()){
                                        if(actualLocation.SIDE == actualUnit.SIDE && actualLocation.AIRFIELD && actualLocation.AIRFIELDDAMAGELEVEL == 0){
                                            GS.AddAction(obj, "TRANSFER NON-CARRIER UNITS TO THIS AIRFIELD");
                                        }
                                    }
                                    GS.AddAction(obj, "TURN RECON MODE " + (obj.RECONMODE ? "OFF" : "ON"));
                                } else {
                                    if(actualLocation.PORT){
                                        if(actualLocation.SIDE == actualUnit.SIDE){
                                            if(!groupMembers.Where(n => !FS.CANDOCK(n)).Any()){

                                                GS.AddAction(obj, "DOCK");
                                            }
                                        }
                                    }
                                }
                                if(!TARGETS.ContainsKey(actualUnit)){
                                    TARGETS.Add(actualUnit, new());
                                    Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers);
                                    attackData.Keys.ToList().ForEach(n => ATTACKDATA.Add(n, attackData[n]));
                                }
                                Dictionary<string, bool> allowable = combats.Any() ? new() : new()
                                {
                                    {
                                        "SSM",
                                        actualUnit.UNITCATEGORY switch
                                        {
                                            "SURFACE" => !(actualUnit.DONESSM || numCombats >= 2),
                                            _ => numCombats == 0
                                        }
                                    },
                                    {
                                        "CC",
                                        actualUnit.UNITCATEGORY switch
                                        {
                                            "SURFACE" => !actualUnit.DONECC,
                                            _ => false
                                        }
                                    },
                                    {
                                        "CM",
                                        actualUnit.UNITCATEGORY switch
                                        {
                                            "SURFACE" => !(actualUnit.DONECM || numCombats >= 2),
                                            _ => numCombats == 0
                                        }
                                    },
                                    {
                                        "ASW",
                                        actualUnit.UNITCATEGORY switch
                                        {
                                            "SURFACE" => !(actualUnit.DONEASW || numCombats >= 2),
                                            _ => numCombats == 0
                                        }
                                    },
                                    {
                                        "BOMB",
                                        actualUnit.UNITCATEGORY switch
                                        {
                                            "AIR" => numCombats == 0,
                                            _ => false
                                        }
                                    },
                                    {
                                        "TORP",
                                        actualUnit.UNITCATEGORY switch
                                        {
                                            "SUB" => numCombats == 0,
                                            _ => false
                                        }
                                    },
                                    {
                                        "AAA",
                                        actualUnit.UNITCATEGORY switch
                                        {
                                            "SURFACE" => FS.AIRSURFACEINTERACTION,
                                            _ => false
                                        }
                                    }
                                };
                                if(allowable.Values.Where(n => n).Any() && !FS.STORM(obj.GAMELOCATION)){
                                    foreach(string ct in FS.COMBATMISSIONTYPES.Where(n => allowable[n])){
                                        if(!TARGETS[actualUnit].ContainsKey(ct)){
                                            TARGETS[actualUnit].Add(ct, new());
                                            if(ATTACKDATA.Keys.Where(groupMembers.Contains).Where(n => ATTACKDATA[n].Values.Where(n => n.ContainsKey(ct)).Any()).Any()){
                                                TARGETS[actualUnit][ct].AddRange(GETTARGETS(actualUnit, ct));
                                            }
                                        }
                                        if(TARGETS[actualUnit][ct].Any()){
                                            GS.AddAction(obj, ct + " ATTACK");
                                        }
                                    }
                                }
                            }
                            if(combats.Any() || movements.Count > 1){
                                GS.AddAction(obj, "RESET ORDERS");
                            }
                            if(qualifiesForDone){
                                GS.AddAction(obj, "DESIGNATE AS DONE");
                            }
                        }
                    }
                } else {
                    switch(COMBATMODE){
                        case "SSM":
                        case "TORP":
                        case "AAA":
                            GS.AddAction(obj, "TARGET THIS LOCATION");
                            break;
                        case "CM":
                            if(obj.AIRFIELD && !obj.AIRFIELDDESTROYED){GS.AddAction(obj, "TARGET AIRFIELD");}
                            if(obj.PORT && !obj.PORTDESTROYED){GS.AddAction(obj, "TARGET PORT");}
                            break;
                        case "ASW":
                            GS.AddAction(obj, "TARGET");
                            break;
                        default:
                            break;
                    }

                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){
                FS.SETVIEW(GS);
            }
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            GO actualUnit = null;
            GO destinationMarker = null;
            if(gp != null){
                actualUnit = gp.TYPE == "DESTINATION" ? gp.GAMEPIECE : gp;
                destinationMarker = gp.TYPE == "DESTINATION" ? gp : gp.DESTINATIONPIECE;
                if(attackingUnit != null){
                    actualUnit = attackingUnit.TYPE == "DESTINATION" ? attackingUnit.GAMEPIECE : attackingUnit;
                    destinationMarker = attackingUnit.TYPE == "DESTINATION" ? attackingUnit : attackingUnit.DESTINATIONPIECE;
                }
            }
            switch(pData){
                case ">>DESTINATION":
                case ">>ACTUAL":
                    GS.SelectedMarker = gp == actualUnit ? destinationMarker : actualUnit;
                    Start(false);
                    break;
                case "NEXT":
                    if(attackingUnit != null){
                        MainWindow.Alert("You must either choose your attack or cancel first");
                        Start(false);
                    } else {
                        GO errorGO = CANADVANCE(true);
                        if(errorGO == null){
                            FS.ORDERS = false;
                            GS.Advance(this);
                        } else {
                            GS.SelectedMarker = errorGO;
                            Start(false);
                        }
                    }
                    break;
                case "TURN RECON MODE ON":
                case "TURN RECON MODE OFF":
                    gp.RECONMODE = !gp.RECONMODE;
                    //recalc pathing
                    GENERATEFUTURES(gp);
                    Start(false);
                    break;
                case "DOCK":
                    CLEARORDERS(actualUnit);
                    actualUnit.DONE = true;
                    bool isActivationGrp = actualUnit.GRPTYPE == "ACTIVATIONGRP";
                    foreach(GO obj in FS.GROUPMEMBERS(actualUnit)){
                        obj.DOCKED = true;
                        obj.DONE = true;
                        FS.REMOVESCENARIOOBJECT(GS, obj, true);
                        if(isActivationGrp){
                            obj.GAMELOCATION = actualUnit.GAMELOCATION;
                            FS.REMOVEFROMGROUP(obj, actualUnit);
                        }
                    }
                    if(!isActivationGrp){
                        actualUnit.DOCKED = true;
                        FS.REMOVESCENARIOOBJECT(GS, actualUnit, false);
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(actualUnit);
                    Start(false);
                    break;
                case "DESIGNATE AS DONE":
                    actualUnit.DONE = true;
                    isActivationGrp = actualUnit.GRPTYPE == "ACTIVATIONGRP";
                    foreach(GO obj in FS.GROUPMEMBERS(actualUnit)){
                        obj.DONE = true;
                        FS.REMOVESCENARIOOBJECT(GS, obj, obj.UNITCATEGORY != "SUB");
                        if(isActivationGrp){
                            obj.GAMELOCATION = actualUnit.GAMELOCATION;
                            FS.REMOVEFROMGROUP(obj, actualUnit);
                        }
                    }
                    if(!isActivationGrp){
                        FS.REMOVESCENARIOOBJECT(GS, actualUnit, false);
                    }
                    GS.REMOVEINTERACTIVE(destinationMarker);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(actualUnit);
                    Start(false);
                    break;
                case "TARGET SHIPS":
                case "TARGET AIRFIELD":
                case "TARGET PORT":
                    Dictionary<string, string> objData = new()
                    {
                        ["ID"] = actualUnit.ID + GO.DELIM + COMBATMODE + GO.DELIM + FS.GENERATETIMESTAMP(),
                        ["DOMAIN"] = GO.DOMAIN_LOGIC,
                        ["TYPE"] = COMBATMODE
                    };
                    GO combat = new(GS, objData, null, null)
                    {
                        ATTACKERID = actualUnit.ID,
                        ATTACKER = actualUnit,
                        ATTACKERLOCATIONID = attackingUnit.GAMELOCATIONID,
                        ATTACKERLOCATION = attackingUnit.GAMELOCATION,
                        DEFENDERLOCATIONID = attackingUnit.GAMELOCATIONID,
                        DEFENDERLOCATION = attackingUnit.GAMELOCATION,
                        LABEL = pData.Replace("TARGET ", ""),
                        SIDE = actualUnit.SIDE
                    };
                    if(COMBATMODE == "BOMB" || COMBATMODE == "CC"){
                        if(combat.LABEL != "SHIPS"){
                            GO target = TARGETS[actualUnit][COMBATMODE].Where(n => n.UNITTYPE == "BASE").Single();
                            combat.DEFENDERID = target.ID;
                            combat.DEFENDER = target;
                        }
                    } else {
                        GO target = gp;
                        combat.DEFENDERID = target.ID;
                        combat.DEFENDER = target;
                    }
                    GO template = GS.PIECE("ACTION.TARGET");
                    GO clone = FS.CLONE(GS, template, attackingUnit.GAMELOCATIONID);
                    clone.LABEL = COMBATMODE;
                    clone.SIDE = side;
                    combat.GAMEPIECEID = clone.ID;
                    combat.GAMEPIECE = clone;
                    clone.GAMEPIECEID = combat.ID;
                    clone.GAMEPIECE = combat;
                    COMBATS.Add(combat);
                    Update("RETURN TO MOVE MODE");
                    break;
                case "TARGET THIS LOCATION":
                    objData = new()
                    {
                        ["ID"] = actualUnit.ID + GO.DELIM + COMBATMODE + GO.DELIM + FS.GENERATETIMESTAMP(),
                        ["DOMAIN"] = GO.DOMAIN_LOGIC,
                        ["TYPE"] = COMBATMODE
                    };
                    combat = new(GS, objData, null, null)
                    {
                        ATTACKERID = actualUnit.ID,
                        ATTACKER = actualUnit,
                        ATTACKERLOCATIONID = attackingUnit.GAMELOCATIONID,
                        ATTACKERLOCATION = attackingUnit.GAMELOCATION,
                        DEFENDERLOCATIONID = gp.GAMELOCATIONID,
                        DEFENDERLOCATION = gp.GAMELOCATION,
                        DISTANCE = FS.FINDAIRMOVEMENTPATH(attackingUnit.GAMELOCATION, gp.GAMELOCATION).Sum(n => n.DISTANCE),
                        SIDE = actualUnit.SIDE
                    };
                    template = GS.PIECE("ACTION.TARGET");
                    clone = FS.CLONE(GS, template, attackingUnit.GAMELOCATIONID);
                    clone.LABEL = COMBATMODE;
                    clone.SIDE = side;
                    combat.GAMEPIECEID = clone.ID;
                    combat.GAMEPIECE = clone;
                    clone.GAMEPIECEID = combat.ID;
                    clone.GAMEPIECE = combat;
                    COMBATS.Add(combat);
                    GS.ShuffleMarkerToBottom(clone);
                    Update("RETURN TO MOVE MODE");
                    break;
                case "TARGET":
                    objData = new()
                    {
                        ["ID"] = actualUnit.ID + GO.DELIM + COMBATMODE + GO.DELIM + FS.GENERATETIMESTAMP(),
                        ["DOMAIN"] = GO.DOMAIN_LOGIC,
                        ["TYPE"] = COMBATMODE
                    };
                    combat = new(GS, objData, null, null)
                    {
                        ATTACKERID = actualUnit.ID,
                        ATTACKER = actualUnit,
                        ATTACKERLOCATIONID = attackingUnit.GAMELOCATIONID,
                        ATTACKERLOCATION = attackingUnit.GAMELOCATION,
                        DEFENDERLOCATIONID = gp.GAMELOCATIONID,
                        DEFENDERLOCATION = gp.GAMELOCATION,
                        DEFENDERID = gp.ID,
                        DEFENDER = gp,
                        DISTANCE = FS.FINDAIRMOVEMENTPATH(attackingUnit.GAMELOCATION, gp.GAMELOCATION).Sum(n => n.DISTANCE),
                        SIDE = actualUnit.SIDE
                    };
                    template = GS.PIECE("ACTION.TARGET");
                    clone = FS.CLONE(GS, template, attackingUnit.GAMELOCATIONID);
                    clone.LABEL = COMBATMODE;
                    clone.SIDE = side;
                    combat.GAMEPIECEID = clone.ID;
                    combat.GAMEPIECE = clone;
                    clone.GAMEPIECEID = combat.ID;
                    clone.GAMEPIECE = combat;
                    COMBATS.Add(combat);
                    Update("RETURN TO MOVE MODE");
                    break;
                case "RESET ORDERS":
                    CLEARORDERS(actualUnit);
                    Start(false);
                    break;
                case "CANCEL ATTACK":
                case "RETURN TO MOVE MODE":
                    GS.InteractionMap.Clear();
                    ACTIONABLE.ForEach(n => GS.InteractionMap.Add(n, new()));
                    GS.SelectedMarker = attackingUnit;
                    COMBATMODE = null;
                    attackingUnit = null;
                    Start(false);
                    break;
                case "SSM ATTACK":
                case "CM ATTACK":
                case "TORP ATTACK":
                case "ASW ATTACK":
                case "AAA ATTACK":
                    COMBATMODE = pData.Replace(" ATTACK","");
                    attackingUnit = gp;
                    GS.InteractionMap.Clear();
                    TARGETS[actualUnit][COMBATMODE].ForEach(n => GS.InteractionMap.Add(n, new()));
                    GS.InteractionMap.Add(gp, new());
                    GS.SelectedMarker = TARGETS[actualUnit][COMBATMODE].First();
                    Start(false);
                    break;
                case "BOMB ATTACK":
                case "CC ATTACK":
                    COMBATMODE = pData.Replace(" ATTACK","");
                    attackingUnit = gp;
                    GS.InteractionMap.Clear();
                    GS.InteractionMap.Add(gp, new());
                    Start(false);
                    break;
                case "TRANSFER NON-CARRIER UNITS TO THIS AIRFIELD":
                    CLEARORDERS(actualUnit);
                    List<GO> landingAir = FS.GROUPMEMBERS(actualUnit).Where(n => n.HOMEBASE.AIRFIELD).ToList();
                    //attempt to land, if no room throw error
                    GO airfield = actualUnit.GAMELOCATION;
                    if(landingAir.Where(n => !FS.STRATEGICCOUNTRIES[airfield.ORGLEVEL1].Contains(n.COUNTRY) && n.COUNTRY != airfield.COUNTRY).Any()){
                        MainWindow.Alert("Air Units are not able to land in this country");
                        Start(false);
                        break;
                    }
                    List<GO> airUnits = FS.TYPESIDELOCATION(GS, "SQN", actualUnit.SIDE, airfield.ID);
                    airUnits.AddRange(FS.TYPESIDE(GS, "SQN", actualUnit.SIDE).Where(n => n.HOMEBASE == airfield));
                    airUnits.AddRange(landingAir);
                    if(FS.CANSTACKAIR(airUnits)){
                        foreach(GO sqn in landingAir){
                            if(airfield != sqn.HOMEBASE){
                                //transfer, so add delay
                                sqn.ENROUTEDELAY = GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER");
                                sqn.HOMEBASEID = airfield.ID;
                                sqn.HOMEBASE = airfield;
                            }
                            FS.REMOVEFROMGROUP(sqn, actualUnit);
                            FS.RETURNTOHOMEBASE(sqn);
                            FS.REMOVESCENARIOOBJECT(GS, sqn, true);
                            sqn.DONE = !sqn.DESTROYED;
                        }
                        Start(false);
                    } else {
                        MainWindow.Alert("Airbase does not have enough capacity");
                        Start(false);
                    }
                    break;
                case null:
                    if(gp.DRAGGING){
                        if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                            GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                            GO newloc = gp.GAMELOCATION;
                            List<FSMovement> movementPath = MOVEMENTFUTURES[actualUnit];
                            movementPath.Add(MOVEMENTCHOICES[gp].Where(n => n.MOVEMENTLOCATION == newloc).Single());
                        }
                        Start(false);
                    } else if(actualUnit.SIDE == side){
                        FSMovement firstMovement = MOVEMENTFUTURES[actualUnit].First();
                        GO initialLocation = firstMovement.MOVEMENTLOCATION;
                        if(gp.GAMELOCATION != initialLocation){
                            if(gp == actualUnit){
                                GS.CHANGELOCATION(destinationMarker, gp.GAMELOCATION);
                                GS.CHANGELOCATION(actualUnit, initialLocation);
                                GS.SelectedMarker = destinationMarker;
                            }
                            actualUnit.LOCATIONFUTURE = string.Join('|', MOVEMENTFUTURES[actualUnit].Select(n => n.MOVEMENTLOCATIONID));
                        }
                        Start(false);
                    }
                    break;
                default:
                    FSMovement immediateMovement = MOVEMENTCHOICES[gp].Where(n => n.LABEL == pData).SingleOrDefault();
                    if(immediateMovement != null){
                        if(gp == actualUnit){
                            FSMovement firstMovement = MOVEMENTFUTURES[actualUnit].First();
                            GO initialLocation = firstMovement.MOVEMENTLOCATION;
                            GS.CHANGELOCATION(destinationMarker, immediateMovement.MOVEMENTLOCATION);
                            GS.CHANGELOCATION(actualUnit, initialLocation);
                            GS.SelectedMarker = destinationMarker;
                        } else {
                            GS.CHANGELOCATION(gp, immediateMovement.MOVEMENTLOCATION);
                        }
                        //construct tmp array until you hit the new loc
                        List<FSMovement> movementPath = MOVEMENTFUTURES[actualUnit];
                        movementPath.Add(immediateMovement);
                        actualUnit.LOCATIONFUTURE = string.Join('|', MOVEMENTFUTURES[actualUnit].Select(n => n.MOVEMENTLOCATIONID));                        
                    }
                    Start(false);
                    break;
            }            
        }
        private List<GO> GETTARGETS(GO actualUnit, string combatType){
            return combatType switch{
                "SSM" => FS.SSMTARGETS(actualUnit, SSMSCOPE, ATTACKDATA),
                "CM" => FS.CMTARGETS(actualUnit, CMSCOPE, ATTACKDATA),
                "BOMB" => FS.BOMBTARGETS(actualUnit, BOMBSCOPE, ATTACKDATA),
                "TORP" => FS.TORPTARGETS(actualUnit, TORPSCOPE),
                "ASW" => FS.ASWTARGETS(actualUnit, ASWSCOPE),
                "AAA" => FS.AAATARGETS(actualUnit, AAASCOPE, SURFACETOAIRS.Where(n => FS.LOGICALPARENT(n.ATTACKER) == actualUnit).ToList(), ATTACKDATA),
                "CC" => FS.CCTARGETS(actualUnit, CCSCOPE, ATTACKDATA),
                _ => new()
            };
        }
        private void CLEARORDERS(GO actualUnit){
            foreach(GO obj in COMBATS.Where(n => n.ATTACKER == actualUnit).ToList()){
                FS.DISCARDLOGIC(obj);
                COMBATS.Remove(obj);
            }
            FSMovement firstMovement = MOVEMENTFUTURES[actualUnit].First();
            GS.CHANGELOCATION(actualUnit.DESTINATIONPIECE, firstMovement.MOVEMENTLOCATION);
            actualUnit.LOCATIONFUTURE = firstMovement.MOVEMENTLOCATIONID;
            MOVEMENTFUTURES[actualUnit] = new(){firstMovement};
        }
        private GO CANADVANCE(bool alert){
            GO returnGO = null;
           //confirm all active air units have a planned path
            List<GO> INACTIVEAIR = GS.InteractionMap.Keys
                .Where(n => n.UNITCATEGORY == "AIR" && n.ENROUTEDELAY == 0)
                .Where(n => !MOVEMENTFUTURES.ContainsKey(n) || MOVEMENTFUTURES[n].Count == 1).ToList();

            if(INACTIVEAIR.Any()){
                if(alert){MainWindow.Alert("Air unit has no movement orders");}
                returnGO = INACTIVEAIR.First();
            }
            return returnGO;
        }
        private void GENERATEFUTURES(GO obj){
            string[] locations = obj.LOCATIONFUTURE.Split('|');
            MOVEMENTFUTURES.Remove(obj);
            //generate futures
            List<FSMovement> ms = new(){
                new(){
                    MOVEMENTLOCATIONID = locations[0],
                    MOVEMENTLOCATION = GS.LOCATION(locations[0])
                }
            };
            for(int i = 1; i < locations.Length; i++){
                string f = locations[i - 1];
                string t = locations[i];
                GO connector = GS.TYPE("UNITMOVEMENT" , "CONNECTORLOCATIONID", f).Where(n => n.CONNECTORLOCATION2ID == t).FirstOrDefault();
                ms.Add(
                    new(){
                        MOVEMENTLOCATIONID = locations[i],
                        MOVEMENTLOCATION = GS.LOCATION(locations[i]),
                        MOVEMENTCONNECTORID = connector.ID,
                        MOVEMENTCONNECTOR = connector,
                        DISTANCE = Math.Max(1, connector.DISTANCE) * (obj.RECONMODE && connector.DISTANCE <= 1 ? (int)Math.Floor(Math.Max(1, GetDouble("_CONFIG_AIR_RECON_MODE_MOVE_COST_MULTIPLIER"))) : 1)
                    }
                );
            }
            MOVEMENTFUTURES.Add(obj, ms);
        }
    }
    public class ActionCombat : GamePhaseGroupLogic
    {
        public ActionCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionGenerateCombats("Calculate", this, GS));
            AddGamePhase(new ActionCCCombat("CC", this, GS));
            AddGamePhase(new ActionAAACombat("AAA", this, GS));
            AddGamePhase(new ActionBOMBCombat("BOMB", this, GS));
            AddGamePhase(new ActionTORPCombat("TORP", this, GS));
            AddGamePhase(new ActionASWCombat("ASW", this, GS));
            AddGamePhase(new ActionSSMCombat("SSM", this, GS));
            AddGamePhase(new ActionCMCombat("CM", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init()
        {
            //throw new NotImplementedException();
        }
        public override void End()
        {
            //apply damages
            foreach(GO obj in GS.PIECES().Where(n => n.UNAPPLIEDDAMAGE > 0)){
                int unapplied = obj.UNAPPLIEDDAMAGE;
                obj.UNAPPLIEDDAMAGE = 0;
                for(int i = 0; i < unapplied && !obj.DESTROYED; i++){
                    FS.DAMAGE(obj);
                }
            }
            foreach(GO obj in GS.LOCATIONS().Where(n => n.UNAPPLIEDPORTDAMAGE > 0)){
                int unapplied = obj.UNAPPLIEDPORTDAMAGE;
                obj.UNAPPLIEDPORTDAMAGE = 0;
                for(int i = 0; i < unapplied && !obj.PORTDESTROYED; i++){
                    FS.DAMAGEBASE(obj, "PORT");
                }
            }
            foreach(GO obj in GS.LOCATIONS().Where(n => n.UNAPPLIEDAIRFIELDDAMAGE > 0)){
                int unapplied = obj.UNAPPLIEDAIRFIELDDAMAGE;
                obj.UNAPPLIEDAIRFIELDDAMAGE = 0;
                for(int i = 0; i < unapplied && !obj.AIRFIELDDESTROYED; i++){
                    FS.DAMAGEBASE(obj, "AIRFIELD");
                }
            }
        }
    }
}