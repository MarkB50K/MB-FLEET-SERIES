using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
namespace CWApp.FS
{    
    public class ActionAAACombat : GamePhaseLoopLogic
    {
        public ActionAAACombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionAAACombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionAAACombatOffensiveFire("Offensive Fire", this, GS));
            AddGamePhase(new ActionAAACombatShipsPicksCasualties("Pick Casualties", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOLOGICS(GS, "ACTION.AAACOMBAT").Any();}
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.AAACOMBAT");
            GO firstcombat = combats.First();
            List<GO> combined_combats = new(){firstcombat};
            if(FS.COMBINEDATTACKS){
                combined_combats = combats.Where(n => n.SIDE == firstcombat.SIDE && n.DEFENDERLOCATION == firstcombat.DEFENDERLOCATION).ToList();
            }
            List<GO> attackingUnits = combined_combats.Select(n => n.ATTACKER).ToList();
            Set("ACTIVE.SIDE", attackingUnits.First().SIDE);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIONING", attackingUnits);
            combats.RemoveAll(n => combined_combats.Contains(n));
            FS.SETSCENARIOOBJECTS(GS, "ACTION.AAACOMBAT", combats);
            List<GO> defenders = FS.TYPESIDELOCATION(GS, "SQN", FS.ENEMY(firstcombat.SIDE), firstcombat.DEFENDERLOCATIONID).Where(n => 
                n.ENROUTEDELAY == 0 &&
                n.ACTIVATED &&
                n.ADMINDETECTED).ToList();
            
            List<GO> attackers = new();
            if(defenders.Any() && !FS.STORM(firstcombat.DEFENDERLOCATION)){
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", defenders);
                foreach(GO combat in combined_combats){
                    GO attackingUnit = combat.ATTACKER;
                    //determine which attackers can reach this range
                    List<GO> groupMembers = FS.GROUPMEMBERS(attackingUnit);
                    groupMembers.ForEach(n => n.ADMINDETECTED = true);
                    Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers, "AAA");
                    double range = combat.DISTANCE;                   
                    foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                        if(attackData[obj].ContainsKey("AAA")){
                            if(attackData[obj]["AAA"].Values.Max(n=> n["RANGE"]) >= range){
                                attackers.Add(obj);
                            }
                        }
                    }
                    foreach(GO a in attackers){
                        foreach(GO d in defenders){
                            //add logic
                            Dictionary<string, string> clonedData = new()
                            {
                                ["ID"] = a.ID + GO.DELIM + d.ID + GO.DELIM + FS.GENERATETIMESTAMP(),
                                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                ["TYPE"] = "SURFACETOAIR"
                            };
                            GO interception = new(GS, clonedData, null, null)
                            {
                                ATTACKERID = a.ID,
                                ATTACKER = a,
                                INTERCEPTEDGRPID = d.ID,
                                INTERCEPTEDGRP = d
                            };
                        }
                    }
                }
            }
            string reason = "";
            if(!attackers.Any()){reason = "no units able to attack";}
            if(!defenders.Any()){reason = "no viable targets in target location";}
            if(reason != ""){
                MainWindow.Alert("Planned " + firstcombat.SIDE + " " + firstcombat.TYPE + " combat not possible: " + reason);
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", attackers);
            combined_combats.ForEach(FS.DISCARDLOGIC);                       
        }
        public override void End()
        {
            FS.REMOVECOMBATSHEET();
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionAAACombatDeclaration : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, Dictionary<string, double>> ATTACKS = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> ATTACKDATA = new();
        public ActionAAACombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                ATTACKS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE SHIPS THAT WILL PARTICIPATE"});
                GS.HELPTEXT = 
                "AAA COMBAT DECLARATION.  Declare which units you will attack with\n\n" + 
                "When done with your allocation you can click the NEXT button.  The combat will resolved\n\n" + 
                "*This is a new combat type enabled by automation.  AA ammo will be used, and it will use the similar concept as defensive fire in BOMB combat include modifiers etc.";                
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ATTACKER")){
                    GS.InteractionMap.Add(obj, new());
                }
                ATTACKDATA = FS.ATTACKDATA(GS.InteractionMap.Keys.ToList(), "AAA");
            }
            FS.SETINSTRUCTIONS(GS, new(){"ALLOCATE AAA POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"])});
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "USE AAA");
                if(GS.InteractionMap.Count == 1 && !ATTACKS.Any()){
                    Update("USE AAA");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(ATTACKS.Any() || !GS.InteractionMap.Any()){
                        //collect attack data
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", ATTACKS.Keys.ToList());
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        GS.Advance(this);
                    } else {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE AAA":
                    gp.AAPTS--;
                    //possibly adjust point value.
                    //if LAA and range <= 1 multiply by 6
                    GO defender = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").First();
                    int distance = FS.FINDAIRMOVEMENTPATH(FS.PARENTGROUPLOCATION(gp), FS.PARENTGROUPLOCATION(defender)).Sum(n => n.DISTANCE);
                    if(distance <= 1 && (gp.TEMPLATE.LAA || gp.TEMPLATE.MAA)){
                        Dictionary<string, double> data = ATTACKDATA[gp]["AAA"]["AAA"];
                        data["PTS"] *= gp.TEMPLATE.LAA ? 6 : 3;
                    }
                    ATTACKS.Add(gp, ATTACKDATA[gp]["AAA"]["AAA"]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionAAACombatOffensiveFire : GamePhaseAutomated
    {
        public ActionAAACombatOffensiveFire(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            SetInt("ACTION.DEFENSEMODIFIER", 0);
            //any losses to attacking aircraft
            SetInt("ACTION.ATTACKERLOSSES", 0);
            SetInt("ACTION.DEFENDERLOSSES", 0);
            List<GO> sqns = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            List<GO> aaShips = FS.SCENARIOUNITS(GS, "ACTION.ATTACKER");
            if(sqns.Any()){
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                List<GO> actioningGroups = FS.SCENARIOUNITS(GS, "ACTION.ACTIONING");
                GO defenseLocation = sqns.First().GAMELOCATION;
                string report = "AAA COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                
                //combine AA values
                int combinedAAValue = GetInt("ACTION.PTS");
                report += "TOTAL AA = " + combinedAAValue + "\n\n";
                int defenseModifier = 0;
                int rollModifier = 0;
                if(combinedAAValue > 0){
                    if(aaShips.Where(n => n.GROUP?.UNITTYPE == "TF").Any()){
                        rollModifier += 2;
                        report += "TF: Roll +2\n";
                    }
                    if(!aaShips.Where(n => n.GROUP != null).Any()){
                        rollModifier -= 4;
                        report += "NO TG/TF: Roll -4\n";
                    }
                    if(FS.GROUPSANDMEMBERS(sqns).Where(n => n.UNITTYPE == "EW").Any()){
                        rollModifier -= 2;
                        report += "EW: Roll -2\n";
                    }
                    if(FS.GROUPSANDMEMBERS(sqns).Where(n => n.HIGHMISSIONPROFILE).Any()){
                        rollModifier += 2;
                        report += "HIGH MISSION PROFILE: Roll + 2\n";
                    }
                    report += "ATTACK ROLL MODIFIER: " + rollModifier + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + rollModifier) + "\n";
                    dieRoll += rollModifier;
                    defenseModifier = FS.COMBATRESULTSTABLE(false, dieRoll, combinedAAValue);
                }
                SetInt("ACTION.DEFENSEMODIFIER", defenseModifier);
                int losses = 0;
                if(defenseModifier >= 7){
                    int roll1 = FS.DIEROLL();
                    int roll2 = FS.DIEROLL();
                    losses = (roll1 % 2 == 0 ? 1 : 0) + (roll2 % 2 == 0 ? 1 : 0);
                    SetInt("ACTION.DEFENDERLOSSES", losses);
                } else if(defenseModifier >= 4){
                    int roll1 = FS.DIEROLL();
                    losses = roll1 % 2 == 0 ? 1 : 0;
                    SetInt("ACTION.DEFENDERLOSSES", losses);
                }
                report += "**Defending Air take " + losses + " steps lost**";
            
                //local detection
                foreach(GO activatedUnit in actioningGroups.Where(n => !n.LOCALDETECTED)){
                    List<GO> actioningUnits = FS.GROUPMEMBERS(activatedUnit);
                    List<GO> adjacent = new();
                    foreach(GO loc in FS.FINDAIRRADIUS(activatedUnit.GAMELOCATION, 1)){
                        adjacent.AddRange(FS.ALLSHIPSINHEX(defendingSide, loc, true, true));
                    }
                    if(actioningUnits.Where(n => FS.STORM(n.GAMELOCATION)).Any()){break;}
                    adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)));
                    if(adjacent.Any()){
                        FS.DINTERRUPT(GS, defendingSide, true);
                        FS.LOCALDETECT(actioningUnits, true);
                    }
                }
                MainWindow.Alert(report);
            }
            GS.Advance(this);           
        }
    }
    public class ActionAAACombatShipsPicksCasualties : GamePhaseInteractive
    {
        int stepLosses = 0;
        string side = null;
        public ActionAAACombatShipsPicksCasualties(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                int defenderLosses = GetInt("ACTION.DEFENDERLOSSES");
                if(defenderLosses == 0){
                    Update("NEXT");
                    return;
                }
                List<GO> defenders = FS.GROUPSANDMEMBERS(FS.SCENARIOUNITS(GS, "ACTION.DEFENDER"));
                side = Get("ACTIVE.SIDE");
                stepLosses = defenderLosses;
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "AAA Combat Casualties\n\nChoose the ENEMY squadrons to apply losses to"; 
                foreach(GO obj in defenders.Where(n => !FS.ISGROUP(n))){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(stepLosses == 0 || !GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            FS.SETINSTRUCTIONS(GS, new(){"APPLY LOSSES: STEPS REMAINING TO SELECT = " + stepLosses});
            foreach(GO obj in GS.InteractionMap.Keys){
                GS.AddAction(obj, "APPLY LOSS");
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){}
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    SetInt("ACTION.DEFENDERLOSSES", 0);
                    GS.Advance(this);
                    break;
                case "APPLY LOSS":
                    gp.UNAPPLIEDDAMAGE++;
                    if((gp.DAMAGED ? 1 : 0) + gp.UNAPPLIEDDAMAGE >= 2){
                        GS.REMOVEINTERACTIVE(gp);
                    }
                    stepLosses--;
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
}
