using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using System.Runtime.InteropServices;
using System.Windows.Media.Animation;
using System.Diagnostics;
using System.Windows.Input;

namespace CWApp.FS
{
    public class TurnLoop : GamePhaseLoopLogic
    {
        public TurnLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new InitialCycle("Event Cycle", this, GS));
            AddGamePhase(new StrategicCycle("Strategic Cycle", this, GS));
            AddGamePhase(new ActionCycle("Action Cycle", this, GS));
            AddGamePhase(new TerminalCycle("Terminal Cycle", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init()
        {
            IncrementInt("TURN", 1);
            Set("TURN.TYPE", new List<string>{"NIGHT", "AM", "PM"}[GetInt("TURN") % 3]);
            MainWindow.Alert("TURN: " + GetInt("TURN") + " - " + Get("TURN.TYPE"));
            SetBoolean("TURN.DARKNESS", Get("TURN.TYPE") == "NIGHT");
            SetInt("CMRELOADS", GetInt("_CONFIG_TURNS_PER_CM_RELOADS") > 0 ? GetInt("TURN") / GetInt("_CONFIG_TURNS_PER_CM_RELOADS") : 0);
            if(GetInt("TURN") > 1){
                foreach(GO obj in GS.PIECES().Where(n => n.ENROUTEDELAY > 0)){
                    obj.ENROUTEDELAY--;
                }
                if(Get("TURN.TYPE") == "AM"){
                    //RANDOM EVENTS
                    GS.TYPE("FAILURE").Where(n => n.GAMELOCATIONID != null).ToList().ForEach(GS.DISCARD);
                    Set("RANDOM.COMMANDFAILUREZONES", null);
                    Set("RANDOM.COMMANDFAILURE", null);
                    Set("RANDOM.COMMANDO", null);
                    Set("RANDOM.AIRCRAFTREPLACEMENT", null);
                    Set("RANDOM.SATELLITE", null);
                    string randomEvent = "SATELLITE";//RANDOMEVENT();
                    switch(randomEvent){
                        case "COMMANDFAILURE":
                            List<GO> zoneLocations = GS.TYPE("WEATHERLOCATION");
                            List<string> THEATERS = new(){"CARIBBEAN", "ATLANTIC", "MEDITERRANEAN", "INDIAN", "PACIFIC"};
                            string theater = THEATERS[GS.RANDOMINT(THEATERS.Count)];
                            string failureside = FS.SIDE_NAMES[GS.RANDOMINT(FS.SIDE_NAMES.Count)];
                            Set("RANDOM.COMMANDFAILURE", failureside);
                            List<string> zonesAffected = FS.RANDOMZONETABLE[theater][FS.DIEROLL()].Split('|').ToList();
                            FS.SETSCENARIOSTRINGS(GS, "RANDOM.COMMANDFAILUREZONES", zonesAffected);
                            foreach(string z in zonesAffected){
                                GO template = FS.FAILURETEMPLATES.Where(n => n.ID == failureside + ".FAILURE").Single();
                                FS.CLONE(GS, template, zoneLocations.Where(n => n.ZONE == z).Single().ID);
                            }
                            MainWindow.Alert(failureside + " suffer COMMAND FAILURE!  Markers placed on Strategic Air Display(s) in " + zonesAffected.Count + " zones");
                            break;
                        case "COMMANDO":
                        case "SATELLITE":
                        case "AIRCRAFTREPLACEMENT":
                            Set("RANDOM." + randomEvent, FS.SIDE_NAMES[GS.RANDOMINT(FS.SIDE_NAMES.Count)]);
                            break;
                        case "AIRCRAFTREPLACEMENT.ALL":
                            FS.SETSCENARIOSTRINGS(GS, "RANDOM.AIRCRAFTREPLACEMENT", FS.SIDE_NAMES);
                            break;
                        default:
                            break;
                    }

                    if(FS.LANDWAR){
                        foreach(GO obj in GS.TYPE("POSSESSIONFLAG").Where(n => FS.SIDE_NAMES.Contains(n.SIDE))){
                            if(obj.SUPPLIES > 0){
                                int supplyUsage = Math.Max(1, (int)Math.Floor(obj.STRENGTH / FS.LANDCOMBATSIZE));
                                obj.SUPPLIES -= supplyUsage;
                            }
                            obj.STRENGTH += obj.STRENGTHPRODUCTIONRATE;
                            obj.SUPPLIES += obj.SUPPLYPRODUCTIONRATE;
                        }
                    }
                }
            }
        }
        public override void End()
        {
            
        }
        private string RANDOMEVENT(){
            return FS.DIEROLL() switch{
                0 => "COMMANDO",
                1 => "COMMANDFAILURE",
                2 => "COMMANDFAILURE",
                3 => "COMMANDFAILURE",
                4 => "COMMANDFAILURE",
                5 => "AIRCRAFTREPLACEMENT.ALL",
                6 => "SATELLITE",
                7 => "SATELLITE",
                8 => "AIRCRAFTREPLACEMENT",
                9 => "AIRCRAFTREPLACEMENT",
                _ => null
            };
        }
    }
    public class InitialCycle : GamePhaseGroup
    {
        public InitialCycle(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new LandCombat("Land Combat", this, GS));
            AddGamePhase(new RandomEventAircraftReplacement("Aircraft Replacement", this, GS));
            AddGamePhase(new RandomEventSatellite("Satellite Pass", this, GS));
            AddGamePhase(new RandomEventCommandoRaid("Commando Raid", this, GS));
            AddGamePhase(new DeclareWarOnNeutrals("Declare War on Neutrals", this, GS));
            AddGamePhase(new LandOrders("Land Orders", this, GS));
            AddGamePhase(new StrategicNavalMovement("Strategic Naval Movement", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
    }
    public class LandCombat : GamePhaseAutomated
    {
        public LandCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            if(FS.LANDWAR){
                //do transfers
                foreach(GO from in GS.TYPE("LANDTRANSFER").Select(n => n.ATTACKER).Distinct()){
                    List<GO> transfers = GS.TYPE("LANDTRANSFER").Where(n => n.ATTACKER == from).ToList();
                    foreach(GO transfer in transfers.ToList()){
                        if(from.SIDE != transfer.DEFENDER.SIDE){
                            FS.DISCARDLOGIC(transfer);
                            transfers.Remove(transfer);
                            continue;
                        }
                    }
                    double TROOPSTOTRANSFER = 0;
                    double SUPPLIESTOTRANSFER = 0;
                    foreach(GO logic in transfers){
                        GO to = logic.DEFENDER;                    
                        double MODIFIER = logic.MOVEMENTCONNECTOR.TERRAIN switch{
                            "COASTAL" => 0.5,
                            "SEA" => 0.25,
                            _ => 1
                        };
                        TROOPSTOTRANSFER += FS.LANDTRANSFERSIZE * MODIFIER;
                        SUPPLIESTOTRANSFER += TROOPSTOTRANSFER * 0.1;
                    }
                    
                    if(from.STRENGTH <= TROOPSTOTRANSFER || from.SUPPLIES <= SUPPLIESTOTRANSFER){
                        transfers.ForEach(FS.DISCARDLOGIC);
                        continue;
                    }
                    foreach(GO logic in transfers){
                        GO to = logic.DEFENDER;                    
                        double MODIFIER = logic.MOVEMENTCONNECTOR.TERRAIN switch{
                            "COASTAL" => 0.5,
                            "SEA" => 0.25,
                            _ => 1
                        };
                        double strength = FS.LANDTRANSFERSIZE * MODIFIER;
                        double supplies = strength * 0.1;
                        from.STRENGTH -= strength;
                        from.SUPPLIES -= supplies;
                        to.STRENGTH += strength;
                        to.SUPPLIES += supplies;
                    }            
                }
                Dictionary<GO, List<GO>> RESULTS = new();
                //first remove any combats that don't make sense anymore
                Dictionary<GO, List<GO>> COMBATS = new();
                List<GO> COMBATANTS = new();
                Dictionary<GO, double> STRENGTHLOSSES = new();
                Dictionary<GO, double> SUPPLYLOSSES = new();
                foreach(GO logic in GS.TYPE("LANDCOMBAT")){
                    //if attacking same side remove
                    if(logic.SIDE == logic.DEFENDER.SIDE){
                        //if invasion left over supplies, transfer to defender
                        logic.DEFENDER.STRENGTH += Math.Max(0, logic.STRENGTH);
                        logic.DEFENDER.SUPPLIES += Math.Max(0, logic.SUPPLIES);
                        FS.DISCARDLOGIC(logic);
                        continue;
                    }
                    //if from has no resources
                    if(logic.ATTACKER == null){
                        if(logic.STRENGTH <= 0){
                            logic.DEFENDER.SUPPLIES += Math.Max(0, logic.SUPPLIES);
                            FS.DISCARDLOGIC(logic);
                            continue;
                        } 
                    } else if(logic.ATTACKER.STRENGTH <= 0){
                        FS.DISCARDLOGIC(logic);
                        continue;
                    }
                    //if defender has no strength, remove from battle cycle but put in results cycle
                    if(logic.DEFENDER.STRENGTH <= 0){
                        if(!RESULTS.ContainsKey(logic.DEFENDER)){
                            RESULTS.Add(logic.DEFENDER, new());
                        }
                        RESULTS[logic.DEFENDER].Add(logic);
                        continue;
                    }
                    //put in combat cycle
                    if(!COMBATS.ContainsKey(logic.DEFENDER)){
                        COMBATS.Add(logic.DEFENDER, new());
                        RESULTS.Add(logic.DEFENDER, new());
                    }
                    COMBATS[logic.DEFENDER].Add(logic);
                    RESULTS[logic.DEFENDER].Add(logic);
                    COMBATANTS.Add(logic.DEFENDER);
                    if(!STRENGTHLOSSES.ContainsKey(logic.DEFENDER)){
                        STRENGTHLOSSES.Add(logic.DEFENDER, 0);
                        SUPPLYLOSSES.Add(logic.DEFENDER, 0);
                    }
                    GO ATTACKER = logic.ATTACKER ?? logic;
                    COMBATANTS.Add(ATTACKER);
                    if(!STRENGTHLOSSES.ContainsKey(ATTACKER)){
                        STRENGTHLOSSES.Add(ATTACKER, 0);
                        SUPPLYLOSSES.Add(ATTACKER, 0);
                    }                
                }
                Dictionary<GO, double> COMBATSTRENGTH = new();
                foreach(GO combatant in COMBATANTS.Distinct()){
                    double count = COMBATANTS.Where(n => n == combatant).Count();
                    COMBATSTRENGTH.Add(combatant, combatant.STRENGTH / count);
                }
                //supplies used once if in any combat
                COMBATANTS.Distinct().ToList().ForEach(n => SUPPLYLOSSES[n] += Math.Min(n.SUPPLIES, n.STRENGTH / FS.LANDCOMBATSIZE));
                //do combats
                foreach(GO DEFENDER in COMBATS.Keys){
                    foreach(GO COMBAT in COMBATS[DEFENDER]){
                        double MODIFIER = COMBAT.MOVEMENTCONNECTOR?.TERRAIN switch{
                            "COASTAL" => 0.5,
                            "SEA" => 0.25,
                            _ => 1
                        };
                        GO ATTACKER = COMBAT.ATTACKER ?? COMBAT;
                        double DSTART = COMBATSTRENGTH[DEFENDER];
                        double ASTART = COMBATSTRENGTH[ATTACKER] * MODIFIER;
                        double DCURR = DSTART;
                        double ACURR = ASTART;
                        double chunks = Math.Max(DSTART, ASTART) / FS.LANDCOMBATSIZE;
                        for(double i = 0; i < chunks; i++){
                            double D = Math.Min(DCURR, DSTART / chunks);
                            double A = Math.Min(ACURR, ASTART / chunks);
                            double sizeRatio = Math.Max(D, A) / FS.LANDCOMBATSIZE;
                            if(sizeRatio < 0.5){sizeRatio = 0.5;} else if(sizeRatio < 1){sizeRatio = 1;}
                            DCURR -= D;
                            ACURR -= A;
                            //switch to percentage
                            double T = D + A;
                            D /= T;
                            A /= T;
                            double DCHANCE = D * 0.5 * (DEFENDER.SUPPLIES == 0 ? 0.5 : 1);
                            double ACHANCE = A * 0.5 * (ATTACKER.SUPPLIES == 0 ? 0.5 : 1);
                            if(CWConstants._random.NextDouble() <= DCHANCE){STRENGTHLOSSES[ATTACKER] += sizeRatio;}
                            if(CWConstants._random.NextDouble() <= ACHANCE){STRENGTHLOSSES[DEFENDER] += sizeRatio;}
                        }
                    }            
                }
                //apply losses of strength and supply
                String report = "";
                foreach(GO obj in STRENGTHLOSSES.Keys){
                    report += "\n" + (obj.TYPE == "LANDCOMBAT" ? "INVASION OF " + obj.DEFENDER.LABEL : obj.LABEL) + " loses " + Math.Round(Math.Min(obj.STRENGTH, STRENGTHLOSSES[obj]), 1) + " strength and " + Math.Round(SUPPLYLOSSES[obj], 1) + " supplies";
                    obj.STRENGTH = Math.Max(0, obj.STRENGTH - STRENGTHLOSSES[obj]);
                    obj.SUPPLIES = Math.Max(0, obj.SUPPLIES - SUPPLYLOSSES[obj]);
                }
                //clean up empty attacking combats
                foreach(GO DEFENDER in RESULTS.Keys){
                    //remove attacker combats no longer valid :  0 strength
                    List<GO> combats = RESULTS[DEFENDER];
                    List<GO> invalidinvasions = combats.Where(n => n.ATTACKER == null && n.STRENGTH == 0).ToList();
                    foreach(GO obj in invalidinvasions){
                        obj.DEFENDER.SUPPLIES += obj.SUPPLIES;
                        FS.DISCARDLOGIC(obj);
                    }
                    combats.RemoveAll(invalidinvasions.Contains);
                    List<GO> invalid = combats.Where(n => n.ATTACKER != null && n.ATTACKER.STRENGTH == 0).ToList();
                    combats.RemoveAll(invalid.Contains);
                }
                //resolve empty defenders, conquers
                foreach(GO DEFENDER in RESULTS.Keys){
                    List<GO> combats = RESULTS[DEFENDER];
                    if(DEFENDER.STRENGTH == 0 && combats.Any()){
                        //conquered
                        //move over half attacker total or combat size, whichever is smaller
                        foreach(GO combat in combats){
                            if(combat.ATTACKER == null){
                                DEFENDER.STRENGTH += combat.STRENGTH;
                                DEFENDER.SUPPLIES += combat.SUPPLIES;
                            } else {
                                double incomingStrength = Math.Min(FS.LANDCOMBATSIZE, combat.ATTACKER.STRENGTH * 0.5);
                                double incomingSupply = Math.Min(FS.LANDCOMBATSIZE * 0.1, combat.ATTACKER.SUPPLIES * 0.5);
                                DEFENDER.STRENGTH += incomingStrength;
                                DEFENDER.SUPPLIES += incomingSupply;
                                combat.ATTACKER.STRENGTH -= incomingStrength;
                                combat.ATTACKER.SUPPLIES -= incomingSupply;
                            }
                            FS.DISCARDLOGIC(combat);
                        }
                        report += "\n" + DEFENDER.LABEL + " is CONQUERED";
                        FS.CONQUERLOGISTICALZONE(DEFENDER);
                    }
                }
                if(report != ""){
                    MainWindow.Alert("LAND COMBAT REPORT\n" + report);
                }
            }
            GS.Advance(this);
        }
    }
    public class RandomEventAircraftReplacement : GamePhaseInteractive
    {
        string side = null;
        public RandomEventAircraftReplacement(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"REPAIR AIR UNIT"});
                GS.HELPTEXT = 
                "Replacements have arrived for your air units!\n\n" +
                "Please choose any damaged non-BMB air units to bring up to full health";                
                
                if(FS.SCENARIOSTRINGS(GS, "RANDOM.AIRCRAFTREPLACEMENT").Contains(side)){
                    foreach(GO obj in FS.TYPESIDE(GS, "SQN", side).Where(n => 
                        n.DAMAGED && n.UNITTYPE != "BMB" && !FS.ISGROUP(n))){

                        GS.InteractionMap.Add(obj, new());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "REPAIR");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case "REPAIR":
                    FS.REPAIR(gp);
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class RandomEventSatellite : GamePhaseInteractive
    {
        string side = null;
        public RandomEventSatellite(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            zoomLevel = 0.333;
        }
        public override void Execute(Boolean init){
            if(init){
                side = FS.SCENARIOSTRINGS(GS, "RANDOM.SATELLITE").FirstOrDefault();
                if(side == null){
                    Update("NEXT");
                    return;
                }
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"STRATEGICALLY DETECT ENEMY IN SELECTED ZONE"});
                GS.HELPTEXT = 
                "A Military Satellite pass is available!\n\n" +
                "Please choose either:\n" +
                "- any locally detected surface stack\n" +
                "- OR if you'd like to search a zone choose the Strategic Display sheet";                
                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => 
                    n.UNITCATEGORY == "SURFACE" &&
                    !n.STRATDETECTED && n.LOCALDETECTED)){

                    GS.InteractionMap.Add(obj, new());
                }
                foreach(GO obj in GS.TYPE("STRATEGICAIRTRAY")){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, obj.TYPE == "SHIP" ? "DETECT THIS LOCATION": "SEARCH ZONE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    GS.Advance(this);
                    break;
                case "DETECT THIS LOCATION":
                    //if surface, find all enemy locations where ships are not strategically detected 
                    GO target = FS.PARENTGROUPLOCATION(gp);
                    List<GO> ships = FS.ALLSHIPSINHEX(FS.ENEMY(side), target, true, false);
                    FS.STRATDETECT(ships, true);
                    MainWindow.Alert("Detected " + ships.Count + " surface ships!");
                    Update("NEXT");
                    break;
                case "SEARCH ZONE":
                    //if surface, find all enemy locations where ships are not strategically detected 
                    Dictionary<GO, List<GO>> STACKSTABLE = new();
                    foreach(GO obj in FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => n.UNITCATEGORY == "SURFACE" &&
                        FS.PARENTGROUPLOCATION(n).ZONE == gp.ZONE &&
                        !n.STRATDETECTED && !FS.ISGROUP(n))){

                        GO loc = FS.PARENTGROUPLOCATION(obj);
                        if(!STACKSTABLE.ContainsKey(loc)){
                            STACKSTABLE.Add(loc, new());
                        }
                        STACKSTABLE[loc].Add(obj);
                    }                             
                    target = STACKSTABLE.Keys.OrderByDescending(n => STACKSTABLE[n].Count).FirstOrDefault();
                    if(target != null){
                        ships = FS.ALLSHIPSINHEX(FS.ENEMY(side), target, true, false);
                        FS.STRATDETECT(ships, true);
                        MainWindow.Alert("Detected " + ships.Count + " surface ships!");
                    } else {
                        MainWindow.Alert("Search Unsuccessful");
                    }
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class RandomEventCommandoRaid : GamePhaseInteractive
    {
        string side = null;
        public RandomEventCommandoRaid(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = FS.SCENARIOSTRINGS(GS, "RANDOM.COMMANDO").FirstOrDefault();
                if(side == null){
                    Update("NEXT");
                    return;
                }
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"PERFORM COMMANDO RAID ON ENEMY AIRFIELD"});
                GS.HELPTEXT = 
                "A Commando is available to Raid an enemy Airfield!\n\n" +
                "Please choose any on-map Enemy Airfield";                
                
                foreach(GO obj in FS.TYPESIDE(GS, "FACILITY", FS.ENEMY(side)).Where(n => 
                    n.AIRFIELD && !n.AIRFIELDDESTROYED)){

                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "PERFORM RAID");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    GS.Advance(this);
                    break;
                case "PERFORM RAID":
                    int dieRoll = FS.DIEROLL();
                    string facilityBeingAttacked = "AIRFIELD";
                    GO facility = gp;
                    string report = "COMMANDO RAID ON " + facilityBeingAttacked + " " + facility.LABEL + "\n";
                    int objRollModifer = 0;
                    report += "ROLL: " + dieRoll + "\n";
                    dieRoll += objRollModifer;
                    int attackResult = dieRoll switch{
                        2 => 1,
                        3 => 1,
                        4 => 1,
                        5 => 2,
                        6 => 2,
                        7 => 3,
                        8 => 3,
                        9 => 4,
                        _ => 0
                    };
                    facility.ATK = 0;
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    GO bombedBase = facility.GAMELOCATION;
                    string increase = "";
                    if(attackResult > 0){
                        increase = attackResult + "";
                    } else {
                        report += "No effect\n";
                    }
                    bombedBase.UNAPPLIEDAIRFIELDDAMAGE += attackResult;
                    if(increase != ""){
                        if(bombedBase.AIRFIELDDAMAGELEVEL + bombedBase.UNAPPLIEDAIRFIELDDAMAGE >= 4){
                            report += facilityBeingAttacked + " Destroyed\n";
                        } else {
                            report += facilityBeingAttacked + " Damaged Level increases by " + increase + "\n";
                        }
                    }
                    MainWindow.Alert(report);
                    int num = bombedBase.UNAPPLIEDAIRFIELDDAMAGE;
                    for(int i = 0; i < num; i++){
                        bombedBase.UNAPPLIEDAIRFIELDDAMAGE--;
                        FS.DAMAGEBASE(bombedBase, "AIRFIELD");
                    }
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class DeclareWarOnNeutrals : GamePhaseInteractive
    {
        public DeclareWarOnNeutrals(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            zoomLevel = 0.333;
        }
        public override void Execute(Boolean init){
            if(init){
                Set("ACTIVE.SIDE", "SOV");
                FS.SIDE_MODE = "SOV";
                FS.SETINSTRUCTIONS(GS, new(){"DECLARE WAR ON NEUTRALS"});
                GS.HELPTEXT = "DECLARE WAR phase\n\n" + 
                "SOV Side only.  Choose a Neutral Country possession flag and Declare War.  Upon doing so, the country will immediately align with ALLIES and its forces and territory will be set to ALLIES and will be attackable";
                //add flags to each base
                foreach(GO flag in GS.TYPE("POSSESSIONFLAG").Where(n => n.SIDE == "NEUT")){
                    GS.InteractionMap.Add(flag, new());
                }
            }
            foreach(GO obj in GS.InteractionMap.Keys.ToList().Where(n => n.SIDE != "NEUT")){
                GS.InteractionMap.Remove(obj);
            }
            if(!GS.InteractionMap.Keys.Any()){
                GS.Advance(this);
                return;
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "DECLARE WAR");
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            if(pData == "NEXT"){
                GS.Advance(this); 
            } else if(pData == null) {
                Start(false);  
            } else if(pData == "DECLARE WAR"){
                GO obj = GS.SelectedMarker;
                FS.ALIGNCOUNTRY(GS, obj.COUNTRY, "ALLIES");
                GS.SelectedMarker = GS.NEXTINTERACTIVE(obj);
                Start(false);
            }
        }
    }
    public class LandOrders : GamePhaseInteractive
    {
        Dictionary<GO, List<GO>> TRANSFERS = new();
        Dictionary<GO, List<GO>> COMBATS = new();
        Dictionary<GO, List<FSMovement>> CHOICES = new();
        string side = null;
        public LandOrders(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            zoomLevel = 0.333;
        }
        public override void Execute(Boolean init){
            if(init){
                if(!FS.LANDWAR){
                    Update("NEXT");
                    return;
                }
                CHOICES.Clear();
                TRANSFERS.Clear();
                COMBATS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DECLARE TRANSFERS", "DECLARE LAND ATTACKS"});
                GS.HELPTEXT = 
                "Land War\n\n" + 
                "This phase only appears when you have turned on the LAND WAR option in your save file. From any Logistical Zone you can possibly move (transfer) or attack (combat) to neighboring zones.\n\n" +
                "Many logistical zones are not reachable via this method.  Like islands, etc.  The only way to get troops or supplies there is via activated units during the action segment\n\n" +
                "This component of the game is highly abstracted, and is pretty much a numbers game in the end, but you can simulate a background land war as you see fit for your scenarios. Or not use this at all\n\n" +
                "The strength and supplies of a zone will be spread evenly on any combats.  For transfers, its a set amount of the configured TRANSFER value in the save file.  Combats and Transfers are kept on like a faucet, until you cancel them or they auto-cancel because it cannot be filled, i.e. the supplying place runs out\n\n" +
                "MODIFIERS: Each logistical connection between zones is either a LAND connection (no effect), COASTAL connection (rates of combat and transfer halved) or SEA (rates quartered)\n\n" +
                "COMBAT: combat is resolved in chunks of a configurable COMBAT SIZE amount.  Example: if the combat size is 100, and 900 SOV are attacking 500 ALLIES, each turn the combat will be broken into 9 chunks of 100 SOV vs 55.6 ALLIES. " +
                "This means that in each chunk, SOV has around 64% of the total, ALLIES 36%.  Half of each side's percentage is their chance to kill a point on the other side, so in this case SOV have 32% chance each turn to kill an ALLIES strength point. " +
                "This continues each turn until one side is reduced to 0 at which that zone is conquered or liberated.  Any supplies left on the losing side at that point get transferred to the conqueror\n\n" +
                "SUPPLIES: Supplies are used every DAY (3 turns) at the rate of 1 point per chunk size, so in the example above, SOV would use 9 supplies each day, ALLIES would use 5. As strength is reduced, less supplies are used of course.  Also, if you do the math, setting the COMBAT SIZE higher would slow losses and supply usage if you want to tweak that. " +
                "Additionally, supplies are used each TURN at the same above rate if the zone is in combat, so over a day a chunk of 100 strength (in our example) could use up to 4 points over the entire day if they are in combat all 3 turns.  ONCE SUPPLIES RUN OUT, all effectiveness in combat is HALVED for that side\n\n" +
                "You can use this supply mechanic to simulate the Warsaw Pact limited logistical capabilities, and although they will have advantage in troop numbers, you can start them with lower supplies and a shorter leash\n\n" + 
                "All transfers and combats will take effect at the beginning of each turn after all loading/unloading and orders have been given in the previous turn.  Transfers first, then combats.  Supplies will transfer along with troops at a rate of 10% of the troop transfer.  The game should give alerts on combat results\n\n" + 
                "GROWTH: Each zone has an intrinsic growth rate of troops and supplies each TURN.  This is defaulted in the game files and you had an opportunity to tweak this in setup.";                
                foreach(GO obj in FS.TYPESIDE(GS, "POSSESSIONFLAG", side).Where(n => n.GAMELOCATION?.LOGISTICALBASE == true)){
                    //find choices
                    List<FSMovement> landmovements = FS.GENERATELANDLOGISTICALCONNECTIONS(obj.GAMELOCATION).Where(n => FS.SIDE_NAMES.Contains(n.MOVEMENTLOCATION.SIDE)).ToList();
                    if(landmovements.Any()){
                        GS.InteractionMap.Add(obj, new());   
                        CHOICES.Add(obj, landmovements);
                        //find current land movements or land combats involving this log zone
                        TRANSFERS.Add(obj, GS.TYPE("LANDTRANSFER").Where(n=> n.SIDE == obj.SIDE && (n.ATTACKER == obj || n.DEFENDER == obj)).ToList());
                        COMBATS.Add(obj, GS.TYPE("LANDCOMBAT").Where(n=> (n.SIDE == obj.SIDE && n.ATTACKER == obj) || (n.SIDE == FS.ENEMY(obj.SIDE) && n.DEFENDER == obj)).ToList());
                    }            
                }
            }

            //foreach(GO obj in GS.InteractionMap.Keys){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                List<GO> transferPartners = new();
                transferPartners.AddRange(TRANSFERS[obj].Select(n => n.ATTACKER));
                transferPartners.AddRange(TRANSFERS[obj].Select(n => n.DEFENDER));
                transferPartners.RemoveAll(n => n == obj);
                List<GO> combatPartners = new(); 
                combatPartners.AddRange(COMBATS[obj].Select(n => n.ATTACKER));
                combatPartners.AddRange(COMBATS[obj].Select(n => n.DEFENDER));
                combatPartners.RemoveAll(n => n == obj);
                combatPartners.RemoveAll(n => n == null);
                //show current transfers
                foreach(GO transfer in TRANSFERS[obj]){
                    GO connector = transfer.MOVEMENTCONNECTOR;
                    string type = connector.TERRAIN;
                    GS.AddAction(obj, "STOP " + type + " TRANSFER " + (transfer.ATTACKER == obj ? "TO " : "FROM ") + transfer.DEFENDER.LABEL);
                }
                //show current combats
                foreach(GO transfer in COMBATS[obj]){
                    GO connector = transfer.MOVEMENTCONNECTOR;
                    string type = connector?.TERRAIN ?? "LAND";
                    string label = transfer.ATTACKER?.LABEL ?? "INVASION";
                    if(transfer.ATTACKER == obj){
                        GS.AddAction(obj, "STOP " + type + " COMBAT AGAINST " + transfer.DEFENDER.LABEL);
                    } else {
                        GS.AddAction(obj, "UNDER " + type + " ATTACK BY " + label);
                    }

                }
                //find logistical hops
                foreach(FSMovement landmovement in CHOICES[obj]){
                    string type = landmovement.MOVEMENTCONNECTOR.TERRAIN;
                    string label = landmovement.MOVEMENTLOCATION.LABEL;
                    if(landmovement.MOVEMENTLOCATION.SIDE == obj.SIDE){
                        if(!transferPartners.Where(n => n.LABEL == label).Any()){
                            GS.AddAction(obj, "START " + type + " TRANSFER TO " + label);
                        }
                    } else {
                        if(!combatPartners.Where(n => n.LABEL == label).Any()){
                            GS.AddAction(obj, "START " + type + " COMBAT AGAINST " + label);
                        }
                    }
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    Start(false);
                    break;
                default:
                    List<string> types = new(){"LAND", "COASTAL", "SEA"};
                    foreach(string type in types){
                        if(pData.StartsWith("STOP " + type + " TRANSFER TO ")){
                            string label = pData.Replace("STOP " + type + " TRANSFER TO ", "");
                            GO logic = TRANSFERS[gp].Where(n => n.DEFENDER.LABEL == label).Single();
                            GO other = logic.DEFENDER;
                            FS.DISCARDLOGIC(logic);
                            TRANSFERS[gp].Remove(logic);
                            TRANSFERS[other].Remove(logic);
                        } else if(pData.StartsWith("STOP " + type + " TRANSFER FROM ")){
                            string label = pData.Replace("STOP " + type + " TRANSFER FROM ", "");
                            GO logic = TRANSFERS[gp].Where(n => n.ATTACKER.LABEL == label).Single();
                            GO other = logic.ATTACKER;
                            FS.DISCARDLOGIC(logic);
                            TRANSFERS[gp].Remove(logic);
                            TRANSFERS[other].Remove(logic);
                        } else if(pData.StartsWith("START " + type + " TRANSFER")){
                            string label = pData.Replace("START " + type + " TRANSFER TO ", "");
                            FSMovement transfer = CHOICES[gp].Where(n => n.MOVEMENTLOCATION.LABEL == label).Single();
                            GO other = FS.TYPELOCATION(GS, "POSSESSIONFLAG", transfer.MOVEMENTLOCATIONID).Single();
                            Dictionary<string, string> objData = new()
                            {
                                ["ID"] = gp.ID + GO.DELIM + other.ID + GO.DELIM + "LANDTRANSFER" + GO.DELIM + FS.GENERATETIMESTAMP(),
                                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                ["TYPE"] = "LANDTRANSFER"
                            };
                            GO logic = new(GS, objData, null, null)
                            {
                                ATTACKERID = gp.ID,
                                ATTACKER = gp,
                                DEFENDERID = other.ID,
                                DEFENDER = other,
                                MOVEMENTCONNECTORID = transfer.MOVEMENTCONNECTORID,
                                MOVEMENTCONNECTOR = transfer.MOVEMENTCONNECTOR,
                                SIDE = gp.SIDE
                            };    
                            TRANSFERS[gp].Add(logic);
                            TRANSFERS[other].Add(logic);
                        } else if(pData.StartsWith("STOP " + type + " COMBAT")){
                            string label = pData.Replace("STOP " + type + " COMBAT AGAINST ", "");
                            GO logic = COMBATS[gp].Where(n => n.DEFENDER.LABEL == label).Single();
                            FS.DISCARDLOGIC(logic);
                            COMBATS[gp].Remove(logic);
                        } else if(pData.StartsWith("START " + type + " COMBAT")){
                            string label = pData.Replace("START " + type + " COMBAT AGAINST ", "");
                            FSMovement landmovement = CHOICES[gp].Where(n => n.MOVEMENTLOCATION.LABEL == label).Single();
                            GO other = FS.TYPELOCATION(GS, "POSSESSIONFLAG", landmovement.MOVEMENTLOCATIONID).Single();
                            Dictionary<string, string> objData = new()
                            {
                                ["ID"] = gp.ID + GO.DELIM + other.ID + GO.DELIM + "LANDCOMBAT" + GO.DELIM + FS.GENERATETIMESTAMP(),
                                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                ["TYPE"] = "LANDCOMBAT"
                            };
                            GO logic = new(GS, objData, null, null)
                            {
                                ATTACKERID = gp.ID,
                                ATTACKER = gp,
                                DEFENDERID = other.ID,
                                DEFENDER = other,
                                MOVEMENTCONNECTORID = landmovement.MOVEMENTCONNECTORID,
                                MOVEMENTCONNECTOR = landmovement.MOVEMENTCONNECTOR,
                                SIDE = gp.SIDE
                            };    
                            COMBATS[gp].Add(logic);
                        }
                    }
                    Start(false);
                    break;
            }
        }
    }
}