using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using System.Runtime.InteropServices;
using System.Windows.Media.Animation;
using System.Diagnostics;

namespace CWApp.FS
{
    public class TurnLoop : GamePhaseLoop
    {
        public TurnLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new TurnMarkerProcessing("Turn Start", this, GS));
            AddGamePhase(new StrategicNavalMovement("Strategic Naval Movement", this, GS));
            AddGamePhase(new StrategicCycle("Strategic Cycle", this, GS));
            AddGamePhase(new ActionCycle("Action Cycle", this, GS));
            AddGamePhase(new TerminalCycle("Terminal Cycle", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
    }
    public class TurnMarkerProcessing : GamePhaseAutomated
    {
        public TurnMarkerProcessing(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}
            
        public override void Execute(Boolean init){
            IncrementInt("TURN", 1);
            Set("TURN.TYPE", new List<string>{"NIGHT", "AM", "PM"}[GetInt("TURN") % 3]);
            SetBoolean("TURN.DARKNESS", Get("TURN.TYPE") == "NIGHT");
            SetInt("CMRELOADS", GetInt("_CONFIG_TURNS_PER_CM_RELOADS") > 0 ? GetInt("TURN") / GetInt("_CONFIG_TURNS_PER_CM_RELOADS") : 0);
            if(GetInt("TURN") > 1){
                foreach(GO obj in GS.PIECES().Where(n => n.ENROUTEDELAY > 0)){
                    obj.ENROUTEDELAY--;
                }
            }
            GS.Advance(this);           
        }
    }
}