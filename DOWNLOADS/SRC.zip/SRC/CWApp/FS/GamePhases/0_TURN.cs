using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using System.Runtime.InteropServices;
using System.Windows.Media.Animation;
using System.Diagnostics;

namespace CWApp.FS
{
    public class TurnLoop : GamePhaseLoopLogic
    {
        public TurnLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new InitialCycle("Event Cycle", this, GS));
            AddGamePhase(new StrategicCycle("Strategic Cycle", this, GS));
            AddGamePhase(new ActionCycle("Action Cycle", this, GS));
            AddGamePhase(new TerminalCycle("Terminal Cycle", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
        public override void Init()
        {
            IncrementInt("TURN", 1);
            Set("TURN.TYPE", new List<string>{"NIGHT", "AM", "PM"}[GetInt("TURN") % 3]);
            SetBoolean("TURN.DARKNESS", Get("TURN.TYPE") == "NIGHT");
            SetInt("CMRELOADS", GetInt("_CONFIG_TURNS_PER_CM_RELOADS") > 0 ? GetInt("TURN") / GetInt("_CONFIG_TURNS_PER_CM_RELOADS") : 0);
            if(GetInt("TURN") > 1){
                foreach(GO obj in GS.PIECES().Where(n => n.ENROUTEDELAY > 0)){
                    obj.ENROUTEDELAY--;
                }
                if(Get("TURN.TYPE") == "AM"){
                    //RANDOM EVENTS
                    GS.TYPE("FAILURE").Where(n => n.GAMELOCATIONID != null).ToList().ForEach(GS.DISCARD);
                    Set("RANDOM.COMMANDFAILUREZONES", null);
                    Set("RANDOM.COMMANDFAILURE", null);
                    Set("RANDOM.COMMANDO", null);
                    Set("RANDOM.AIRCRAFTREPLACEMENT", null);
                    Set("RANDOM.SATELLITE", null);
                    string randomEvent = "SATELLITE";//RANDOMEVENT();
                    switch(randomEvent){
                        case "COMMANDFAILURE":
                            List<GO> zoneLocations = GS.TYPE("WEATHERLOCATION");
                            List<string> THEATERS = new(){"CARIBBEAN", "ATLANTIC", "MEDITERRANEAN", "INDIAN", "PACIFIC"};
                            string theater = THEATERS[GS.RANDOMINT(THEATERS.Count)];
                            string failureside = FS.SIDE_NAMES[GS.RANDOMINT(FS.SIDE_NAMES.Count)];
                            Set("RANDOM.COMMANDFAILURE", failureside);
                            List<string> zonesAffected = FS.RANDOMZONETABLE[theater][FS.DIEROLL()].Split('|').ToList();
                            FS.SETSCENARIOSTRINGS(GS, "RANDOM.COMMANDFAILUREZONES", zonesAffected);
                            foreach(string z in zonesAffected){
                                GO template = FS.FAILURETEMPLATES.Where(n => n.ID == failureside + ".FAILURE").Single();
                                FS.CLONE(GS, template, zoneLocations.Where(n => n.ZONE == z).Single().ID);
                            }
                            MainWindow.Alert(failureside + " suffer COMMAND FAILURE!  Markers placed on Strategic Air Display(s) in " + zonesAffected.Count + " zones");
                            break;
                        case "COMMANDO":
                        case "SATELLITE":
                        case "AIRCRAFTREPLACEMENT":
                            Set("RANDOM." + randomEvent, FS.SIDE_NAMES[GS.RANDOMINT(FS.SIDE_NAMES.Count)]);
                            break;
                        case "AIRCRAFTREPLACEMENT.ALL":
                            FS.SETSCENARIOSTRINGS(GS, "RANDOM.AIRCRAFTREPLACEMENT", FS.SIDE_NAMES);
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        public override void End()
        {
            
        }
        private string RANDOMEVENT(){
            return FS.DIEROLL() switch{
                0 => "COMMANDO",
                1 => "COMMANDFAILURE",
                2 => "COMMANDFAILURE",
                3 => "COMMANDFAILURE",
                4 => "COMMANDFAILURE",
                5 => "AIRCRAFTREPLACEMENT.ALL",
                6 => "SATELLITE",
                7 => "SATELLITE",
                8 => "AIRCRAFTREPLACEMENT",
                9 => "AIRCRAFTREPLACEMENT",
                _ => null
            };
        }
    }
    public class InitialCycle : GamePhaseGroup
    {
        public InitialCycle(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new RandomEventAircraftReplacement("Aircraft Replacement", this, GS));
            AddGamePhase(new RandomEventSatellite("Satellite Pass", this, GS));
            AddGamePhase(new RandomEventCommandoRaid("Commando Raid", this, GS));
            AddGamePhase(new StrategicNavalMovement("Strategic Naval Movement", this, GS));
        }
        public override Boolean ProcessCheck(){return true;}
    }
    public class RandomEventAircraftReplacement : GamePhaseInteractive
    {
        string side = null;
        public RandomEventAircraftReplacement(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"REPAIR AIR UNIT"});
                GS.HELPTEXT = 
                "Replacements have arrived for your air units!\n\n" +
                "Please choose any damaged non-BMB air units to bring up to full health";                
                
                if(FS.SCENARIOSTRINGS(GS, "RANDOM.AIRCRAFTREPLACEMENT").Contains(side)){
                    foreach(GO obj in FS.TYPESIDE(GS, "SQN", side).Where(n => 
                        n.DAMAGED && n.UNITTYPE != "BMB" && !FS.ISGROUP(n))){

                        GS.InteractionMap.Add(obj, new());
                    }
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "REPAIR");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case "REPAIR":
                    FS.REPAIR(gp);
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class RandomEventSatellite : GamePhaseInteractive
    {
        string side = null;
        public RandomEventSatellite(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = FS.SCENARIOSTRINGS(GS, "RANDOM.SATELLITE").FirstOrDefault();
                if(side == null){
                    Update("NEXT");
                    return;
                }
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"STRATEGICALLY DETECT ENEMY IN SELECTED ZONE"});
                GS.HELPTEXT = 
                "A Military Satellite pass is available!\n\n" +
                "Please choose either:\n" +
                "- any locally detected surface stack\n" +
                "- OR if you'd like to search a zone choose the Strategic Display sheet";                
                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => 
                    n.UNITCATEGORY == "SURFACE" &&
                    !n.STRATDETECTED && n.LOCALDETECTED)){

                    GS.InteractionMap.Add(obj, new());
                }
                foreach(GO obj in GS.TYPE("STRATEGICAIRTRAY")){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, obj.TYPE == "SHIP" ? "DETECT THIS LOCATION": "SEARCH ZONE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    GS.Advance(this);
                    break;
                case "DETECT THIS LOCATION":
                    //if surface, find all enemy locations where ships are not strategically detected 
                    GO target = FS.PARENTGROUPLOCATION(gp);
                    List<GO> ships = FS.ALLSHIPSINHEX(FS.ENEMY(side), target, true, false);
                    FS.STRATDETECT(ships, true);
                    MainWindow.Alert("Detected " + ships.Count + " surface ships!");
                    Update("NEXT");
                    break;
                case "SEARCH ZONE":
                    //if surface, find all enemy locations where ships are not strategically detected 
                    Dictionary<GO, List<GO>> STACKSTABLE = new();
                    foreach(GO obj in FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => n.UNITCATEGORY == "SURFACE" &&
                        FS.PARENTGROUPLOCATION(n).ZONE == gp.ZONE &&
                        !n.STRATDETECTED && !FS.ISGROUP(n))){

                        GO loc = FS.PARENTGROUPLOCATION(obj);
                        if(!STACKSTABLE.ContainsKey(loc)){
                            STACKSTABLE.Add(loc, new());
                        }
                        STACKSTABLE[loc].Add(obj);
                    }                             
                    target = STACKSTABLE.Keys.OrderByDescending(n => STACKSTABLE[n].Count).FirstOrDefault();
                    if(target != null){
                        ships = FS.ALLSHIPSINHEX(FS.ENEMY(side), target, true, false);
                        FS.STRATDETECT(ships, true);
                        MainWindow.Alert("Detected " + ships.Count + " surface ships!");
                    } else {
                        MainWindow.Alert("Search Unsuccessful");
                    }
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class RandomEventCommandoRaid : GamePhaseInteractive
    {
        string side = null;
        public RandomEventCommandoRaid(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = FS.SCENARIOSTRINGS(GS, "RANDOM.COMMANDO").FirstOrDefault();
                if(side == null){
                    Update("NEXT");
                    return;
                }
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"PERFORM COMMANDO RAID ON ENEMY AIRFIELD"});
                GS.HELPTEXT = 
                "A Commando is available to Raid an enemy Airfield!\n\n" +
                "Please choose any on-map Enemy Airfield";                
                
                foreach(GO obj in FS.TYPESIDE(GS, "FACILITY", FS.ENEMY(side)).Where(n => 
                    n.AIRFIELD && !n.AIRFIELDDESTROYED)){

                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "PERFORM RAID");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    GS.Advance(this);
                    break;
                case "PERFORM RAID":
                    int dieRoll = FS.DIEROLL();
                    string facilityBeingAttacked = "AIRFIELD";
                    GO facility = gp;
                    string report = "COMMANDO RAID ON " + facilityBeingAttacked + " " + facility.LABEL + "\n";
                    int objRollModifer = 0;
                    report += "ROLL: " + dieRoll + "\n";
                    dieRoll += objRollModifer;
                    int attackResult = dieRoll switch{
                        2 => 1,
                        3 => 1,
                        4 => 1,
                        5 => 2,
                        6 => 2,
                        7 => 3,
                        8 => 3,
                        9 => 4,
                        _ => 0
                    };
                    facility.ATK = 0;
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    GO bombedBase = facility.GAMELOCATION;
                    string increase = "";
                    if(attackResult > 0){
                        increase = attackResult + "";
                    } else {
                        report += "No effect\n";
                    }
                    bombedBase.UNAPPLIEDAIRFIELDDAMAGE += attackResult;
                    if(increase != ""){
                        if(bombedBase.AIRFIELDDAMAGELEVEL + bombedBase.UNAPPLIEDAIRFIELDDAMAGE >= 4){
                            report += facilityBeingAttacked + " Destroyed\n";
                        } else {
                            report += facilityBeingAttacked + " Damaged Level increases by " + increase + "\n";
                        }
                    }
                    MainWindow.Alert(report);
                    int num = bombedBase.UNAPPLIEDAIRFIELDDAMAGE;
                    for(int i = 0; i < num; i++){
                        bombedBase.UNAPPLIEDAIRFIELDDAMAGE--;
                        FS.DAMAGEBASE(bombedBase, "AIRFIELD");
                    }
                    Update("NEXT");
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
}