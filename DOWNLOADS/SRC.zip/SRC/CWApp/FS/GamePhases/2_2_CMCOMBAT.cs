using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
using System.Printing.IndexedProperties;
namespace CWApp.FS
{    
    public class ActionCMCombat : GamePhaseLoopLogic
    {
        public ActionCMCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionCMCombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionCombatAllocation("Allocation", this, GS, "CM"));
            AddGamePhase(new ActionCMCombatResolution("Resolution", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOLOGICS(GS, "ACTION.CMCOMBAT").Any();}
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.CMCOMBAT");
            GO firstcombat = combats.First();
            List<GO> combined_combats = new(){firstcombat};
            if(FS.COMBINEDATTACKS){
                combined_combats = combats.Where(n => n.SIDE == firstcombat.SIDE && n.DEFENDER == firstcombat.DEFENDER && n.LABEL == firstcombat.LABEL).ToList();
            }
            List<GO> attackingUnits = combined_combats.Select(n => n.ATTACKER).ToList();
            Set("ACTIVE.SIDE", attackingUnits.First().SIDE);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIONING", attackingUnits);
            combats.RemoveAll(n => combined_combats.Contains(n));
            FS.SETSCENARIOOBJECTS(GS, "ACTION.CMCOMBAT", combats);
            List<GO> defenders = new();
            if(firstcombat.DEFENDER != null){
                GO facility = firstcombat.DEFENDER;
                if((firstcombat.LABEL == "PORT" && facility.PORT && !facility.PORTDESTROYED) || (firstcombat.LABEL == "AIRFIELD" && facility.AIRFIELD && !facility.AIRFIELDDESTROYED)){
                    defenders.Add(facility);
                }
            }
            List<GO> attackers = new();
            if(defenders.Any() && !FS.STORM(firstcombat.DEFENDERLOCATION)){
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", defenders);           
                foreach(GO combat in combined_combats){
                    GO attackingUnit = combat.ATTACKER;
                    //determine which attackers can reach this range
                    List<GO> atks = new();
                    List<GO> groupMembers = FS.GROUPMEMBERS(attackingUnit);
                    Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers, "CM");
                    foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                        if(attackData[obj].ContainsKey("CM")){
                            atks.Add(obj);
                        }
                    }
                    if(atks.Any()){
                        attackingUnit.NUMCOMBATS++;
                        attackingUnit.DONECM = true;
                    }
                    attackers.AddRange(atks);
                }
                Set("ACTION.TARGET", firstcombat.LABEL);
            }
            string reason = "";
            if(!attackers.Any()){reason = "no units able to attack";}
            if(!defenders.Any()){reason = "facility is no longer a viable target.  Maybe its already been destroyed";}
            if(reason != ""){
                MainWindow.Alert("Planned " + firstcombat.SIDE + " " + firstcombat.TYPE + " combat not possible: " + reason);
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", attackers);
            combined_combats.ForEach(FS.DISCARDLOGIC);       
        }
        public override void End()
        {
            FS.REMOVECOMBATSHEET();   
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionCMCombatDeclaration : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, Dictionary<string, double>> ATTACKS = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = new();
        public ActionCMCombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                ATTACKS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE UNITS THAT WILL PARTICIPATE"});
                GS.HELPTEXT = 
                "CRUISE MISSILE COMBAT.  Declare which units you will attack with\n\n" + 
                "When done with your allocation you can click the NEXT button";                
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ATTACKER")){
                    GS.InteractionMap.Add(obj, new());
                }
                attackData = FS.ATTACKDATA(GS.InteractionMap.Keys.ToList(), "CM");
            }
            FS.SETINSTRUCTIONS(GS, new(){"ALLOCATE CM POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"])});
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "USE CM");
                if(GS.InteractionMap.Count == 1 && !ATTACKS.Any()){
                    Update("USE CM");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(ATTACKS.Any() || !GS.InteractionMap.Any()){
                        //collect attack data
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", ATTACKS.Keys.ToList());
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        GS.Advance(this);
                    } else {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE CM":
                    gp.CMPTS--;
                    gp.CM = 0;
                    ATTACKS.Add(gp, attackData[gp]["CM"]["CM"]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionCMCombatResolution : GamePhaseAutomated
    {
        public ActionCMCombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            string facilityBeingAttacked = Get("ACTION.TARGET");    
            if(defenders.Any()){
                List<GO> actioningGroups = FS.SCENARIOUNITS(GS, "ACTION.ACTIONING").Where(n => n.UNITCATEGORY != "AIR" && !n.LOCALDETECTED).ToList();
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                GO facility = defenders.First();
                GO defenseLocation = facility.GAMELOCATION;
                string report = "CM COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                int rollModifier = 0;
                List<GO> capAir = FS.CAPSQNS(GS, defendingSide).Where(n => !n.DONE && n.GAMELOCATION == defenseLocation).ToList();
                if(capAir.Any()){
                    double aaaRating = capAir.Sum(FS.GETAIRCAA);
                    if(aaaRating >= 18){
                        rollModifier -= 2;
                        report += "CAP >= 18: Roll -2\n";
                    } else if(aaaRating >= 9){
                        rollModifier -= 1;
                        report += "CAP >= 9: Roll -1\n";
                    }
                }
                
                report += "\nATTACK ON " + facilityBeingAttacked + " " + facility.LABEL + " with " + facility.ATK + " pts:\n";
                int objRollModifer = rollModifier;
                report += "ATTACK ROLL MODIFIER: " + objRollModifer + "\n";
                int dieRoll = FS.DIEROLL();
                report += "ROLL: " + dieRoll + " => " + (dieRoll + objRollModifer) + "\n";
                dieRoll += objRollModifer;
                double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)facility.ATK);
                facility.ATK = 0;
                report += "ATTACK RESULT: " + attackResult + "\n";
                GO bombedBase = defenseLocation;
                string increase = "";
                if(attackResult >= 11){
                    //FS.DESTROYBASE(bombedBase, facilityBeingAttacked);
                    if(facilityBeingAttacked == "AIRFIELD"){
                        bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 4;                        
                    } else {
                        bombedBase.UNAPPLIEDPORTDAMAGE += 4;                        
                    }
                    report += facilityBeingAttacked + " Destroyed\n";
                    increase = "4";
                } else if(attackResult >= 10){
                    //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                    //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                    //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                    if(facilityBeingAttacked == "AIRFIELD"){
                        bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 3;                        
                    } else {
                        bombedBase.UNAPPLIEDPORTDAMAGE += 3;                        
                    }
                    increase = "3";
                } else if(attackResult >= 8){
                    //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                    //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                    if(facilityBeingAttacked == "AIRFIELD"){
                        bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 2;                        
                    } else {
                        bombedBase.UNAPPLIEDPORTDAMAGE += 2;                        
                    }
                    increase = "2";
                } else if(attackResult >= 4){
                    //FS.DAMAGEBASE(bombedBase, facilityBeingAttacked);
                    if(facilityBeingAttacked == "AIRFIELD"){
                        bombedBase.UNAPPLIEDAIRFIELDDAMAGE += 1;                        
                    } else {
                        bombedBase.UNAPPLIEDPORTDAMAGE += 1;                        
                    }
                    increase = "1";
                } else {
                    report += "No effect\n";
                }
                if(increase != ""){
                    switch(facilityBeingAttacked){
                        case "PORT":
                            if(bombedBase.PORTDAMAGELEVEL + bombedBase.UNAPPLIEDPORTDAMAGE >= 4){
                                report += facilityBeingAttacked + " Destroyed\n";
                            } else {
                                report += facilityBeingAttacked + " Damaged Level increases by " + increase + "\n";
                            }
                            break;
                        case "AIRFIELD":
                            if(bombedBase.AIRFIELDDAMAGELEVEL + bombedBase.UNAPPLIEDAIRFIELDDAMAGE >= 4){
                                report += facilityBeingAttacked + " Destroyed\n";
                            } else {
                                report += facilityBeingAttacked + " Damaged Level increases by " + increase + "\n";
                            }
                            break;
                        default:
                            break;
                    }
                }
                //local detection
                foreach(GO actioningUnit in actioningGroups){
                    List<GO> actioningUnits = FS.GROUPMEMBERS(actioningUnit);
                    List<GO> adjacent = new();
                    foreach(GO loc in FS.FINDAIRRADIUS(actioningUnit.GAMELOCATION, 1)){
                        adjacent.AddRange(FS.ALLSHIPSINHEX(defendingSide, loc, true, true));
                    }
                    switch(actioningUnit.UNITCATEGORY){
                        case "SURFACE":
                            if(actioningUnits.Where(n => FS.STORM(n.GAMELOCATION)).Any()){break;}
                            adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)));
                            if(adjacent.Any()){
                                FS.DINTERRUPT(GS, defendingSide, true);
                                FS.LOCALDETECT(actioningUnits, true);
                            }
                            break;
                        case "SUB":
                            adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)) && n.UNITCATEGORY == "SURFACE");
                            if(adjacent.Any()){
                                foreach(GO obj in actioningUnits){
                                    if(FS.SUBDETECTIONRESULT(obj, "ACTION", "SSM", adjacent) == "D"){
                                        FS.DINTERRUPT(GS, defendingSide, true);
                                        FS.LOCALDETECT(new(){obj}, true);
                                    }
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
                if(report != ""){
                    MainWindow.Alert(report);
                }
            }
            GS.Advance(this);           
        }
    }
}
