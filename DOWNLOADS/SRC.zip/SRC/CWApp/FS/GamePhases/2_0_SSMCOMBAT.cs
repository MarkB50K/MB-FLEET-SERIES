using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
namespace CWApp.FS
{    
    public class ActionSSMCombat : GamePhaseLoopLogic
    {
        public ActionSSMCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionSSMCombatLoadTrays("Load Trays", this, GS));
            AddGamePhase(new ActionSSMCombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionSSMCombatDefenderSetup("Defender Setup", this, GS));
            AddGamePhase(new ActionSSMCombatRollForTargets("Roll For Targets", this, GS));
            AddGamePhase(new ActionCombatAllocation("Allocation", this, GS, "SSM"));
            AddGamePhase(new ActionSSMCombatResolution("Resolution", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOLOGICS(GS, "ACTION.SSMCOMBAT").Any();}
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.SSMCOMBAT");
            GO firstcombat = combats.First();
            List<GO> combined_combats = new(){firstcombat};
            if(FS.COMBINEDATTACKS){
                combined_combats = combats.Where(n => n.SIDE == firstcombat.SIDE && n.DEFENDERLOCATION == firstcombat.DEFENDERLOCATION).ToList();
            }
            List<GO> attackingUnits = combined_combats.Select(n => n.ATTACKER).ToList();
            Set("ACTIVE.SIDE", attackingUnits.First().SIDE);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIONING", attackingUnits);
            combats.RemoveAll(n => combined_combats.Contains(n));
            FS.SETSCENARIOOBJECTS(GS, "ACTION.SSMCOMBAT", combats);
            List<GO> defenders = FS.TYPESIDELOCATION(GS, "SHIP", FS.ENEMY(firstcombat.SIDE), firstcombat.DEFENDERLOCATIONID).Where(n => 
                n.ENROUTEDELAY == 0 &&
                !n.DOCKED && 
                n.UNITCATEGORY == "SURFACE" &&
                (n.STRATDETECTED || n.LOCALDETECTED)).ToList();
            
            List<GO> attackers = new();
            if(defenders.Any() && !FS.STORM(firstcombat.DEFENDERLOCATION)){
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", defenders);
                foreach(GO combat in combined_combats){
                    List<GO> atks = new();
                    GO attackingUnit = combat.ATTACKER;
                    //determine which attackers can reach this range
                    List<GO> groupMembers = FS.GROUPMEMBERS(attackingUnit);
                    Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers, "SSM");
                    double range = combat.DISTANCE;                   
                    foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                        if(attackData[obj].ContainsKey("SSM")){
                            if(attackData[obj]["SSM"].Values.Max(n=> n["RANGE"]) >= range){
                                atks.Add(obj);
                            }
                        }
                    }
                    if(atks.Any()){
                        attackingUnit.NUMCOMBATS++;
                        attackingUnit.DONESSM = true; 
                    }
                    attackers.AddRange(atks);
                }
            }
            string reason = "";
            if(!attackers.Any()){reason = "no units able to attack";}
            if(!defenders.Any()){reason = "no viable targets in target location";}
            if(reason != ""){
                MainWindow.Alert("Planned " + firstcombat.SIDE + " " + firstcombat.TYPE + " combat not possible: " + reason);
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", attackers);
            combined_combats.ForEach(FS.DISCARDLOGIC);
        }
        public override void End()
        {
            FS.REMOVECOMBATSHEET();
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionSSMCombatLoadTrays : GamePhaseAutomated
    {
        public ActionSSMCombatLoadTrays(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            if(FS.SCENARIOUNITS(GS, "ACTION.ATTACKER").Any()){
                List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Where(n => !FS.ISGROUP(n)).ToList();
                defenders.AddRange(FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Where(FS.ISGROUP));
                foreach(GO obj in defenders){
                    obj.HOMEBASEID = obj.GAMELOCATIONID;
                    obj.HOMEBASE = obj.GAMELOCATION;
                }
                FS.DISPLAYCOMBATSHEET(GS, defenders);
            }
            GS.Advance(this);           
        }
    }
    public class ActionSSMCombatDeclaration : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, Dictionary<string, double>> ATTACKS = new();
        Dictionary<GO, int> RANGES = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = new();
        public ActionSSMCombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                ATTACKS.Clear();
                RANGES.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE UNITS THAT WILL PARTICIPATE AND WHAT ATTACK TYPE"});
                GS.HELPTEXT = 
                "SSM COMBAT.  Declare which units you will attack with\n\n" + 
                "- Choose which ammunition, game will only allow ones in range, and will only allow one choice\n\n" +
                "When done with your declaration(s) you can click the NEXT button.  The Defender will be given a chance to reposition forces in the target hex.";
                GO defenseLocation = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").FirstOrDefault()?.HOMEBASE;                
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ATTACKER")){
                    GS.InteractionMap.Add(obj, new());
                    RANGES.Add(obj, FS.FINDAIRMOVEMENTPATH(FS.PARENTGROUPLOCATION(obj), defenseLocation).Sum(n => n.DISTANCE));
                }
            }
            FS.SETINSTRUCTIONS(GS, new(){"ALLOCATE SSM POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"])});
            attackData = FS.ATTACKDATA(GS.InteractionMap.Keys.ToList(), "SSM");
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                int range = RANGES[obj];
                if(attackData.ContainsKey(obj)){
                    if(attackData[obj].ContainsKey("SSM")){
                        foreach(string attackType in attackData[obj]["SSM"].Keys){
                            Dictionary<string, double> cd = attackData[obj]["SSM"][attackType];
                            if(cd["RANGE"] >= range){
                                GS.AddAction(obj, "USE " + attackType);
                            }
                        }
                    }
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(ATTACKS.Any() || !GS.InteractionMap.Any()){
                        //collect attack data
                        int numattackers = ATTACKS.Keys.Count;
                        double numseaskimmer = ATTACKS.Values.Sum(n => n["SEASKIMMER"]);
                        double numfastssm  = ATTACKS.Values.Sum(n => n["FAST"]);
                        SetBoolean("ACTION.SEASKIMMER", numseaskimmer * 2 >= numattackers);
                        SetBoolean("ACTION.FAST", numfastssm * 2 >= numattackers);
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", ATTACKS.Keys.ToList());
                        GS.Advance(this);
                    } else {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE SSM":
                    if(gp.UNITCATEGORY == "AIR"){gp.SSMPTS = 0; gp.SSM = 0;} else {gp.SSMPTS--;}
                    ATTACKS.Add(gp, attackData[gp]["SSM"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE INTENSIVE SSM":
                    gp.SSMPTS -= 2;
                    ATTACKS.Add(gp, attackData[gp]["SSM"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE MAXIMUM SSM":
                    gp.SSMPTS -= 3;
                    ATTACKS.Add(gp, attackData[gp]["SSM"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE SSM2":
                    gp.SSM2PTS--;
                    ATTACKS.Add(gp, attackData[gp]["SSM"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE INTENSIVE SSM2":
                    gp.SSM2PTS -= 2;
                    ATTACKS.Add(gp, attackData[gp]["SSM"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE MAXIMUM SSM2":
                    gp.SSM2PTS -= 3;
                    ATTACKS.Add(gp, attackData[gp]["SSM"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "USE AAA AS SSM":
                    gp.AAPTS--;
                    ATTACKS.Add(gp, attackData[gp]["SSM"][pData.Replace("USE ", "")]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionSSMCombatDefenderSetup : GamePhaseInteractive
    {
        string side = null;
        List<string> groupingOrder = new();
        List<GO> GROUPTRAYLOCATIONS = new();
        List<GO> UNDOCKEDTRAYLOCATIONS = new();
        public ActionSSMCombatDefenderSetup(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            DragDrop = true;
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            List<GO> DefendersOnDefenseSheet = GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID);
            if(init){
                side = FS.ENEMY(Get("ACTIVE.SIDE"));
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG OR USE MENU TO REARRANGE SHIP IN STACK"});
                GS.HELPTEXT = 
                "Adjust Defender Positioning. This will determine which units provide Close AA assistance\n\n" + 
                "- You can arrange units within a TF/TG\n" +
                "- You can arrange units within the hex by group and then within group\n" +
                "- All undocked ships not in TF/TG will always be grouped together.  Use context menu options to move up/down the grouping as a whole\n" + 
                "- Dragging ships within a group will only rearrange the ships within the group, the grouping will not move.  Grouping position is only determined with context menu options\n\n" +
                "When done with your setup you can click the NEXT button.  A roll will determine which units the attacking player can target. " + 
                "The attacking player will then be allowed to allocate pts prior to combat resolution.";                
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.DEFENDER")){
                    GS.InteractionMap.Add(obj, new());
                    if(FS.ISGROUP(obj)){
                        List<GO> groupmembers = FS.GROUPMEMBERS(obj);
                        if(groupmembers.Count <= 1){continue;}
                        foreach(GO obj2 in groupmembers){
                            GS.InteractionMap.Add(obj2, new());
                        }
                    }
                }
                if(DefendersOnDefenseSheet.Count == 1){
                    foreach(GO obj in GS.InteractionMap.Keys.Where(n => n.PARENTSHEET == FS.DEFENDSHEET).ToList()){
                        GS.InteractionMap.Remove(obj);
                    }
                }
                if(!(DefendersOnDefenseSheet.Count > 1 || DefendersOnDefenseSheet.Max(n => FS.GROUPMEMBERS(n).Count) > 1)){
                    Update("NEXT");
                    return;
                }
                //determine initial grouping
                HashSet<string> groupings = new();
                foreach(GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).OrderBy(n => n.GAMELOCATIONID)){
                    if(FS.ISGROUP(obj)){
                        groupings.Add(obj.ID);
                    } else {
                        groupings.Add("UNDOCKED");
                    }
                }
                groupingOrder = groupings.ToList();
            }
            GROUPTRAYLOCATIONS = GS.TYPE("PIECE", "PARENTSHEETID", FS.GRPSHEET.ID).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).ToList();
            UNDOCKEDTRAYLOCATIONS = DefendersOnDefenseSheet.Where(n => !FS.ISGROUP(n) && !n.DOCKED).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).ToList();
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                List<GO> targets = GS.InteractionMap[obj];
                targets.Clear();
                if(obj.HOMEBASE != null){
                    if(!FS.ISGROUP(obj)){
                        targets.AddRange(UNDOCKEDTRAYLOCATIONS.Where(n => n != obj.GAMELOCATION));
                    }
                } else {
                    targets.AddRange(GROUPTRAYLOCATIONS.Where(n => n != obj.GAMELOCATION));
                }
                if(obj.HOMEBASE != null){
                    int index = groupingOrder.IndexOf(FS.ISGROUP(obj) ? obj.ID : "UNDOCKED");
                    if(index > 0){GS.AddAction(obj, "MOVE GROUP UP");}
                    if(index < groupingOrder.Count - 1){GS.AddAction(obj, "MOVE GROUP DOWN");}
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        private void ARRANGEUNITS(GO gp, bool left){
            //always keep non TF/TG grouped together
            GO newsheet = FS.DEFENDSHEET;
            List<GO> grouptraylocations = GS.TYPE("PIECE", "PARENTSHEETID", newsheet.ID).OrderBy(n => n.GAMELOCATIONID).Select(n => n.GAMELOCATION).Distinct().ToList();
            List<GO> groupMembers = new();
            List<GO> tfs = new();
            List<GO> undocked = new();
            foreach(GO loc in grouptraylocations){
                List<GO> unitsAtLoc = FS.TYPELOCATION(GS, "PIECE", loc.ID);
                if(unitsAtLoc.Any()){
                    if(unitsAtLoc.Count == 1){
                        GO u = unitsAtLoc.First();
                        if(FS.ISGROUP(u)){
                            tfs.Add(u);
                        } else {
                            undocked.Add(u);
                        }
                    } else {
                        if(left){
                            undocked.Add(gp);
                        }
                        GO u = unitsAtLoc.Where(n => n != gp).Single();
                        if(FS.ISGROUP(u)){
                            tfs.Add(u);
                        } else {
                            undocked.Add(u);
                        }
                        if(!left){
                            undocked.Add(gp);
                        }
                    }
                }
            }
            foreach(string grouping in groupingOrder){
                switch(grouping){
                    case "UNDOCKED":
                        groupMembers.AddRange(undocked);
                        break;
                    default:
                        groupMembers.Add(tfs.Where(n => n.ID == grouping).Single());
                        break;
                }
            }
            FS.DISPLAYCOMBATSHEET(GS, groupMembers);
        }
        private void REORDERGROUPINGS(GO gp, bool up){
            string key = FS.ISGROUP(gp) ? gp.ID : "UNDOCKED";
            int index = groupingOrder.IndexOf(key);
            groupingOrder.Remove(key);
            if(up){
                groupingOrder.Insert(index - 1, key);
            } else {
                if(index >= groupingOrder.Count - 1){
                    groupingOrder.Add(key);
                } else {
                    groupingOrder.Insert(index + 1, key);
                }
            }
            ARRANGEUNITS(gp, true);
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    GS.Advance(this);
                    break;
                case "MOVE GROUP UP":
                    REORDERGROUPINGS(gp, true);
                    Start(false);
                    break;
                case "MOVE GROUP DOWN":
                    REORDERGROUPINGS(gp, false);
                    Start(false);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        GO newloc = gp.GAMELOCATION;                        
                        if(oldloc.PARENTSHEET == FS.GRPSHEET && newloc.PARENTSHEET == FS.GRPSHEET){
                            GO newsheet = newloc.PARENTSHEET;
                            int oldindex = GROUPTRAYLOCATIONS.IndexOf(oldloc);
                            int newindex = GROUPTRAYLOCATIONS.IndexOf(newloc);
                            for(int i = 0; i < Math.Abs(oldindex - newindex); i++){
                                if(oldindex < newindex){
                                    FS.MOVEDOWNINGROUP(GS, gp, gp.GROUP);
                                } else {
                                    FS.MOVEUPINGROUP(GS, gp, gp.GROUP);
                                }
                            }
                        }
                        if(oldloc.PARENTSHEET == FS.DEFENDSHEET && newloc.PARENTSHEET == FS.DEFENDSHEET){
                            int oldindex = UNDOCKEDTRAYLOCATIONS.IndexOf(oldloc);
                            int newindex = UNDOCKEDTRAYLOCATIONS.IndexOf(newloc);
                            ARRANGEUNITS(gp, oldindex > newindex);
                        }
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionSSMCombatRollForTargets : GamePhaseAutomated
    {
        public ActionSSMCombatRollForTargets(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            List<GO> defenders = new();
            foreach(GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID).OrderBy(n => n.GAMELOCATIONID)){
                if(FS.ISGROUP(obj)){
                    defenders.AddRange(FS.GROUPMEMBERS(obj).OrderBy(n => n.GROUPINDEX));
                } else {
                    defenders.Add(obj);
                }
            }
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
            if(defenders.Any()){
                List<GO> targets = new();
                if(defenders.Count == 1){
                    targets.AddRange(defenders);
                } else {
                    int dieRoll = FS.DIEROLL();
                    if(dieRoll == 0 || dieRoll == 9){
                        MainWindow.Alert("Roll: " + dieRoll + ". No targets acquired!");
                        FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
                    } else if(dieRoll % 2 == 0){
                        for(int i = 0; i < defenders.Count * 0.5; i++){
                            targets.Add(defenders[i]);
                        }
                        MainWindow.Alert("Roll: " + dieRoll + ". Top half of stack targeted!");
                    } else {
                        for(int i = defenders.Count - 1; i >= defenders.Count * 0.5; i--){
                            targets.Add(defenders[i]);
                        }
                        MainWindow.Alert("Roll: " + dieRoll + ". Bottom half of stack targeted!");
                    }
                }
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", targets);
            }
            GS.Advance(this);           
        }
    }
    public class ActionCombatAllocation : GamePhaseInteractive
    {
        string combatType = null;
        string side = null;
        Dictionary<GO, int> ALLOCATIONS = new();
        int maxNumberOfTargets = 0;
        public ActionCombatAllocation(string pid, GamePhase pparent, GameScenario pscenario, string pCombatType) : base(pid, pparent, pscenario) {
            combatType = pCombatType;
        }
        public override void Execute(Boolean init){
            if(init){
                maxNumberOfTargets = combatType switch{
                    "ASW" => 1,
                    "TORP" => 2,
                    _ => 0
                };
                ALLOCATIONS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "Allocate " + combatType + " Points. \n\n" + 
                "- You can increase or reset points allocated\n\n" +
                "When done with your allocation you can click the NEXT button.  The Combat will then be resolved";                
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.DEFENDER")){
                    if(FS.ISGROUP(obj)){
                        foreach(GO obj2 in FS.GROUPMEMBERS(obj)){
                            GS.InteractionMap.Add(obj2, new());
                        }
                    } else {
                        GS.InteractionMap.Add(obj, new());
                    }
                }
            }
            int ptsToAssign = GetInt("ACTION.PTS") - ALLOCATIONS.Values.Sum();
            FS.SETINSTRUCTIONS(GS, new(){"ALLOCATE POINTS TO ATTACK", "TOTAL LEFT TO ALLOCATE: " + ptsToAssign});
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(ptsToAssign > 0){
                    GS.AddAction(obj, "ALLOCATE ALL REMAINING TO THIS TARGET");
                    GS.AddAction(obj, "ALLOCATE 1 PT");
                    if(ptsToAssign >= 5){
                        GS.AddAction(obj, "ALLOCATE 5 PT");
                        if(ptsToAssign >= 10){
                            GS.AddAction(obj, "ALLOCATE 10 PT");
                        }
                    }
                }
                if(ALLOCATIONS.ContainsKey(obj)){GS.AddAction(obj, "CANCEL ALLOCATION TO THIS TARGET : " + ALLOCATIONS[obj]);}
                if(GS.InteractionMap.Count == 1 && ptsToAssign > 0){
                    Update("ALLOCATE ALL REMAINING TO THIS TARGET");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any() || ptsToAssign == 0){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            bool newTarget = gp != null && !ALLOCATIONS.ContainsKey(gp);
            switch(pData){
                case "NEXT":
                    foreach(GO obj in ALLOCATIONS.Keys){
                        obj.ATK = ALLOCATIONS[obj];
                    }
                    FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", ALLOCATIONS.Keys.ToList());
                    SetInt("ACTION.PTS", 0);
                    GS.Advance(this);
                    break;
                case "ALLOCATE ALL REMAINING TO THIS TARGET":
                    int ptsToAssign = GetInt("ACTION.PTS") - ALLOCATIONS.Values.Sum();
                    if(newTarget && maxNumberOfTargets > 0 && ALLOCATIONS.Count >= maxNumberOfTargets){
                        MainWindow.Alert("Already at max number of targets.  Cannot add another");
                    } else {
                        if(newTarget){
                            ALLOCATIONS.Add(gp, 0);
                        }
                        ALLOCATIONS[gp] += ptsToAssign;
                    }
                    Start(false);
                    break;
                case "ALLOCATE 1 PT":
                    if(newTarget && maxNumberOfTargets > 0 && ALLOCATIONS.Count >= maxNumberOfTargets){
                        MainWindow.Alert("Already at max number of targets.  Cannot add another");
                    } else {
                        if(newTarget){
                            ALLOCATIONS.Add(gp, 0);
                        }
                        ALLOCATIONS[gp] += 1;
                    }
                    Start(false);
                    break;
                case "ALLOCATE 5 PT":
                    if(newTarget && maxNumberOfTargets > 0 && ALLOCATIONS.Count >= maxNumberOfTargets){
                        MainWindow.Alert("Already at max number of targets.  Cannot add another");
                    } else {
                        if(newTarget){
                            ALLOCATIONS.Add(gp, 0);
                        }
                        ALLOCATIONS[gp] += 5;
                    }
                    Start(false);
                    break;
                case "ALLOCATE 10 PT":
                    if(newTarget && maxNumberOfTargets > 0 && ALLOCATIONS.Count >= maxNumberOfTargets){
                        MainWindow.Alert("Already at max number of targets.  Cannot add another");
                    } else {
                        if(newTarget){
                            ALLOCATIONS.Add(gp, 0);
                        }
                        ALLOCATIONS[gp] += 10;
                    }
                    Start(false);
                    break;
                case null:
                    Start(false);
                    break;
                default:
                    if(pData.StartsWith("CANCEL")){
                        ALLOCATIONS.Remove(gp);
                    }
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionSSMCombatResolution : GamePhaseAutomated
    {
        public ActionSSMCombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            List<GO> attackers = FS.SCENARIOUNITS(GS, "ACTION.ATTACKER");
            bool airAttack = attackers.Where(n => n.UNITCATEGORY == "AIR").Any();
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            if(defenders.Any()){
                List<GO> actioningGroups = FS.SCENARIOUNITS(GS, "ACTION.ACTIONING");
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                bool seaskimmer = GetBoolean("ACTION.SEASKIMMER");
                bool fast = GetBoolean("ACTION.FAST");
                GO defenseLocation = defenders.First().HOMEBASE ?? FS.LOGICALPARENT(defenders.First()).HOMEBASE;
                Dictionary<GO, int> RANGES = new();
                foreach(GO attacker in attackers){
                    RANGES.Add(attacker, FS.FINDAIRMOVEMENTPATH(FS.PARENTGROUPLOCATION(attacker), defenseLocation).Sum(n => n.DISTANCE));
                }
                bool AIRATTACKFROMONEHEX = attackers.Where(n => n.UNITCATEGORY == "AIR" && RANGES[n] <= 1).Any();
                bool ATTACKFROMOVERONEHEX = attackers.Where(n => RANGES[n] >= 2).Any();
                string report = "SSM COMBAT : " + attackingSide + " vs " + defendingSide + (fast ? " FAST" : "") + (seaskimmer ? " SEASKIMMER" : "") + "\n\n";
                List<List<FSMovement>> ssmPaths = new();
                foreach(GO attackingGroup in actioningGroups){
                    GO attackLocation = attackingGroup.GAMELOCATION;
                    ssmPaths.Add(FS.FINDSSMDIRECTPATH(attackLocation, defenseLocation));
                }
                List<GO> freeShips = new();
                List<GO> DEFENDERSONSHEET = GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID);
                //put defenders in groups
                foreach(GO obj in DEFENDERSONSHEET.OrderBy(n => n.GAMELOCATIONID)){
                    if(!FS.ISGROUP(obj)){
                        freeShips.Add(obj);
                    }
                }
                //create Dict of targets to ships beneath them
                Dictionary<GO, GO> targetsAndBeneath = new();
                foreach(GO defender in defenders){
                    if(defender.HOMEBASE != null){
                        int position1 = freeShips.IndexOf(defender);
                        int position2 = (position1 + 1) % freeShips.Count;
                        GO beneath = freeShips[position2];
                        if(beneath == defender || defenders.Contains(beneath)){
                            beneath = null;
                        }
                        targetsAndBeneath.Add(defender, beneath);
                    } else {
                        GO group = FS.LOCATIONPARENT(defender);
                        List<GO> groupMembers = FS.GROUPMEMBERS(group).OrderBy(n => n.GROUPINDEX).ToList();
                        int position1 = groupMembers.IndexOf(defender);
                        int position2 = (position1 + 1) % groupMembers.Count;
                        GO beneath = groupMembers[position2];
                        if(beneath == defender || defenders.Contains(beneath)){
                            beneath = null;
                        }
                        targetsAndBeneath.Add(defender, beneath);
                    }
                }
                FS.REMOVECOMBATSHEET();          
                //combine AA values
                int combinedAAValue = 0;
                double sskim = seaskimmer ? 0.5 : 1;
                double fst = fast ? 0.5 : 1;
           
                //AAA in target hex
                if(!(defenseLocation.RESTRICTED || defenseLocation.FJORD)){
                    List<GO> SHIPSINHEX = FS.ALLSHIPSINHEX(defendingSide, defenseLocation, true, false).Where(n => n.AAPTS > 0).ToList();
                    foreach(GO obj in SHIPSINHEX){
                        obj.AAPTS--;
                        double val = obj.TEMPLATE.AAA;
                        double laa = obj.TEMPLATE.LAA && AIRATTACKFROMONEHEX ? 6 : 1;
                        double maa = obj.TEMPLATE.MAA && AIRATTACKFROMONEHEX ? 3 : 1;
                        // if AAA combat is enabled and this ship has already been activated, it had its chance to attack air
                        if(FS.AIRSURFACEINTERACTION && obj.ACTIVATED){
                            laa = 1;
                            maa = 1;
                        }
                        val = Math.Floor(val * laa * maa * sskim);
                        combinedAAValue += (int)val;
                        report += obj.UNITTYPE + " " + obj.LABEL + " AAA=" + obj.TEMPLATE.AAA + " contributes " + val + "\n";
                    }
                }
                //CAA of targets
                double targetCAA = 0;
                foreach(GO obj in defenders){
                    targetCAA += obj.TEMPLATE.CAA;
                    report += obj.UNITTYPE + " " + obj.LABEL + " CAA=" + obj.TEMPLATE.CAA + "\n";
                }
                //CAA of beneath
                foreach(GO obj in targetsAndBeneath.Values.Where(n => n != null)){
                    targetCAA += obj.TEMPLATE.CAA;
                    report += obj.UNITTYPE + " " + obj.LABEL + " CAA=" + obj.TEMPLATE.CAA + "\n";
                }
                report += "contributes " + Math.Floor(targetCAA * fst) + "\n";
                combinedAAValue += (int)Math.Floor(targetCAA * fst);  
                //AAA of outside hex
                if(ATTACKFROMOVERONEHEX){
                    List<GO> aaaLoc = new();
                    List<GO> laaLoc = new();
                    List<GO> ships = new();
                    foreach(List<FSMovement> movements in ssmPaths){
                        foreach(FSMovement movement in movements){
                            aaaLoc.Add(movement.MOVEMENTLOCATION);
                            FS.FINDAIRRADIUS(movement.MOVEMENTLOCATION, 2).ForEach(laaLoc.Add);
                        }
                    }
                    laaLoc.RemoveAll(aaaLoc.Contains);
                    aaaLoc.RemoveAll(n => n == defenseLocation);
                    foreach(GO loc in aaaLoc.Distinct()){
                        foreach(GO obj in FS.ALLSHIPSINHEX(defendingSide, loc, true, false).Where(n => n.AAPTS > 0)){
                            obj.AAPTS--;
                            double val = obj.TEMPLATE.AAA;
                            val = Math.Floor(val);
                            combinedAAValue += (int)val;
                            report += obj.UNITTYPE + " " + obj.LABEL + " AAA=" + obj.TEMPLATE.AAA + " contributes " + val + "\n";
                        }
                    }
                    foreach(GO loc in laaLoc.Distinct()){
                        foreach(GO obj in FS.ALLSHIPSINHEX(defendingSide, loc, true, false).Where(n => n.AAPTS > 0)){
                            obj.AAPTS--;
                            double val = obj.TEMPLATE.AAA;
                            val = Math.Floor(val);
                            combinedAAValue += (int)val;
                            report += obj.UNITTYPE + " " + obj.LABEL + " AAA=" + obj.TEMPLATE.AAA + " contributes " + val + "\n";
                        }
                    }
                }
                report += "TOTAL AA = " + combinedAAValue + "\n\n";
                int defenseModifier = 0;
                int rollModifier = 0;
                if(combinedAAValue > 0){
                    if(defenders.Where(n => n.GROUP?.UNITTYPE == "TF").Any()){
                        rollModifier += 2;
                        report += "TF: Roll +2\n";
                    }
                    if(!defenders.Where(n => n.GROUP != null).Any()){
                        rollModifier -= 4;
                        report += "NO TG/TF: Roll -4\n";
                    }
                    List<GO> capAir = FS.CAPSQNS(GS, defendingSide).Where(n => !n.DONE && n.GAMELOCATION == defenseLocation).ToList();
                    if(capAir.Any()){
                        if(!seaskimmer){
                            if(capAir.Where(n => n.COUNTRY == "USA" && n.LABEL.StartsWith("F-14")).Any()){
                                rollModifier += 1;
                                report += "F14 CAP: Roll +1\n";
                            }
                        }
                        if(capAir.Where(n => n.UNITTYPE == "AEW" || n.HOMEBASE == n.GAMELOCATION).Any()){
                            rollModifier += 2;
                            report += "AEW: Roll +2\n";
                        }
                    }
                    List<GO> ALLATTACKERS = FS.GROUPSANDMEMBERS(actioningGroups);
                    if(ALLATTACKERS.Where(n => n.UNITTYPE == "EW").Any()){
                        rollModifier -= 2;
                        report += "EW: Roll -2\n";
                    }
                    if(ALLATTACKERS.Where(n => n.HIGHMISSIONPROFILE).Any()){
                        rollModifier += 2;
                        report += "HIGH MISSION PROFILE: Roll + 2\n";
                    }
                    report += "DEFENSE ROLL MODIFIER: " + rollModifier + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + rollModifier) + "\n";
                    dieRoll += rollModifier;
                    defenseModifier = FS.COMBATRESULTSTABLE(false, dieRoll, combinedAAValue);
                }
                report += "DEFENSE MODIFIER: " + defenseModifier + "\n\n";
                rollModifier = -defenseModifier;
                if(FS.ALLSHIPSINHEX(defendingSide, defenseLocation, true, false).Where(n => n.TACCOORDPIECEID != null).Any()){
                    rollModifier += 2;
                    report += "TAC COORD: Roll +2\n";
                }
                if(defenseLocation.RESTRICTED || defenseLocation.FJORD){
                    rollModifier -= 4;
                    report += "RESTRICTED/FJORD: Roll -4\n";
                } else if(defenseLocation.COASTAL){
                    rollModifier -= 2;
                    report += "COASTAL: Roll -2\n";
                }
                if(ATTACKFROMOVERONEHEX){
                    List<GO> radius = FS.FINDAIRRADIUS(defenseLocation, 1);
                    bool adjacent = radius.Where(n => FS.ALLSHIPSINHEX(attackingSide, n, true, true).Where(n => FS.SURFACECOMBATTYPES.Contains(n.UNITTYPE) || n.UNITCATEGORY == "SUB").Any()).Any();
                    if(!adjacent){
                        int range = RANGES.Values.Max();
                        rollModifier -= range;
                        report += "RANGE W/O ADJACENT FRIENDLY: Roll -" + range + "\n";
                    }
                }
                
                foreach(GO obj in defenders){
                    report += "\nATTACK ON " + obj.UNITTYPE + " " + obj.LABEL + " with " + obj.ATK + " pts:\n";
                    report += "ATTACK ROLL MODIFIER: " + rollModifier + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + rollModifier) + "\n";
                    dieRoll += rollModifier;
                    double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)obj.ATK);
                    obj.ATK = 0;
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    //compare to ship defense
                    double defense = FS.GETDEFENSE(obj);
                    if(attackResult >= defense){
                        obj.UNAPPLIEDDAMAGE += 2;
                        report += "Target Destroyed\n";
                    } else if(attackResult >= defense * 0.5){
                        obj.UNAPPLIEDDAMAGE++;
                        if((obj.DAMAGED ? 1 : 0) + obj.UNAPPLIEDDAMAGE >= 2){
                            report += "Target Destroyed\n";
                        } else {
                            report += "Target Damaged\n";
                        }
                    } else {
                        report += "No effect\n";
                    }
                }
                //local detection
                foreach(GO actioningUnit in actioningGroups){
                    List<GO> actioningUnits = FS.GROUPMEMBERS(actioningUnit);
                    List<GO> adjacent = new();
                    foreach(GO loc in FS.FINDAIRRADIUS(actioningUnit.GAMELOCATION, 1)){
                        adjacent.AddRange(FS.ALLSHIPSINHEX(defendingSide, loc, true, true));
                    }
                    switch(actioningUnit.UNITCATEGORY){
                        case "SURFACE":
                            if(actioningUnits.Where(n => FS.STORM(n.GAMELOCATION)).Any()){break;}
                            adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)));
                            if(adjacent.Any()){
                                FS.DINTERRUPT(GS, defendingSide, true);
                                FS.LOCALDETECT(actioningUnits, true);
                            }
                            break;
                        case "SUB":
                            adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)) && n.UNITCATEGORY == "SURFACE");
                            if(adjacent.Any()){
                                foreach(GO obj in actioningUnits){
                                    if(FS.SUBDETECTIONRESULT(obj, "ACTION", "SSM", adjacent) == "D"){
                                        FS.DINTERRUPT(GS, defendingSide, true);
                                        FS.LOCALDETECT(new(){obj}, true);
                                    }
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
                if(report != ""){
                    MainWindow.Alert(report);
                }
            }
            GS.Advance(this);           
        }
    }
}
