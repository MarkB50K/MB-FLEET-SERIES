using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using System.Runtime.InteropServices;
using System.Windows.Media.Animation;
using System.Diagnostics;
using System.Reflection.Metadata.Ecma335;
using System.Security.Policy;
using System.Security.Cryptography.X509Certificates;
using System.Xaml.Schema;
using System.Windows.Documents;
using CWApp.Helpers;
using System.Reflection.Emit;

namespace CWApp.FS
{
    public class StrategicCycle : GamePhaseGroup
    {
        public StrategicCycle(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new DetermineWeather("Determine Weather", this, GS));
            AddGamePhase(new StrategicAirMovement("Strategic Air Movement", this, GS));
            AddGamePhase(new DeepMode("SUB Deep Mode", this, GS));
            AddGamePhase(new StrategicAir("Allocate Strategic Air", this, GS));
            AddGamePhase(new StrategicAirCalculation("Air-To-Air Calculation", this, GS));
            AddGamePhase(new StrategicAirCombatLoop("Air-To-Air Combat Loop", this, GS));
            AddGamePhase(new StrategicAirInterceptionRTB("Air-To-Air INT RTB", this, GS));
            AddGamePhase(new StrategicAirMining("Mining", this, GS));
            AddGamePhase(new StrategicAirRecon("Recon", this, GS));
        }
        public override Boolean ProcessCheck(){return Get("TURN.TYPE") == "AM";}
    }
    public class StrategicAirCombatLoop : GamePhaseLoop
    {
        public StrategicAirCombatLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new StrategicAirInterception("Interception", this, GS));
            AddGamePhase(new StrategicAirInterceptionPickCasualties("Interception Casualties", this, GS));
            AddGamePhase(new StrategicAirBounce("Bounce", this, GS));
            AddGamePhase(new StrategicAirBouncePickCasualties("Bounce Casualties", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.STRATAIRSHEETS.Where(n => n.INTERCEPTIONELIGIBLE || n.BOUNCEELIGIBLE).Any();}
    }
    public class DetermineWeather : GamePhaseAutomated
    {
        Dictionary<string, Dictionary<string, int>> THEATERROLLMATRIX = new(){
            //{"CARIBBEAN", new(){
            //    {"SQUALL", 8},
            //    {"STORM", 9}
            //}},
            {"NPACIFIC", new(){
                {"SQUALL", 6},
                {"STORM", 8}
            }},
            {"ATLANTIC", new(){
                {"SQUALL", 6},
                {"STORM", 8}
            }},
            {"MED", new(){
                {"SQUALL", 7},
                {"STORM", 9}
            }},
            {"INDIAN", new(){
                {"SQUALL", 7},
                {"STORM", 9}
            }},
            {"PACIFIC", new(){
                {"SQUALL", 6},
                {"STORM", 8}
            }},
        };
        //squall - SURFACE spends 2 pts per hex
        //SURFACE have LDZ only
        //CARRIER AIR NO ACTIVATE
        //CARRIER AIR CAN CAP and STRAT
        //NO at sea replenishment

        //storm - SURFACE spend 4 pts per hex
        //no AIR activation, cap, or strat
        //no attacks other than ASW attacks from SUBs
        //SURFACE have no detection zones
        //SUB have LDZ but can only attempt to detect SUB
        //No replenishment at all
        public DetermineWeather(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            string report = "";
            Dictionary<string, List<string>> weatherZones = new(){{"SQUALL", new()},{"STORM", new()}};
            List<string> squallTheaters = new();
            foreach(string theater in THEATERROLLMATRIX.Keys){
                string weather = "";
                int roll1 = FS.DIEROLL();
                report += theater + " ROLL: " + roll1;
                if(roll1 >= THEATERROLLMATRIX[theater]["STORM"]){weather = "STORM";}
                else if(roll1 >= THEATERROLLMATRIX[theater]["SQUALL"]){weather = "SQUALL";}
                if(weather != ""){
                    int roll2 = FS.DIEROLL();
                    report += " ROLL: " + roll2;
                    weatherZones[weather].AddRange(FS.RANDOMZONETABLE[theater][roll2].Split('|'));
                }
                report += "\n";                
            }
            report += "\n";
            foreach(GO weatherLocation in GS.TYPE("WEATHERLOCATION")){
                if(GetInt("TURN") == 1){
                    GO strategicAirSheet = weatherLocation.PARENTSHEET;
                    string zone = strategicAirSheet.ZONE;
                    List<GO> zoneLocations = GS.TYPE("HEX").Where(n => n.ZONE == zone).ToList();
                    //move sheet to docking location
                    if(zoneLocations.Any()){
                        GO anchorLocation = GS.LOCATION(strategicAirSheet.SHEETANCHORLOCATIONID);
                        double averageX = zoneLocations.Average(n => n.x);
                        double averageY = zoneLocations.Average(n => n.y);
                        anchorLocation.x = averageX;
                        anchorLocation.XCOORD = averageX;
                        anchorLocation.y = averageY;
                        anchorLocation.YCOORD = averageY;
                        GS.CHANGELOCATION(strategicAirSheet, anchorLocation.ID);
                    }
                }
                string weather = weatherZones.Keys.Where(n => weatherZones[n].Contains(weatherLocation.ZONE)).FirstOrDefault() ?? "CLEAR";
                Set(weatherLocation.ZONE + ".WEATHER", weather);
                GO currentWeatherMarker = GS.TYPE("WEATHERMARKER", "ZONE", weatherLocation.ZONE).SingleOrDefault();
                if(currentWeatherMarker?.LABEL != weather){
                    if(currentWeatherMarker != null){GS.CHANGELOCATION(currentWeatherMarker, "TEMP");}
                    if(weather != "CLEAR"){
                        report += weatherLocation.ZONE + " weather is " + weather + "\n";
                        currentWeatherMarker = FS.CLONE(GS, GS.PIECE(weather), weatherLocation.ID);
                        GS.CHANGELOCATION(currentWeatherMarker, weatherLocation);
                    }
                }
            }            
            MainWindow.Alert(report);
            GS.Advance(this);           
        }
    }
    public class StrategicAirMovement : GamePhaseInteractive
    {
        List<GO> LOGAIRS = new();
        Dictionary<GO, List<GO>> ELIGIBLEAIRBASESCOMBAT = new();
        List<GO> ELIGIBLEAIRBASES = new();
        Dictionary<GO, double> CHOICES = new();
        string side = null;
        public StrategicAirMovement(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            DragDrop = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"MOVE UNIT THROUGH STRATEGIC NETWORK"});
                GS.HELPTEXT = 
                "Strategic Air Movement.  Only usable in AM turns\n\n" + 
                "- Transfers allowed:\n" +
                "  AIRBASE -> LOGISTICAL AREA\n" +
                "  LOGISTICAL -> LOGISTICAL\n" + 
                "  LOGISTICAL -> AIRBASE\n\n" +
                "- Airbase to Airbase transfers are not allowed.  The idea is that you would use the action phase to do these transfers on the same map.  For bases on different maps you'll have to use at least one strategic hop\n" + 
                "- Each air unit can use 3x their movement allowance\n" + 
                "- Each strategic hop will incur a transfer delay of " + GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER") + " turns (configurable)\n" +
                "- No transfers to damaged airbases";                
                LOGAIRS = FS.TYPESIDE(GS, "LOCATION", side).Where(n => n.LOGAIR).ToList();
                ELIGIBLEAIRBASES.Clear();
                ELIGIBLEAIRBASESCOMBAT.Clear();
                foreach(GO obj in FS.TYPESIDE(GS, "FACILITY", side).Where(n => n.AIRFIELD && n.AIRFIELDDAMAGELEVEL == 0 && !FS.STORM(n.GAMELOCATION))){
                    List<GO> sqns = FS.TYPESIDELOCATION(GS, "SQN", side, obj.GAMELOCATIONID);
                    ELIGIBLEAIRBASES.Add(obj.GAMELOCATION);
                    ELIGIBLEAIRBASESCOMBAT.Add(obj.GAMELOCATION, sqns.Where(n => FS.AIRCOMBATTYPES.Contains(n.UNITTYPE)).ToList());
                }
                CHOICES.Clear();

                foreach(GO obj in FS.TYPESIDE(GS, "SQN", side).Where(n => n.ENROUTEDELAY == 0)){
                    if(!FS.STRATEGICCOUNTRIES["ALL"].Contains(obj.COUNTRY)){continue;}
                    if(!LOGAIRS.Contains(obj.GAMELOCATION) && !ELIGIBLEAIRBASES.Contains(obj.GAMELOCATION)){continue;}
                    bool canTransferToLogistic = FINDLOGISTICAL(obj).Any();
                    bool canTransferToAirbase = obj.GAMELOCATION.LOGAIR && FINDAIRBASE(obj).Any();
                    if(canTransferToAirbase || canTransferToLogistic){
                        GS.InteractionMap.Add(obj, new());
                    }
                }
            }

            //foreach(GO obj in GS.InteractionMap.Keys){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                //find logistical hops
                CHOICES = FINDLOGISTICAL(obj);                    
                if(!obj.GAMELOCATION.AIRFIELD){
                    Dictionary<GO, double> tmp = FINDAIRBASE(obj);
                    tmp.Keys.ToList().ForEach(n => CHOICES.Add(n, tmp[n]));
                }
                foreach(GO obj2 in CHOICES.Keys){
                    GS.AddAction(obj, obj2.LABEL);
                }
                if(!CHOICES.Any()){
                    GS.AddAction(obj, "NO OPTIONS");
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case "NO OPTIONS":
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        LAND(gp, gp.GAMELOCATION);
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    GO airbaseHex = CHOICES.Keys.Where(n => n.LABEL == pData).Single();
                    LAND(gp, airbaseHex);
                    Start(false);
                    break;
            }
        }
        private Dictionary<GO, double> FINDLOGISTICAL(GO obj){
            Dictionary<GO, double> dict = new();
            double range = obj.MOVEMENTALLOWANCE * 3;
            GO from = obj.GAMELOCATION;
            foreach(GO to in LOGAIRS){
                if(to == from){continue;}
                double x1 = to.x;
                //map wrap around
                double x2 = to.x > from.x ? to.x - GS.WorldSize : to.x + GS.WorldSize;
                double distance1 = GS.GetDistance(from, x1, to.y);
                double distance2 = GS.GetDistance(from, x2, to.y);
                double distance = Math.Min(distance1, distance2) / FS.HEXDISTANCE;
                if(distance <= range){
                    dict.Add(to, distance);
                }
            }
            return dict;
        }
        private Dictionary<GO, double> FINDAIRBASE(GO obj){
            Dictionary<GO, double> dict = new();
            double range = obj.MOVEMENTALLOWANCE * 3;
            GO from = obj.GAMELOCATION;
            List<GO> tos = FS.AIRCOMBATTYPES.Contains(obj.UNITTYPE) ? ELIGIBLEAIRBASESCOMBAT.Keys.Where(n => ELIGIBLEAIRBASESCOMBAT[n].Count < 4).ToList() : ELIGIBLEAIRBASES;
            foreach(GO to in tos){
                if(to == from){continue;}
                if(!FS.STRATEGICCOUNTRIES[to.ORGLEVEL1].Contains(obj.COUNTRY)){continue;}
                double x1 = to.x;
                //map wrap around
                double x2 = to.x > from.x ? to.x - GS.WorldSize : to.x + GS.WorldSize;
                double distance1 = GS.GetDistance(from, x1, to.y);
                double distance2 = GS.GetDistance(from, x2, to.y);
                double distance = Math.Min(distance1, distance2) / FS.HEXDISTANCE;
                if(distance <= range){
                    dict.Add(to, distance);
                }
            }
            return dict;
        }
        private void LAND(GO obj, GO loc){
            GO airbaseHex = loc;
            //transfer, so add delay
            obj.ENROUTEDELAY = GetInt("_CONFIG_TURNS_DELAY_AFTER_AIRBASE_TRANSFER");
            GS.CHANGELOCATION(obj, airbaseHex);
            if(FS.AIRCOMBATTYPES.Contains(obj.UNITTYPE) && airbaseHex.AIRFIELD){
                ELIGIBLEAIRBASESCOMBAT[airbaseHex].Add(obj);
            }
            GS.REMOVEINTERACTIVE(obj);                        
        }
    }
    public class StrategicNavalMovement : GamePhaseInteractive
    {
        List<GO> LOGSEAS = new();
        List<GO> MAPLINKS = new();
        Dictionary<GO, Dictionary<GO, List<FSMovement>>> CHOICESTABLE = new();
        Dictionary<GO, List<FSMovement>> CHOICES = new();
        int MINTURNS = 0;
        int MAXTURNS = 0;
        string side = null;
        public StrategicNavalMovement(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            DragDrop = true;
            zoomLevel = 0.333;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"MOVE UNIT THROUGH STRATEGIC NETWORK"});
                GS.HELPTEXT = 
                "Strategic Naval Movement\n\n" + 
                "- Each naval unit can travel 100 miles per turn\n" + 
                "- From any off-map sea location, you can designate any other destination.  Obviously, further trips will keep your ships out of action for a long time\n" +
                "- The only way to enter a proper map is via special locations that connect to a map sea zone.  From this location, movement is free, and ships can be moved to a limited number of hexes highlighted on the map\n" +
                "- To enter the network from the map, ships in those hexes are eligible as well\n" +
                "- No fuel will be expended during strategic movement\n\n" +
                "NOTE: Most actions in this phase are done via the unit menu. The only dragging you can do is from an arriving Enroute area onto the proper maps";                
                LOGSEAS = GS.LOCATIONS().Where(n => n.LOGSEA).ToList();
                MAPLINKS = GS.LOCATIONS().Where(n => n.MAPLINK).ToList();
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => n.ENROUTEDELAY == 0 && (LOGSEAS.Contains(n.GAMELOCATION) || MAPLINKS.Contains(n.GAMELOCATION)))){
                    if(!FS.STRATEGICCOUNTRIES["ALL"].Contains(obj.COUNTRY)){continue;}
                    GS.InteractionMap.Add(obj, new());                
                }
                CHOICESTABLE.Clear();
                CHOICES.Clear();
                MINTURNS = 0;
                MAXTURNS = 20;
            }

            //foreach(GO obj in GS.InteractionMap.Keys){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                //find logistical hops
                List<GO> targets = GS.InteractionMap[obj];
                targets.Clear();
                GO logisticalStartPoint = obj.GAMELOCATION.MAPLINK ? LOGSEAS.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).Single() : obj.GAMELOCATION;
                if(!CHOICESTABLE.ContainsKey(logisticalStartPoint)){
                    CHOICESTABLE[logisticalStartPoint] = FINDDESTINATIONS(logisticalStartPoint);
                }
                CHOICES = CHOICESTABLE[logisticalStartPoint];
                Dictionary<GO, List<FSMovement>> choices = new();
                foreach(GO tmp in CHOICES.Keys.Where(n => FS.STRATEGICCOUNTRIES[n.GAMELOCATION.ORGLEVEL1].Contains(obj.COUNTRY))){
                    choices.Add(tmp, CHOICES[tmp]);
                }
                double min = choices.Keys.Min(n => n.DISTANCE);
                double max = choices.Keys.Max(n => n.DISTANCE);
                List<int> rangeLowerLimits = new();
                for(int i = 0; i <= max; i += 20){
                    rangeLowerLimits.Add(i);
                }
                if(!rangeLowerLimits.Contains(MINTURNS)){
                    MINTURNS = rangeLowerLimits.First();
                    MAXTURNS = MINTURNS + 20;
                }
                foreach(GO obj2 in choices.Keys.Where(n => n.DISTANCE < MINTURNS || n.DISTANCE >= MAXTURNS)){
                    foreach(FSMovement movement in choices[obj2].Where(n => n.MOVEMENTCONNECTOR != null)){
                        movement.MOVEMENTCONNECTOR.MakeLineVisible("BLACK");
                    }
                }
                foreach(GO obj2 in choices.Keys.Where(n => n.DISTANCE >= MINTURNS && n.DISTANCE < MAXTURNS).OrderBy(n => n.DISTANCE)){
                    GS.AddAction(obj, obj2.LABEL);
                    foreach(FSMovement movement in choices[obj2].Where(n => n.MOVEMENTCONNECTOR != null)){
                        movement.MOVEMENTCONNECTOR.MakeLineVisible("LIGHTBLUE");
                    }
                }
                foreach(int i in rangeLowerLimits.Where(n => n != MINTURNS)){
                    GS.AddAction(obj, i + " - " + (i + 20) + " TURNS");
                }
                if(obj.GAMELOCATION.TYPE == "ENROUTE" && obj.ENROUTEDELAY == 0){
                    targets.AddRange(MAPLINKS.Where(n => n.ZONE == obj.GAMELOCATION.ZONE));
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    if(pData.EndsWith(" TURNS")){
                        List<string> pDataParts = pData.Split(' ').ToList();
                        MINTURNS = CSVFile.ParseInt(pDataParts[0],0);
                        MAXTURNS = CSVFile.ParseInt(pDataParts[2],0);
                        Start(false);
                    } else {
                        GO destination = CHOICES.Keys.Where(n => n.LABEL == pData).Single();
                        GS.CHANGELOCATION(gp, destination.GAMELOCATION);
                        gp.ENROUTEDELAY = destination.DISTANCE;
                        if(FS.ISGROUP(gp)){
                            FS.GROUPMEMBERS(gp).ForEach(n => n.ENROUTEDELAY = destination.DISTANCE);
                        }
                        GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                        Start(false);
                    }
                    break;
            }
        }
        private Dictionary<GO, List<FSMovement>> FINDDESTINATIONS(GO loc){
            Dictionary<GO, List<FSMovement>> movementPathMap = new();
            FSMovement startMovement = new(){
                MOVEMENTLOCATIONID = loc.ID,
                MOVEMENTLOCATION = loc
            };
            List<List<FSMovement>> movementPaths = new(){ new(){ startMovement } };
            while(movementPaths.Count > 0){
                List<List<FSMovement>> newMovementPaths = new();
                foreach(List<FSMovement> movementPath in movementPaths){
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    foreach(FSMovement nextMovement in FS.GENERATESEALOGISTICALCONNECTIONS(from).Where(n => 
                                                                                !hexPath.Contains(n.MOVEMENTLOCATION))){
                        nextMovement.DISTANCE = nextMovement.MOVEMENTCONNECTOR.DISTANCE;
                        GO to = nextMovement.MOVEMENTLOCATION;
                        int newCost = movementPath.Sum(n => n.DISTANCE) + nextMovement.DISTANCE;
                        Boolean lowestCostToThisHex = true;
                        GO obj = movementPathMap.Keys.Where(n => n.GAMELOCATION == to).SingleOrDefault();
                        if(obj == null){
                            obj = new(){
                                LABEL = "",
                                GAMELOCATIONID = to.ID,
                                GAMELOCATION = to,
                                DISTANCE = newCost
                            };
                            movementPathMap.Add(obj, new());
                        } else {
                            double shortestCost = obj.DISTANCE;
                            lowestCostToThisHex = newCost < shortestCost;                        
                            if(!lowestCostToThisHex){continue;}
                        }
                        List<FSMovement> newMovementPath = new(movementPath){nextMovement};
                        movementPathMap[obj] = newMovementPath;
                        newMovementPaths.Add(newMovementPath);
                    }
                }
                movementPaths = newMovementPaths;
            }
            foreach(GO obj in movementPathMap.Keys){
                List<FSMovement> movements = movementPathMap[obj];
                foreach(FSMovement m in movements.Where(n => n != movements.First())){
                    obj.LABEL += " > " + m.MOVEMENTLOCATION.LABEL;
                }
                obj.DISTANCE = (int)Math.Ceiling(obj.DISTANCE / FS.MILESPERTURN);
                obj.LABEL += " (" + obj.DISTANCE + ")";
            }
            return movementPathMap;
        }
    }
    public class DeepMode : GamePhaseInteractive
    {
        string side = null;
        public DeepMode(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"SET SUBS IN/OUT OF DEEP MODE"});
                GS.HELPTEXT = 
                "This phase is your opportunity to set eligible Submarines into or out of 'Deep Mode'.\n\n" +
                "When done with your setup you can click the NEXT button.\n\n" +
                "NOTE: Submarines in Deep Mode will have a BLACK SQUARE covering their movement rating.";                
                
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => 
                n.UNITCATEGORY == "SUB" && 
                n.TEMPLATE.MOVEMENTALLOWANCE >= 2 &&
                n.ENROUTEDELAY == 0 &&
                !n.GAMELOCATION.FJORD &&
                !n.GAMELOCATION.SHALLOW &&
                !n.GAMELOCATION.RESTRICTED &&
                !n.DOCKED)){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "TURN DEEP MODE " + (obj.DEEPMODE ? "OFF" : "ON"));
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                case "TURN DEEP MODE OFF":
                case "TURN DEEP MODE ON":
                    gp.DEEPMODE = !gp.DEEPMODE;
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class StrategicAir : GamePhaseInteractive
    {
        public List<string> REACHABLEZONES(string zone, int range){
            HashSet<string> reachablezones = new(){zone};
            List<string> froms = new(reachablezones);
            for(int i = 0; i < range; i++){
                List<string> newfroms = new(froms);
                foreach(string from in new List<string>(froms)){
                    foreach(string to in FS.ZONECONNECTIONS[from].Where(n => !reachablezones.Contains(n))){
                        //special restriction
                        if(side == "SOV" && from == "NORTH SEA" && to == "BAY OF BISCAY"){continue;}
                        newfroms.Add(to);
                        if(!FS.UNDERCOMMANDFAILURE(GS, to, side, true)){
                            reachablezones.Add(to);
                        }
                    }
                }
                froms = newfroms;
            }
            return reachablezones.ToList();
        }
        Dictionary<GO, List<GO>> ELIGIBLEMAP = new();
        string side = null;
        public StrategicAir(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            DragDrop = true;
            ShowExpandedMenu = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                ELIGIBLEMAP.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG AIR UNIT TO STRATEGIC DISPLAY"});
                GS.HELPTEXT = 
                "Allocate available air units to strategic missions.  The game will only allow you to select air units that can perform a strategic mission, and will only allow you to drag the unit to a reachable zone.\n\n" +
                "- On damaged carriers, Only 1 air unit can be assigned.\n" +
                "- On damaged airfields, no air unit can be assigned.\n\n" +
                "When done with your setup you can click the NEXT button.  After both sides allocate, the Interception and Bounce segment will be Resolved.\n\n" +
                "NOTE: When selecting a unit, available locations on the strategic display(s) will have an indicator.";                
                List<GO> friendlyINTBases = new();
                List<GO> enemyINTBases = new();
                List<GO> strategicAirCandidates = new();
                List<GO> strategicLocs = GS.TYPE("STRATMISSIONLOCATION");
                foreach(GO obj in GS.TYPE("SQN")){
                    if(!FS.CANLAUNCHSTRATEGIC(obj)){continue;}
                    GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                    bool carrierDamaged = obj.CARRIER?.DAMAGED == true || obj.HOMEBASE?.DAMAGED == true;
                    if(obj.UNITTYPE == "INT" && !carrierDamaged){
                        if(obj.SIDE == side){
                            friendlyINTBases.Add(locationToCheck);
                        } else {
                            enemyINTBases.Add(locationToCheck);
                        }
                    }
                    if(obj.SIDE != side || obj.MOVEMENTALLOWANCE < 11){continue;}
                    strategicAirCandidates.Add(obj);
                }
                List<GO> enemyCovered = new();
                //eliminate enemy INT if nearby friendly INT
                foreach(GO enemyINTBase in enemyINTBases.Distinct()){
                    List<GO> airRadius = FS.FINDAIRRADIUS(enemyINTBase, 4);
                    if(airRadius.Intersect(friendlyINTBases).Any()){continue;}
                    enemyCovered.AddRange(airRadius);
                }
                foreach(GO obj in strategicAirCandidates){
                    string sqnType = obj.UNITTYPE;
                    //special considerations RCN must have ASW value to do mining
                    bool nonMiningRCN = obj.TEMPLATE.ASW == 0 && sqnType == "RCN";
                    GO locationToCheck = FS.PARENTGROUPLOCATION(obj);
                    //if within 4 of enemy INT, skip
                    if(enemyCovered.Contains(locationToCheck)){
                        continue;
                    }
                    List<GO> targets = new();
                    //find zone range
                    int zoneRange = obj.MOVEMENTALLOWANCE > 70 ? 3 : obj.MOVEMENTALLOWANCE > 50 ? 2 : obj.MOVEMENTALLOWANCE > 25 ? 1 : 0;
                    //find reachable zones
                    List<string> reachableZones = REACHABLEZONES(locationToCheck.ZONE, zoneRange).Where(n => !FS.STORM(GS, n)).ToList();
                    foreach(GO sLoc in strategicLocs.Where(n => reachableZones.Contains(n.ZONE) && FS.MISSIONELIGIBILITY[sqnType].Contains(n.AIRMISSION))){
                        if(sLoc.AIRMISSION != "STRATMINING" || !nonMiningRCN){
                            targets.Add(sLoc);
                        }
                    }
                    if(targets.Any()){
                        GS.InteractionMap.Add(obj, targets);
                        ELIGIBLEMAP.Add(obj, targets);
                    }
                }
            }

            //foreach(GO obj in GS.InteractionMap.Keys){}
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                if(obj.GAMELOCATION.TYPE == "STRATMISSIONLOCATION"){GS.AddAction(obj, "UNDO");}
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    foreach(GO obj in GS.InteractionMap.Keys.Where(n => n.GAMELOCATION.AIRMISSION != null)){
                        obj.AIRMISSION = obj.GAMELOCATION.AIRMISSION + (obj.GAMELOCATION.AIRMISSION == "STRATRECON" ? ".SURFACE" : "");
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case "UNDO":
                    GO homeBase = gp.HOMEBASE;
                    if(homeBase.DOMAIN == GO.DOMAIN_LOCATION){
                        GS.CHANGELOCATION(gp, homeBase);
                    } else {
                        //if homebase is carrier, and carrier is damaged, move all other air units back to interaction map
                        if(gp.HOMEBASE.DAMAGED){
                            foreach(GO obj in ELIGIBLEMAP.Keys.Where(n => n.CARRIER == gp.HOMEBASE)){
                                GS.InteractionMap.Add(obj, new(ELIGIBLEMAP[obj]));
                            }
                        }
                        FS.ADDTOGROUP(gp, homeBase);
                    }                    
                    gp.HOMEBASEID = null;
                    Start(false);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, gp.TEMPLOCATIONID);
                        GO newloc = gp.GAMELOCATION;
                        if(newloc.TYPE == "STRATMISSIONLOCATION"){
                            if(gp.CARRIERID != null){
                                gp.HOMEBASEID = gp.CARRIERID;
                                gp.HOMEBASE = gp.CARRIER;
                                gp.CARRIERID = null;
                            } else if(gp.HOMEBASEID == null){
                                gp.HOMEBASEID = oldloc.ID;
                                gp.HOMEBASE = oldloc;
                            }
                            if(oldloc.TYPE == "TRAYLOCATION"){
                                GO oldsheet = oldloc.PARENTSHEET;
                                GO oldgroup = oldsheet.SHEETPARENTPIECE;
                                FS.REMOVEFROMGROUP(gp, oldgroup);
                            }
                            //if homebase is carrier, and carrier is damaged, move all other air units out of interaction map
                            if(gp.HOMEBASE.DOMAIN == GO.DOMAIN_PIECE){
                                if(gp.HOMEBASE.DAMAGED){
                                    foreach(GO obj in ELIGIBLEMAP.Keys.Where(n => n.CARRIER == gp.HOMEBASE)){
                                        GS.REMOVEINTERACTIVE(obj);
                                    }
                                }
                            }
                        }
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class StrategicAirCalculation : GamePhaseAutomated
    {
        public StrategicAirCalculation(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            foreach(GO combatLoc in GS.TYPE("STRATMISSIONLOCATION").Where(n => n.AIRMISSION == "STRATINTERCEPTION")){
                GO sheet = combatLoc.PARENTSHEET;
                sheet.BOUNCEELIGIBLE = false;
                sheet.INTERCEPTIONELIGIBLE = false;
                sheet.ACTIVATED = false;
                sheet.ALLIESSTEPLOSSES = 0;
                sheet.SOVSTEPLOSSES = 0;
                //if units in both side
                string attackingSide = FS.DIEROLL() % 2 == 0 ? "ALLIES" : "SOV";
                string defendingSide = FS.ENEMY(attackingSide);
                List<GO> attackers = FS.TYPESIDELOCATION(GS, "SQN", attackingSide, combatLoc.ID);
                List<GO> defenders = FS.TYPESIDELOCATION(GS, "SQN", defendingSide, combatLoc.ID);
                List<GO> attackerBounceTargets = GS.TYPE("SQN", "PARENTSHEETID", sheet.ID).
                    Where(n => n.GAMELOCATION.TYPE == "STRATMISSIONLOCATION" && 
                        n.GAMELOCATION != combatLoc && 
                        n.SIDE == attackingSide).ToList();
                List<GO> defenderBounceTargets = GS.TYPE("SQN", "PARENTSHEETID", sheet.ID).
                    Where(n => n.GAMELOCATION.TYPE == "STRATMISSIONLOCATION" && 
                        n.GAMELOCATION != combatLoc && 
                        n.SIDE == defendingSide).ToList();
                if(attackers.Any() && defenders.Any()){
                    sheet.INTERCEPTIONELIGIBLE = true;
                }
                if((attackers.Any() && defenderBounceTargets.Any()) || (defenders.Any() && attackerBounceTargets.Any())){
                    sheet.BOUNCEELIGIBLE = true;
                }
            }
            GS.Advance(this);
        }
    }
    public class StrategicAirInterception : GamePhaseAutomated
    {
        public StrategicAirInterception(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            GO sheet = FS.STRATAIRSHEETS.Where(n => n.INTERCEPTIONELIGIBLE || n.BOUNCEELIGIBLE).FirstOrDefault();
            sheet.ACTIVATED = true;
            Window().ScrollToCoordinate(sheet.GAMELOCATION.x, sheet.GAMELOCATION.y, true);
            List<GO> combatants = GS.TYPE("SQN", "PARENTSHEETID", sheet.ID).Where(n => n.GAMELOCATION.AIRMISSION == "STRATINTERCEPTION").ToList();
            //if units in both side
            string attackingSide = FS.DIEROLL() % 2 == 0 ? "ALLIES" : "SOV";
            string defendingSide = FS.ENEMY(attackingSide);
            List<GO> attackers = combatants.Where(n => n.SIDE == attackingSide).ToList();
            List<GO> defenders = combatants.Where(n => n.SIDE == defendingSide).ToList();
            if(attackers.Any() && defenders.Any()){
                attackers.ForEach(n => n.ADMINDETECTED = true);
                defenders.ForEach(n => n.ADMINDETECTED = true);                
                string report = "INTERCEPTION COMBAT : " + sheet.ZONE + " - " + attackingSide + " vs " + defendingSide + "\n\n";
                double atkAArating = attackers.Sum(n => n.TEMPLATE.CAA);
                bool atkEW = attackers.Where(n => n.UNITTYPE == "EW").Any();
                double defAArating = defenders.Sum(n => n.TEMPLATE.CAA);
                bool defEW = defenders.Where(n => n.UNITTYPE == "EW").Any();

                double ratio = atkAArating / defAArating;
                double columnRatio = FS.INTERCEPTIONCOLUMNS.Keys.Where(n => n <= ratio).Any() ? FS.INTERCEPTIONCOLUMNS.Keys.Where(n => n <= ratio).Last() : FS.INTERCEPTIONCOLUMNS.Keys.Order().First();
                string columnHeader = FS.INTERCEPTIONCOLUMNHEADER(columnRatio);
                report += "COLUMN: " + columnHeader + "\n";
                int rollmodifier = (atkEW ? 2 : 0) + (defEW ? -2 : 0);
                report += "ROLL modifier: " + rollmodifier + "\n";
                int dieRoll = Math.Min(9, Math.Max(0, FS.DIEROLL() + rollmodifier));
                report += "ROLL: " + dieRoll + "\n";
                List<string> results = FS.INTERCEPTIONRESULTS(columnHeader, dieRoll);
                report += "RESULTS: " + results[0] + "/" + results[1];
                MainWindow.Alert(report);
                string atkResult = results[0];
                if(atkResult.Contains("R")){
                    atkResult = atkResult.Replace("R","");
                    attackers.ForEach(n => n.MUSTRETREAT = true);        
                }
                sheet.Set(attackingSide + "STEPLOSSES", atkResult);
                string defResult = results[1];
                if(defResult.Contains("R")){
                    defResult = defResult.Replace("R","");
                    defenders.ForEach(n => n.MUSTRETREAT = true);        
                }
                sheet.Set(defendingSide + "STEPLOSSES", defResult);
            }
            GS.Advance(this);           
        }
    }
    public class StrategicAirInterceptionPickCasualties : GamePhaseInteractive
    {
        int stepLosses = 0;
        string side = null;
        GO selectedSheet = null;
        public StrategicAirInterceptionPickCasualties(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                selectedSheet = FS.STRATAIRSHEETS.Where(n => n.ACTIVATED).Single();
                stepLosses = side == "SOV" ? selectedSheet.ALLIESSTEPLOSSES : selectedSheet.SOVSTEPLOSSES;
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "Choose the ENEMY squadrons to apply losses to. You must choose INTs first before other types.\n\n" +
                "When all step losses have been applied, the phase will end.  Any retreats will be carried out automatically at the end of this phase.\n\n" +
                "NOTE: You will be temporarily able to see ENEMY squadrons in the strategic display in order to pick the units."; 
                foreach(GO obj in GS.TYPE("SQN", "PARENTSHEETID", selectedSheet.ID).Where(n => n.SIDE == FS.ENEMY(side) && n.GAMELOCATION.AIRMISSION == "STRATINTERCEPTION")){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(stepLosses == 0 || !GS.InteractionMap.Keys.Any()){
                selectedSheet.Set(FS.ENEMY(side) + "STEPLOSSES", "0");
                selectedSheet.INTERCEPTIONELIGIBLE = false;
                GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", selectedSheet.ZONE).Single();
                foreach(GO obj in GS.InteractionMap.Keys){
                    if(obj.MUSTRETREAT){
                        obj.MUSTRETREAT = false;
                        GS.CHANGELOCATION(obj, RTBLocation);
                    }
                }
                FS.ADVANCESIDE(this, side);
                return;
            }
            FS.SETINSTRUCTIONS(GS, new(){"APPLY LOSSES: STEPS REMAINING TO SELECT = " + stepLosses});
            bool INTPRESENT = GS.InteractionMap.Keys.Where(n => n.UNITTYPE == "INT").Any();
            foreach(GO obj in GS.InteractionMap.Keys){
                if(obj.UNITTYPE == "INT" || !INTPRESENT){GS.AddAction(obj, "APPLY LOSS");};
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){}
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "APPLY LOSS":
                    FS.DAMAGE(gp);
                    stepLosses--;
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class StrategicAirBounce : GamePhaseAutomated
    {
        public StrategicAirBounce(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            GO sheet = FS.STRATAIRSHEETS.Where(n => n.ACTIVATED).Single();            
            List<GO> combatants = GS.TYPE("SQN", "PARENTSHEETID", sheet.ID).Where(n => n.GAMELOCATION.AIRMISSION != null).ToList();
            //if units in both side
            string attackingSide = FS.DIEROLL() % 2 == 0 ? "ALLIES" : "SOV";
            string defendingSide = FS.ENEMY(attackingSide);
            List<GO> attackers = combatants.Where(n => n.GAMELOCATION.AIRMISSION == "STRATINTERCEPTION" && n.SIDE == attackingSide).ToList();
            List<GO> defenders = combatants.Where(n => n.GAMELOCATION.AIRMISSION == "STRATINTERCEPTION" && n.SIDE == defendingSide).ToList();
            List<GO> attackerBounceTargets = combatants.
                Where(n => n.GAMELOCATION.AIRMISSION != "STRATINTERCEPTION" && 
                    n.SIDE == attackingSide).ToList();
            List<GO> defenderBounceTargets = combatants.
                Where(n => n.GAMELOCATION.AIRMISSION != "STRATINTERCEPTION" && 
                    n.SIDE == defendingSide).ToList();
            if(attackers.Any() != defenders.Any()){
                if((attackers.Any() && defenderBounceTargets.Any()) || (defenders.Any() && attackerBounceTargets.Any())){
                    if(attackers.Any()){
                       defenders = defenderBounceTargets; 
                    } else {
                        attackers = defenders;
                        attackingSide = defendingSide;
                        defendingSide = FS.ENEMY(attackingSide);
                        defenders = attackerBounceTargets;
                    }
                    string report = "BOUNCE COMBAT : " + sheet.ZONE + " - " + attackingSide + " vs " + defendingSide + "\n\n";
                    bool atkEW = attackers.Where(n => n.UNITTYPE == "EW").Any();
                    bool defEW = false;

                    report += "COLUMN: Bounce\n";
                    int rollmodifier = (atkEW ? 2 : 0) + (defEW ? -2 : 0);
                    report += "ROLL modifier: " + rollmodifier + "\n";
                    int dieRoll = Math.Min(9, Math.Max(0, FS.DIEROLL() + rollmodifier));
                    report += "ROLL: " + dieRoll + "\n";
                    List<string> results = FS.BOUNCERESULTS(dieRoll);
                    report += "RESULTS: " + results[0] + "/" + results[1];
                    MainWindow.Alert(report);
                    string atkResult = results[0];
                    if(atkResult.Contains("R")){
                        atkResult = atkResult.Replace("R","");
                        attackers.ForEach(n => n.MUSTRETREAT = true);        
                    }
                    if(atkResult != "0"){
                        attackers.ForEach(n => n.ADMINDETECTED = true);
                    }
                    sheet.Set(attackingSide + "STEPLOSSES", atkResult);
                    string defResult = results[1];
                    if(defResult.Contains("R")){
                        defResult = defResult.Replace("R","");
                        defenders.ForEach(n => n.MUSTRETREAT = true);        
                    }
                    if(defResult != "0"){
                        defenders.ForEach(n => n.ADMINDETECTED = true);
                    }
                    sheet.Set(defendingSide + "STEPLOSSES", defResult);
                }
            }
            GS.Advance(this);           
        }
    }
    public class StrategicAirBouncePickCasualties : GamePhaseInteractive
    {
        int stepLosses = 0;
        string side = null;
        GO selectedSheet = null;
        public StrategicAirBouncePickCasualties(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) { 
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                selectedSheet = FS.STRATAIRSHEETS.Where(n => n.ACTIVATED).Single();
                stepLosses = side == "SOV" ? selectedSheet.ALLIESSTEPLOSSES : selectedSheet.SOVSTEPLOSSES;
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "Choose the ENEMY squadrons to apply losses to.\n\n" +
                "When all step losses have been applied, the phase will end.  Any retreats will be carried out automatically at the end of this phase.\n\n" +
                "NOTE: You will be temporarily able to see ENEMY squadrons in the strategic display in order to pick the units."; 
                foreach(GO obj in GS.TYPE("SQN", "PARENTSHEETID", selectedSheet.ID).Where(n => n.SIDE == FS.ENEMY(side) && n.GAMELOCATION.AIRMISSION != null)){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(stepLosses == 0 || !GS.InteractionMap.Keys.Any()){
                selectedSheet.Set(FS.ENEMY(side) + "STEPLOSSES", "0");
                selectedSheet.BOUNCEELIGIBLE = false;
                GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", selectedSheet.ZONE).Single();
                foreach(GO obj in GS.InteractionMap.Keys){
                    if(obj.MUSTRETREAT){
                        obj.MUSTRETREAT = false;
                        GS.CHANGELOCATION(obj, RTBLocation);
                    }
                }
                if(side != GS.Get("ACTIVE.SIDE1")){selectedSheet.ACTIVATED = false;}
                FS.ADVANCESIDE(this, side);
                return;
            }
            FS.SETINSTRUCTIONS(GS, new(){"APPLY LOSSES: STEPS REMAINING TO SELECT = " + stepLosses});
            foreach(GO obj in GS.InteractionMap.Keys){
                GS.AddAction(obj, "APPLY LOSS");
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){}
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "APPLY LOSS":
                    FS.DAMAGE(gp);
                    stepLosses--;
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class StrategicAirInterceptionRTB : GamePhaseAutomated
    {
        public StrategicAirInterceptionRTB(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            foreach(GO obj in GS.TYPE("SQN").Where(n => n.AIRMISSION == "STRATINTERCEPTION" && n.GAMELOCATION.AIRMISSION == "STRATINTERCEPTION")){
                GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", obj.GAMELOCATION.ZONE).Single();
                GS.CHANGELOCATION(obj, RTBLocation);
            }
            GS.Advance(this);           
        }
    }
    public class StrategicAirMining : GamePhaseInteractive
    {
        List<GO> DEPLOYEDMINES = new();
        List<GO> DEPLOYMENTLOCATIONS = new();
        string side = null;
        public StrategicAirMining(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            DragDrop = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                DEPLOYEDMINES = GS.TYPE("MINEMARKER").Where(n => n.SIDE != null).ToList();
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "Perform mining missions.  Per the rules, you can drag an air unit performing the mission to any coastal, fjord, restricted, or shallow hex.\n" + 
                "The game will restrict you to those hexes, within the zone the aircraft is in.\n\n" +
                "The game will only allow dropping mines up to a user-configurable amount in the scenario file.  This number is per SIDE per THEATER (ATLANTIC, CARIBBEAN, etc).  The game will track the number of mines deployed.\n\n" +
                "SOV side will be able to use SUBs with 3+ TORP logistic boxes.  For Subs, you can drag to a neighboring allowable hex.\n\n" +
                "When done with your setup you can click the NEXT button.  Air units will be moved to the RTB box in the respective zone.\n\n" +
                "NOTE: When selecting a unit, available locations on the map will have an indicator.";                
                DEPLOYMENTLOCATIONS = GS.TYPE("HEX").Where(n => FS.THEATERS.ContainsKey(n.ORGLEVEL1) &&
                n.TERRAIN == "SEA" && (n.COUNTRY != null || n.RESTRICTED || n.FJORD || n.SHALLOW)).ToList();
                List<GO> eligibleSQNs = FS.TYPESIDE(GS, "SQN", side).Where(n => n.GAMELOCATION.AIRMISSION == "STRATMINING").ToList();
                List<GO> eligibleSUBs = side == "ALLIES" ? new() : FS.TYPESIDE(GS, "SHIP", side).Where(n => n.UNITCATEGORY == "SUB" && n.TORPPTS >= 3).ToList();
                List<string> MAXEDOUTTHEATERS = FS.THEATERS.Keys.Where(n => DEPLOYEDMINES.Where(n2 => n2.SIDE == side && n2.GAMELOCATION.ORGLEVEL1 == n).Count() == GS.GetInt("_CONFIG_MINES_PER_SIDE_PER_THEATER")).ToList();
                DEPLOYMENTLOCATIONS.RemoveAll(n => MAXEDOUTTHEATERS.Contains(n.ORGLEVEL1));
                List<GO> MAXEDOUTLOCATIONS = DEPLOYEDMINES.Where(n => GS.TYPE("MINEMARKER", "GAMELOCATIONID", n.GAMELOCATIONID).Count == 4).ToList();
                DEPLOYMENTLOCATIONS.RemoveAll(MAXEDOUTLOCATIONS.Contains);
                foreach(GO obj in eligibleSQNs){
                    List<GO> targets = DEPLOYMENTLOCATIONS.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList();
                    if(targets.Any()){
                        GS.InteractionMap.Add(obj, targets);
                    }
                }
                foreach(GO obj in eligibleSUBs){
                    List<GO> targets = FS.FINDSUBMOVEMENTS(obj, obj.GAMELOCATION).Where(n => DEPLOYMENTLOCATIONS.Contains(n.MOVEMENTLOCATION)).Select(n => n.MOVEMENTLOCATION).ToList();
                    if(targets.Any()){
                        GS.InteractionMap.Add(obj, targets);
                    }
                }
            }
            foreach(GO obj in GS.InteractionMap.Keys.ToList()){
                List<GO> targets = GS.InteractionMap[obj];
                targets.RemoveAll(n => !DEPLOYMENTLOCATIONS.Contains(n));
                if(!targets.Any()){
                    GS.InteractionMap.Remove(obj);
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO gp = GS.SelectedMarker;
                string minesDeployed = DEPLOYEDMINES.Where(n2 => n2.SIDE == side && n2.GAMELOCATION.ORGLEVEL1 == gp.GAMELOCATION.ORGLEVEL1).Count() + "/" + GS.Get("_CONFIG_MINES_PER_SIDE_PER_THEATER");
                FS.SETINSTRUCTIONS(GS, side == "SOV" ? new(){"DRAG AIR UNIT TO TARGET HEX", "DRAG SUB TO TARGET HEX", "MINES DEPLOYED: " + minesDeployed} : new(){"DRAG AIR UNIT TO TARGET HEX", "MINES DEPLOYED: " + minesDeployed});
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    foreach(GO obj in GS.InteractionMap.Keys.Where(n => n.UNITCATEGORY == "AIR")){
                        GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", obj.GAMELOCATION.ZONE).Single();
                        GS.CHANGELOCATION(obj, RTBLocation);
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, oldloc);
                        GO newloc = GS.LOCATION(gp.TEMPLOCATIONID);
                        GO template = GS.PIECE("MINE");
                        GO clone = FS.CLONE(GS, template, gp.TEMPLOCATIONID);
                        clone.SIDE = side;
                        DEPLOYEDMINES.Add(clone);
                        List<string> MAXEDOUTTHEATERS = FS.THEATERS.Keys.Where(n => DEPLOYEDMINES.Where(n2 => n2.SIDE == side && n2.GAMELOCATION.ORGLEVEL1 == n).Count() == GS.GetInt("_CONFIG_MINES_PER_SIDE_PER_THEATER")).ToList();
                        DEPLOYMENTLOCATIONS.RemoveAll(n => MAXEDOUTTHEATERS.Contains(n.ORGLEVEL1));
                        List<GO> MAXEDOUTLOCATIONS = DEPLOYEDMINES.Where(n => GS.TYPE("MINEMARKER", "GAMELOCATIONID", n.GAMELOCATIONID).Count == 4).ToList();
                        DEPLOYMENTLOCATIONS.RemoveAll(MAXEDOUTLOCATIONS.Contains);
                        //if sub, remove ammo
                        if(gp.UNITCATEGORY == "SUB"){
                            gp.TORPPTS -= 3;
                        } else {
                            GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", gp.GAMELOCATION.ZONE).Single();
                            GS.CHANGELOCATION(gp, RTBLocation);
                        }
                        GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class StrategicAirRecon : GamePhaseInteractive
    {
        List<GO> RECONATTEMPTS = new();
        List<GO> SURFACERECONLOCATIONS = new();
        List<GO> SURFACEENEMYINTLOCATIONS = new();
        List<GO> SUBRECONLOCATIONS = new();
        string side = null;
        public StrategicAirRecon(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
            DragDrop = true;
            ShowExpandedMenu = true;
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                RECONATTEMPTS.Clear();
                SURFACEENEMYINTLOCATIONS.Clear();
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"DRAG AIR UNIT TO TARGET HEX"});

                GS.HELPTEXT = 
                "Perform recon missions.  In this phase, the power of automation requires a slight change to how this phase works.  In the physical game " +
                "you can see all enemy units and you simply click the stack. In this game, you can't see all units so this phase works differently.  You can pick any sea hex in the affected zone as the " +
                "'center' of your search, and a 'Recon Attempt' marker will be created at the location.  At the end of the phase, automation will 100% pick the nearest surface stack " +
                "and Strategically detect it (if in SURFACE mode) or attempt a detection on the nearest Submarine (if in SUB mode).  You can increase the chances on the Sub searches by " + 
                "adding attempt markers to that same hex from multiple air units.\n\n" + 
                "To set the search mode (SURFACE vs SUB) right click the air unit.  Only air unit with ASW factor can go to SUB mode.\n" + 
                "You can UNDO a search marker placement by right clicking on the attempt marker and selecting the option.\n\n" +
                "Rules concerning Enemy INT are adhered to in the placement of the 'attempt' marker AND in the automated search that follows (i.e. a stack under INT protection will not be picked by the automation). " +
                "Other rules enforced include allowing certain air designated as LONGRANGERECON to detect Surface units under INT protection, and only one attempt per sub is allowed by the automation.\n\n" +
                "When done with your setup you can click the NEXT button.  Air units will be moved to the RTB box in the respective zone after performing the search automation.\n\n" +
                "NOTE: Sub attempt markers in the same hex will combine ASW values to perform Detection attempt.\n" +
                "NOTE: When selecting a unit, available locations on the map will have an indicator.";  
                //find INTs on non-damaged airfields  
                List<GO> enemyINTRange4 = new();
                foreach(GO obj in FS.TYPESIDE(GS, "SQN", FS.ENEMY(side)).Where(n =>
                n.UNITTYPE == "INT" && 
                n.AIRMISSION == null &&
                n.ENROUTEDELAY == 0 &&
                (n.GAMELOCATION.AIRFIELD || n.HOMEBASE?.AIRFIELD == true) &&
                !(n.GAMELOCATION.AIRFIELDDAMAGELEVEL > 0 || n.HOMEBASE?.AIRFIELDDAMAGELEVEL > 0))){
                    //find hexes adjacent;
                    SURFACEENEMYINTLOCATIONS.AddRange(FS.FINDAIRRADIUS(obj.GAMELOCATION, 1));
                    enemyINTRange4.AddRange(FS.FINDAIRRADIUS(obj.GAMELOCATION, 4));
                } 
                SURFACERECONLOCATIONS = GS.TYPE("HEX").Where(n => FS.THEATERS.ContainsKey(n.ORGLEVEL1) && n.TERRAIN == "SEA" && !n.PACKICE).ToList();
                SUBRECONLOCATIONS = SURFACERECONLOCATIONS.Where(n => !enemyINTRange4.Contains(n)).ToList();

                foreach(GO obj in FS.TYPESIDE(GS, "SQN", side).Where(n => n.GAMELOCATION.AIRMISSION == "STRATRECON")){
                    GS.InteractionMap.Add(obj, GETRECONLOCATIONS(obj));
                }
            }
            foreach(GO obj in GS.InteractionMap.Keys.ToList()){
                if(obj.GAMEPIECEID != null){GS.AddAction(obj, "UNDO"); continue;}
                switch(obj.AIRMISSION){
                    case "STRATRECON.SURFACE":
                        if(obj.TEMPLATE.ASW > 0){GS.AddAction(obj, "CHANGE TO SUB RECON");}
                        break;
                    case "STRATRECON.SUB":
                        GS.AddAction(obj, "CHANGE TO SURFACE RECON");
                        break;
                    default:
                        break;
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        private List<GO> GETRECONLOCATIONS(GO obj){
            if(obj.TYPE == "SQN"){
                if(obj.AIRMISSION == "STRATRECON.SURFACE"){
                    List<GO> locs = SURFACERECONLOCATIONS.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList();
                    if(!obj.TEMPLATE.LONGRANGERECON){
                        locs.RemoveAll(SURFACEENEMYINTLOCATIONS.Contains);
                    }
                    return locs;
                } else {
                    return SUBRECONLOCATIONS.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList();
                }
            } else {
                if(obj.UNITCATEGORY == "SURFACE"){
                    List<GO> locs = SURFACERECONLOCATIONS.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList();
                    if(!obj.LONGRANGERECON){
                        locs.RemoveAll(SURFACEENEMYINTLOCATIONS.Contains);
                    }
                    return locs;
                } else {
                    return SUBRECONLOCATIONS.Where(n => n.ZONE == obj.GAMELOCATION.ZONE).ToList();
                }
            }
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    //make sure all air units are on mission
                    if(GS.InteractionMap.Keys.Where(n => n.GAMEPIECE == null).Any()){
                        MainWindow.Alert("You must assign all aircraft eligible");
                        Start(false);
                        break;
                    }
                    string report = "";
                    List<GO> ATTEMPTEDSUBS = new();
                    foreach(string zone in RECONATTEMPTS.Select(n => n.GAMELOCATION.ZONE).Distinct().Order()){
                        string zonereport = "";
                        foreach(string category in new List<string>{"SUB", "SURFACE"}){
                            foreach(GO loc in RECONATTEMPTS.Where(n => n.UNITCATEGORY == category && n.GAMELOCATION.ZONE == zone).Select(n => n.GAMELOCATION).Distinct()){
                                List<GO> attempts = RECONATTEMPTS.Where(n => n.UNITCATEGORY == category && n.GAMELOCATION == loc).ToList();
                                if(category == "SUB"){
                                    GO attempt = attempts.First();
                                    attempt.ASW = attempts.Sum(n => n.ASW);
                                    attempts = new(){attempt};
                                }
                                foreach(GO attempt in attempts){
                                    if(category == "SURFACE"){
                                        //if surface, find all enemy locations where ships are not strategically detected                                
                                        List<GO> locs = FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => n.UNITCATEGORY == category &&
                                        n.GAMELOCATION.ZONE == attempt.GAMELOCATION.ZONE &&
                                        !n.STRATDETECTED).Select(n => n.GAMELOCATION).Distinct().ToList();
                                        locs.RemoveAll(n => !GETRECONLOCATIONS(attempt).Contains(n));
                                        GO target = locs.OrderBy(n => MainWindow.GetDistance(attempt.GAMELOCATION, n.x, n.y)).FirstOrDefault();
                                        if(target != null){
                                            List<GO> ships = FS.ALLSHIPSINHEX(FS.ENEMY(side), target, true, false);
                                            FS.STRATDETECT(ships, true);
                                            zonereport += loc.ID + ": detected " + ships.Count + " surface ships\n";
                                        }
                                    } else {
                                        //find all enemy subs who are not strategically detected and haven't been attempted on 
                                        List<GO> subs = FS.TYPESIDE(GS, "SHIP", FS.ENEMY(side)).Where(n => n.UNITCATEGORY == category &&
                                        n.GAMELOCATION.ZONE == attempt.GAMELOCATION.ZONE &&
                                        !n.STRATDETECTED &&
                                        !ATTEMPTEDSUBS.Contains(n)).ToList();
                                        subs.RemoveAll(n => !GETRECONLOCATIONS(attempt).Contains(n.GAMELOCATION));
                                        GO target = subs.OrderBy(n => MainWindow.GetDistance(attempt.GAMELOCATION, n.GAMELOCATION.x, n.GAMELOCATION.y)).FirstOrDefault();
                                        if(target != null){
                                            if(FS.SUBDETECTIONRESULT(target, "STRATRECON", null, new(){attempt}) == "D"){
                                                target.STRATDETECTED = true;
                                                zonereport += loc.ID + ": detected " + target.UNITTYPE + " " + target.LABEL + "\n";
                                            }
                                            ATTEMPTEDSUBS.Add(target);
                                        }
                                    }                                
                                }
                            }
                        }
                        report += "---- " + zone + " ----\n" + (zonereport == "" ? "Unsuccessful" : zonereport) + "\n";                        
                    }
                    if(report != ""){
                        MainWindow.Alert(report);
                    }
                    foreach(GO obj in GS.InteractionMap.Keys.ToList()){
                        obj.GAMEPIECEID = null;
                        if(obj.UNITCATEGORY == "AIR"){
                            GO RTBLocation = GS.TYPE("STRATRTBLOCATION", "ZONE", obj.GAMELOCATION.ZONE).Single();
                            GS.CHANGELOCATION(obj, RTBLocation);
                        } else {
                            GS.DISCARD(obj);
                        }
                    }
                    FS.ADVANCESIDE(this, side);
                    break;
                case "UNDO":
                    //remove attempt marker, make recon unit useable
                    GO reconmarker = gp.TYPE == "RECONMARKER" ? gp : gp.GAMEPIECE;
                    GO reconsqn = gp.TYPE == "RECONMARKER" ? gp.GAMEPIECE : gp;
                    RECONATTEMPTS.Remove(reconmarker);
                    GS.DISCARD(reconmarker);
                    reconsqn.GAMEPIECEID = null;
                    reconmarker.GAMEPIECEID = null;
                    GS.SelectedMarker = reconsqn;
                    GS.InteractionMap[reconsqn] = GETRECONLOCATIONS(reconsqn);
                    Start(false);
                    break;
                case "CHANGE TO SUB RECON":
                    //update AIRMISSION
                    gp.AIRMISSION = "STRATRECON.SUB";
                    GS.InteractionMap[gp] = GETRECONLOCATIONS(gp);
                    Start(false);
                    break;
                case "CHANGE TO SURFACE RECON":
                    //update AIRMISSION
                    gp.AIRMISSION = "STRATRECON.SURFACE";
                    GS.InteractionMap[gp] = GETRECONLOCATIONS(gp);
                    Start(false);
                    break;
                case null:
                    GO oldloc = gp.GAMELOCATION;
                    if(gp.TEMPLOCATIONID != null && gp.TEMPLOCATIONID != gp.GAMELOCATIONID){
                        GS.CHANGELOCATION(gp, oldloc);
                        GO newloc = GS.LOCATION(gp.TEMPLOCATIONID);
                        //add attempt marker
                        GO template = GS.PIECE("RECON" + gp.AIRMISSION.Split('.').Last());
                        GO clone = FS.CLONE(GS, template, gp.TEMPLOCATIONID);
                        clone.SIDE = side;
                        clone.ASW = gp.TEMPLATE.ASW;
                        clone.LONGRANGERECON = gp.TEMPLATE.LONGRANGERECON;
                        clone.GAMEPIECEID = gp.ID;
                        clone.GAMEPIECE = gp;
                        gp.GAMEPIECEID = clone.ID;
                        gp.GAMEPIECE = clone;
                        RECONATTEMPTS.Add(clone);
                        GS.InteractionMap[gp].Clear();
                        //add attempt marker to action map
                        GS.InteractionMap.Add(clone, new());
                        GS.SelectedMarker = clone;
                        Start(false);
                    } else {
                        Start(false);
                    }
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
}