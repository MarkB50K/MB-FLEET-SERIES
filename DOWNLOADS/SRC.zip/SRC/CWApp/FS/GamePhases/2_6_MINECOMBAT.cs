using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
namespace CWApp.FS
{    
    public class ActionMINECombat : GamePhaseLoopLogic
    {
        public ActionMINECombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionMINECombatLoadTrays("Load Trays", this, GS));
            AddGamePhase(new ActionMINECombatResolution("Resolution", this, GS));
            AddGamePhase(new ActionMINECombatPickCasualties("Pick Casualties", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOLOGICS(GS, "ACTION.MINECOMBAT").Any();}
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.MINECOMBAT");
            GO firstcombat = combats.First();
            List<GO> combined_combats = new(){firstcombat};
            List<GO> defenders = combined_combats.Select(n => n.DEFENDER).ToList();
            combats.RemoveAll(n => combined_combats.Contains(n));
            FS.SETSCENARIOOBJECTS(GS, "ACTION.MINECOMBAT", combats);
            defenders = defenders.Where(n => 
                    n.SIDE != null &&
                    n.ENROUTEDELAY == 0).ToList();
            
            FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", defenders);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDERLOC", new(){firstcombat.DEFENDERLOCATION});
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", new());
            combined_combats.ForEach(FS.DISCARDLOGIC);
        }
        public override void End()
        {
            FS.REMOVECOMBATSHEET();   
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDERLOC");
        }
    }
    public class ActionMINECombatLoadTrays : GamePhaseAutomated
    {
        public ActionMINECombatLoadTrays(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            if(FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Any()){
                List<GO> tagged = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER").Where(n => n.TYPE != "FACILITY").ToList();
                List<GO> defenders = tagged.Where(n => !FS.ISGROUP(n) && !n.DOCKED).ToList();
                defenders.AddRange(tagged.Where(n => !FS.ISGROUP(n) && n.DOCKED));
                defenders.AddRange(tagged.Where(n => FS.ISGROUP(n)));
                foreach(GO obj in defenders){
                    obj.HOMEBASEID = obj.GAMELOCATIONID;
                    obj.HOMEBASE = obj.GAMELOCATION;
                }
                if(defenders.Any()){
                    FS.DISPLAYCOMBATSHEET(GS, defenders, GS.LOCATION("ALLDESTROYED"));                        
                }
            }
            GS.Advance(this);           
        }
    }
    public class ActionMINECombatResolution : GamePhaseAutomated
    {
        public ActionMINECombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            SetInt("ACTION.DEFENSEMODIFIER", 0);
            //any losses to attacking aircraft
            SetInt("ACTION.ATTACKERLOSSES", 0);
            SetInt("ACTION.DEFENDERLOSSES", 0);
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            if(defenders.Any()){
                GO firstDefender = defenders.First();
                string defendingSide = firstDefender.SIDE;
                defenders = FS.GROUPSANDMEMBERS(defenders);
                GO defenseLocation = FS.SCENARIOLOCATIONS(GS, "ACTION.DEFENDERLOC").First();
                List<GO> MINES = GS.TYPE("MINEMARKER", "GAMELOCATIONID", defenseLocation.ID);
                MINES.ForEach(n => n.ADMINDETECTED = true);
                int numMines = MINES.Count;
                string report = "MINE COMBAT against " + defendingSide + "(" + numMines + " mines)\n\n";
                //modifiers:  if RH53 within two hexes, +2.  can only be used once per turn
                //minesweeper value in hex +modifier
                //max modifier of 4
                //if damage, person who picks is random.
                //move defense tray to neutral spot
                //SURFACE COMBAT with defense >= 5 can be damaged but not destroyed
                //no ship can be picked twice in same attack
                List<GO> MINESWEEPERS = defenders.Where(n => n.UNITTYPE == "MS").ToList();
                MINESWEEPERS.AddRange(FS.ALLSHIPSINHEX(defendingSide, defenseLocation, true, false).Where(n => n.UNITTYPE == "MS"));
                int minesweeperStrength = (int)MINESWEEPERS.Distinct().Sum(n => n.TEMPLATE.SPECIAL);

                List<GO> mswRadius = FS.FINDAIRRADIUS(defenseLocation, 2);
                List<GO> AERIALMINESWEEPERS = FS.TYPESIDE(GS, "SQN", defendingSide).Where(n => !n.DONE && n.UNITTYPE == "MSW").ToList();
                List<GO> msws = AERIALMINESWEEPERS.Where(n => defenders.Contains(n.CARRIER)).ToList();
                msws.AddRange(AERIALMINESWEEPERS.Where(n => mswRadius.Contains(FS.PARENTGROUPLOCATION(n))));
                GO aerialminesweeper = msws.FirstOrDefault();
                int mswStrength = 0;
                if(aerialminesweeper != null){
                    aerialminesweeper.DONE = true;
                    mswStrength = (int)aerialminesweeper.TEMPLATE.SPECIAL;
                }
                int combatResult = 0;
                int rollModifier = 0;
                if(minesweeperStrength > 0 || mswStrength > 0){
                    int amount = Math.Min(4, minesweeperStrength + mswStrength);
                    rollModifier += amount;
                    report += "Minesweeper/MSW: Roll +" + amount + "\n";
                }
                report += "DEFENSE ROLL MODIFIER: " + rollModifier + "\n";
                int dieRoll = FS.DIEROLL();
                report += "ROLL: " + dieRoll + " => " + (dieRoll + rollModifier) + "\n";
                dieRoll += rollModifier;
                combatResult = FS.MINERESULTSTABLE(dieRoll, numMines);
                report += "MINE COMBAT RESULT: " + combatResult + "\n\n";
                
                report += "**Ships take " + combatResult + " steps lost**";   
                SetInt("ACTION.DEFENDERLOSSES", combatResult); 
                //set active side
                Set("ACTIVE.SIDE", FS.SIDE_NAMES[GS.RANDOMINT(FS.SIDE_NAMES.Count)]);     
                MainWindow.Alert(report);
            }
            GS.Advance(this);           
        }
    }
    public class ActionMINECombatPickCasualties : GamePhaseInteractive
    {
        string side = null;
        public ActionMINECombatPickCasualties(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                GS.HELPTEXT = 
                "Mine Combat Casualties\n\n" + 
                "Surface Combat units with defense of 5 or more cannot receive a killing blow from mines, only damaged\n\n" + 
                "A die roll determined which side pick casualties\n\n" +
                "*It is intended for this phase to take place off-map so that an enemy doesnt get an idea where the mine location or enemy units were";                
                foreach(GO obj in FS.GROUPSANDMEMBERS(FS.SCENARIOUNITS(GS, "ACTION.DEFENDER"))){
                    if(obj.SIDE != side){obj.ADMINDETECTED = true;}
                    if(FS.ISGROUP(obj)){continue;}
                    if(FS.SURFACECOMBATTYPES.Contains(obj.UNITTYPE) && obj.TEMPLATE.DEF >= 5 && obj.DAMAGED){continue;}
                    GS.InteractionMap.Add(obj, new());
                }
            }
            int stepLosses = GetInt("ACTION.DEFENDERLOSSES"); 
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "APPLY LOSS");
            }
            if(!GS.InteractionMap.Keys.Any() || stepLosses == 0){
                Update("NEXT");
                return;
            }
            FS.SETINSTRUCTIONS(GS, new(){"APPLY LOSSES: STEPS REMAINING TO SELECT = " + stepLosses});
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    SetInt("ACTION.DEFENDERLOSSES", 0);
                    FS.GROUPSANDMEMBERS(FS.SCENARIOUNITS(GS, "ACTION.DEFENDER")).ForEach(n => n.ADMINDETECTED = false);
                    GS.Advance(this);
                    break;
                case "APPLY LOSS":
                    FS.DAMAGE(gp);
                    IncrementInt("ACTION.DEFENDERLOSSES", -1);
                    GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
}
