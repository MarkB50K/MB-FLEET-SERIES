using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
using System.Printing.IndexedProperties;
namespace CWApp.FS
{    
    public class ActionASWCombat : GamePhaseLoopLogic
    {
        public ActionASWCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionASWCombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionCombatAllocation("Allocation", this, GS, "ASW"));
            AddGamePhase(new ActionASWCombatResolution("Resolution", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.GETTAGGEDLOGICS(GS, "ACTION.ASWCOMBAT").Any();}
        public override void Init()
        {
            List<GO> combats = FS.GETTAGGEDLOGICS(GS, "ACTION.ASWCOMBAT");
            GO combat = combats.First();
            GO attackingUnit = combat.ATTACKER;
            Set("ACTIVE.SIDE", attackingUnit.SIDE);
            FS.SETTAGGED(GS, "ACTION.ACTIONING", new(){attackingUnit});
            Set("ACTION.TYPE", attackingUnit.UNITCATEGORY);
            combats.Remove(combat);
            FS.SETTAGGED(GS, "ACTION.ASWCOMBAT", combats);
            List<GO> attackers = new();
            //if defender is not in location we expect cancel
            bool canAttack = (attackingUnit.UNITCATEGORY == "AIR" && !combat.DEFENDER.ATTACKEDBYAIR) || (attackingUnit.UNITCATEGORY == "SURFACE" && !combat.DEFENDER.ATTACKEDBYSURFACE);
            if(FS.PARENTGROUPLOCATION(combat.DEFENDER) == combat.DEFENDERLOCATION && canAttack){
                FS.SETTAGGED(GS, "ACTION.DEFENDER", new(){combat.DEFENDER});
                //determine which attackers can reach this range
                List<GO> groupMembers = FS.GROUPMEMBERS(attackingUnit);
                Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers);
                foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                    if(attackData[obj].ContainsKey("ASW")){
                        attackers.Add(obj);
                    }
                }
                if(attackers.Any()){
                    attackingUnit.NUMCOMBATS++;
                    attackingUnit.DONEASW = true;   
                    switch(attackingUnit.UNITCATEGORY){
                        case "AIR":
                            combat.DEFENDER.ATTACKEDBYAIR = true;
                            break;
                        case "SURFACE":
                            combat.DEFENDER.ATTACKEDBYSURFACE = true;
                            break;
                        default:
                            break;
                    }                 
                }
            }
            FS.SETTAGGED(GS, "ACTION.ATTACKER", attackers);
            FS.DISCARDLOGIC(combat);
        }
        public override void End()
        {
            foreach(GO obj in GS.TYPE("PIECE", "PARENTSHEETID", FS.DEFENDSHEET.ID)){
                GS.CHANGELOCATION(obj, obj.HOMEBASE);
                obj.HOMEBASEID = null;
            }
            GS.CHANGELOCATION(FS.DEFENDSHEET.SHEETPARENTPIECE, "TEMP");
            FS.CLEARTAGGED(GS, "ACTION.ATTACKER");
            FS.CLEARTAGGED(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionASWCombatDeclaration : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, Dictionary<string, double>> ATTACKS = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = new();
        public ActionASWCombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                ATTACKS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE UNITS THAT WILL PARTICIPATE"});
                GS.HELPTEXT = 
                "ASW COMBAT.  Declare which units you will attack with\n\n" + 
                "- SURFACE:  Max 3 units\n" +
                "- AIR:  Max 2 units\n" +
                "When done with your allocation you can click the NEXT button";                
                foreach(GO obj in FS.GETTAGGEDUNITS(GS, "ACTION.ATTACKER")){
                    GS.InteractionMap.Add(obj, new());
                }
                attackData = FS.ATTACKDATA(GS.InteractionMap.Keys.ToList());
            }
            FS.SETINSTRUCTIONS(GS, new(){"ALLOCATE ASW POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"])});
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "USE ASW");
                if(GS.InteractionMap.Count == 1 && !ATTACKS.Any()){
                    Update("USE ASW");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(ATTACKS.Any() || !GS.InteractionMap.Any()){
                        //collect attack data
                        FS.SETTAGGED(GS, "ACTION.ATTACKER", ATTACKS.Keys.ToList());
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        GS.Advance(this);
                    } else {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE ASW":
                    if(gp.UNITCATEGORY != "AIR"){gp.ASWPTS--;}
                    ATTACKS.Add(gp, attackData[gp]["ASW"]["ASW"]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    if(Get("ACTION.TYPE") == "SURFACE" && ATTACKS.Count == 3){
                        Update("NEXT");
                        break;
                    } else if(Get("ACTION.TYPE") == "AIR" && ATTACKS.Count == 2){
                        Update("NEXT");
                        break;
                    } else if(Get("ACTION.TYPE") == "SUB"){
                        Update("NEXT");
                        break;
                    }
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionASWCombatResolution : GamePhaseAutomated
    {
        public ActionASWCombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            List<GO> defenders = FS.GETTAGGEDUNITS(GS, "ACTION.DEFENDER");
            if(defenders.Any()){
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                GO attackLocation = FS.PARENTGROUPLOCATION(FS.GETTAGGEDUNITS(GS, "ACTION.ATTACKER").First());
                GO defenseLocation = defenders.First().HOMEBASE ?? FS.LOGICALPARENT(defenders.First()).HOMEBASE;
                string report = "ASW COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                int rollModifier = 0;
                foreach(GO obj in defenders){
                    int objRollModifer = rollModifier;
                    report += "\nATTACK ON " + obj.UNITTYPE + " " + obj.LABEL + " with " + GetInt("ACTION.PTS") + " pts:\n";
                    if(obj.TACCOORDPIECEID != null && !FS.STORM(defenseLocation)){
                        objRollModifer += 2;
                        report += "TAC COORD: Roll +2\n";
                    }
                    if(obj.UNITTYPE != "SS" && !obj.DOCKED && defenseLocation.SHALLOW){
                        objRollModifer += 3;
                        report += "SHALLOW SN: Roll +3\n";
                    }
                    if(Get("ACTION.TYPE") == "SURFACE" && obj.DOCKED && defenseLocation.PORTDAMAGELEVEL == 0){
                        objRollModifer -= 3;
                        report += "UNDAMAGED PORT: Roll -3\n";
                    } else if(defenseLocation.RESTRICTED || defenseLocation.FJORD || obj.DOCKED){
                        objRollModifer += 3;
                        report += "RESTRICTED/FJORD/DOCKED: Roll +3\n";
                    }
                    if(obj.DEEPMODE){
                        objRollModifer -= 2;
                        report += "DEEPMODE: Roll -2\n";
                    }
                    report += "ATTACK ROLL MODIFIER: " + objRollModifer + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + objRollModifer) + "\n";
                    dieRoll += objRollModifer;
                    double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, GetInt("ACTION.PTS"));
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    //compare to ship defense
                    double defense = FS.GETDEFENSE(obj);
                    if(attackResult >= defense){
                        //FS.DESTROY(obj);
                        obj.UNAPPLIEDDAMAGE += 2;
                        report += "Target Destroyed\n";
                    } else if(attackResult >= defense * 0.5){
                        //FS.DAMAGE(obj);
                        obj.UNAPPLIEDDAMAGE++;
                        if((obj.DAMAGED ? 1 : 0) + obj.UNAPPLIEDDAMAGE >= 2){
                            report += "Target Destroyed\n";
                        } else {
                            report += "Target Damaged\n";
                        }
                    } else {
                        report += "No effect\n";
                    }
                }         
                //local detection
                if(Get("ACTION.TYPE") == "SURFACE" || Get("ACTION.TYPE") == "SUB"){
                    List<GO> activatedUnits = FS.GROUPSANDMEMBERS(FS.GETTAGGEDUNITS(GS, "ACTION.ACTIONING"));
                    List<GO> adjacent = new();
                    foreach(GO loc in FS.FINDAIRRADIUS(attackLocation, 1)){
                        adjacent.AddRange(FS.ALLSHIPSINHEX(defendingSide, loc, true, true));
                    }
                    switch(Get("ACTION.TYPE")){
                        case "SURFACE":
                            if(activatedUnits.Where(n => FS.STORM(n.GAMELOCATION)).Any()){break;}
                            adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)));
                            if(adjacent.Any()){
                                report += "\nACTIVATED UNITS are detected";
                                FS.LOCALDETECT(activatedUnits, true);
                            }
                            break;
                        case "SUB":
                            adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)) && n.UNITCATEGORY == "SURFACE");
                            if(adjacent.Any()){
                                foreach(GO obj in activatedUnits){
                                    if(FS.SUBDETECTIONRESULT(obj, "ACTION", "ASW", adjacent) == "D"){
                                        report += "\nACTIVATED UNITS are detected";
                                        FS.LOCALDETECT(new(){obj}, true);
                                    }
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
                if(report != ""){
                    MainWindow.Alert(report);
                }
            }
            GS.Advance(this);           
        }
    }
}
