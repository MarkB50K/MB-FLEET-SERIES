using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Windows.Automation;
using log4net.Core;
using System.Printing.IndexedProperties;
namespace CWApp.FS
{    
    public class ActionASWCombat : GamePhaseLoopLogic
    {
        public ActionASWCombat(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionASWCombatDeclaration("Declaration", this, GS));
            AddGamePhase(new ActionCombatAllocation("Allocation", this, GS, "ASW"));
            AddGamePhase(new ActionASWCombatResolution("Resolution", this, GS));
        }
        public override Boolean ProcessCheck(){return FS.SCENARIOLOGICS(GS, "ACTION.ASWCOMBAT").Any();}
        public override void Init()
        {
            List<GO> combats = FS.SCENARIOLOGICS(GS, "ACTION.ASWCOMBAT");
            GO combat = combats.First();
            GO attackingUnit = combat.ATTACKER;
            Set("ACTIVE.SIDE", attackingUnit.SIDE);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ACTIONING", new(){attackingUnit});
            Set("ACTION.TYPE", attackingUnit.UNITCATEGORY);
            combats.Remove(combat);
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ASWCOMBAT", combats);
            List<GO> attackers = new();
            //if defender is not in location we expect cancel
            bool canAttack = ((attackingUnit.UNITCATEGORY == "AIR" && !combat.DEFENDER.ATTACKEDBYAIR) || (attackingUnit.UNITCATEGORY == "SURFACE" && !combat.DEFENDER.ATTACKEDBYSURFACE) || attackingUnit.UNITCATEGORY == "SUB") &&
                            FS.PARENTGROUPLOCATION(combat.DEFENDER) == combat.DEFENDERLOCATION;
            if(canAttack){
                FS.SETSCENARIOOBJECTS(GS, "ACTION.DEFENDER", new(){combat.DEFENDER});
                //determine which attackers can reach this range
                List<GO> groupMembers = FS.GROUPMEMBERS(attackingUnit);
                Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers, "ASW");
                foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                    if(attackData[obj].ContainsKey("ASW")){
                        attackers.Add(obj);
                    }
                }
                if(attackers.Any()){
                    attackingUnit.NUMCOMBATS++;
                    attackingUnit.DONEASW = true;   
                    switch(attackingUnit.UNITCATEGORY){
                        case "AIR":
                            combat.DEFENDER.ATTACKEDBYAIR = true;
                            break;
                        case "SURFACE":
                            combat.DEFENDER.ATTACKEDBYSURFACE = true;
                            break;
                        default:
                            break;
                    }                 
                }
            }
            string reason = "";
            if(!attackers.Any()){reason = "no units able to attack";}
            if(!canAttack){reason = "target SUB is no longer in target location or has already been attacked";}
            if(reason != ""){
                MainWindow.Alert("Planned " + combat.TYPE + " combat (" + combat.SIDE + " vs " + FS.ENEMY(combat.SIDE) + ") not possible: " + reason);
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", attackers);
            FS.DISCARDLOGIC(combat);
        }
        public override void End()
        {
            FS.REMOVECOMBATSHEET();
            FS.CLEARSCENARIOVAR(GS, "ACTION.ATTACKER");
            FS.CLEARSCENARIOVAR(GS, "ACTION.DEFENDER");
        }
    }
    public class ActionASWCombatDeclaration : GamePhaseInteractive
    {
        string side = null;
        Dictionary<GO, Dictionary<string, double>> ATTACKS = new();
        Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = new();
        public ActionASWCombatDeclaration(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                ATTACKS.Clear();
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"CHOOSE UNITS THAT WILL PARTICIPATE"});
                GS.HELPTEXT = 
                "ASW COMBAT.  Declare which units you will attack with\n\n" + 
                "- SURFACE:  Max 3 units\n" +
                "- AIR:  Max 2 units\n" +
                "When done with your allocation you can click the NEXT button";                
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ATTACKER")){
                    GS.InteractionMap.Add(obj, new());
                }
                attackData = FS.ATTACKDATA(GS.InteractionMap.Keys.ToList(), "ASW");
            }
            FS.SETINSTRUCTIONS(GS, new(){"ALLOCATE ASW POINTS TO ATTACK", "TOTAL ALLOCATED: " + ATTACKS.Values.Sum(n => n["PTS"])});
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "USE ASW");
                if(GS.InteractionMap.Count == 1 && !ATTACKS.Any()){
                    Update("USE ASW");
                    return;
                }
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "NEXT":
                    if(ATTACKS.Any() || !GS.InteractionMap.Any()){
                        //collect attack data
                        FS.SETSCENARIOOBJECTS(GS, "ACTION.ATTACKER", ATTACKS.Keys.ToList());
                        SetInt("ACTION.PTS", (int)ATTACKS.Values.Sum(n => n["PTS"]));
                        GS.Advance(this);
                    } else {
                        MainWindow.Alert("You are committed and must select at least one attacker.");
                        Start(false);
                    }
                    break;
                case "USE ASW":
                    if(gp.UNITCATEGORY == "SURFACE"){
                        gp.ASWPTS--;
                    } else if(gp.UNITCATEGORY == "SUB"){
                        gp.TORPPTS--;
                    }
                    ATTACKS.Add(gp, attackData[gp]["ASW"]["ASW"]);
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    if(Get("ACTION.TYPE") == "SURFACE" && ATTACKS.Count == 3){
                        Update("NEXT");
                        break;
                    } else if(Get("ACTION.TYPE") == "AIR" && ATTACKS.Count == 2){
                        Update("NEXT");
                        break;
                    } else if(Get("ACTION.TYPE") == "SUB"){
                        Update("NEXT");
                        break;
                    }
                    Start(false);
                    break;
                default:
                    Start(false);
                    break;
            }            
        }
    }
    public class ActionASWCombatResolution : GamePhaseAutomated
    {
        public ActionASWCombatResolution(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            List<GO> defenders = FS.SCENARIOUNITS(GS, "ACTION.DEFENDER");
            if(defenders.Any()){
                string attackingSide = Get("ACTIVE.SIDE");
                string defendingSide = FS.ENEMY(attackingSide);
                GO attackLocation = FS.PARENTGROUPLOCATION(FS.SCENARIOUNITS(GS, "ACTION.ATTACKER").First());
                GO defenseLocation = FS.PARENTGROUPLOCATION(defenders.First());
                string report = "ASW COMBAT : " + attackingSide + " vs " + defendingSide + "\n\n";
                int rollModifier = 0;
                foreach(GO obj in defenders){
                    int objRollModifer = rollModifier;
                    report += "\nATTACK ON " + obj.UNITTYPE + " " + obj.LABEL + " with " + obj.ATK + " pts:\n";
                    if(obj.TACCOORDPIECEID != null && !FS.STORM(defenseLocation)){
                        objRollModifer += 2;
                        report += "TAC COORD: Roll +2\n";
                    }
                    if(obj.UNITTYPE != "SS" && !obj.DOCKED && defenseLocation.SHALLOW){
                        objRollModifer += 3;
                        report += "SHALLOW SN: Roll +3\n";
                    }
                    if(Get("ACTION.TYPE") == "SURFACE" && obj.DOCKED && defenseLocation.PORTDAMAGELEVEL == 0){
                        objRollModifer -= 3;
                        report += "UNDAMAGED PORT: Roll -3\n";
                    } else if(defenseLocation.RESTRICTED || defenseLocation.FJORD || obj.DOCKED){
                        objRollModifer += 3;
                        report += "RESTRICTED/FJORD/DOCKED: Roll +3\n";
                    }
                    if(obj.DEEPMODE){
                        objRollModifer -= 2;
                        report += "DEEPMODE: Roll -2\n";
                    }
                    report += "ATTACK ROLL MODIFIER: " + objRollModifer + "\n";
                    int dieRoll = FS.DIEROLL();
                    report += "ROLL: " + dieRoll + " => " + (dieRoll + objRollModifer) + "\n";
                    dieRoll += objRollModifer;
                    double attackResult = FS.COMBATRESULTSTABLE(true, dieRoll, (int)obj.ATK);
                    obj.ATK = 0;
                    report += "ATTACK RESULT: " + attackResult + "\n";
                    //compare to ship defense
                    double defense = FS.GETDEFENSE(obj);
                    if(attackResult >= defense){
                        //FS.DESTROY(obj);
                        obj.UNAPPLIEDDAMAGE += 2;
                        report += "Target Destroyed\n";
                    } else if(attackResult >= defense * 0.5){
                        //FS.DAMAGE(obj);
                        obj.UNAPPLIEDDAMAGE++;
                        if((obj.DAMAGED ? 1 : 0) + obj.UNAPPLIEDDAMAGE >= 2){
                            report += "Target Destroyed\n";
                        } else {
                            report += "Target Damaged\n";
                        }
                    } else {
                        report += "No effect\n";
                    }
                }         
                //local detection
                if(Get("ACTION.TYPE") == "SURFACE" || Get("ACTION.TYPE") == "SUB"){
                    List<GO> activatedUnits = FS.GROUPSANDMEMBERS(FS.SCENARIOUNITS(GS, "ACTION.ACTIONING")).Where(n => !n.LOCALDETECTED).ToList();
                    List<GO> adjacent = new();
                    foreach(GO loc in FS.FINDAIRRADIUS(attackLocation, 1)){
                        adjacent.AddRange(FS.ALLSHIPSINHEX(defendingSide, loc, true, true));
                    }
                    switch(Get("ACTION.TYPE")){
                        case "SURFACE":
                            if(activatedUnits.Where(n => FS.STORM(n.GAMELOCATION)).Any()){break;}
                            adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)));
                            if(adjacent.Any()){
                                FS.DINTERRUPT(GS, defendingSide, true);
                                FS.LOCALDETECT(activatedUnits, true);
                            }
                            break;
                        case "SUB":
                            adjacent.RemoveAll(n => FS.STORM(FS.PARENTGROUPLOCATION(n)) && n.UNITCATEGORY == "SURFACE");
                            if(adjacent.Any()){
                                foreach(GO obj in activatedUnits){
                                    if(FS.SUBDETECTIONRESULT(obj, "ACTION", "ASW", adjacent) == "D"){
                                        FS.DINTERRUPT(GS, defendingSide, true);
                                        FS.LOCALDETECT(new(){obj}, true);
                                    }
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
                if(report != ""){
                    MainWindow.Alert(report);
                }
            }
            GS.Advance(this);           
        }
    }
}
