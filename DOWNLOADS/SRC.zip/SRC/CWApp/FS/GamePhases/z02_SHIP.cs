using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using Microsoft.Windows.Themes;
using System.Windows;
using System.Reflection.Metadata.Ecma335;
namespace CWApp.FS
{
    public class ActionSubFullSpeed : GamePhaseInteractive
    {
        string side = null;
        public ActionSubFullSpeed(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"SELECT FULL SPEED"});

                GS.HELPTEXT = 
                "SUB Movement Speed\n" + 
                "- Full, +1 movement point. may result in Strategic Detection\n" +
                "- Normal";
                foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATING").Where(n => n.UNITCATEGORY == "SUB" && !n.DEEPMODE && !n.GAMELOCATION.RESTRICTED && !n.GAMELOCATION.SHALLOW && !n.GAMELOCATION.FJORD)){
                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "FULL");
                GS.AddAction(obj, "NORMAL");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "FULL":
                    gp.FULLSPEED = true;
                    GS.Advance(this);
                    break;
                case "NORMAL":
                case "NEXT":
                    GS.Advance(this);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionSurfaceFullSpeed : GamePhaseInteractive
    {
        string side = null;
        public ActionSurfaceFullSpeed(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            ManualAdvance = true;
        }
        public override void Execute(Boolean init){
            if(init){
                if(Get("TURN.TYPE") != "AM"){
                    Update("NEXT");
                    return;
                }
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"SELECT FULL SPEED"});

                GS.HELPTEXT = 
                "SURFACE High Speed Movement\n\n" + 
                "- High, increased movement for all 3 turns this day, 1 Fuel Point will be Immediately used\n" +
                "- Normal\n\n" +
                "NOTE: PC units prohibited.  CO/FF +2 movement.  Other +1 movement.  Units moving at high speed expend 2 points to enter restricted/fjord";
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => 
                    !FS.ISGROUP(n) && 
                    n.ENROUTEDELAY == 0 &&
                    n.UNITCATEGORY == "SURFACE" && 
                    n.UNITTYPE != "PC" &&
                    FS.PARENTGROUPLOCATION(n).TYPE == "HEX" &&
                    (n.FUELPTS >= 2 || n.TEMPLATE.FUELPTS == 0))){

                    GS.InteractionMap.Add(obj, new());
                }
            }
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, "HIGH");
                GS.AddAction(obj, "END PHASE");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "HIGH":
                    gp.FULLSPEED = true;
                    gp.FUELPTS = Math.Max(0, gp.FUELPTS - 1);
                    if(gp.GROUPID != null){
                        FS.UPDATEGROUP(gp.GROUP);
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    Start(false);
                    break;
                case "END PHASE":
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
    public class ActionShipMovement : GamePhaseGroupLogic
    {
        public ActionShipMovement(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
            AddGamePhase(new ActionShipMove("Movement", this, GS));
            AddGamePhase(new ActionMINECombat("MINE", this, GS));
            AddGamePhase(new MaintainLocalDetection("Maintain Local Detection", this, GS));
            AddGamePhase(new ActionAirTacCoordReassignmentLoop("Loop", this, GS));
            AddGamePhase(new ActionSurfaceOverstacking("Overstacking", this, GS));
        }
        public override Boolean ProcessCheck(){return GetInt("ACTION.CYCLES") == 5;}
        public override void Init()
        {
        }
        public override void End()
        {
            //MINE RULES
            //if a ship leaves a hex with mines
            //max 4 mines per hex
            
        }
    }
    public class ActionShipMove : GamePhaseAutomated
    {
        public ActionShipMove(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            //find all activated units with movements to do
            //move all one hex
            //resolve detection
            List<GO> UNDESTROYEDBASES = GS.TYPE("FACILITY").Where(n => n.SIDE != null && ((n.PORT && !n.PORTDESTROYED) || (n.AIRFIELD && !n.AIRFIELDDESTROYED))).ToList();
            List<GO> FULLSPEEDDETECTORS = GS.TYPE("SHIP").Where(n => n.SIDE != null && n.GAMELOCATION.TYPE == "HEX").ToList();
            List<GO> MINELOCATIONS = GS.TYPE("MINEMARKER").Where(n => n.GAMELOCATION?.TYPE == "HEX").Select(n => n.GAMELOCATION).Distinct().ToList();
            List<GO> MINECOMBATS = new();
            Dictionary<GO, GO> FROM = new();
            Dictionary<GO, GO> TO = new();
            Dictionary<GO, List<List<GO>>> DetectionRadiusPRE = FS.DETECTIONRADIUSTABLE(GS);
            List<GO> moving = new();
            foreach(GO obj in FS.SCENARIOUNITS(GS, "ACTION.ACTIVATED").Where(n => n.TYPE == "SHIP")){
                FROM.Add(obj, obj.GAMELOCATION);
                List<string> past_locations = obj.LOCATIONHISTORY.Split('|').ToList();
                List<string> future_locations = obj.LOCATIONFUTURE.Split('|').ToList();
                List<GO> groupMembers = FS.GROUPMEMBERS(obj);
                if(future_locations.Count > 1 && obj.MOVEMENTALLOWANCE > 0){
                    //get next connector
                    string oldLocId = future_locations[0];
                    GO newLocation = GS.LOCATION(future_locations[1]);
                    FSMovement movement = obj.UNITCATEGORY switch{
                        "SURFACE" => FS.FINDSURFACEMOVEMENTS(obj, obj.GAMELOCATION).Where(n => n.MOVEMENTLOCATION == newLocation).Single(),
                        "SUB" => FS.FINDSUBMOVEMENTS(obj, obj.GAMELOCATION).Where(n => n.MOVEMENTLOCATION == newLocation).Single(),
                        _ => null
                    };
                    if(movement.DISTANCE <= obj.MOVEMENTALLOWANCE || obj.HEXESTRAVELLED == 0){
                        //moving out so check if mines are here
                        if(MINELOCATIONS.Contains(obj.GAMELOCATION)){
                            //add mine combat
                            Dictionary<string, string> objData = new()
                            {
                                ["ID"] = obj.ID + GO.DELIM + "MINE" + GO.DELIM + FS.GENERATETIMESTAMP(),
                                ["DOMAIN"] = GO.DOMAIN_LOGIC,
                                ["TYPE"] = "MINE"
                            };
                            MINECOMBATS.Add(new(GS, objData, null, null)
                            {
                                DEFENDERID = obj.ID,
                                DEFENDER = obj,
                                DEFENDERLOCATIONID = obj.GAMELOCATIONID,
                                DEFENDERLOCATION = obj.GAMELOCATION,
                                SIDE = obj.SIDE
                            });
                        }
                        TO.Add(obj, newLocation);
                        IncrementInt("ACTION.MOVES." + obj.SIDE, 1);
                        GS.CHANGELOCATION(obj, newLocation);
                        moving.Add(obj);
                        past_locations.Add(newLocation.ID);
                        future_locations.Remove(oldLocId);
                        obj.LOCATIONHISTORY = string.Join('|', past_locations);
                        obj.LOCATIONFUTURE = string.Join('|', future_locations);
                        if(obj.UNITCATEGORY == "SURFACE"){
                            groupMembers.ForEach(n => n.MOVEMENTALLOWANCE = Math.Max(0, n.MOVEMENTALLOWANCE - movement.DISTANCE));
                        }
                        obj.MOVEMENTALLOWANCE = Math.Max(0, obj.MOVEMENTALLOWANCE - movement.DISTANCE);
                        //must end movement at fjord
                        if(newLocation.FJORD){
                            groupMembers.ForEach(n => n.MOVEMENTALLOWANCE = 0);
                            obj.MOVEMENTALLOWANCE = 0;
                        }
                        obj.HEXESTRAVELLED++;
                        if(FS.STORM(newLocation) && obj.UNITCATEGORY == "SURFACE"){
                            FS.LOCALDETECT(groupMembers, false);
                            FS.STRATDETECT(groupMembers, false);
                        } else {
                            if(!obj.STRATDETECTED){
                                if(obj.UNITCATEGORY == "SURFACE"){
                                    if(FS.FINDAIRRADIUS(obj.GAMELOCATION, 1).Intersect(UNDESTROYEDBASES.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Select(n => n.GAMELOCATION)).Any()){
                                        if(!obj.LOCALDETECTED){
                                            FS.DINTERRUPT(GS, FS.ENEMY(obj.SIDE), true);
                                        }
                                        FS.STRATDETECT(groupMembers, true);
                                    }
                                }
                                if(obj.UNITCATEGORY == "SUB" && obj.FULLSPEED){
                                    if(FS.FINDAIRRADIUS(obj.GAMELOCATION, 5).Intersect(FULLSPEEDDETECTORS.Where(n => n.SIDE == FS.ENEMY(obj.SIDE))).Any()){
                                        if(!obj.LOCALDETECTED){
                                            FS.DINTERRUPT(GS, FS.ENEMY(obj.SIDE), true);
                                        }
                                        FS.STRATDETECT(groupMembers, true);
                                    }
                                }
                            }
                        }
                    } else {
                        TO.Add(obj, obj.GAMELOCATION);
                    }
                } else {
                    TO.Add(obj, obj.GAMELOCATION);
                }
            }
            Dictionary<GO, List<List<GO>>> DetectionRadiusPOST = FS.DETECTIONRADIUSTABLE(GS);
            //detection.  look for ships that moved
            foreach(GO obj in TO.Keys.Where(n => !n.LOCALDETECTED)){
                if(obj.UNITCATEGORY == "SUB" && obj.DETECTIONATTEMPTED){continue;}
                int i = obj.UNITCATEGORY == "SURFACE" ? 1 : 2;
                GO from = FROM[obj];
                GO to = TO[obj];
                if(obj.UNITCATEGORY == "SURFACE"){
                    //if moving, as long as its in the full detection zone of any enemy unit, its detected
                    //if not moving, it needs to be in the 1 hex 
                    if(to != from || FS.SURFACEREALTIMEDETECTION){  
                        if(FS.SURFACEREALTIMEDETECTION && to == from){
                            i = 0;
                        }              
                        List<GO> PRE = DetectionRadiusPRE.Keys.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Where(n => DetectionRadiusPRE[n][i].Contains(from)).ToList();
                        List<GO> POST = DetectionRadiusPOST.Keys.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Where(n => DetectionRadiusPOST[n][i].Contains(to)).ToList();
                        if(PRE.Intersect(POST).Any()){
                            FS.LOCALDETECT(FS.GROUPMEMBERS(obj), true);
                            FS.DINTERRUPT(GS, FS.ENEMY(obj.SIDE), true);
                        }
                    }
                } else if(to != from){
                    List<GO> PRE = DetectionRadiusPRE.Keys.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Where(n => DetectionRadiusPRE[n][i].Contains(from)).ToList();
                    List<GO> POST = DetectionRadiusPOST.Keys.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Where(n => DetectionRadiusPOST[n][i].Contains(to)).ToList();
                    List<GO> DETECTORS = PRE.Intersect(POST).ToList();
                    if(DETECTORS.Sum(n => n.TEMPLATE.ASW) >= 6){
                        obj.DETECTIONATTEMPTED = true;
                        if(FS.SUBDETECTIONRESULT(obj, "ACTION", null, DETECTORS) == "D"){
                            FS.LOCALDETECT(new(){obj}, true);
                            FS.DINTERRUPT(GS, FS.ENEMY(obj.SIDE), true);
                        }
                    }
                }
            }
            //move CAP
            List<GO> MOVINGCAP = FS.CAPSQNS(GS, null);
            MOVINGCAP.RemoveAll(n => n.HOMEBASE == n.GAMELOCATION);
            MOVINGCAP.RemoveAll(n => n.HOMEBASE.DESTROYED);
            MOVINGCAP.RemoveAll(n => FS.PARENTGROUPLOCATION(n.HOMEBASE) == n.GAMELOCATION);
            MOVINGCAP.ForEach(n => GS.CHANGELOCATION(n, FS.PARENTGROUPLOCATION(n.HOMEBASE)));
            FS.AIRDETECTION(GS, new());
            FS.AIRVSSURFACEDETECTION(GS);
            FS.SURFACEVSAIRTARGETING(GS);

            //identify TACCOORD reassignment
            Dictionary<GO, List<GO>> TACCOORDTABLE = new();
            foreach(GO obj in moving.Where(n => n.TACCOORDPIECEID != null && n.UNITCATEGORY == "SURFACE").Select(n => n.TACCOORDPIECE).Distinct()){
                TACCOORDTABLE.Add(obj, new());
            }
            foreach(string s in FS.SIDE_NAMES){
                if(TACCOORDTABLE.Keys.Where(n => n.SIDE == s).Any()){
                    List<GO> trackedShips = FS.TYPESIDE(GS, "SHIP", FS.ENEMY(s)).Where(n => TACCOORDTABLE.Keys.Contains(n.TACCOORDPIECE)).ToList();
                    foreach(GO obj in TACCOORDTABLE.Keys.Where(n => n.SIDE == s)){
                        TACCOORDTABLE[obj].AddRange(trackedShips.Where(n => n.TACCOORDPIECE == obj).Select(FS.PARENTGROUPLOCATION).Distinct());
                    }
                }
            }
            FS.SETSCENARIOOBJECTS(GS, "ACTION.TACCOORDREASSIGN.NEEDED", TACCOORDTABLE.Keys.Where(n => TACCOORDTABLE[n].Count > 1).ToList());
            FS.SETSCENARIOOBJECTS(GS, "ACTION.MINECOMBAT", MINECOMBATS);
            GS.Advance(this);
        }
    }
    public class MaintainLocalDetection : GamePhaseAutomated
    {
        public MaintainLocalDetection(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            Dictionary<GO, List<GO>> LOCATIONTABLE = new();
            foreach(GO obj in GS.TYPE("SHIP").Where(n => FS.SIDE_NAMES.Contains(n.SIDE) && n.UNITCATEGORY == "SURFACE")){
                GO loc = FS.PARENTGROUPLOCATION(obj);
                if(loc.TYPE != "HEX"){
                    obj.STRATDETECTED = false;
                    obj.LOCALDETECTED = false;
                    continue;
                }
                if(!LOCATIONTABLE.ContainsKey(loc)){
                    LOCATIONTABLE.Add(loc, new());
                }
                LOCATIONTABLE[loc].Add(obj);
            }
            foreach(GO loc in LOCATIONTABLE.Keys){
                foreach(string s in FS.SIDE_NAMES){
                    List<GO> objs = LOCATIONTABLE[loc].Where(n => n.SIDE == s).ToList();
                    bool STRATDETECTED = objs.Where(n => n.STRATDETECTED).Any();
                    bool LOCALDETECTED = objs.Where(n => n.LOCALDETECTED).Any() || STRATDETECTED;
                    if(STRATDETECTED && objs.Where(n => !n.STRATDETECTED).Any()){
                        objs.ForEach(n => n.STRATDETECTED = true);
                        FS.DINTERRUPT(GS, FS.ENEMY(s), true);
                    }
                    if(LOCALDETECTED && objs.Where(n => !n.LOCALDETECTED).Any()){
                        objs.ForEach(n => n.LOCALDETECTED = true);
                        FS.DINTERRUPT(GS, FS.ENEMY(s), true);
                    }
                }
            }
            GS.Advance(this);
        }
    }
    public class RemoveLocalDetection : GamePhaseAutomated
    {
        public RemoveLocalDetection(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {}            
        public override void Execute(Boolean init){
            Dictionary<GO, List<List<GO>>> DetectionRadius = FS.DETECTIONRADIUSTABLE(GS);
            Dictionary<GO, List<GO>> LOCATIONTABLE = new();
            foreach(GO obj in GS.TYPE("SHIP").Where(n => FS.SIDE_NAMES.Contains(n.SIDE))){
                GO loc = FS.PARENTGROUPLOCATION(obj);
                if(loc.TYPE != "HEX"){
                    obj.STRATDETECTED = false;
                    obj.LOCALDETECTED = false;
                    continue;
                }
                if(!obj.STRATDETECTED){
                    if(obj.UNITCATEGORY == "SUB"){
                        List<GO> detectors = DetectionRadius.Keys.Where(n => n.SIDE == FS.ENEMY(obj.SIDE)).Where(n => DetectionRadius[n][2].Contains(loc)).ToList();
                        if(detectors.Sum(n => n.TEMPLATE.ASW) < 6){
                            FS.LOCALDETECT(new(){obj}, false);
                        }
                    } else {
                        if(!LOCATIONTABLE.ContainsKey(loc)){
                            LOCATIONTABLE.Add(loc, new());
                        }
                        LOCATIONTABLE[loc].Add(obj);
                    }
                }
            }
            //surface done as groups by location
            foreach(GO loc in LOCATIONTABLE.Keys){
                string side = LOCATIONTABLE[loc].First().SIDE;
                if(!DetectionRadius.Keys.Where(n => n.SIDE == FS.ENEMY(side)).Where(n => DetectionRadius[n][1].Contains(loc)).Any()){
                    FS.LOCALDETECT(LOCATIONTABLE[loc], false);
                }
            }
            GS.Advance(this);
        }
    }
    public class ActionSurfaceOverstacking : GamePhaseInteractive
    {
        Dictionary<GO, List<GO>> STACKINGTABLE = new();
        string side = null;
        public ActionSurfaceOverstacking(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario) {
        }
        public override void Execute(Boolean init){
            if(init){
                side = Get("ACTIVE.SIDE");
                FS.SIDE_MODE = side;
                FS.SETINSTRUCTIONS(GS, new(){"REVIEW OVERSTACKED HEXES"});
                STACKINGTABLE.Clear();
                GS.HELPTEXT = 
                "Overstacking\n" + 
                "- Max of 12 surface combat units can be in any hex\n" +
                "- If this is still during the Action Movement phase, this is just informational, and you should move ships by the end of the phase to avoid violation\n" +
                "- If this is after all moves are completely, you must destroy ships to get under the limit";
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", side).Where(n => 
                    FS.PARENTGROUPLOCATION(n).TYPE == "HEX" && 
                    FS.SURFACECOMBATTYPES.Contains(n.UNITTYPE))){

                    GO loc = FS.PARENTGROUPLOCATION(obj);
                    if(!STACKINGTABLE.ContainsKey(loc)){
                        STACKINGTABLE.Add(loc, new());
                    }
                    STACKINGTABLE[loc].Add(obj);
                }
                foreach(GO loc in STACKINGTABLE.Keys.Where(n => STACKINGTABLE[n].Count >= 12)){
                    foreach(GO obj in STACKINGTABLE[loc]){
                        obj.OVERSTACKED = true;
                        GS.InteractionMap.Add(obj, new());
                    }
                }
            }
            bool postMovement = !FS.SIDE_NAMES.Where(n => !GetBoolean("ACTION." + n)).Any();
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                }
            }
            if(GS.SelectedMarker != null){
                GO obj = GS.SelectedMarker;
                GS.AddAction(obj, postMovement ? "SCUTTLE" : "NEXT");
            }
            if(!GS.InteractionMap.Keys.Any()){
                Update("NEXT");
                return;
            }
            if(init){FS.SETVIEW(GS);}
        }
        public override void Update(string pData){
            GO gp = GS.SelectedMarker;
            switch(pData){
                case "SCUTTLE":
                    GO loc = FS.PARENTGROUPLOCATION(gp);
                    List<GO> otherShips = STACKINGTABLE[loc];
                    if(gp.GROUPID != null){
                       FS.REMOVEFROMGROUP(gp, gp.GROUP); 
                    }
                    FS.DESTROY(gp);
                    otherShips.Remove(gp);
                    if(otherShips.Count < 12){
                        foreach(GO obj in otherShips){
                            obj.OVERSTACKED = false;
                            GS.REMOVEINTERACTIVE(obj);
                        }
                        otherShips.Clear();
                        STACKINGTABLE.Remove(loc);
                    }
                    GS.SelectedMarker = GS.REMOVEINTERACTIVE(gp);
                    break;
                case "NEXT":
                    FS.ADVANCESIDE(this, side);
                    break;
                default:
                    Start(false);
                    break;
            }
        }
    }
}