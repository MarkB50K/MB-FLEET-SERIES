using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Data;
using System.Windows;
using System.DirectoryServices.ActiveDirectory;
using System.Windows.Markup;
using System.Windows.Navigation;
using System.Dynamic;
using System.CodeDom;
using System.Reflection.Metadata.Ecma335;
//using CWApp.TWW;
using System.Configuration;
using System.Collections;

namespace CWApp.FS
{
    public class FSGeography : GOGeography {
        public FSGeography(GameScenario gs, Dictionary<string, string> pdata, Dictionary<string, string> odata, Dictionary<string, string> sdata) : base(gs, pdata, odata, sdata) { }
        public FSGeography() : base() { }
    }
    public class FSMovement : FSGeography {
        public FSMovement() : base() {DOMAIN = GO.DOMAIN_MOVEMENT;}
        public string MOVEMENTCONNECTORID { get{ return Get("MOVEMENTCONNECTORID");} set{ Set("MOVEMENTCONNECTORID", value); if(value == null){_MOVEMENTCONNECTOR = null;}} }
        private GO _MOVEMENTCONNECTOR { get; set; }
        public GO MOVEMENTCONNECTOR { 
            get {
                if(GS != null && _MOVEMENTCONNECTOR == null && MOVEMENTCONNECTORID != null){
                    _MOVEMENTCONNECTOR = GS.CONNECTOR(MOVEMENTCONNECTORID);
                }
                return _MOVEMENTCONNECTOR;
            } 
            set {
                _MOVEMENTCONNECTOR = value;
            }
        }  
        public string MOVEMENTLOCATIONID { get{ return Get("MOVEMENTLOCATIONID");} set{ Set("MOVEMENTLOCATIONID", value); if(value == null){_MOVEMENTLOCATION = null;}} }
        private GO _MOVEMENTLOCATION { get; set; }
        public GO MOVEMENTLOCATION { 
            get {
                if(GS != null && _MOVEMENTLOCATION == null && MOVEMENTLOCATIONID != null){
                    _MOVEMENTLOCATION = GS.LOCATION(MOVEMENTLOCATIONID);
                }
                return _MOVEMENTLOCATION;
            } 
            set {
                _MOVEMENTLOCATION = value;
            }
        }
    }
    public abstract class FS : GameScenario
    {
        public static int DIEROLL(){
            return CWConstants._random.Next(10);
        }
        public static void SETINSTRUCTIONS(GameScenario GS, List<string> instructions){
            string player = SIDE_MODE == "SOV" || SIDE_MODE == "ALLIES" ? SIDE_MODE : "ADMIN";
            List<string> i = new(){"**" + player + "**"};
            i.AddRange(instructions);
            GS.SetInstructions(i);
        }
        public static bool ADMIN = false;
        public static bool ORDERS = false;
        public static GO GRPSHEET;
        public static GO CVSHEET;
        public static GO DETAILSHEET;
        public static GO ACTIVATIONGRPSHEET;
        public static GO SETUPSHEET;
        public static GO DEFENDSHEET;
        public static GO BLINDER;
        public static List<GO> TRAYSHEETS;
        public static List<GO> TMPSHEETS;
        public static List<GO> STRATAIRSHEETS;
        public static List<GO> FACILITYTEMPLATES = new();
        public static List<GO> FLAGTEMPLATES = new();
        public static string SIDE_MODE = "ALLIESSOVNEUT";
        public static string OLD_SIDE_MODE = null;
        public static Dictionary<double, string> INTERCEPTIONCOLUMNS = new(){
            {1.0/5.0, "1:5"}, 
            {1.0/4.0, "1:4"}, 
            {1.0/3.0, "1:3"}, 
            {1.0/2.0, "1:2"}, 
            {1, "1:1"},
            {2, "2:1"}, 
            {3, "3:1"}, 
            {4, "4:1"}
        };
        public override void SHOWINSTRUCTIONS()
        {
            TextBlock textBlock = ((TextBlock)_Window.FindName("TXTINFO"));
            textBlock.Text = INSTRUCTIONS;
            switch(SIDE_MODE){
                case "SOV":
                    textBlock.Background = System.Windows.Media.Brushes.Red;
                    textBlock.Foreground = System.Windows.Media.Brushes.White;
                    break;
                case "ALLIES":
                    textBlock.Background = System.Windows.Media.Brushes.Blue;
                    textBlock.Foreground = System.Windows.Media.Brushes.White;
                    break;
                default:
                    textBlock.Background = System.Windows.Media.Brushes.White;
                    textBlock.Foreground = System.Windows.Media.Brushes.Black;
                    break;
            }
        }

        public static string INTERCEPTIONCOLUMNHEADER(double odds){
            return INTERCEPTIONCOLUMNS[odds];
        }
        public static List<string> INTERCEPTIONRESULTS(string column, int dieRoll){
            return column switch
            {
                "1:5" => dieRoll switch
                {
                    0 => new() { "3R", "0" },
                    1 => new() { "3R", "0" },
                    2 => new() { "3R", "0" },
                    3 => new() { "3R", "0" },
                    4 => new() { "2R", "0" },
                    5 => new() { "2R", "0" },
                    6 => new() { "1R", "0" },
                    7 => new() { "1R", "0" },
                    8 => new() { "0R", "0" },
                    9 => new() { "0", "0R" },                    
                    _ => new() { "0", "0" },
                },
                "1:4" => dieRoll switch
                {
                    0 => new() { "3R", "0" },
                    1 => new() { "3R", "0" },
                    2 => new() { "3R", "0" },
                    3 => new() { "2R", "0" },
                    4 => new() { "2R", "0" },
                    5 => new() { "1R", "0" },
                    6 => new() { "1R", "0" },
                    7 => new() { "0R", "0" },
                    8 => new() { "0", "0R" },
                    9 => new() { "0", "0R" },                    
                    _ => new() { "0", "0" },
                },
                "1:3" => dieRoll switch
                {
                    0 => new() { "3R", "0" },
                    1 => new() { "2R", "0" },
                    2 => new() { "2R", "0" },
                    3 => new() { "1R", "0" },
                    4 => new() { "1R", "0" },
                    5 => new() { "0R", "0" },
                    6 => new() { "0R", "0R" },
                    7 => new() { "0", "0R" },
                    8 => new() { "0", "0R" },
                    9 => new() { "0", "1R" },                    
                    _ => new() { "0", "0" },
                },
                "1:2" => dieRoll switch
                {
                    0 => new() { "2R", "0" },
                    1 => new() { "2R", "0" },
                    2 => new() { "1R", "0" },
                    3 => new() { "1R", "0" },
                    4 => new() { "0R", "0" },
                    5 => new() { "0R", "0R" },
                    6 => new() { "0", "0R" },
                    7 => new() { "0", "1R" },
                    8 => new() { "0", "1R" },
                    9 => new() { "0", "2R" },                    
                    _ => new() { "0", "0" },
                },
                "1:1" => dieRoll switch
                {
                    0 => new() { "2R", "0" },
                    1 => new() { "1R", "0" },
                    2 => new() { "1R", "0" },
                    3 => new() { "0R", "0" },
                    4 => new() { "0R", "0R" },
                    5 => new() { "0", "0R" },
                    6 => new() { "0", "1R" },
                    7 => new() { "0", "1R" },
                    8 => new() { "0", "1R" },
                    9 => new() { "0", "2R" },                    
                    _ => new() { "0", "0" },
                },
                "2:1" => dieRoll switch
                {
                    0 => new() { "1R", "0" },
                    1 => new() { "0R", "0" },
                    2 => new() { "0R", "0R" },
                    3 => new() { "0", "0R" },
                    4 => new() { "0", "0R" },
                    5 => new() { "0", "1R" },
                    6 => new() { "0", "1R" },
                    7 => new() { "0", "1R" },
                    8 => new() { "0", "2R" },
                    9 => new() { "0", "2R" },                    
                    _ => new() { "0", "0" },
                },
                "3:1" => dieRoll switch
                {
                    0 => new() { "0R", "0" },
                    1 => new() { "0R", "0R" },
                    2 => new() { "0", "0R" },
                    3 => new() { "0", "1R" },
                    4 => new() { "0", "1R" },
                    5 => new() { "0", "1R" },
                    6 => new() { "0", "2R" },
                    7 => new() { "0", "2R" },
                    8 => new() { "0", "3R" },
                    9 => new() { "0", "3R" },                    
                    _ => new() { "0", "0" },
                },
                "4:1" => dieRoll switch
                {
                    0 => new() { "0R", "0R" },
                    1 => new() { "0", "1R" },
                    2 => new() { "0", "1R" },
                    3 => new() { "0", "1R" },
                    4 => new() { "0", "2R" },
                    5 => new() { "0", "2R" },
                    6 => new() { "0", "3R" },
                    7 => new() { "0", "3R" },
                    8 => new() { "0", "4R" },
                    9 => new() { "0", "4R" },                    
                    _ => new() { "0", "0" },
                },
                _ => new() { "0", "0" },
            };
        }
        public static List<string> BOUNCERESULTS(int dieRoll){
            return dieRoll switch
            {
                0 => new() { "0", "0" },
                1 => new() { "0", "1" },
                2 => new() { "0", "0R" },
                3 => new() { "0", "0R" },
                4 => new() { "0", "1R" },
                5 => new() { "0", "1R" },
                6 => new() { "0", "1R" },
                7 => new() { "0", "2R" },
                8 => new() { "0", "2R" },
                9 => new() { "0", "3R" },                    
                _ => new() { "0", "0" },
            };
        }
        public static List<string> COMBATMISSIONTYPES = new(){"SSM", "ASW", "CM", "BOMB", "TORP"};
        public const double HEXDISTANCE = 94; 
        public const double MILESPERTURN = 100;           
        public static Dictionary<string, string> THEATERS = new(){
            {"CARIBBEAN", "CARIBBEAN"},
            {"ATLANTIC", "EUROPEAN"},
            {"MEDITERRANEAN", "EUROPEAN"},
            {"INDIAN", "INDIAN"},
            {"PACIFIC", "PACIFIC"},
        };
        public static Dictionary<string, List<string>> STRATEGICCOUNTRIES = new();
        //15 hexes from OMAF to ZONE is 1 hop, 30 is 2, 45 is 3....
        public static Dictionary<string, List<string>> ZONECONNECTIONS = new(){
            {"ADRIATIC", new(){"BLACK SEA", "AEGEAN", "CENTRAL MEDITERRANEAN", "THYRRENIAN SEA"}},
            {"AEGEAN", new(){"ADRIATIC", "BLACK SEA", "CENTRAL MEDITERRANEAN", "EASTERN MEDITERRANEAN"}},
            {"ALEUTIAN", new(){"SEA OF OKHOTSK", "KAMCHATKA"}},
            {"ASHKHABAD", new(){"PERSIAN GULF"}},
            {"ATLANTIC", new(){"PUERTO RICO", "BAHAMAS"}},
            {"AZORES", new(){"NORTH ATLANTIC", "WESTERN APPROACHES", "IBERIAN"}},
            {"BAHAMAS", new(){"FLORIDA", "ATLANTIC", "PUERTO RICO", "WINDWARD PASSAGE"}},
            {"BAKU", new(){"BLACK SEA", "PERSIAN GULF"}},
            {"BALTIC SEA", new(){"BOTHNIA GULF", "NORTH SEA", "NORWEGIAN SEA"}},
            {"BARENTS SEA", new(){"BOTHNIA GULF", "NORWEGIAN SEA", "GREENLAND", "SVALBARD"}},
            {"BAY OF BENGAL", new(){"SUMATRA", "EAST INDIAN OCEAN", "SRI LANKA", "INDIA"}},
            {"BAY OF BISCAY", new(){"IBERIAN", "WESTERN MEDITERRANEAN", "WESTERN APPROACHES", "IRELAND", "NORTH SEA"}},
            {"BERMUDA", new(){"BERMUDA1", "BAHAMAS"}},
            {"BERMUDA1", new(){"BERMUDA2"}},
            {"BERMUDA2", new(){"AZORES"}},
            {"BLACK SEA", new(){"EASTERN MEDITERRANEAN", "ADRIATIC", "AEGEAN"}},
            {"BONIN ISLANDS", new(){"NORTHWEST PACIFIC", "NORTH PACIFIC", "MARIANAS", "CENTRAL PACIFIC", "JAPAN"}},
            {"BOTHNIA GULF", new(){"BARENTS SEA", "BALTIC SEA", "NORWEGIAN SEA"}},
            {"CAPE FAREWELL", new(){"LABRADOR SEA", "NORTH ATLANTIC", "WESTERN APPROACHES", "ICELAND SEA", "GREENLAND"}},
            {"CENTRAL MEDITERRANEAN", new(){"EASTERN MEDITERRANEAN", "AEGEAN", "ADRIATIC", "THYRRENIAN SEA"}},
            {"CENTRAL PACIFIC", new(){"JAPAN", "BONIN ISLANDS", "MARIANAS", "SOUTH PACIFIC", "PHILIPPINES", "FORMOSA", "EAST CHINA SEA", }},
            {"CHAGOS ARCHIPELAGO", new(){"MALDIVES", "EAST INDIAN OCEAN"}},
            {"EAST CHINA SEA", new(){"YELLOW SEA", "SEA OF JAPAN", "JAPAN", "CENTRAL PACIFIC", "FORMOSA"}},
            {"EAST INDIAN OCEAN", new(){"SUMATRA", "CHAGOS ARCHIPELAGO", "MALDIVES", "SRI LANKA", "BAY OF BENGAL"}},
            {"EASTERN MEDITERRANEAN", new(){"CENTRAL MEDITERRANEAN", "AEGEAN", "BLACK SEA"}},
            {"EGLIN", new(){"FLORIDA"}},
            {"ELMENDORF AFB", new(){"ALEUTIAN"}},
            {"FLORIDA", new(){"BAHAMAS", "WINDWARD PASSAGE", "WESTERN CARIBBEAN"}},
            {"FORMOSA", new(){"EAST CHINA SEA", "CENTRAL PACIFIC", "PHILIPPINES", "SOUTH CHINA SEA", "HAINAN"}},
            {"GALENA", new(){"ALEUTIAN"}},
            {"GEORGE TOWN", new(){"SUMATRA", "SOUTH CHINA SEA"}},
            {"GREENLAND", new(){"SVALBARD", "BARENTS SEA", "NORWEGIAN SEA", "ICELAND SEA", "CAPE FAREWELL"}},
            {"GULF OF ADEN", new(){"SAUDI ARABIA", "SOCOTRA"}},
            {"GULF OF OMAN", new(){"NORTH ARABIAN SEA", "SOUTH ARABIAN SEA", "SOCOTRA", "SAUDI ARABIA", "PERSIAN GULF"}},
            {"HAINAN", new(){"FORMOSA", "SOUTH CHINA SEA"}},
            {"HOKKAIDO", new(){"SEA OF OKHOTSK", "NORTHWEST PACIFIC", "JAPAN", "SEA OF JAPAN"}},
            {"IBERIAN", new(){"AZORES", "WESTERN APPROACHES", "BAY OF BISCAY", "WESTERN MEDITERRANEAN"}},
            {"ICELAND SEA", new(){"GREENLAND", "NORWEGIAN SEA", "NORTH SEA", "IRELAND", "WESTERN APPROACHES", "CAPE FAREWELL"}},
            {"INDIA", new(){"BAY OF BENGAL", "SRI LANKA", "LACCADIVES", "NORTH ARABIAN SEA"}},
            {"IRELAND", new(){"BAY OF BISCAY", "WESTERN APPROACHES", "ICELAND SEA", "NORTH SEA"}},
            {"JAPAN", new(){"HOKKAIDO", "NORTHWEST PACIFIC", "BONIN ISLANDS", "CENTRAL PACIFIC", "EAST CHINA SEA", "SEA OF JAPAN"}},
            {"KABUL", new(){"GULF OF OMAN"}},
            {"KAMCHATKA", new(){"ALEUTIAN", "SEA OF OKHOTSK"}},
            {"KING SALMON", new(){"ALEUTIAN"}},
            {"LABRADOR SEA", new(){"CAPE FAREWELL", "NORTH ATLANTIC"}},
            {"LACCADIVES", new(){"INDIA", "SRI LANKA", "MALDIVES", "WEST INDIAN OCEAN", "SOUTH ARABIAN SEA", "NORTH ARABIAN SEA"}},
            {"LESSER ANTILLES", new(){"PUERTO RICO", "VENEZUELA", }},
            {"LORING AFB", new(){"LABRADOR SEA"}},
            {"MAGADAN", new(){"KAMCHATKA"}},
            {"MALDIVES", new(){"SRI LANKA", "EAST INDIAN OCEAN", "CHAGOS ARCHIPELAGO", "WEST INDIAN OCEAN", "LACCADIVES"}},
            {"MARIANAS", new(){"SOUTH PACIFIC", "CENTRAL PACIFIC", "BONIN ISLANDS", "NORTH PACIFIC"}},
            {"MIDWAY ISLAND", new(){"MIDWAY1"}},
            {"MIDWAY1", new(){"NORTH PACIFIC", "ALEUTIAN", "MIDWAY2"}},
            {"MIDWAY2", new(){"MARIANAS"}},
            {"NORTH ARABIAN SEA", new(){"INDIA", "LACCADIVES", "SOUTH ARABIAN SEA", "GULF OF OMAN"}},
            {"NORTH ATLANTIC", new(){"LABRADOR SEA", "CAPE FAREWELL", "WESTERN APPROACHES", "AZORES"}},
            {"NORTH PACIFIC", new(){"NORTHWEST PACIFIC", "MARIANAS", "BONIN ISLANDS"}},
            {"NORTH SEA", new(){"NORWEGIAN SEA", "BALTIC SEA", "BAY OF BISCAY", "IRELAND", "ICELAND SEA"}},
            {"NORTHWEST PACIFIC", new(){"SEA OF OKHOTSK", "NORTH PACIFIC", "BONIN ISLANDS", "JAPAN", "HOKKAIDO"}},
            {"NORWEGIAN SEA", new(){"GREENLAND", "BARENTS SEA", "BOTHNIA GULF", "BALTIC SEA", "NORTH SEA", "ICELAND SEA"}},
            {"OKHOTSK", new(){"KAMCHATKA"}},
            {"PANAMA CANAL", new(){"WESTERN CARIBBEAN", "VENEZUELA"}},
            {"PEARL HARBOR", new(){"PEARL1"}},
            {"PEARL1", new(){"PEARL2"}},
            {"PEARL2", new(){"ALEUTIAN"}},
            {"PERSIAN GULF", new(){"GULF OF OMAN", "SAUDI ARABIA"}},
            {"PHILIPPINES", new(){"CENTRAL PACIFIC", "SOUTH PACIFIC", "SOUTH CHINA SEA", "FORMOSA"}},
            {"PRINCE RUPERT", new(){"PRINCERUPERT1"}},
            {"PRINCERUPERT1", new(){"ALEUTIAN"}},
            {"PUERTO RICO", new(){"ATLANTIC", "LESSER ANTILLES", "VENEZUELA", "WINDWARD PASSAGE", "BAHAMAS"}},
            {"SAUDI ARABIA", new(){"PERSIAN GULF", "GULF OF OMAN", "SOCOTRA", "GULF OF ADEN"}},
            {"SEA OF JAPAN", new(){"HOKKAIDO", "JAPAN", "EAST CHINA SEA", "YELLOW SEA"}},
            {"SEA OF OKHOTSK", new(){"KAMCHATKA", "ALEUTIAN", "NORTHWEST PACIFIC", "HOKKAIDO"}},
            {"SINGAPORE", new(){"SUMATRA", "SINGAPORE1"}},
            {"SINGAPORE1", new(){"SOUTH CHINA SEA"}},
            {"SOCOTRA", new(){"GULF OF OMAN", "SOUTH ARABIAN SEA", "WEST INDIAN OCEAN", "GULF OF ADEN", "SAUDI ARABIA"}},
            {"SOUTH ARABIAN SEA", new(){"NORTH ARABIAN SEA", "LACCADIVES", "WEST INDIAN OCEAN", "SOCOTRA", "GULF OF OMAN"}},
            {"SOUTH CHINA SEA", new(){"SCSSUMATRA", "HAINAN", "FORMOSA", "PHILIPPINES"}},
            {"SCSSUMATRA", new(){"SOUTH CHINA SEA", "SUMATRA"}},
            {"SOUTH PACIFIC", new(){"CENTRAL PACIFIC", "MARIANAS", "PHILIPPINES"}},
            {"SRI LANKA", new(){"INDIA", "BAY OF BENGAL", "EAST INDIAN OCEAN", "MALDIVES", "LACCADIVES"}},
            {"SUMATRA", new(){"SCSSUMATRA", "EAST INDIAN OCEAN", "BAY OF BENGAL"}},
            {"SVALBARD", new(){"GREENLAND", "BARENTS SEA"}},
            {"THYRRENIAN SEA", new(){"WESTERN MEDITERRANEAN", "CENTRAL MEDITERRANEAN", "ADRIATIC", }},
            {"VENEZUELA", new(){"WINDWARD PASSAGE", "PUERTO RICO", "LESSER ANTILLES", "PANAMA CANAL", "WESTERN CARIBBEAN"}},
            {"WEST INDIAN OCEAN", new(){"SOUTH ARABIAN SEA", "LACCADIVES", "MALDIVES", "SOCOTRA"}},
            {"WESTERN APPROACHES", new(){"CAPE FAREWELL", "NORTH ATLANTIC", "AZORES", "IBERIAN", "BAY OF BISCAY", "IRELAND", "ICELAND SEA"}},
            {"WESTERN CARIBBEAN", new(){"FLORIDA", "WINDWARD PASSAGE", "VENEZUELA", "PANAMA CANAL"}},
            {"WESTERN MEDITERRANEAN", new(){"THYRRENIAN SEA", "BAY OF BISCAY", "IBERIAN"}},
            {"WINDWARD PASSAGE", new(){"FLORIDA", "BAHAMAS", "PUERTO RICO", "VENEZUELA", "WESTERN CARIBBEAN"}},
            {"YELLOW SEA", new(){"SEA OF JAPAN", "EAST CHINA SEA"}}
        };
        public static Dictionary<string, List<string>> ALIGNEDCOUNTRIES = new(){
            {"ALLIES", new(){"USA", "UK", "CAN", "FRA", "SPN", "PRT", "FRG", "GRC", "NED", "DEN", "BEL", "NOR", "ITA", "TUR", "ICE",
                            "JPN", "SKOR", "TAI", "PHL", "AUS", "SGP", "MLY", "THA",
                            "BHR", "SAU", "OMN", "QTR", "UAE", "KUW",
                            "AAB", "GRN", "PAN", "MEX", "APW"}},
            {"SOV", new(){"USSR", "POL", "DDR", "CZE", "ROM", "BUL", "HUN", 
                            "AFG", "CUB", "NIC", "SYM", "NYM", "ETH", "VNM", "NKOR", 
                            "SYR", "LIB", "ALG", "MON", 
                            "BEN", "ANG", "MOZ", "SPW"}},
            {"NEUT", new(){"NPW"}}
        };
        public static List<string> GENERICCOUNTRIES = new(){"APW", "SPW", "NPW"};
        public static bool ISGROUP(GO obj){
            return obj.GRPTYPE != null;
        }
        public override string TURNTITLE(){
            return "TURN " + GetInt("TURN") + " : " + (Get("TURN.TYPE") ?? "-");
        }
        public override string TURNPHASE(){
            string fullName = "";
            GamePhase tmp = ExecutingGamePhase();
            string[] pathParts = tmp.UNIQUEPATH.Split('|');
            for(int p = 0; p < pathParts.Length; p++){
                string pathPart = pathParts[p];
                if(!pathPart.Contains("*")){
                    if(fullName == ""){
                        fullName = pathPart;
                    } else {
                        fullName += " | " + pathPart;
                    }
                }
            }
            return fullName;
        }
        public override List<GO> STACKSATLOCATION(string glid){
            List<GO> markers = new();
            List<GO> tmp = TYPE("PIECE", "GAMELOCATIONID", glid).ToList();
            markers.AddRange(tmp.Where(n => n.TYPE == "POSSESSIONFLAG"));
            //pieces.AddRange(tmp.Where(n => n.TYPE == "SHIP" || n.TYPE == "SQN" || n.TYPE == "FACILITY"));
            markers.AddRange(tmp.Where(n => !markers.Contains(n)));
            return markers;
        }
        public override void PreCallProcess()
        {
            if(SelectedMarker != null){
                if(!InteractionMap.ContainsKey(SelectedMarker)){
                    _Window.ClearSelectedMarker();
                }
            }
            if(GetBoolean("_CONFIG_PROMPT_WHEN_SWITCHING_SIDE_VISIBILITY")){
                GO anchorLocation = LOCATION(BLINDER.SHEETANCHORLOCATIONID);
                double viewportWidth = Math.Max(_Window.CANVAS_SCROLL_VIEWER.ViewportWidth, 1000);
                double viewportHeight = Math.Max(_Window.CANVAS_SCROLL_VIEWER.ViewportHeight, 500);
                double realX = _Window.CANVAS_SCROLL_VIEWER.HorizontalOffset + viewportWidth * 0.5;
                double realY = _Window.CANVAS_SCROLL_VIEWER.VerticalOffset + viewportHeight * 0.5;
                double gameX = realX / _Window.MapZoomLevel;
                double gameY = realY / _Window.MapZoomLevel;
                anchorLocation.x = gameX;
                anchorLocation.XCOORD = gameX;
                anchorLocation.y = gameY;
                anchorLocation.YCOORD = gameY;
                CHANGELOCATION(BLINDER, anchorLocation.ID);
                _Window.DrawMarkerStackImmediately(GO.DOMAIN_SHEET, anchorLocation);
            }
        }
        public override void PostCallProcess()
        {
            Boolean changingSideView = OLD_SIDE_MODE != SIDE_MODE && !GetBoolean("SETUP");
            //pop up blinder and message when switching side views
            if(changingSideView){
                GO selectedGO = SelectedMarker;
                _Window.ClearSelectedMarker();
                OLD_SIDE_MODE = SIDE_MODE;
                if(GetBoolean("_CONFIG_PROMPT_WHEN_SWITCHING_SIDE_VISIBILITY")){
                    MainWindow.Alert("The game is entering " + SIDE_MODE + " perspective.\n\nIf necessary, please switch players before continuing.");
                }
                SelectedMarker = selectedGO;
            }
            CHANGELOCATION(BLINDER, "TEMP");
            DISPLAYDETAILSHEET(this);
            //handle sheets
            //if selected unit or its move targets are on a sheet, show it
            List<GO> SelectedTargetLocations = new();
            HashSet<GO> SheetsThatMustBeVisible = InteractionMap.Keys.Where(n => n.PARENTSHEETID != null).Select(n => n.PARENTSHEET).ToHashSet();
            if(SelectedMarker != null && InteractionMap.ContainsKey(SelectedMarker)){
                SelectedTargetLocations.AddRange(InteractionMap[SelectedMarker]);
                foreach(GO sheet in SelectedTargetLocations.Where(n => n.PARENTSHEETID != null).Select(n => n.PARENTSHEET)){
                    SheetsThatMustBeVisible.Add(sheet);
                }        
                if(SelectedMarker.CARRIERID != null){
                    if(CVSHEET.SHEETPARENTPIECE != SelectedMarker.CARRIER){
                        if(SelectedMarker.CARRIER.GROUPID != null){
                            if(GRPSHEET.SHEETPARENTPIECE != SelectedMarker.CARRIER.GROUP){
                                DISPLAYGROUP(this, SelectedMarker.CARRIER.GROUP);
                            }
                        }
                        DISPLAYGROUP(this, SelectedMarker.CARRIER);
                    }
                    SheetsThatMustBeVisible.Add(CVSHEET);
                } else if(SelectedMarker.GROUPID != null){
                    if(GRPSHEET.SHEETPARENTPIECE != SelectedMarker.GROUP){
                        DISPLAYGROUP(this, SelectedMarker.GROUP);
                    }
                    SheetsThatMustBeVisible.Add(GRPSHEET);
                } else if(SelectedMarker.ACTIVATIONGRPID != null){
                    if(ACTIVATIONGRPSHEET.SHEETPARENTPIECE != SelectedMarker.ACTIVATIONGRP){
                        DISPLAYGROUP(this, SelectedMarker.ACTIVATIONGRP);
                    }
                    SheetsThatMustBeVisible.Add(ACTIVATIONGRPSHEET);
                }
            }
            //any target for our selected marker, show indicator
            if(!ExecutingGamePhase().NoShowLocationIndicators && ExecutingGamePhase().DragDrop){
                SelectedTargetLocations.ForEach(n => n.MakeEllipseVisible("WHITE", false, 40, false));
            }
            //handle connecting lines from open trays
            List<GO> tmpsheets = new(FS.TRAYSHEETS);
            tmpsheets.AddRange(FS.TMPSHEETS);
            foreach(GO grouptray in tmpsheets){
                if(grouptray.SHEETPARENTPIECE == null || grouptray.SHEETPARENTPIECE.GAMELOCATION.LOCATIONHIDDEN || grouptray.SHEETPARENTPIECE.HIDDEN){
                    if(grouptray.GAMELOCATIONID != "TEMP"){
                        REMOVEGROUPSHEET(this, grouptray);
                    }
                } else {
                    SheetsThatMustBeVisible.Add(grouptray);
                    GO group = grouptray.SHEETPARENTPIECE;
                    GO fromLoc = grouptray.GAMELOCATION;
                    GO toLoc = group.GAMELOCATION;
                    _Window.GOIndicatorsDrawn["WHITE"].Remove(grouptray);
                    grouptray.MakeLineVisible("WHITE");
                }
            }
            foreach(GO sheet in SHEETS()){
                if(sheet == BLINDER){continue;}
                if(SheetsThatMustBeVisible.Contains(sheet) && !sheet.EXPANDED){
                    _Window.ExpandOrCollapseSheet(sheet, true);
                } else if(changingSideView && !SheetsThatMustBeVisible.Contains(sheet) && sheet.EXPANDED){
                    _Window.ExpandOrCollapseSheet(sheet, false);
                }               
            }
            if(SelectedMarker?.PARENTSHEET?.SHEETPARENTPIECE != null){
                GO pickedMarker = SelectedMarker.PARENTSHEET.SHEETPARENTPIECE;
                ShuffleMarker(pickedMarker);
                _Window.DrawMarkerStack(pickedMarker.DOMAIN, pickedMarker.GAMELOCATION);
            }
            //show trails of activated units
            if(FS.SIDE_NAMES.Contains(SIDE_MODE)){
                foreach(GO obj in FS.GETTAGGEDUNITS(this, "ACTION.ACTIVATED").Where(n => n.LOCATIONHISTORY != null && !n.HIDDEN)){
                    string[] locations = obj.LOCATIONHISTORY.Split('|');
                    for(int i = 1; i < locations.Length; i++){
                        bool first = i == 1;
                        bool last = i == locations.Length - 1;
                        string f = locations[i - 1];
                        string t = locations[i];
                        if(first && obj.SIDE == SIDE_MODE){
                            LOCATION(f).MakeEllipseVisible("GRAY", true, 20, true);
                        }
                        if(last || obj.SIDE == SIDE_MODE){
                            GO connector = TYPE("UNITMOVEMENT" , "CONNECTORLOCATIONID", f).Where(n => n.CONNECTORLOCATION2ID == t).FirstOrDefault();
                            connector?.MakeLineVisible("GRAY", true);
                        }
                    }
                }
                foreach(GO obj in FS.TYPESIDE(this, "PIECE", SIDE_MODE).Where(n => n.LOCATIONFUTURE != null && !n.HIDDEN)){
                    string[] locations = obj.LOCATIONFUTURE.Split('|');
                    for(int i = 1; i < locations.Length; i++){
                        bool first = i == 1;
                        bool last = i == locations.Length - 1;
                        string f = locations[i - 1];
                        string t = locations[i];
                        GO connector = TYPE("UNITMOVEMENT" , "CONNECTORLOCATIONID", f).Where(n => n.CONNECTORLOCATION2ID == t).FirstOrDefault();
                        string color = "BLACK";
                        if(obj == SelectedMarker || obj == SelectedMarker.GAMEPIECE){
                            GO movingUnit = obj.DESTINATIONPIECE ?? obj;
                            color = movingUnit.REMAININGMOVEMENT < 0 ? "RED" : "WHITE";
                        }
                        connector?.MakeLineVisible(color, true);
                    }
                }
            }
        }
        public static List<GO> TYPELOCATION(GameScenario gs, string type, string p1){
            return gs.TYPE(type, "GAMELOCATIONID", p1);
        }
        public static List<GO> TYPESIDE(GameScenario gs, string type, string p1){
            return gs.TYPE(type, "SIDE", p1);
        }
        public static List<GO> TYPEAIRTHEATER(GameScenario gs, string type, string p1){
            return gs.TYPE(type, "AIRTHEATER", p1);
        }
        public static List<GO> TYPECOUNTRY(GameScenario gs, string type, string p1){
            return gs.TYPE(type, "COUNTRY", p1);
        }
        public static List<GO> TYPEORGLEVEL1(GameScenario gs, string type, string p1){
            return gs.TYPE(type, "ORGLEVEL1", p1);
        }
        public static List<GO> TYPEORGLEVEL2(GameScenario gs, string type, string p1){
            return gs.TYPE(type, "ORGLEVEL2", p1);
        }
        public static List<GO> TYPEMILDISTRICT(GameScenario gs, string type, string p1){
            return gs.TYPE(type, "MILDISTRICT", p1);
        }
        public static List<GO> TYPESIDEAIRTHEATER(GameScenario gs, string type, string p1, string p2){
            return TYPESIDE(gs, type, p1).Intersect(TYPEAIRTHEATER(gs, type, p2)).ToList();
        }
        public static List<GO> TYPESIDELOCATION(GameScenario gs, string type, string p1, string p2){
            return TYPESIDE(gs, type, p1).Intersect(TYPELOCATION(gs, type, p2)).ToList();
        }
        public static List<GO> TYPESIDECOUNTRY(GameScenario gs, string type, string p1, string p2){
            return TYPESIDE(gs, type, p1).Intersect(TYPECOUNTRY(gs, type, p2)).ToList();
        }
        public static List<string> SIDE_NAMES = new(){
            "SOV",
            "ALLIES"
        };
        public static Dictionary<string, List<string>> ADJACENT_AIR_THEATERS = new(){
            {"NORTHERN", new(){"BALTIC"}},
            {"BALTIC", new(){"NORTHERN", "WESTERNEUROPE"}},
            {"WESTERNEUROPE", new(){"BALTIC", "SOUTHWESTERN"}},
            {"SOUTHWESTERN", new(){"WESTERNEUROPE", "BALKAN"}},
            {"BALKAN", new(){"SOUTHWESTERN", "WESTERNASIA", "PALESTINIAN"}},
            {"WESTERNASIA", new(){"BALKAN", "PERSIANGULF", "PALESTINIAN"}},
            {"PERSIANGULF", new(){"WESTERNASIA", "PALESTINIAN"}},
            {"PALESTINIAN", new(){"BALKAN", "WESTERNASIA", "PERSIANGULF"}}
        };
        public static List<string> AIR_THEATER_NAMES = ADJACENT_AIR_THEATERS.Keys.ToList();
        public static string ENEMY(string side){
            return side == "ALLIES" ? "SOV" : side == "SOV" ? "ALLIES" : "";            
        }
        public void SetTrackValue(string track, int value, int numTracks){
            if(numTracks == 2){
                int ones = value % 10;
                GO onesMarker = PIECE(track);
                CHANGELOCATION(onesMarker, track + GO.DELIM + ones + "");
                
                int tens = value - ones;
                GO tensMarker = PIECE(track + "10");
                CHANGELOCATION(tensMarker, track + "10" + GO.DELIM + tens + "");
            }
            else {
                GO onesMarker = PIECE(track);
                CHANGELOCATION(onesMarker, track + GO.DELIM + value + "");
            }
        }
        public override void ProcessCanvasRightClick(double x, double y)
        {
            List<GO> actions = ACTIONS(TYPE("MAP").First());
            if(actions.Any()){
                _Window.MapDynamicMenu.Items.Clear();
                foreach(GO action in actions){
                    MenuItem mi = new(){Header = action.ACTION};
                    mi.Click += _Window.MapcmiImg_Click;
                    _Window.MapDynamicMenu.Items.Add(mi);
                }
                _Window.MapDynamicMenu.PlacementTarget = _Window.WORLD_CANVAS;
                _Window.MapDynamicMenu.IsOpen = true;
            }
        }
        public override void ProcessMapMouseMove(double realX, double realY)
        {
        }
        public override void ProcessControlClick(GO marker)
        {
            if(marker.GRPTYPE == "TFTGGRP"){
                TOGGLETRAY(marker, GRPSHEET);
            } else if(marker.GRPTYPE == "ACTIVATIONGRP"){
                TOGGLETRAY(marker, ACTIVATIONGRPSHEET);
            } else if(marker.TEMPLATE?.AIRUNITS != null){
                TOGGLETRAY(marker, CVSHEET);
            } else if(marker.PARENTSHEETID != null && TRAYSHEETS.Contains(marker.PARENTSHEET)){
                TOGGLETRAY(marker.PARENTSHEET.SHEETPARENTPIECE, marker.PARENTSHEET);
            } else if(TRAYSHEETS.Contains(marker)){
                TOGGLETRAY(marker.SHEETPARENTPIECE, marker);
            }          
        }
        public void TOGGLETRAY(GO marker, GO tmpSheet){
            GO DIRECTSHEET = SelectedMarker.PARENTSHEET;
            GO INDIRECTSHEET = SelectedMarker.CARRIER?.PARENTSHEET;
            bool closing = tmpSheet.SHEETPARENTPIECE == marker;
            List<GO> doesNotNeedThisSheet = InteractionMap.Keys.Where(n => n.PARENTSHEET != tmpSheet && n.CARRIER?.PARENTSHEET != tmpSheet).ToList();
            List<GO> children = InteractionMap.Keys.Where(n => LOGICALPARENT(n) == marker || LOGICALPARENT(LOGICALPARENT(n)) == marker).ToList();
            if(DIRECTSHEET == tmpSheet || INDIRECTSHEET == tmpSheet){
                if(closing){
                    if(doesNotNeedThisSheet.Any()){
                        SelectedMarker = doesNotNeedThisSheet.First();
                        REMOVEGROUPSHEET(this, tmpSheet);
                    }
                } else {
                    if(children.Any()){
                        SelectedMarker = children.First();
                        DISPLAYGROUP(this, marker);
                    } else if(doesNotNeedThisSheet.Any()){
                        SelectedMarker = doesNotNeedThisSheet.First();
                        DISPLAYGROUP(this, marker);
                    }
                }
            } else {
                if(closing){
                    REMOVEGROUPSHEET(this, tmpSheet);
                } else {
                    DISPLAYGROUP(this, marker);
                }
            }
        }
        public override void ProcessMenu(GO marker, bool forceExpansion, bool stackMode)
        {
            Menu m = _Window.MarkerMenu;
            if(stackMode){
                List<GO> tmp = TYPE("PIECE", "GAMELOCATIONID", marker.GAMELOCATIONID).Where(n => !n.HIDDEN).ToList();
                if(tmp.Count > 1){
                    stackedGOs.Clear();
                    stackedGOs.AddRange(tmp.Where(n => n.TYPE == "SQN" && n.AIRMISSION == "CAP"));
                    tmp.RemoveAll(stackedGOs.Contains);
                    stackedGOs.AddRange(tmp.Where(n => n.TYPE == "SQN"));
                    tmp.RemoveAll(stackedGOs.Contains);
                    stackedGOs.AddRange(tmp.Where(n => n.UNITCATEGORY == "SURFACE"));
                    tmp.RemoveAll(stackedGOs.Contains);
                    stackedGOs.AddRange(tmp.Where(n => n.UNITCATEGORY == "SUB"));
                    tmp.RemoveAll(stackedGOs.Contains);
                    stackedGOs.AddRange(tmp);
                    double yoffset = marker.IMAGEHEIGHTVALUE > 0 ? marker.IMAGEHEIGHTVALUE : marker.IMAGEWIDTHVALUE;                    
                    Image img = marker.image;
                    m.Items.Clear();
                    for(int i = 0; i < stackedGOs.Count; i++){
                        GO obj = stackedGOs[i];
                        if(m.Items.Count > 0){
                            m.Items.Add(new Separator());
                        }
                        MenuItem mi = new(){Header = i + " : " + (obj.AIRMISSION == "CAP" ? "On CAP : " : "") + (obj.UNITTYPE != null ? obj.UNITTYPE + " " : "") + obj.LABEL};
                        mi.Click += _Window.StackcmiImg_Click;
                        m.Items.Add(mi);
                    }

                    double x = Canvas.GetLeft(img) + (marker.IMAGEWIDTHVALUE * _Window.MapZoomLevel);
                    double y = Canvas.GetTop(img) + (yoffset * _Window.MapZoomLevel);
                    Canvas.SetLeft(m, Math.Max(x, 1));
                    Canvas.SetTop(m, Math.Max(y, 1));
                    Canvas.SetZIndex(m, Canvas.GetZIndex(img) + 1000000);
                } else {
                    _Window.HideMenus();
                }
            } else {
                if(marker != null && (CANACTION(marker) || FS.ORDERS)){
                    double yoffset = marker.IMAGEHEIGHTVALUE > 0 ? marker.IMAGEHEIGHTVALUE : marker.IMAGEWIDTHVALUE;
                        
                    Image img = marker.image;
                    m.Items.Clear();
                    if(FS.ORDERS && marker.SIDE == FS.SIDE_MODE){
                        string hdr = "MP: " + marker.REMAININGMOVEMENT;
                        MenuItem mi = new(){Header = hdr};
                        m.Items.Add(mi);
                    }                    
                    if(CANDRAG(marker) && !ExecutingGamePhase().ShowExpandedMenu && !forceExpansion)
                    {
                        MenuItem mi = new(){Header = "+"};
                        mi.Click += _Window.Expandcmi_Click;
                        m.Items.Add(mi);
                    } else {
                        foreach(GO action in ACTIONS(marker)){
                            if(m.Items.Count > 0){
                                m.Items.Add(new Separator());
                            }
                            MenuItem mi = new(){Header = action.ACTION};
                            mi.Click += _Window.MarkercmiImg_Click;
                            m.Items.Add(mi);
                        }
                    }

                    double x = Canvas.GetLeft(img) + (marker.IMAGEWIDTHVALUE * _Window.MapZoomLevel);
                    double y = Canvas.GetTop(img) + (yoffset * _Window.MapZoomLevel);
                    Canvas.SetLeft(m, Math.Max(x, 1));
                    Canvas.SetTop(m, Math.Max(y, 1));
                    Canvas.SetZIndex(m, Canvas.GetZIndex(img) + 1000000);
                } else {
                    _Window.HideMenus();
                }
            }
        }
        public override void ProcessDoubleLeftClick(GO marker)
        {
            if(FS.ISGROUP(marker) || marker.TEMPLATE?.AIRUNITS != null || FS.TRAYSHEETS.Contains(marker.PARENTSHEET) || FS.TRAYSHEETS.Contains(marker)){
                ProcessControlClick(marker);
                _Window.RefreshScenario(false);
            } else if(marker.DOMAIN == GO.DOMAIN_SHEET && marker != DETAILSHEET){
                _Window.ExpandOrCollapseSheet(marker, !marker.EXPANDED);
                _Window.RefreshScenario(false);                
            } else {
                ProcessDoubleRightClick(marker);
            }
        }
        public override void ProcessDoubleRightClick(GO marker)
        {
            if(marker == DETAILSHEET || marker.GAMELOCATION == InspectedLocation){
                _Window.DrawMarkerStack(GO.DOMAIN_PIECE, marker.GAMELOCATION);
                InspectedLocation = null;
                _Window.RefreshScenario(false);
            } else if(marker.DOMAIN == GO.DOMAIN_PIECE){
                if(InspectedLocation != null){
                    _Window.DrawMarkerStack(GO.DOMAIN_PIECE, InspectedLocation);
                }                
                InspectedLocation = marker.GAMELOCATION;
                InspectedLocation.z_inspection = DETAILSHEET.z;
                _Window.DrawMarkerStack(GO.DOMAIN_PIECE, InspectedLocation);
                _Window.RefreshScenario(false);
                if(marker == SelectedMarker){
                    ProcessMenu(SelectedMarker, false, true);
                }
            }
        }
        public override void ProcessStackMenuClick(string header)
        {
        
            int index = CWApp.Helpers.CSVFile.ParseInt(header.Split(':').First().Trim(), 0);
            GO marker = stackedGOs[index];                
            if(CANINTERACT(marker)){
                _Window.PickMarkerImmediately(marker);
            } else {
                _Window.ClickMarker(marker);                             
            }
        }
        public override void PreLoadProcessing(){
            foreach(string category in new List<string>(){
                "ID",
                "COUNTRY",
                "SIDE",
                "ORGLEVEL1",
                "ZONE",
                "CONNECTORLOCATIONID",
                "GAMELOCATIONID",
                "PARENTSHEETID",
                "CARRIERID",
                "GROUPID",
                "CAPID",
                "ACTIVATIONGRPID",
                "TARGETGRPID"
            }){
                GOCategorizedFields.Add(category);
            }
            foreach(string category in new List<string>(){
                "DOMAIN",
                "TYPE",
                "GRPTYPE"
            }){
                GOTypedFields.Add(category);
            }
            foreach(string category in new List<string>(){
                "DAMAGED",
                "AIRFIELDDAMAGELEVEL",
                "PORTDAMAGELEVEL",
                "EXPANSION",
                "ENROUTEDELAY",
                "DEEPMODE",
                "LOCALDETECTED",
                "STRATDETECTED",
                "TACCOORDPIECEID",
                "DOCKED",
                "REPLENISHING",
                "DONE",
                "NUMCOMBATS",
                "FUELPTS",
                "ASWPTS",
                "AAPTS",
                "SSMPTS",
                "SSM2PTS",
                "CMPTS",
                "TORPPTS",
                "TEMPLATEID"
            }){
                GOIndicatorFields.Add(category);
            }
        }
        public override List<Image> GOImages(GO obj, Boolean refreshAll){
            List<Image> info = new();
            Image img;
            Boolean bNew = false;
            if(obj.image != null)
                img = obj.image;
            else {
                img = new Image();
                obj.image = img;
                if(obj.DOMAIN == GO.DOMAIN_SHEET || obj.DOMAIN == GO.DOMAIN_PIECE){
                    _Window.AddImageToGame(img);
                    GOImageMap[img] = obj;
                } else {
                    img.MouseMove += _Window.Img_MouseMove;
                    _Window.WORLD_CANVAS.Children.Add(img);
                }
                bNew = true;
            }
            string fn = obj.IMAGEFILENAME;
            if(bNew || refreshAll){
                if(obj.DYNAMICSIZE){
                    _Window.SetZoomableImage(img,  _Window.GetScenarioImageDir() + "/" + fn, obj.IMAGEWIDTHVALUE, obj.IMAGEHEIGHTVALUE);
                } else {
                    double imgWidth = obj.DOMAIN == GO.DOMAIN_SHEET  && !obj.EXPANDED ? obj.MINIMIZEDWIDTHVALUE : obj.IMAGEWIDTHVALUE;
                    _Window.SetZoomableImage(img,  _Window.GetScenarioImageDir() + "/" + fn, imgWidth);
                }
            }
            info.Add(img);
            return info;
        }
        protected Dictionary<string, CWRectangleWrapper> BaseRectangleMap = new();
        public override List<CWRectangleWrapper> GORectangles(GO obj, Boolean refreshAll){
            //produce a bunch of rectangles based on units status
            List<CWRectangleWrapper> info = new();
            List<string> currentStatusKeys = new();
            if(obj.TYPE == "SHIP" || obj.TYPE == "SQN"){
                if(obj.DONE){currentStatusKeys.Add("DONE");}
                if(obj.EXPANSION){currentStatusKeys.Add("EXPANSION");}
                if(obj.OVERSTACKED){currentStatusKeys.Add("OVERSTACKED");}
                if(obj.DEEPMODE){currentStatusKeys.Add("DEEPMODE");}
                if(obj.ENROUTEDELAY > 0){currentStatusKeys.Add("ENROUTE");}
                if(obj.STRATDETECTED){currentStatusKeys.Add("STRATDETECTED");}
                if(obj.LOCALDETECTED && !obj.STRATDETECTED){currentStatusKeys.Add("LOCALDETECTED");}
                if(!SIDE_MODE.Contains(obj.SIDE ?? "")){
                    if(obj.TACCOORDPIECEID != null){currentStatusKeys.Add("TACCOORD");}
                }
                if(obj.DOCKED){currentStatusKeys.Add("DOCKED");}
                if(obj.REPLENISHING){currentStatusKeys.Add("REPLENISHING");}
                if(obj.AIRMISSION == "CAP"){
                    currentStatusKeys.Add("CAP");
                    if(obj.NUMCOMBATS > 1){currentStatusKeys.Add("ATTACKS2");}
                    if(obj.NUMCOMBATS > 0){currentStatusKeys.Add("ATTACKS1");}
                }
            } else if(obj.TYPE == "FACILITY"){
                if(obj.PORT){
                    for(int i = 1; i <= 3; i++){
                        if(obj.PORTDAMAGELEVEL >= i){currentStatusKeys.Add("PORTDAMAGE" + i);}
                    }
                }
                if(obj.AIRFIELD){
                    for(int i = 1; i <= 3; i++){
                        if(obj.AIRFIELDDAMAGELEVEL >= i){currentStatusKeys.Add("AIRFIELDDAMAGE" + i);}
                    }
                }
            }
            foreach(string baseKey in BaseRectangleMap.Keys.Where(n => currentStatusKeys.Contains(n) || obj.RECTANGLES.ContainsKey(n))){
                Boolean bNew = false;
                CWRectangleWrapper rw = BaseRectangleMap[baseKey];
                CWRectangleWrapper newrw = new();
                newrw.show = currentStatusKeys.Contains(baseKey);
                if(obj.RECTANGLES.ContainsKey(baseKey)){
                    newrw.rect = obj.RECTANGLES[baseKey];
                } else if(newrw.show) {
                    newrw.rect = new Rectangle();
                    newrw.rect.Fill = rw.rect.Fill;
                    newrw.rect.Stroke = rw.rect.Stroke;
                    obj.RECTANGLES[baseKey] = newrw.rect;
                    _Window.AddRectToGame(newrw.rect);
                    bNew = true;
                }
                newrw.x = rw.x;
                newrw.y = rw.y;
                newrw.z = rw.z;
                if(bNew || refreshAll){
                    newrw.rect.Width = rw.width * _Window.MapZoomLevel;
                    newrw.rect.Height = (rw.height == 0 ? rw.width : rw.height) * _Window.MapZoomLevel;
                    newrw.rect.StrokeThickness = rw.thickness * _Window.MapZoomLevel;
                }
                info.Add(newrw);   
            }
            return info;
        }
        public static void SHOWBORDER(GameScenario GS, GO obj, Boolean show){
            if(show || obj.lineIndicator2 != null){
                Line l = GS.GetLine2(obj, false);
                //l.Stroke = colorMap[typecolorkey];
                Canvas.SetZIndex(l, show ? MainWindow.Z_BORDER_INDICATOR : MainWindow.Z_HIDDEN);
            }
        }
        public static Boolean CANSTACK(GameScenario GS, GO location, List<GO> units){
            if(!units.Any()){return true;}
            int stackingLimit = 0;
            return units.Distinct().Sum(n => n.STEPS) <= stackingLimit;
        }
        public static List<FSMovement> GENERATECONNECTIONS(GO fromLoc){
            List<FSMovement> movements = new();
            fromLoc.GS.CONNECTIONS(fromLoc.ID, null).ForEach(
                n => movements.Add(GENERATECONNECTION(n[0], n[1]))
            );
            return movements;
        }
        public static List<FSMovement> GENERATEAIRMOVEMENTCONNECTIONS(GO fromLoc){
            List<FSMovement> movements = new();
            foreach( GO connector in fromLoc.GS.TYPE("UNITMOVEMENT" , "CONNECTORLOCATIONID", fromLoc.ID)){
                movements.Add(GENERATECONNECTION(connector, connector.CONNECTORLOCATION2));
            }
            return movements;
        }
        public static List<FSMovement> GENERATESEAMOVEMENTCONNECTIONS(GO fromLoc){
            List<FSMovement> movements = new();
            foreach( GO connector in fromLoc.GS.TYPE("UNITMOVEMENT" , "CONNECTORLOCATIONID", fromLoc.ID).Where(n => n.TERRAIN == "SEA" || n.TERRAIN == "COASTAL")){
                movements.Add(GENERATECONNECTION(connector, connector.CONNECTORLOCATION2));
            }
            return movements;
        }
        public static FSMovement GENERATECONNECTION(GO connector, GO toLoc){
            if(connector == null || toLoc == null){
                return null;
            }
            return new FSMovement(){
                MOVEMENTCONNECTORID = connector.ID,
                MOVEMENTCONNECTOR = connector,
                MOVEMENTLOCATIONID = toLoc.ID,
                MOVEMENTLOCATION = toLoc
            };
        }
        public static List<FSMovement> GENERATESEALOGISTICALCONNECTIONS(GO fromLoc){
            List<FSMovement> movements = new();
            foreach( GO connector in fromLoc.GS.TYPE("LOGISTICAL" , "CONNECTORLOCATIONID", fromLoc.ID).Where(n => n.LOGSEA)){
                movements.Add(GENERATECONNECTION(connector, connector.CONNECTORLOCATION2));
            }
            return movements;
        }
        public override void PostLoadProcessing()
        {
            FS.GRPSHEET = SHEET("GROUPTRAY");
            FS.DETAILSHEET = SHEET("DETAILTRAY");
            FS.CVSHEET = SHEET("CVTRAY");
            FS.ACTIVATIONGRPSHEET = SHEET("ACTIVATIONTRAY");
            FS.SETUPSHEET = SHEET("SETUPTRAY");
            FS.DEFENDSHEET = SHEET("DEFENDTRAY");
            FS.DEFENDSHEET.SHEETPARENTPIECE = PIECE("ACTION.TARGET");            
            FS.BLINDER = SHEET("BLINDER");
            FS.TRAYSHEETS = new(){FS.GRPSHEET, FS.ACTIVATIONGRPSHEET, FS.CVSHEET};
            FS.TMPSHEETS = new(){FS.SETUPSHEET, FS.DEFENDSHEET};
            FS.STRATAIRSHEETS = TYPE("STRATEGICAIRTRAY");
            FS.FACILITYTEMPLATES = new(){
                PIECE("ALLIES.PORT.AIRFIELD"),
                PIECE("SOV.PORT.AIRFIELD"),
                PIECE("NEUT.PORT.AIRFIELD"),
                PIECE("ALLIES.PORT"),
                PIECE("SOV.PORT"),
                PIECE("NEUT.PORT"),
                PIECE("ALLIES.AIRFIELD"),
                PIECE("SOV.AIRFIELD"),
                PIECE("NEUT.AIRFIELD"),
            };
            FS.FLAGTEMPLATES = new(){
                PIECE("FLAG.ALLIES.ALLIES"),
                PIECE("FLAG.ALLIES.SOV"),
                PIECE("FLAG.ALLIES.NEUT"),
                PIECE("FLAG.NEUT.NEUT"),
                PIECE("FLAG.SOV.SOV"),
                PIECE("FLAG.SOV.ALLIES"),
                PIECE("FLAG.SOV.NEUT"),
            };
            FS.STRATEGICCOUNTRIES.Add("ALL", new());
            foreach(string map in FS.THEATERS.Keys){
                List<string> countries = Get("_CONFIG_" + map + "_STRATEGIC_COUNTRIES").Split('|').ToList();
                FS.STRATEGICCOUNTRIES.Add(map, countries);
                FS.STRATEGICCOUNTRIES["ALL"].AddRange(countries);
            }
            //for any sheet, set z
            foreach(GO sheet in SHEETS()){
                sheet.z = sheet.ZCOORD;
                if(sheet.GAMELOCATIONID != "TEMP"){
                    if(TRAYSHEETS.Contains(sheet)){sheet.EXPANDED = true;}
                    if(TMPSHEETS.Contains(sheet)){sheet.EXPANDED = true;}
                }
                if(sheet == FS.BLINDER){sheet.EXPANDED = true;}
            }
            //for any location not on a sheet, assign x and y
            //for any location on a sheet, set x y and z
            foreach(GO loc in LOCATIONS().Where(n => n.PARENTSHEETID == null)){
                if(loc.PARENTMAPID != null){
                    loc.x = loc.PARENTMAP.XCOORD + loc.XCOORD;
                    loc.y = loc.PARENTMAP.YCOORD + loc.YCOORD;
                    loc.z = loc.PARENTMAP.ZCOORD;
                } else {
                    loc.x = loc.XCOORD;
                    loc.y = loc.YCOORD;
                    loc.HIDDEN = loc.LOCATIONHIDDEN;
                }
            }
            foreach(GO loc in LOCATIONS().Where(n => n.PARENTSHEETID != null)){
                loc.x = loc.PARENTSHEET.GAMELOCATION.x + loc.XCOORD - loc.PARENTSHEET.IMAGEWIDTHVALUE * 0.5;
                loc.y = loc.PARENTSHEET.GAMELOCATION.y + loc.YCOORD - (loc.PARENTSHEET.IMAGEHEIGHTVALUE == 0 ? loc.PARENTSHEET.IMAGEWIDTHVALUE : loc.PARENTSHEET.IMAGEHEIGHTVALUE) * 0.5;
                loc.z = loc.PARENTSHEET.ZCOORD;
                loc.HIDDEN = !loc.PARENTSHEET.EXPANDED;
            }
            foreach(GO conn in CONNECTORS().Where(n => n.ALWAYSSHOW)){
                conn.MakeLineVisible(conn.TYPE.Contains("SEA") ? "LIGHTBLUE" : "WHITE");
                //if(conn.CONNECTORLOCATION.SIDE != null && conn.CONNECTORLOCATION2.SIDE != null && conn.CONNECTORLOCATION.SIDE != conn.CONNECTORLOCATION2.SIDE){
                //    SHOWBORDER(this, conn, true);
                //}
            }
            foreach(string s in new List<string>{"TARGET", "DESTINATION", "FACILITY"}){
                TYPE(s).ForEach(ShuffleMarkerToBottom);
            }
            /*//for any object without a history, give it a default history with its current GL
            foreach(GameObject obj in GameObjects()){
                if((obj.DOMAIN == GameObject.DOMAIN_PIECE || obj.DOMAIN == GameObject.DOMAIN_SHEET) && !HISTORIES(obj.ID).Any()){
                    SETMOVEMENTHISTORY(obj, obj.GAMELOCATIONID);
                }
            }*/
            //create dictionary metadata
            double rectangleWidth = MarkerSize * 0.125;
            CWRectangleWrapper rw = new();
            rw.width = rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Black;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = System.Windows.Media.Brushes.White;
            BaseRectangleMap.Add("EXPANSION", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 6 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Black;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Yellow;
            BaseRectangleMap.Add("ENROUTE", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 6 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Black;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = System.Windows.Media.Brushes.Red;
            BaseRectangleMap.Add("OVERSTACKED", rw);

            rw = new();
            rw.width = 1.5 * rectangleWidth;
            rw.x = 0.5 * rectangleWidth;
            rw.y = 0.75 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.White;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("DEEPMODE", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.height = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Gray;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Gray;
            BaseRectangleMap.Add("LOCALDETECTED", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.height = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.White;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.White;
            BaseRectangleMap.Add("STRATDETECTED", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 2 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Black;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("TACCOORD", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 6 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Gray;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.White;
            BaseRectangleMap.Add("DOCKED", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Gray;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("REPLENISHING", rw);

            rw = new();
            rw.width = 8 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 0 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.White;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.LightSkyBlue;
            BaseRectangleMap.Add("CAP", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 6 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.White;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Red;
            BaseRectangleMap.Add("ATTACKS1", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 5 * rectangleWidth;
            rw.y = 7 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.White;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Red;
            BaseRectangleMap.Add("ATTACKS2", rw);

            rw = new();
            rw.width = 2 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 0 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Black;
            rw.thickness = 1;
            rw.z = 2;
            rw.rect.Fill = System.Windows.Media.Brushes.Red;
            BaseRectangleMap.Add("DONE", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 2 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("PORTDAMAGE1", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("PORTDAMAGE2", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 2 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("PORTDAMAGE3", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 3 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("PORTDAMAGE4", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 4 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("AIRFIELDDAMAGE1", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 5 * rectangleWidth;
            rw.y = 3 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("AIRFIELDDAMAGE2", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 4 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("AIRFIELDDAMAGE3", rw);

            rw = new();
            rw.width = 1 * rectangleWidth;
            rw.height = 1 * rectangleWidth;
            rw.x = 5 * rectangleWidth;
            rw.y = 4 * rectangleWidth;
            rw.rect = new Rectangle();
            rw.rect.Stroke = System.Windows.Media.Brushes.Red;
            rw.thickness = 1;
            rw.z = 1;
            rw.rect.Fill = System.Windows.Media.Brushes.Black;
            BaseRectangleMap.Add("AIRFIELDDAMAGE4", rw);
        } 
        public override Boolean CANACTION(GO obj){
            return ACTIONS(obj).Count > 0;
        }
        public override Boolean CANDRAG(GO obj){
            return DRAGTARGETS(obj).Count > 0 || (obj.DOMAIN == GO.DOMAIN_SHEET && obj != DETAILSHEET);
        }
        public override List<GO> DRAGTARGETS(GO obj){
            if(InteractionMap.ContainsKey(obj) && InteractionMap[obj].Any()){
                return new(InteractionMap[obj]);
            } else if(obj.TYPE == "STRATEGICAIRTRAY"){
                return TYPE("HEX").Where(n => n.ZONE == obj.ZONE).ToList();
            } else {
                return new();
            }
        }
        public static List<FSMovement> FINDDIRECTMOVEMENTPATH(GameScenario gs, GO startLoc, GO endLoc){
            double left = Math.Min(startLoc.x, endLoc.x);
            double right = Math.Max(startLoc.x, endLoc.x);
            if(left == right){
                List<GO> connectedHexes = gs.CONNECTIONS(startLoc.ID, "ALLIES").Select(n => n[1]).ToList();
                left = connectedHexes.Min(n => n.x);
                right = connectedHexes.Max(n => n.x);
            }
            double top = Math.Min(startLoc.y, endLoc.y);
            double bottom = Math.Max(startLoc.y, endLoc.y);
            List<GO> validHexes = gs.TYPE("HEX").Where(n => n.x >= left && n.x <= right && n.y >= top && n.y <= bottom).ToList();
            return FINDMOVEMENTPATH(gs, startLoc, endLoc, validHexes);
        }
        public static List<FSMovement> FINDMOVEMENTPATH(GameScenario gs, GO startHex, GO endHex, List<GO> validHexes){
            Dictionary<string, List<FSMovement>> movementPathMap = new();
            FSMovement startMovement = new(){
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            List<List<FSMovement>> movementPaths = new(){ new(){ startMovement } };
            while(movementPaths.Count > 0){
                List<List<FSMovement>> newMovementPaths = new();
                foreach(List<FSMovement> movementPath in movementPaths){
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    foreach(FSMovement nextMovement in FS.GENERATECONNECTIONS(from).Where(n => 
                                                                                !hexPath.Contains(n.MOVEMENTLOCATION) && 
                                                                                validHexes.Contains(n.MOVEMENTLOCATION))){
                        GO to = nextMovement.MOVEMENTLOCATION;
                        int newCost = movementPath.Count + 1;
                        Boolean lowestCostToThisHex = true;
                        if(movementPathMap.ContainsKey(to.ID)){
                            int shortestCost = movementPathMap[to.ID].Count;
                            lowestCostToThisHex = newCost < shortestCost;
                        }
                        if(!lowestCostToThisHex){continue;}
                        List<FSMovement> newMovementPath = new(movementPath){nextMovement};
                        movementPathMap[to.ID] = newMovementPath;
                        newMovementPaths.Add(newMovementPath);
                    }
                }
                movementPaths = newMovementPaths;
            }
            if(movementPathMap.ContainsKey(endHex.ID)){
                return movementPathMap[endHex.ID];
            } else {
                return new();
            }
        }
        public static List<GO> FINDAIRRADIUS(GO startHex, int radius){
            if(startHex.TYPE != "HEX"){return new();}
            List<GO> radiusHexes = new(){startHex};
            Dictionary<string, List<FSMovement>> movementPathMap = new();
            FSMovement startMovement = new(){
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            List<List<FSMovement>> movementPaths = new(){ new(){ startMovement } };
            while(movementPaths.Count > 0){
                List<List<FSMovement>> newMovementPaths = new();
                foreach(List<FSMovement> movementPath in movementPaths){
                    if(movementPath.Count > radius){continue;}
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    foreach(FSMovement nextMovement in FS.GENERATEAIRMOVEMENTCONNECTIONS(from).Where(n => 
                                                                                !hexPath.Contains(n.MOVEMENTLOCATION) && 
                                                                                !radiusHexes.Contains(n.MOVEMENTLOCATION))){
                        GO to = nextMovement.MOVEMENTLOCATION;
                        if(to.TYPE != "HEX"){continue;}
                        int newCost = movementPath.Count + 1;
                        Boolean lowestCostToThisHex = true;
                        if(movementPathMap.ContainsKey(to.ID)){
                            int shortestCost = movementPathMap[to.ID].Count;
                            lowestCostToThisHex = newCost < shortestCost;
                        }
                        if(!lowestCostToThisHex){continue;}
                        List<FSMovement> newMovementPath = new(movementPath){nextMovement};
                        movementPathMap[to.ID] = newMovementPath;
                        newMovementPaths.Add(newMovementPath);
                        radiusHexes.Add(to);
                    }
                }
                movementPaths = newMovementPaths;
            }
            return radiusHexes;
        }
        public static List<FSMovement> FINDAIRMOVEMENTPATH(GO startHex, GO endHex){
            GameScenario gs = startHex.GS;
            if(startHex == endHex){return new();}
            int distanceToEnd = 0;
            if(FS.THEATERS[startHex.ORGLEVEL1] != FS.THEATERS[endHex.ORGLEVEL1]){
                //if these are in different theaters, one of these locations must be 1 hop from other theater
                bool startConnectsToOtherTheater = FS.GENERATECONNECTIONS(startHex).Where(n => FS.THEATERS[n.MOVEMENTLOCATION.ORGLEVEL1] == FS.THEATERS[endHex.ORGLEVEL1]).Any();
                bool endConnectsToOtherTheater = FS.GENERATECONNECTIONS(endHex).Where(n => FS.THEATERS[n.MOVEMENTLOCATION.ORGLEVEL1] == FS.THEATERS[startHex.ORGLEVEL1]).Any();
                if(!startConnectsToOtherTheater && !endConnectsToOtherTheater){
                    return new();
                }
            }
            List<FSMovement> directPath = FINDAIRMOVEMENTDIRECTPATH(startHex, endHex, 0);
            if(directPath.Any()){return directPath;}

            Dictionary<string, List<FSMovement>> movementPathMap = new();
            FSMovement startMovement = new(){
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            List<List<FSMovement>> movementPaths = new(){ new(){ startMovement } };
            while(movementPaths.Count > 0){
                List<List<FSMovement>> newMovementPaths = new();
                foreach(List<FSMovement> movementPath in movementPaths){
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    foreach(FSMovement nextMovement in FS.GENERATEAIRMOVEMENTCONNECTIONS(from).Where(n => 
                                                                                !hexPath.Contains(n.MOVEMENTLOCATION))){
                        GO to = nextMovement.MOVEMENTLOCATION;
                        int newCost = FS.GETAIRMOVEMENTDISTANCE(movementPath) + 
                            Math.Max(nextMovement.MOVEMENTCONNECTOR.DISTANCE, 1);
                        if(distanceToEnd > 0 && newCost >= distanceToEnd){continue;}
                        if(to == endHex){
                            distanceToEnd = distanceToEnd == 0 ? newCost : Math.Min(distanceToEnd, newCost);
                        }
                        Boolean lowestCostToThisHex = true;
                        if(movementPathMap.ContainsKey(to.ID)){
                            int shortestCost = FS.GETAIRMOVEMENTDISTANCE(movementPathMap[to.ID]);
                            lowestCostToThisHex = newCost < shortestCost;
                        }
                        if(!lowestCostToThisHex){continue;}
                        List<FSMovement> newMovementPath = new(movementPath){nextMovement};
                        movementPathMap[to.ID] = newMovementPath;
                        newMovementPaths.Add(newMovementPath);
                    }
                }
                movementPaths = newMovementPaths;
            }
            if(movementPathMap.ContainsKey(endHex.ID)){
                return movementPathMap[endHex.ID];
            } else {
                return new();
            }
        }
        private static List<FSMovement> FINDAIRMOVEMENTDIRECTPATH(GO startHex, GO endHex, int maxDistance){
            GameScenario gs = startHex.GS;
            FSMovement startMovement = new(){
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            List<List<FSMovement>> movementPaths = new(){ new(){ startMovement } };
            while(movementPaths.Count > 0){
                List<List<FSMovement>> newMovementPaths = new();
                foreach(List<FSMovement> movementPath in movementPaths){
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    FSMovement nextMovement = 
                    FS.GENERATEAIRMOVEMENTCONNECTIONS(from)
                        .Where(n => !hexPath.Contains(n.MOVEMENTLOCATION))
                        .OrderBy(n => gs.GetDistance(n.MOVEMENTLOCATION, endHex.x, endHex.y)).FirstOrDefault();
                    
                    if(nextMovement == null){return new();}
                    nextMovement.DISTANCE = Math.Max(1, nextMovement.MOVEMENTCONNECTOR.DISTANCE);
                    GO to = nextMovement.MOVEMENTLOCATION;
                    List<FSMovement> newMovementPath = new(movementPath){nextMovement};
                    newMovementPaths.Add(newMovementPath);
                    if(newMovementPath.Sum(n => n.DISTANCE) > maxDistance && maxDistance > 0){
                        return new();
                    }    
                    if(to == endHex){
                        return newMovementPath;
                    }                
                }
                movementPaths = newMovementPaths;
            }
            return new();
        }
        public static List<FSMovement> FINDSSMDIRECTPATH(GO startHex, GO endHex){
            GameScenario gs = startHex.GS;
            FSMovement startMovement = new(){
                MOVEMENTLOCATIONID = startHex.ID,
                MOVEMENTLOCATION = startHex
            };
            List<List<FSMovement>> movementPaths = new(){ new(){ startMovement } };
            while(movementPaths.Count > 0){
                List<List<FSMovement>> newMovementPaths = new();
                foreach(List<FSMovement> movementPath in movementPaths){
                    List<GO> hexPath = movementPath.Select(n => n.MOVEMENTLOCATION).ToList();
                    GO from = hexPath.Last();
                    FSMovement nextMovement = 
                    FS.GENERATESEAMOVEMENTCONNECTIONS(from)
                        .Where(n => !hexPath.Contains(n.MOVEMENTLOCATION))
                        .OrderBy(n => gs.GetDistance(n.MOVEMENTLOCATION, endHex.x, endHex.y)).FirstOrDefault();
                    
                    if(nextMovement == null){return new();}

                    GO to = nextMovement.MOVEMENTLOCATION;
                    List<FSMovement> newMovementPath = new(movementPath){nextMovement};
                    newMovementPaths.Add(newMovementPath);    
                    if(to == endHex){
                        return newMovementPath;
                    }                
                }
                movementPaths = newMovementPaths;
            }
            return new();
        }
        public static double GETDEFENSE(GO obj){
            return obj.TEMPLATE.DEF - (obj.OUTOFFUEL || obj.REPLENISHING ? 1 : 0);
        }
        public static void RESETMOVEMENTALLOWANCE(GO obj){
            if(obj.UNITCATEGORY == "AIR"){
                double ratio = 1 + (obj.EXTENDEDRANGE ? 0.25 : 0);
                obj.MOVEMENTALLOWANCE = Math.Floor(obj.TEMPLATE.MOVEMENTALLOWANCE * ratio);

            } else {
                obj.MOVEMENTALLOWANCE = obj.DEEPMODE || obj.OUTOFFUEL ? 1 : obj.TEMPLATE.MOVEMENTALLOWANCE;
                if(obj.FULLSPEED){
                    if(obj.UNITCATEGORY == "SUB"){obj.MOVEMENTALLOWANCE++;}
                }
                if(PARENTGROUPLOCATION(obj).FJORD){obj.MOVEMENTALLOWANCE = Math.Ceiling(obj.MOVEMENTALLOWANCE * 0.5);}
            }
        }
        public static void DOCK(GO obj){
            obj.DOCKED = true;
            obj.MOVEMENTALLOWANCE = 0;
        }
        public static bool CANDOCK(GO obj){
            return obj.UNITCATEGORY switch{
                "SURFACE" => obj.OUTOFFUEL || obj.MOVEMENTALLOWANCE >= 2,
                "SUB" => obj.MOVEMENTALLOWANCE >= Math.Min(obj.TEMPLATE.MOVEMENTALLOWANCE - 1, 2),
                _ => false
            };
        }
        public static List<FSMovement> FINDAIRMOVEMENTS(GO fromLoc){
            List<FSMovement> connections = new();
            foreach(FSMovement movement in GENERATEAIRMOVEMENTCONNECTIONS(fromLoc)){
                movement.DISTANCE = Math.Max(1, movement.MOVEMENTCONNECTOR.DISTANCE);
                connections.Add(movement);
            }
            return connections;
        }
        public static List<FSMovement> FINDSURFACEMOVEMENTS(GO obj, GO fromLoc){
            GameScenario GS = obj.GS;
            List<FSMovement> connections = new();
            foreach(FSMovement movement in GENERATESEAMOVEMENTCONNECTIONS(fromLoc)){
                if(movement.MOVEMENTLOCATION.SHOALS && !obj.PCCOONLY){continue;}
                movement.DISTANCE = GS.Get(movement.MOVEMENTLOCATION.ZONE + ".WEATHER") switch
                {
                    "STORM" => 4,
                    "SQUALL" => 2,
                    _ => 1,
                };
                if(obj.FULLSPEED && movement.MOVEMENTLOCATION.RESTRICTED){
                    movement.DISTANCE++;
                }
                if(movement.MOVEMENTLOCATION.DRIFTICE){
                    movement.DISTANCE++;
                }
                connections.Add(movement);
            }
            return connections;
        }
        public static List<FSMovement> FINDSUBMOVEMENTS(GO obj, GO fromLoc){
            List<FSMovement> connections = new();
            foreach(FSMovement movement in GENERATESEAMOVEMENTCONNECTIONS(fromLoc)){
                if(movement.MOVEMENTLOCATION.SHOALS){continue;}
                if(obj.DEEPMODE || obj.FULLSPEED){
                    if(movement.MOVEMENTLOCATION.RESTRICTED || movement.MOVEMENTLOCATION.SHALLOW || movement.MOVEMENTLOCATION.DRIFTICE){continue;}
                }
                movement.DISTANCE = 1;
                connections.Add(movement);
            }
            return connections;
        }
        public override string GetToolTip(int column, int row)
        {
            return column switch
            {
                0 => row switch
                {
                    0 => "Help/Instructions",
                    1 => "Next Phase",
                    _ => "",
                },
                1 => row switch
                {
                    0 => "",
                    1 => "",
                    _ => "",
                },
                2 => row switch
                {
                    0 => "",
                    1 => "",
                    _ => "",
                },
                3 => row switch
                {
                    0 => "",
                    1 => "",
                    _ => "",
                },
                4 => row switch
                {
                    0 => "",
                    1 => "",
                    _ => "",
                },
                5 => row switch
                {
                    0 => "",
                    1 => "",
                    _ => "",
                },
                6 => row switch
                {
                    0 => "",
                    1 => "",
                    _ => "",
                },
                7 => row switch
                {
                    0 => "Save Progress (limited)",
                    1 => "Copy To New Branch",
                    _ => "",
                },
                8 => row switch
                {
                    0 => "Zoom Level 1",
                    1 => "Zoom Level 3",
                    _ => "",
                },
                9 => row switch
                {
                    0 => "Zoom Level 2",
                    1 => "Zoom Level 4",
                    _ => "",
                },
                _ => "",
            };
        }
        public override string GetScenarioSpecificImage(int column, int row)
        {
            return column switch
            {
                0 => row switch
                {
                    0 => "IconHelp.png",
                    1 => "IconNext.png",
                    _ => "EMPTY.png",
                },
                1 => row switch
                {
                    0 => "EMPTY.png",
                    1 => "EMPTY.png",
                    _ => "EMPTY.png",
                },
                2 => row switch
                {
                    0 => "EMPTY.png",
                    1 => "EMPTY.png",
                    _ => "EMPTY.png",
                },
                3 => row switch
                {
                    0 => "EMPTY.png",
                    1 => "EMPTY.png",
                    _ => "EMPTY.png",
                },
                4 => row switch
                {
                    0 => "EMPTY.png",
                    1 => "EMPTY.png",
                    _ => "EMPTY.png",
                },
                5 => row switch
                {
                    0 => "EMPTY.png",
                    1 => "EMPTY.png",
                    _ => "EMPTY.png",
                },
                6 => row switch
                {
                    0 => "EMPTY.png",
                    1 => "EMPTY.png",
                    _ => "EMPTY.png",
                },
                7 => row switch
                {
                    0 => "IconSave.png",
                    1 => "IconBranch.png",
                    _ => "",
                },
                8 => row switch
                {
                    0 => "IconZoom1.png",
                    1 => "IconZoom3.png",
                    _ => "",
                },
                9 => row switch
                {
                    0 => "IconZoom2.png",
                    1 => "IconZoom4.png",
                    _ => "",
                },
                _ => "",
            };
        }
        public override void ScenarioButtonClick(int column, int row)
        {
            switch (column)
            {
                case 0:
                    switch (row){
                        case 0: //HELP
                            if(HELPTEXT != null){
                                MessageBox.Show(HELPTEXT);
                            }
                            break;
                        case 1: //NEXT PHASE
                            if(RESULT != null){
                                MessageBox.Show("Scenario " + data.ID + " is over. " + RESULT);
                                return;
                            } else if(ExecutingGamePhase().ManualAdvance){
                                _Window.UpdateScenario("NEXT");
                            }
                            break;
                    }
                    break;
                case 1:
                    switch (row){
                        case 0: //TOGGLE OBJECTIVE VIEW
                            break;
                        case 1: //TOGGLE SURFACE VIEW
                            break;
                    }
                    break;
                case 2:
                    switch (row){
                        case 0: 
                            break;
                        case 1: //TOGGLE SUB VIEW
                            break;
                    }
                    break;
                case 3:
                    switch (row){
                        case 0: 
                            break;
                        case 1: //TOGGLE AIR VIEW
                            break;
                    }
                    break;
                case 6:
                    switch (row){
                        case 0: //CEUR
                            break;
                        case 1: //SWASIA
                            break;
                    }
                    break;
                case 7:
                    switch (row){
                        case 0:
                            if(ExecutingGamePhase().InProgressSave){
                                _Window.SaveGameStateToLocalFiles();
                                MainWindow.Alert("Progress within current phase saved successfully");
                            } else {
                                MainWindow.Alert("Current phase does not support In-Progress save.  Please advance to next phase to save progress.");
                            }
                            break;
                        case 1: //save branch
                            if(ExecutingGamePhase().InProgressSave){
                                _Window.SaveGameStateToLocalFiles();
                            }
                            string newSaveGameName = _Window.GenerateSessionID();
                            string newDirectory = _Window.GetGameSaveDir() + "/" + newSaveGameName;
                            System.IO.Directory.CreateDirectory(newDirectory);            
                            string[] ofiles = System.IO.Directory.GetFiles(_Window.GetGameSessionDir(), "*.*");
                            foreach (string s in ofiles)
                            {
                                // Use static Path methods to extract only the file name from the path.
                                string fileName = System.IO.Path.GetFileName(s);
                                string _currFileName = System.IO.Path.Combine(newDirectory, fileName);
                                System.IO.File.Copy(s, _currFileName, true);
                            }
                            MainWindow.Alert("New Save Game folder created: " + newSaveGameName);
                            break;
                    }
                    break;
                case 8:
                    switch (row){
                        case 0: //zoom
                            if(_Window.MapZoomLevel != 0.075){
                                _Window.MapZoomLevel = 0.075;
                                _Window.ZoomAll();
                            }
                            break;
                        case 1: //zoom
                            if(_Window.MapZoomLevel != 0.667){
                                _Window.MapZoomLevel = 0.667;
                                _Window.ZoomAll();
                            }
                            break;
                    }
                    break;
                case 9:
                    switch (row){
                        case 0: //zoom
                            if(_Window.MapZoomLevel != 0.333){
                                _Window.MapZoomLevel = 0.333;
                                _Window.ZoomAll();
                            }
                            break;
                        case 1: //zoom
                            if(_Window.MapZoomLevel != 1){
                                _Window.MapZoomLevel = 1;
                                _Window.ZoomAll();
                            }
                            break;
                    }
                    break;
                default:
                    break;
            };
        }
        public static void SETVIEW(GameScenario GS){
            HashSet<GO> changedLocations = new();
            List<GO> groups = new();
            foreach(GO piece in GS.PIECES().Where(n => n.SIDE != null && !n.OBJECTIVE && n.TYPE != "FACILITY" && n.GAMELOCATIONID != null)){
                bool hidden = false;
                if(!SIDE_MODE.Contains(piece.SIDE ?? "")){
                    hidden = !piece.STRATDETECTED && !piece.LOCALDETECTED && !piece.ADMINDETECTED;
                } else if(FS.ISGROUP(piece)){
                    groups.Add(piece);
                    continue;
                } else {
                    hidden = false;
                }
                if(hidden != piece.HIDDEN){
                    changedLocations.Add(piece.GAMELOCATION);
                }
                piece.HIDDEN = hidden;
            }
            foreach(GO piece in groups){
                bool hidden = !FS.GROUPMEMBERS(piece).Where(n => !n.HIDDEN).Any();
                if(hidden != piece.HIDDEN){
                    changedLocations.Add(piece.GAMELOCATION);
                }
                piece.HIDDEN = hidden;
            }            
            foreach(GO location in changedLocations){
                GS._Window.DrawMarkerStack(GO.DOMAIN_PIECE, location, true);
            }
        }
        public override string INFO(GameScenario GS, GO obj){            
            return INFOLINE1(obj) + INFOLINE2(obj) + INFOLINE3(obj);
        }
        private string INFOLINE1(GO obj){
            string returnString = "";
            switch (obj.TYPE){
                case "SQN":
                case "SHIP":
                    if(FS.ISGROUP(obj)){
                        GO first = FS.GROUPMEMBERS(obj).OrderBy(n => n.GROUPINDEX).FirstOrDefault();
                        returnString += obj.UNITTYPE + (first != null ? " - " + first.UNITTYPE + " " + first.LABEL : "");
                    } else {
                        returnString += obj.UNITTYPE + " " + obj.LABEL;
                    }
                    break;
                case "TARGET":
                    returnString += obj.LABEL + " Attack";
                    break;
                case "FACILITY":
                    returnString += obj.LABEL + (obj.PORT ? " PORT Dmg:" + obj.PORTDAMAGELEVEL : "") + (obj.AIRFIELD ? " AIRFIELD Dmg:" + obj.AIRFIELDDAMAGELEVEL : "");
                    break;
                case "POSSESSIONFLAG":
                    returnString += obj.LABEL;
                    break;
                case "DESTINATION":
                    returnString += obj.GAMEPIECE.UNITCATEGORY + " Destination";
                    break;
                default:
                    returnString += obj.TYPE;
                    break;
            }
            return returnString;
        }
        private string INFOLINE2(GO obj){
            string returnString = "";
            switch(obj.TYPE){
                case "SQN":
                case "SHIP":
                    if(FS.ISGROUP(obj)){
                        returnString += obj.SIDE + (obj.MOVEMENTALLOWANCE > 0 ? " MOV: " + obj.MOVEMENTALLOWANCE : "");
                    } else {
                        returnString += obj.SIDE + "/" + obj.COUNTRY;
                    }
                    returnString += obj.ENROUTEDELAY > 0 ? obj.ACTIVATED && obj.UNITCATEGORY == "AIR" ? " (" + obj.ENROUTEDELAY + " hexes away)" : " (arrives in " + obj.ENROUTEDELAY + " turns)" : "";
                    break;
                default:
                    returnString += (obj.COUNTRY ?? "") + (obj.COUNTRY != null && obj.SIDE != null ? "/" : "") + (obj.SIDE ?? "");
                    break;
            }
            return (returnString != "" ? "\n" : "") + returnString;
        }
        private string INFOLINE3(GO obj){
            string returnString = "";
            switch(obj.TYPE){
                case "SQN":
                case "SHIP":
                    if(obj.AIRMISSION == "CAP"){returnString += "CAP Attacks: " + obj.NUMCOMBATS + " ";}
                    string fuelInfo = obj.FUELPTS == obj.TEMPLATE.FUELPTS ? "" : " Fuel:" + obj.FUELPTS + "/" + obj.TEMPLATE.FUELPTS;
                    string ssmInfo = obj.SSMPTS == obj.TEMPLATE.SSMPTS ? "" : " SSM:" + obj.SSMPTS + "/" + obj.TEMPLATE.SSMPTS;
                    string ssm2Info = obj.SSM2PTS == obj.TEMPLATE.SSM2PTS ? "" : " SSM2:" + obj.SSM2PTS + "/" + obj.TEMPLATE.SSM2PTS;
                    string torpInfo = obj.TORPPTS == obj.TEMPLATE.TORPPTS ? "" : " Torp:" + obj.TORPPTS + "/" + obj.TEMPLATE.TORPPTS;
                    string cmInfo = obj.CMPTS == obj.TEMPLATE.CMPTS ? "" : " CM:" + obj.CMPTS + "/" + obj.TEMPLATE.CMPTS;
                    string aswInfo = obj.ASWPTS == obj.TEMPLATE.ASWPTS ? "" : " ASW:" + obj.ASWPTS + "/" + obj.TEMPLATE.ASWPTS;
                    string aaInfo = obj.AAPTS == obj.TEMPLATE.AAPTS ? "" : " AA:" + obj.AAPTS + "/" + obj.TEMPLATE.AAPTS;
                    string bmbInfo = obj.BOMBPTS == obj.TEMPLATE.BOMBPTS ? "" : " Bomb:" + obj.BOMBPTS + "/" + obj.TEMPLATE.BOMBPTS;
                    string airssmInfo = obj.AIRSSMPTS == obj.TEMPLATE.AIRSSMPTS ? "" : " AirSSM:" + obj.AIRSSMPTS + "/" + obj.TEMPLATE.AIRSSMPTS;
                    string aInfo = obj.APTS == obj.TEMPLATE.APTS ? "" : " AP:" + obj.APTS + "/" + obj.TEMPLATE.APTS;
                    string fInfo = obj.FPTS == obj.TEMPLATE.FPTS ? "" : " FP:" + obj.FPTS + "/" + obj.TEMPLATE.FPTS;
                    returnString += fuelInfo + ssmInfo + ssm2Info + torpInfo + cmInfo + aswInfo + aaInfo + bmbInfo + airssmInfo + aInfo + fInfo;
                    break;
                default:
                    break;
            }
            return (returnString != "" ? "\n" : "") + returnString;
        }
        public static List<string> AIRCOMBATTYPES = new(){ "INT", "ATK", "BMB"};
            
        public static Boolean CANSTACKONCARRIER(GameScenario GS, GO parent, List<GO> units){
            if(!units.Any()){return true;}
            //check combat aircraft
            if(units.Where(n => AIRCOMBATTYPES.Contains(n.UNITTYPE)).Count() > parent.TEMPLATE.AIRCAPACITYCOMBAT){
                return false;
            }
            //check other types
            if(units.Where(n => n.UNITTYPE == "AEW").Count() > parent.TEMPLATE.AIRCAPACITYAEW){
                return false;
            }
            if(units.Where(n => n.UNITTYPE == "EW").Count() > parent.TEMPLATE.AIRCAPACITYEW){
                return false;
            }
            if(units.Where(n => n.UNITTYPE == "RCN").Count() > parent.TEMPLATE.AIRCAPACITYRCN){
                return false;
            }
            if(units.Where(n => n.UNITTYPE == "MSW").Count() > parent.TEMPLATE.AIRCAPACITYMSW){
                return false;
            }
            if(units.Where(n => n.UNITTYPE == "AR").Count() > parent.TEMPLATE.AIRCAPACITYAR){
                return false;
            }
            return true;
        }
        public static List<string> SURFACECOMBATTYPES = new(){ "CV", "BB", "CT", "CG", "DD", "FF", "CO", "PC"};
        public static List<string> SHOALTYPES = new(){"PC", "CO"};            
        public static Boolean CANSTACKSURFACE(List<GO> units){
            if(!units.Any()){return true;}
            GameScenario GS = units.First().GS;
            List<GO> allUnits = new();
            foreach(GO unit in units.Distinct()){
                if(ISGROUP(unit)){
                    allUnits.AddRange(GROUPMEMBERS(unit));
                } else {
                    allUnits.Add(unit);
                }
            }
            if(allUnits.Where(n => SURFACECOMBATTYPES.Contains(n.UNITTYPE)).Count() > 12){
                return false;
            }
            return true;
        }
        public static Boolean CANSTACKAIR(List<GO> units){
            if(!units.Any()){return true;}
            //check combat aircraft
            if(units.Where(n => AIRCOMBATTYPES.Contains(n.UNITTYPE)).Distinct().Count() > 4){
                return false;
            }
            return true;
        }
        public static void MOVETOGRIDSECTION(GameScenario GS, GO obj, string gridLocation){
            Dictionary<int, List<GO>> locPopulationMap = new();
            List<GO> locs = GS.TYPE(gridLocation).OrderBy(n => n.ID).ToList();
            for(int i = 0; i < locs.Count; i++){
                GO loc = locs[i];
                int population = GS.PIECESATLOCATION(loc.ID).Where(n => n != obj).Count();
                if(!locPopulationMap.ContainsKey(population)){
                    locPopulationMap.Add(population, new());
                }
                locPopulationMap[population].Add(loc);
            }
            GO chosenLoc = locPopulationMap[locPopulationMap.Keys.OrderBy(n => n).First()].First();
            GS.CHANGELOCATION(obj, chosenLoc);
        }
        public static void CHANGEPOSSESSION(GameScenario gs, GO hex, string newSide){
            if(hex.SIDE != null && newSide != hex.SIDE){
                string oldSide = hex.SIDE;
                hex.SIDE = newSide;
                if(hex.PORT || hex.AIRFIELD){
                    if(SIDE_NAMES.Contains(oldSide) && SIDE_NAMES.Contains(newSide)){
                        if(hex.PORT){
                            DESTROYBASE(hex, "PORT");
                        }
                        if(hex.AIRFIELD){
                            DESTROYBASE(hex, "AIRFIELD");
                        }
                    }
                    if(hex.GAMEPIECE != null){
                        gs.DISCARD(hex.GAMEPIECE);
                        hex.GAMEPIECE = FS.CREATEBASE(FACILITYTEMPLATES.Where(n => n.ID == hex.SIDE + (hex.PORT ? ".PORT" : "") + (hex.AIRFIELD ? ".AIRFIELD" : "")).Single(), hex);
                    }
                }
                if(hex.LOGISTICALBASE){
                    GO flagClone = FS.TYPELOCATION(gs, "POSSESSIONFLAG", hex.ID).FirstOrDefault();
                    bool createflag = flagClone == null || flagClone.SIDE != newSide;
                    bool discardflag = flagClone != null && flagClone.SIDE != newSide;
                    //if clone doesn't already exists, create here
                    if(createflag){
                        GO flagTemplate = FS.FLAGTEMPLATES.Where(n => n.ID == "FLAG." + newSide + "." + oldSide).Single();
                        GO newflag = FS.CLONE(gs, flagTemplate, hex.ID);
                        newflag.LABEL = flagTemplate.LABEL;
                        newflag.LABEL ??= hex.LABEL;
                        newflag.COUNTRY ??= hex.COUNTRY;
                        newflag.SIDE = newSide;
                        newflag.FRIENDLYSTRENGTH = flagClone.ENEMYSTRENGTH;
                        newflag.FRIENDLYSUPPLIES = flagClone.ENEMYSUPPLIES;
                        newflag.ENEMYSTRENGTH = flagClone.FRIENDLYSTRENGTH;
                        newflag.ENEMYSUPPLIES = flagClone.FRIENDLYSUPPLIES;
                    }
                    if(discardflag){
                        gs.DISCARD(flagClone);
                    }
                }
            }
        }
        public static string GENERATETIMESTAMP(){
            return DateTime.Now.ToString("yyyyMMddHHmmssfff");
        }
        public static GO DISPLAYGROUP(GameScenario GS, GO group){
            GO sheet = group.GRPTYPE == "TFTGGRP" ? GRPSHEET : 
                group.GRPTYPE == "ACTIVATIONGRP" ? ACTIVATIONGRPSHEET :
                        CVSHEET;
            if(sheet.SHEETPARENTPIECE != group){
                if(GS.TYPE("PIECE", "PARENTSHEETID", sheet.ID).Any()){
                    REMOVEGROUPSHEET(GS, sheet);
                }
                double realY = group.GAMELOCATION.y;
                double offset = sheet == GRPSHEET ? -125 : sheet == CVSHEET ? -250 : sheet == ACTIVATIONGRPSHEET ? 125 : 0;
                //by default add above location
                if(offset < 0){
                    if(realY + offset <= 0){offset = 0 - offset;}
                } else {
                    if(realY + offset >= GS.WorldSize){ offset = 0 - offset;}
                }
                realY += offset;
                GO anchor = GS.LOCATION(sheet.SHEETANCHORLOCATIONID);
                anchor.x = group.GAMELOCATION.x;
                anchor.XCOORD = anchor.x;
                anchor.y = realY;
                anchor.YCOORD = anchor.y;
            }
            List<GO> grpMembers = FS.GROUPMEMBERS(group).Where(n => !n.HIDDEN).OrderBy(n => n.GROUPINDEX).ToList();
            //dynamic size
            double baseSize = GS.MarkerSize * 1.25;
            int c = Math.Max(1, grpMembers.Count);
            int r = 1;
            //while(c * r < grpMembers.Count){
                //if(c == r){c++;} else {r++;}
            //}
            sheet.IMAGEWIDTH = c * baseSize;
            sheet.MINIMIZEDWIDTH = sheet.IMAGEWIDTH;
            sheet.IMAGEHEIGHT = r * baseSize;
            sheet.SHEETPARENTPIECE = group;
            List<GO> dynamiccolorsheets = new(){FS.ACTIVATIONGRPSHEET, FS.CVSHEET, FS.GRPSHEET};
            Dictionary<string, string> sidecolors = new(){{"SOV", "RED"},{"ALLIES", "BLUE"},{"NEUT", "GRAY"}};
            if(dynamiccolorsheets.Contains(sheet)){
                sheet.IMAGEFILE = "COLOR." + sidecolors[group.SIDE] + "." + (sheet == FS.CVSHEET || group.TYPE == "SQN" ? "LIGHT.png" : "GRAY.png");
            }
            GS.CHANGELOCATION(sheet, sheet.SHEETANCHORLOCATIONID);
            List<GO> locs = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", sheet.ID).Where(n => n.XCOORD < sheet.IMAGEWIDTH && n.YCOORD < sheet.IMAGEHEIGHT).ToList();
            for(int i = 0; i < grpMembers.Count; i++){
                GS.CHANGELOCATION(grpMembers[i], locs[i]);
            }
            GS._Window.ExpandOrCollapseSheet(sheet, true);
            return sheet;
        }
        public static void REMOVEGROUPSHEET(GameScenario GS, GO sheet){
            sheet.SHEETPARENTPIECE = null;
            GS._Window.ExpandOrCollapseSheet(sheet, false);
            GS.CHANGELOCATION(sheet, "TEMP");
            foreach(GO obj in GS.TYPE("PIECE", "PARENTSHEETID", sheet.ID)){
                obj.GAMELOCATION.GAMEPIECEID = null;
                GS.CHANGELOCATION(obj, "TEMP");
            }            
        }
        public static GO DISPLAYCOMBATSHEET(GameScenario GS, List<GO> grpMembers){
            GO first = grpMembers.First();
            GO sheet = first.SIDE == GS.Get("ACTIVE.SIDE") ? SETUPSHEET : DEFENDSHEET;
            GO maplocation = first.HOMEBASE.DOMAIN == GO.DOMAIN_LOCATION ? first.HOMEBASE : FS.PARENTGROUPLOCATION(first.HOMEBASE);
            if(first.PARENTSHEET != sheet){
                GO anchor = GS.LOCATION(sheet.SHEETANCHORLOCATIONID);
                anchor.XCOORD = maplocation.x;
                anchor.YCOORD = maplocation.y;
                anchor.x = maplocation.x;
                anchor.y = maplocation.y;
            }            
            //dynamic size
            double baseSize = GS.MarkerSize * 1.25;
            int c = Math.Max(1, grpMembers.Count);
            int r = 1;
            //while(c * r < grpMembers.Count){
                //if(c == r){c++;} else {r++;}
            //}
            sheet.IMAGEWIDTH = c * baseSize;
            sheet.MINIMIZEDWIDTH = sheet.IMAGEWIDTH;
            sheet.IMAGEHEIGHT = r * baseSize;
            GS.CHANGELOCATION(sheet, sheet.SHEETANCHORLOCATIONID);
            GS.CHANGELOCATION(sheet.SHEETPARENTPIECE, maplocation);
            List<GO> locs = GS.TYPE("TRAYLOCATION", "PARENTSHEETID", sheet.ID).Where(n => n.XCOORD < sheet.IMAGEWIDTH && n.YCOORD < sheet.IMAGEHEIGHT).ToList();
            for(int i = 0; i < grpMembers.Count; i++){
                GS.CHANGELOCATION(grpMembers[i], locs[i]);
            }
            GS._Window.ExpandOrCollapseSheet(sheet, true);
            return sheet;
        }
        public static void DISPLAYDETAILSHEET(GameScenario GS){
            bool hide = true;
            if(GS.InspectedLocation != null){
                List<GO> tmp = GS.TYPE("PIECE", "GAMELOCATIONID", GS.InspectedLocation.ID).Where(n => !n.HIDDEN).ToList();
                if(tmp.Count > 1){
                    GO sheet = DETAILSHEET;
                    //dynamic size
                    double baseSize = GS.MarkerSize * 1.25;
                    int c = 1; //Math.Max(1, tmp.Count);
                    int r = 1;
                    while(c * r < tmp.Count){
                        if(c == r){c++;} else {r++;}
                    }
                    sheet.IMAGEWIDTH = c * baseSize;
                    sheet.MINIMIZEDWIDTH = sheet.IMAGEWIDTH;
                    sheet.IMAGEHEIGHT = r * baseSize;
                    GS.CHANGELOCATION(sheet, GS.InspectedLocation);
                    GS._Window.ExpandOrCollapseSheet(sheet, true);
                    hide = false;
                }
            }
            if(hide && DETAILSHEET.GAMELOCATIONID != "TEMP"){
                GS.CHANGELOCATION(DETAILSHEET, "TEMP");
                GS._Window.ExpandOrCollapseSheet(DETAILSHEET, false);
            }
        }
        public static GO CLONE(GameScenario GS, GO obj, string locId){
            Dictionary<string, string> clonedData = new(obj._data);
            clonedData["ID"] = obj.ID + GO.DELIM + locId + GO.DELIM + GENERATETIMESTAMP();
            clonedData["LABEL"] = obj.LABEL;
            GO clone = new(GS, clonedData, null, null);
            GS.CHANGELOCATION(clone, locId);
            return clone;
        }
        public static GO CREATEGROUP(GameScenario GS, GO obj, string locId){
            Dictionary<string, string> clonedData = new();
            clonedData["ID"] = obj.SIDE + "GROUP" + GO.DELIM + GENERATETIMESTAMP();
            clonedData["DOMAIN"] = "PIECE";
            clonedData["TYPE"] = obj.TYPE;
            clonedData["UNITCATEGORY"] = "SURFACE";
            clonedData["SIDE"] = obj.SIDE;
            clonedData["COUNTRY"] = obj.SIDE == "ALLIES" ? "APW" : "SPW";
            clonedData["GRPTYPE"] = "TFTGGRP";
            GO clone = new(GS, clonedData, null, null);
            clone.UNITTYPE = "TG";
            GS.CHANGELOCATION(clone, locId);
            FS.ADDTOGROUP(obj, clone);
            return clone;
        }
        public static GO CREATEACTIVATIONGROUP(GO obj, string locId){
            GameScenario GS = obj.GS;
            Dictionary<string, string> clonedData = new();
            clonedData["ID"] = obj.SIDE + "ACTGROUP" + GO.DELIM + GENERATETIMESTAMP();
            clonedData["DOMAIN"] = "PIECE";
            clonedData["TYPE"] = obj.TYPE;
            clonedData["UNITCATEGORY"] = obj.UNITCATEGORY;
            clonedData["SIDE"] = obj.SIDE;
            clonedData["COUNTRY"] = obj.SIDE == "ALLIES" ? "APW" : "SPW";
            clonedData["GRPTYPE"] = "ACTIVATIONGRP";
            GO clone = new(GS, clonedData, null, null);
            clone.UNITTYPE = "SHIPGRP";
            GS.CHANGELOCATION(clone, locId);
            FS.ADDTOGROUP(obj, clone);
            return clone;
        }
        public static GO CREATEBASE(GO obj, GO loc){
            GameScenario GS = obj.GS;
            Dictionary<string, string> clonedData = new(obj._data);
            clonedData["ID"] = loc.SIDE + "BASE" + GO.DELIM + (loc.LABEL ?? loc.ID).Replace(' ','_') + GO.DELIM + GENERATETIMESTAMP();
            clonedData["TYPE"] = "FACILITY";
            GO clone = new(GS, clonedData, null, null);
            clone.SIDE = loc.SIDE;
            clone.COUNTRY = loc.COUNTRY;
            clone.LABEL = loc.LABEL;
            clone.CAA = loc.CAA;
            clone.PORT = loc.PORT;
            clone.PORTDAMAGELEVEL = clone.PORT ? loc.PORTDAMAGELEVEL : 4;
            clone.PORTDESTROYED = clone.PORT ? loc.PORTDESTROYED : true;
            clone.AIRFIELD = loc.AIRFIELD;
            clone.AIRFIELDDAMAGELEVEL = clone.AIRFIELD ? loc.AIRFIELDDAMAGELEVEL : 4;
            clone.AIRFIELDDESTROYED = clone.AIRFIELD ? loc.AIRFIELDDESTROYED : true;
            GS.CHANGELOCATION(clone, loc);
            loc.GAMEPIECEID = clone.ID;
            loc.GAMEPIECE = clone;
            GS.ShuffleMarkerToBottom(clone);
            return clone;
        }
        public static void ADDTOGROUP(GO obj, GO group){
            GameScenario GS = obj.GS;
            switch(group.GRPTYPE){
                case "TFTGGRP":
                    obj.GROUPID = group.ID;
                    obj.GROUP = group;
                    obj.GROUPINDEX = 999999;
                    break;
                case "ACTIVATIONGRP":
                    obj.ACTIVATIONGRPID = group.ID;
                    obj.ACTIVATIONGRP = group;
                    obj.GROUPINDEX = 999999;
                    break;
                default:
                    obj.CARRIERID = group.ID;
                    obj.CARRIER = group;
                    break;
            }
            GS.CHANGELOCATION(obj, "TEMP");
            FS.UPDATEGROUP(group);
        }
        public static List<GO> GROUPMEMBERS(GO group){
            GameScenario GS = group.GS;
            return group.GRPTYPE == "TFTGGRP" ? 
                GS.TYPE("SHIP", "GROUPID", group.ID) :
                            group.GRPTYPE == "ACTIVATIONGRP" ? 
                                GS.TYPE("PIECE", "ACTIVATIONGRPID", group.ID) :
                                    group.TEMPLATE?.AIRUNITS != null ?            
                                        GS.TYPE("SQN", "CARRIERID", group.ID) :
                                            new(){group};
        }
        public static void REMOVEGROUP(GO group){
            GROUPMEMBERS(group).ForEach(n => REMOVEFROMGROUP(n, group));    
        } 
        public static void REMOVEFROMGROUP(GO obj, GO group){
            switch(group.GRPTYPE){
                case "TFTGGRP":
                    obj.GROUPID = null;
                    obj.GROUPINDEX = 0;
                    break;
                case "ACTIVATIONGRP":
                    obj.ACTIVATIONGRPID = null;
                    obj.GROUPINDEX = 0;
                    break;
                default:
                    obj.CARRIERID = null;
                    break;
            }
            FS.UPDATEGROUP(group);
        } 
        public static void MOVEUPINGROUP(GameScenario GS, GO obj, GO group){
            obj.GROUPINDEX--;
            GROUPMEMBERS(group).Where(n => n != obj && n.GROUPINDEX == obj.GROUPINDEX).ToList().ForEach(n => n.GROUPINDEX++);
            FS.UPDATEGROUP(group);
        } 
        public static void MOVEDOWNINGROUP(GameScenario GS, GO obj, GO group){
            obj.GROUPINDEX++;
            GROUPMEMBERS(group).Where(n => n != obj && n.GROUPINDEX == obj.GROUPINDEX).ToList().ForEach(n => n.GROUPINDEX--);
            FS.UPDATEGROUP(group);
        } 
        public static void UPDATEGROUP(GO group){
            GameScenario GS = group.GS;
            List<GO> groupMembers = GROUPMEMBERS(group);
            if(group.GRPTYPE == "TFTGGRP"){
                if(groupMembers.Count == 1 && !FS.ADMIN){
                    groupMembers.ForEach(n => GS.CHANGELOCATION(n, group.GAMELOCATION));
                    REMOVEGROUP(group);
                } else if(groupMembers.Any()){
                    string unitType = groupMembers.Where(n => SURFACECOMBATTYPES.Contains(n.UNITTYPE)).Count() > 3 ? "TF" : "TG";
                    if(unitType != group.UNITTYPE || group.TEMPLATEID == null){
                        group.UNITTYPE = unitType;
                        group.TEMPLATEID = group.SIDE + GO.DELIM + unitType;
                    }
                    group.LABEL = group.SIDE + " " + unitType;
                    group.MOVEMENTALLOWANCE = groupMembers.Min(n => n.MOVEMENTALLOWANCE);
                    group.ENROUTEDELAY = groupMembers.Max(n => n.ENROUTEDELAY);
                    group.STRATDETECTED = groupMembers.Where(n => n.STRATDETECTED).Any();
                    group.LOCALDETECTED = groupMembers.Where(n => n.LOCALDETECTED).Any();
                    group.FULLSPEED = groupMembers.Where(n => n.FULLSPEED).Any();
                    group.PCCOONLY = !groupMembers.Where(n => !FS.SHOALTYPES.Contains(n.UNITTYPE)).Any();
                    int index = 0;
                    foreach(GO member in groupMembers.OrderBy(n => n.GROUPINDEX)){
                        member.GROUPINDEX = index;
                        index++;
                        member.ENROUTEDELAY = group.ENROUTEDELAY;
                        member.STRATDETECTED = group.STRATDETECTED;
                        member.LOCALDETECTED = group.LOCALDETECTED;
                        if(member.TEMPLATE.AIRUNITS != null){
                            foreach(GO airunit in GS.TYPE("SQN", "CARRIERID", member.ID)){
                                airunit.ENROUTEDELAY = group.ENROUTEDELAY;
                            }
                        }
                    }
                    if(GRPSHEET.SHEETPARENTPIECE == group){DISPLAYGROUP(GS, group);}
                } else {
                    FS.DISCARDTAGGED(group);
                }
            } else if(group.GRPTYPE == "ACTIVATIONGRP"){
                if(groupMembers.Any()){
                    string unitType = groupMembers.Where(n => n.UNITCATEGORY == "AIR").Any() ? "SQNGRP" : "SHIPGRP";
                    if(unitType != group.UNITTYPE || group.TEMPLATEID == null){
                        group.UNITTYPE = unitType;
                        group.TEMPLATEID = group.SIDE + GO.DELIM + unitType;
                    }
                    group.LABEL = group.SIDE + " " + unitType;
                    group.MOVEMENTALLOWANCE = groupMembers.Min(n => n.MOVEMENTALLOWANCE);
                    group.FULLSPEED = groupMembers.Where(n => n.FULLSPEED).Any();
                    group.PCCOONLY = !groupMembers.Where(n => !FS.SHOALTYPES.Contains(n.UNITTYPE)).Any();
                    int index = 0;
                    foreach(GO member in groupMembers.OrderBy(n => n.GROUPINDEX)){
                        member.GROUPINDEX = index;
                        index++;
                    }
                    if(ACTIVATIONGRPSHEET.SHEETPARENTPIECE == group){DISPLAYGROUP(GS, group);}
                } else {
                    FS.DISCARDTAGGED(group);
                }
            } else {
                foreach(GO member in groupMembers){
                    member.ENROUTEDELAY = group.ENROUTEDELAY;
                }
                if(CVSHEET.SHEETPARENTPIECE == group){DISPLAYGROUP(GS, group);}

            }
        }
        public static GO CREATECONVOY(GO obj, string unitType, string locId){
            GameScenario GS = obj.GS;
            if(obj.TYPE == "SHIP"){
                Dictionary<string, string> clonedData = new(obj._data);
                clonedData["ID"] = obj.SIDE + obj.UNITTYPE + "CONVOY" + GO.DELIM + GENERATETIMESTAMP();
                GO clone = new(GS, clonedData, null, null);
                GS.CHANGELOCATION(clone, locId);
                return clone;
            } else {
                GO template = GS.PIECE(obj.SIDE + "." + unitType);
                Dictionary<string, string> clonedData = new(){
                    {"ID", obj.SIDE + obj.UNITTYPE + "CONVOY" + GO.DELIM + GENERATETIMESTAMP()},
                    {"DOMAIN", GO.DOMAIN_PIECE},
                    {"TYPE", "SHIP"},
                    {"UNITTYPE", template.UNITTYPE},
                    {"UNITCATEGORY", template.UNITCATEGORY},
                    {"TEMPLATEID", template.ID},
                    {"COUNTRY", template.COUNTRY},
                    {"SIDE", obj.SIDE},
                    {"LABEL", template.UNITTYPE + " Convoy"},
                };
                GO clone = new(GS, clonedData, null, null);
                GS.CHANGELOCATION(clone, locId);
                return clone;
            }
        }
        
        public static void DAMAGE(GO obj){
            GameScenario GS = obj.GS;
            if(!obj.DESTROYED && !obj.RECYCLED){
                if(obj.TEMPLATE != null){
                    if(obj.TEMPLATE.REPLACEID != null){
                        GO newTemplate = GS.PIECE(obj.TEMPLATE.REPLACEID);
                        obj.TEMPLATEID = newTemplate.ID;
                        obj.TEMPLATE = newTemplate;
                        obj.DAMAGED = true;
                    } else {
                        DESTROY(obj);
                    }
                } else {
                    DESTROY(obj);
                }
            }
        }
        public static void DESTROY(GO obj){
            GameScenario GS = obj.GS;
            if(!obj.DESTROYED && !obj.RECYCLED){
                if(new List<string>{"APW", "SPW"}.Contains(obj.COUNTRY)){
                    DISCARDTAGGED(obj);
                } else {
                    //immediately destroy any aircraft aboard
                    if(obj.TEMPLATE?.AIRUNITS != null){
                        FS.GROUPMEMBERS(obj).ForEach(DESTROY);
                    }
                    GS.CHANGELOCATION(obj, "ALLDESTROYED");
                    obj.DESTROYED = true;
                    REMOVETAGGED(GS, obj);
                    GO group = LOGICALPARENT(obj);
                    if(group != obj){
                        REMOVEFROMGROUP(obj, group);
                    }
                }
            }
            GS.REMOVEINTERACTIVE(obj);
            obj.ACTIVATIONGRPID = null;
            obj.ADMINDETECTED = false;
            obj.AIRMISSION = null;
            obj.CARRIERID = null;
            obj.DAMAGED = false;
            obj.DOCKED = false;
            obj.DONE = false;
            obj.ENROUTEDELAY = 0;
            obj.EXPANSION = false;
            obj.GAMEPIECEID = null;
            obj.GROUPID = null;
            obj.GROUPINDEX = 0;
            obj.HOMEBASEID = null;
            obj.LOCALDETECTED = false;
            obj.MUSTRETREAT = false;
            obj.RECYCLED = false;
            obj.REPLENISHING = false;
            obj.STRATDETECTED = false;
            obj.TACCOORDPIECEID = null;
            obj.DESTINATIONPIECEID = null;
            obj.SIDE = null;
        }
        public static void DAMAGEBASE(GO obj, string baseTarget){
            GameScenario GS = obj.GS;
            if(baseTarget == "AIRFIELD"){
                if(!obj.AIRFIELDDESTROYED){
                    obj.AIRFIELDDAMAGELEVEL++;
                    obj.GAMEPIECE.AIRFIELDDAMAGELEVEL++;
                    if(obj.AIRFIELDDAMAGELEVEL >= 4){
                        DESTROYBASE(obj, baseTarget);
                    }
                }
            } else {
                if(!obj.PORTDESTROYED){
                    obj.PORTDAMAGELEVEL++;
                    obj.GAMEPIECE.PORTDAMAGELEVEL++;
                    if(obj.PORTDAMAGELEVEL >= 4){
                        DESTROYBASE(obj, baseTarget);
                    }
                }
            }
        }
        public static void DESTROYBASE(GO obj, string baseTarget){
            GameScenario GS = obj.GS;
            if(baseTarget == "AIRFIELD"){
                if(!obj.AIRFIELDDESTROYED){
                    obj.AIRFIELDDAMAGELEVEL = 4;
                    obj.AIRFIELDDESTROYED = true;
                    obj.GAMEPIECE.AIRFIELDDAMAGELEVEL = 4;
                    obj.GAMEPIECE.AIRFIELDDESTROYED = true;
                    //destroy any aircraft currently on it
                    foreach(GO sqn in FS.TYPESIDELOCATION(GS, "SQN", obj.SIDE, obj.GAMELOCATIONID).Where(n => !FS.ISGROUP(n))){
                        FS.DESTROY(sqn);
                    }
                }
            } else {
                if(!obj.PORTDESTROYED){
                    obj.PORTDAMAGELEVEL = 4;
                    obj.PORTDESTROYED = true;
                    obj.GAMEPIECE.PORTDAMAGELEVEL = 4;
                    obj.GAMEPIECE.PORTDESTROYED = true;
                }
            }
        }
        public static void DISCARDTAGGED(GO obj){
            REMOVETAGGED(obj.GS, obj);
            obj.GS.DISCARD(obj);
        }
        public static void REPAIR(GO obj){
            if(obj.DOMAIN == GO.DOMAIN_LOCATION){
                if(!obj.PORTDESTROYED){
                    obj.PORTDAMAGELEVEL = Math.Max(0, obj.PORTDAMAGELEVEL - 1);
                    obj.GAMEPIECE.PORTDAMAGELEVEL = Math.Max(0, obj.PORTDAMAGELEVEL - 1);
                }
                if(!obj.AIRFIELDDESTROYED){
                    obj.AIRFIELDDAMAGELEVEL = Math.Max(0, obj.AIRFIELDDAMAGELEVEL - 1);
                    obj.GAMEPIECE.AIRFIELDDAMAGELEVEL = Math.Max(0, obj.AIRFIELDDAMAGELEVEL - 1);
                }
            } else if(!obj.DESTROYED && !obj.RECYCLED){
                if(obj.TEMPLATE != null){
                    if(obj.TEMPLATE.REPLACEID == null){
                        GO newTemplate = obj.GS.PIECE(obj.TEMPLATEID.Replace(".DMG", ""));
                        obj.TEMPLATEID = newTemplate.ID;
                        obj.TEMPLATE = newTemplate;
                        obj.DAMAGED = false;
                    }
                }
            }
        }
        public static GO PARENTGROUPLOCATION(GO obj){
            return LOCATIONPARENT(obj).GAMELOCATION;
        }
        public static GO LOCATIONPARENT(GO obj){
            GO objAtLocation = obj;
            objAtLocation = objAtLocation.CARRIERID != null ? objAtLocation.CARRIER : objAtLocation;
            objAtLocation = objAtLocation.ACTIVATIONGRPID != null ? objAtLocation.ACTIVATIONGRP : objAtLocation;
            objAtLocation = objAtLocation.GROUPID != null ? objAtLocation.GROUP : objAtLocation;
            return objAtLocation;
        }
        public static GO LOGICALPARENT(GO obj){
            if(obj.CARRIERID != null){return obj.CARRIER;}
            if(obj.ACTIVATIONGRPID != null){return obj.ACTIVATIONGRP;}
            if(obj.GROUPID != null){return obj.GROUP;}
            return obj;
        }
        public static string WEATHER(GameScenario GS, string zone){
            return GS.Get(zone + ".WEATHER");
        }
        public static string WEATHER(GO location){
            return WEATHER(location.GS, location.ZONE);
        }
        public static bool STORM(GameScenario GS, string zone){
            return WEATHER(GS, zone) == "STORM";
        }
        public static bool STORM(GO location){
            return STORM(location.GS, location.ZONE);
        }
        public static Dictionary<GO, List<List<GO>>> DETECTIONRADIUSTABLE(GameScenario GS){
            List<string> STORMZONES = ZONECONNECTIONS.Keys.Where(n => STORM(GS, n)).ToList();
            List<string> SQUALLZONES = ZONECONNECTIONS.Keys.Where(n => WEATHER(GS, n) == "SQUALL").ToList();
            Dictionary<GO, List<List<GO>>> DetectionRadius = new();
            foreach(string s in FS.SIDE_NAMES){
                foreach(GO obj in FS.TYPESIDE(GS, "SHIP", s).Where(n => !FS.ISGROUP(n))){
                    GO loc = FS.PARENTGROUPLOCATION(obj);
                    if(loc.TYPE == "HEX"){
                        if(obj.UNITCATEGORY == "SURFACE" && STORMZONES.Contains(loc.ZONE)){continue;}
                        List<GO> r1 = FS.FINDAIRRADIUS(loc, 1);
                        List<GO> r2 = FS.FINDAIRRADIUS(loc, 2);
                        if(obj.UNITCATEGORY == "SURFACE"){
                            r1.RemoveAll(n => STORMZONES.Contains(n.ZONE));
                            r2.RemoveAll(n => STORMZONES.Contains(n.ZONE));
                        }
                        List<GO> SubRadius = new(r1);
                        List<GO> SurfaceRadius = SQUALLZONES.Contains(loc.ZONE) || obj.UNITCATEGORY == "SUB" ? new(r1) : new(r2);
                        DetectionRadius.Add(obj, new(){SurfaceRadius, SubRadius});
                    }
                }
            }
            return DetectionRadius;
        }
        public static string SUBDETECTIONRESULT(GO obj, string phase, string combat, List<GO> detectors){
            string result = "";
            double noise = obj.TEMPLATE.NOISELEVEL;
            int modifier = 0;
            if(obj.DEEPMODE){modifier += 2;}
            if(obj.GAMELOCATION.FJORD || obj.GAMELOCATION.RESTRICTED || (obj.GAMELOCATION.SHALLOW && obj.UNITTYPE != "SS")){modifier -= 3;}
            if(phase == "STRATRECON"){
                double totalASW = detectors.Sum(n => n.ASW);
                if(totalASW >= 8){modifier -= 3;}
                else if(totalASW >= 6){modifier -=2;}
                else if(totalASW >= 4){modifier -=1;}            
            } else {
                double totalASW = detectors.Sum(n => n.TEMPLATE.ASW);
                if(combat != null){
                    if(obj.UNITTYPE == "SS" || combat == "CM" || combat == "SSM"){modifier -= 4;}
                    else{modifier -= 2;}
                }
                if(totalASW >= 26){modifier -= 3;}
                else if(totalASW >= 18){modifier -=2;}
                else if(totalASW >= 10){modifier -=1;}            
            }
            double roll = FS.DIEROLL() + modifier;
            if(roll <= noise){ result = "D"; }
            return result;
        }
        public static int COMBATRESULTSTABLE(bool attack, int roll, int combatValue){
            if(combatValue == 0){return 0;}
            List<int> D = new(){-99,-99,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10,11,12};
            List<int> A = new(){-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10,11,12,13};
            List<int> CV = new (){1,2,3,4,5,6,7,10,14,19,25,32,42,53,64,76,90};
            int[] TABLE = new int[]
            {   0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,
                0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,
                0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,
                0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,
                0,0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,
                0,0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,
                0,0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,
                0,0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,
                0,0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,
                0,0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,
                0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,
                0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,
                0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,
                0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,
                0,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,
                1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,
                1,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,11
                };
            roll = attack ? Math.Max(-7, Math.Min(13, roll)) : Math.Max(-6, Math.Min(12, roll));
            int row = attack ? A.IndexOf(roll) : D.IndexOf(roll);
            int column = CV.IndexOf(CV.Where(n => combatValue <= n).First());
            int tableIndex = column * D.Count + row;
            return TABLE[tableIndex];
        }
        public static void ADVANCESIDE(GamePhase gamePhase, string side){
            GameScenario GS = gamePhase.GS;
            if(side == GS.Get("SIDE1")){
                GS.advanced = true;
                GS.Set("ACTIVE.SIDE", FS.ENEMY(side));
                GS.ResetBetweenUpdates();
                GS.ResetBetweenPhases();
                gamePhase.Start(true);
            } else {
                GS.Set("SIDE1", side);
                GS.Advance(gamePhase);
            }
        }
        private static bool CANLAUNCH(GameScenario GS, GO obj){
            if(!FS.SIDE_NAMES.Contains(obj.SIDE)){return false;}
            if(obj.ENROUTEDELAY > 0){return false;}
            if(obj.AIRMISSION != null){return false;}
            //damaged airfield
            if(obj.GAMELOCATION.AIRFIELDDAMAGELEVEL > 0){return false;}
            //check location is in a valid zone
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            if(locationToCheck.TYPE == "ENROUTE"){return false;}
            if(locationToCheck.ZONE == null){return false;}
            if(!ZONECONNECTIONS.ContainsKey(locationToCheck.ZONE)){return false;}
            //check weather
            if(STORM(locationToCheck)){return false;}                                        
            return true;
        }
        public static Dictionary<string, List<string>> MISSIONELIGIBILITY = new(){
            {"INT", new(){"STRATRECON", "STRATINTERCEPTION"}},
            {"ATK", new(){"STRATRECON"}},
            {"BMB", new(){"STRATRECON", "STRATMINING"}},
            {"RCN", new(){"STRATRECON", "STRATTACCOORD", "STRATMINING"}},
            {"EW", new(){"STRATINTERCEPTION"}},
            {"AEW", new(){"STRATRECON"}},
            {"AR", new()},
            {"MSW", new()}
        };
        public static bool CANLAUNCHSTRATEGIC(GameScenario GS, GO obj){
            if(!FS.MISSIONELIGIBILITY[obj.UNITTYPE].Any()){return false;}
            return CANLAUNCH(GS, obj);
        }
        public static bool CANLAUNCHCAP(GameScenario GS, GO obj){
            if(!new List<string>(){"INT", "AEW", "EW"}.Contains(obj.UNITTYPE)){return false;}
            return CANLAUNCH(GS, obj);
        }
        public static bool CANLAUNCHACTIVATE(GameScenario GS, GO obj){
            if(obj.DONE){return false;}
            //docked carrier
            if(obj.HOMEBASE?.DOCKED == true || obj.HOMEBASE?.REPLENISHING == true){return false;}
            if(obj.CARRIER?.DOCKED == true || obj.CARRIER?.REPLENISHING == true){return false;}
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            //check weather
            if(GS.Get(locationToCheck.ZONE + ".WEATHER") == "SQUALL"){return false;} 
            //no fjord
            if(locationToCheck.FJORD){return false;}
            return CANLAUNCH(GS, obj);
        }
        public static bool CANSHIPACTIVATE(GameScenario GS, GO obj){
            if(!FS.SIDE_NAMES.Contains(obj.SIDE)){return false;}
            if(obj.DONE){return false;}
            if(obj.REPLENISHING || obj.ENROUTEDELAY > 0){return false;}
            GO locationToCheck = PARENTGROUPLOCATION(obj);
            if(locationToCheck.TYPE == "ENROUTE"){return false;}
            if(locationToCheck.ZONE == null){return false;}
            if(!ZONECONNECTIONS.ContainsKey(locationToCheck.ZONE)){return false;}
            return true;
        }
        public static List<GO> CAPSQNS(GameScenario GS, string side){
            List<GO> returnList = new();
            if(side == null){
                returnList.AddRange(GS.TYPE("SQN").Where(n => n.SIDE != null && n.AIRMISSION == "CAP"));
            } else {
                returnList.AddRange(FS.TYPESIDE(GS, "SQN", side).Where(n => n.AIRMISSION == "CAP"));            
            }
            returnList.RemoveAll(STORM);
            return returnList;
        }
        public static List<GO> ACTIVATIONMARKERS(GameScenario GS, string side){
            List<GO> returnList = new();
            if(side == null){
                returnList.AddRange(GS.TYPE("ACTIVATIONGRP").Where(n => n.GAMELOCATION != null));
            } else {
                returnList.AddRange(FS.TYPESIDE(GS, "ACTIVATIONGRP", side).Where(n => n.GAMELOCATION != null));            
            }
            return returnList;
        }
        public static void CLEARDESTINATIONS(GameScenario GS){
            foreach(GO obj in GS.TYPE("DESTINATION").Where(n => n.GAMEPIECE != null)){
                if(obj.GAMEPIECE.SIDE == null){
                    obj.GAMEPIECE.DESTINATIONPIECEID = null;
                    obj.GAMEPIECEID = null;
                    GS.DISCARD(obj);
                }
            }
        }
        public static int GETAIRMOVEMENTDISTANCE(List<FSMovement> movementPath){
            return movementPath.Any() ? movementPath.Where(n => n.MOVEMENTCONNECTOR != null).Sum(n => Math.Max(n.MOVEMENTCONNECTOR.DISTANCE, 1)) : 999999999;
        }
        public static List<GO> GETTAGGEDUNITS(GameScenario GS, string variable){
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            return currentObjIds.Select(n => GS.TYPE("PIECE","ID",n).First()).ToList();
        }
        public static List<GO> GETTAGGEDLOCATIONS(GameScenario GS, string variable){
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            return currentObjIds.Select(n => GS.TYPE("LOCATION","ID",n).First()).ToList();
        }
        public static List<GO> GETTAGGEDLOGICS(GameScenario GS, string variable){
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            return currentObjIds.Select(n => GS.TYPE("LOGIC","ID",n).First()).ToList();
        }
        public static void SETTAGGED(GameScenario GS, string variable, List<GO> objs){
            SETTAGGEDSTRINGS(GS, variable, objs.Select(n => n.ID).ToList());
        }
        public static void SETTAGGEDSTRINGS(GameScenario GS, string variable, List<string> objs){
            GS.Set(variable, string.Join('|', objs.Distinct()));
        }
        public static void CLEARTAGGED(GameScenario GS, string variable){
            GS.Set(variable, null);
        }
        public static void REMOVETAGGED(GameScenario GS, string variable, GO obj){
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            currentObjIds.Remove(obj.ID);
            SETTAGGEDSTRINGS(GS, variable, currentObjIds);
        }
        public static void REMOVETAGGED(GameScenario GS, GO obj){
            foreach(string variable in GS.data._data.Keys.Where(n => n.Contains("ACTION."))){
                string value = GS.Get(variable);
                if(value != null && value.Contains(obj.ID)){
                    REMOVETAGGED(GS, variable, obj);
                }
            }
        }
        public static void ADDTAGGED(GameScenario GS, string variable, GO obj){
            string value = GS.Get(variable);
            List<string> currentObjIds = value != null ? value.Split('|').ToList() : new();
            currentObjIds.Add(obj.ID);
            SETTAGGEDSTRINGS(GS, variable, currentObjIds);
        }
        public static void GETNEXTSELECTED(GameScenario GS){
            GS.SelectedMarker ??= FS.GETTAGGEDUNITS(GS, "ACTION.NEXTSELECTED").FirstOrDefault();
            if(GS.SelectedMarker == null || !GS.InteractionMap.ContainsKey(GS.SelectedMarker)){
                if(GS.InteractionMap.Any()){
                    GS.SelectedMarker = GS.InteractionMap.Keys.First();
                } else {
                    GS.SelectedMarker = null;
                }
            }
            FS.CLEARTAGGED(GS, "ACTION.NEXTSELECTED");
        }
        public static void SETNEXTSELECTED(GO obj){
            if(obj != null){
                SETTAGGED(obj.GS, "ACTION.NEXTSELECTED", new List<GO>{obj});
            }
        }
        public static void RETURNTOHOMEBASE(GO obj){
            if(obj.HOMEBASE.DOMAIN == GO.DOMAIN_PIECE){
                GO carrier = obj.HOMEBASE;
                if(carrier.DESTROYED){
                    FS.DESTROY(obj);
                } else {
                    FS.ADDTOGROUP(obj, carrier);
                }
            } else {
                obj.GS.CHANGELOCATION(obj, obj.HOMEBASE);
            }
            obj.HOMEBASEID = null;
        }
        public static Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> ATTACKDATA(List<GO> objs){
            Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> data = new();
            foreach(GO obj in objs){
                Dictionary<string, Dictionary<string, Dictionary<string, double>>> obj_data = new();
                //SSM
                Dictionary<string, Dictionary<string, double>> ssm = SSMDATA(obj);
                Dictionary<string, Dictionary<string, double>> ssm2 = SSM2DATA(obj);
                Dictionary<string, Dictionary<string, double>> ssmaaa = SSMAAADATA(obj);
                Dictionary<string, Dictionary<string, double>> cc = CLOSECOMBATDATA(obj, false);
                Dictionary<string, Dictionary<string, double>> defcc = CLOSECOMBATDATA(obj, true);
                Dictionary<string, Dictionary<string, double>> bomb = BOMBDATA(obj);
                Dictionary<string, Dictionary<string, double>> cm = CMDATA(obj);
                Dictionary<string, Dictionary<string, double>> asw = ASWDATA(obj, false);
                Dictionary<string, Dictionary<string, double>> defasw = ASWDATA(obj, true);
                Dictionary<string, Dictionary<string, double>> torp = TORPDATA(obj);
                if(ssm.Any() || ssm2.Any() || ssmaaa.Any()){
                    obj_data.Add("SSM", new());
                    ssm.ToList().ForEach(n => obj_data["SSM"].Add(n.Key, n.Value));
                    ssm2.ToList().ForEach(n => obj_data["SSM"].Add(n.Key, n.Value));
                    ssmaaa.ToList().ForEach(n => obj_data["SSM"].Add(n.Key, n.Value));
                }
                if(cc.Any()){
                    obj_data.Add("CC", new());
                    cc.ToList().ForEach(n => obj_data["CC"].Add(n.Key, n.Value));
                }
                if(defcc.Any()){
                    obj_data.Add("DEF CC", new());
                    defcc.ToList().ForEach(n => obj_data["DEF CC"].Add(n.Key, n.Value));
                }
                if(bomb.Any()){
                    obj_data.Add("BOMB", new());
                    bomb.ToList().ForEach(n => obj_data["BOMB"].Add(n.Key, n.Value));
                }
                if(cm.Any()){
                    obj_data.Add("CM", new());
                    cm.ToList().ForEach(n => obj_data["CM"].Add(n.Key, n.Value));
                }
                if(asw.Any()){
                    obj_data.Add("ASW", new());
                    asw.ToList().ForEach(n => obj_data["ASW"].Add(n.Key, n.Value));
                }
                if(defasw.Any()){
                    obj_data.Add("DEF ASW", new());
                    asw.ToList().ForEach(n => obj_data["DEF ASW"].Add(n.Key, n.Value));
                }
                if(torp.Any()){
                    obj_data.Add("TORP", new());
                    torp.ToList().ForEach(n => obj_data["TORP"].Add(n.Key, n.Value));
                }
                if(obj_data.Any()){
                    data.Add(obj, obj_data);
                }
            }
            return data;
        }
        public static double GETAIRCAA(GO obj){
            GameScenario GS = obj.GS;
            double templateCAA = obj.TEMPLATE.CAA;
            if(GS.GetBoolean("TURN.DARKNESS") && !obj.NIGHTAA){
                templateCAA = Math.Max(1, templateCAA - 2);
            }
            if(obj.ROLE == "FIGHTER" || obj.UNITTYPE != "INT" || (obj.UNITTYPE == "INT" && obj.ROLE == null)){
                return templateCAA;
            } else if(obj.ROLE == "BOMBER"){
                return 1;
            } else {
                return Math.Floor(templateCAA * 0.5);
            }
        }
        public static double GETAIRSSM(GO obj){
            if(obj.ROLE == "BOMBER" || obj.UNITTYPE != "INT"){
                return obj.TEMPLATE.SSM;
            } else if(obj.ROLE == "FIGHTER"){
                return 0;
            } else { //FIGHTER-BOMBER
                return Math.Floor(obj.TEMPLATE.SSM * 0.5);
            }
        }
        public static double GETAIRBOMB(GO obj){
            if(obj.ROLE == "BOMBER" || obj.UNITTYPE != "INT"){
                return obj.TEMPLATE.SPECIAL;
            } else if(obj.ROLE == "FIGHTER"){
                return 0;
            } else { //FIGHTER-BOMBER
                return Math.Floor(obj.TEMPLATE.SPECIAL * 0.5);
            }
        }
        public static double GETSUBTORP(GO obj){
            if(obj.DEEPMODE){
                return Math.Floor(obj.TEMPLATE.SPECIAL * 0.5);
            } else {
                return obj.TEMPLATE.SPECIAL;
            }
        }

        private static Dictionary<string, Dictionary<string, double>> SSMDATA(GO obj){
            Dictionary<string, Dictionary<string, double>> data = new();
            if(obj.TEMPLATE.SSM > 0 && !obj.DOCKED && !obj.DEEPMODE){
                if(obj.UNITTYPE == "PC"){
                    //normal SSM only
                    data.Add("SSM", new());
                    data["SSM"].Add("PTS", obj.TEMPLATE.SSM);
                    data["SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                    data["SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                    data["SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                } else if(obj.TYPE == "SHIP" && obj.SSMPTS > 0){
                    //normal SSM
                    data.Add("SSM", new());
                    data["SSM"].Add("PTS", obj.TEMPLATE.SSM);
                    data["SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                    data["SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                    data["SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                    if(obj.SSMPTS >= 2 && obj.UNITCATEGORY == "SURFACE"){
                        //intensive SSM
                        data.Add("INTENSIVE SSM", new());
                        data["INTENSIVE SSM"].Add("PTS", Math.Floor(obj.TEMPLATE.SSM * 1.5));
                        data["INTENSIVE SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                        data["INTENSIVE SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                        data["INTENSIVE SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        if(obj.SSMPTS >= 3){
                            //maximum SSM
                            data.Add("MAXIMUM SSM", new());
                            data["MAXIMUM SSM"].Add("PTS", obj.TEMPLATE.SSM * 2);
                            data["MAXIMUM SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                            data["MAXIMUM SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                            data["MAXIMUM SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        }
                    }
                } else if(obj.TYPE == "SQN"){
                    if(!obj.LIMITEDSSM){
                        //normal SSM
                        data.Add("SSM", new());
                        data["SSM"].Add("PTS", GETAIRSSM(obj));
                        data["SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                        data["SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                        data["SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                    } else if(obj.HOMEBASE.AIRSSMPTS >= obj.TEMPLATE.AIRSSMCOST && GETAIRSSM(obj) > 0){
                        //normal SSM
                        data.Add("LIMITED SSM", new());
                        data["LIMITED SSM"].Add("PTS", GETAIRSSM(obj));
                        data["LIMITED SSM"].Add("RANGE", obj.TEMPLATE.SSMRANGE);
                        data["LIMITED SSM"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                        data["LIMITED SSM"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                    }
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> SSM2DATA(GO obj){
            Dictionary<string, Dictionary<string, double>> data = new();
            if(obj.TEMPLATE.SSM2 > 0 && !obj.DOCKED && !obj.DEEPMODE){
                if(obj.TYPE == "SHIP" && obj.SSM2PTS > 0){
                    //normal SSM2
                    data.Add("SSM2", new());
                    data["SSM2"].Add("PTS", obj.TEMPLATE.SSM2);
                    data["SSM2"].Add("RANGE", obj.TEMPLATE.SSM2RANGE);
                    data["SSM2"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                    data["SSM2"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                    if(obj.SSM2PTS >= 2 && obj.UNITCATEGORY == "SURFACE"){
                        //intensive SSM2
                        data.Add("INTENSIVE SSM2", new());
                        data["INTENSIVE SSM2"].Add("PTS", Math.Floor(obj.TEMPLATE.SSM2 * 1.5));
                        data["INTENSIVE SSM2"].Add("RANGE", obj.TEMPLATE.SSM2RANGE);
                        data["INTENSIVE SSM2"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                        data["INTENSIVE SSM2"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        if(obj.SSM2PTS >= 3){
                            //maximum SSM2
                            data.Add("MAXIMUM SSM2", new());
                            data["MAXIMUM SSM2"].Add("PTS", obj.TEMPLATE.SSM2 * 2);
                            data["MAXIMUM SSM2"].Add("RANGE", obj.TEMPLATE.SSM2RANGE);
                            data["MAXIMUM SSM2"].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                            data["MAXIMUM SSM2"].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                        }
                    }
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> SSMAAADATA(GO obj){
            Dictionary<string, Dictionary<string, double>> data = new();
            if(obj.COUNTRY == "USA" && obj.TEMPLATE.AAA > 0 && !obj.DOCKED){
                if(obj.TYPE == "SHIP" && obj.AAPTS > 0){
                    //normal SSM
                    data.Add("AAA AS SSM", new());
                    data["AAA AS SSM"].Add("PTS", 4);
                    data["AAA AS SSM"].Add("RANGE", 1);
                    data["AAA AS SSM"].Add("FAST", 1);
                    data["AAA AS SSM"].Add("SEASKIMMER", 0);
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> CLOSECOMBATDATA(GO obj, bool defense){
            string key = defense ? "DEF CC" : !obj.DOCKED ? "CC" : null;
            Dictionary<string, Dictionary<string, double>> data = new();
            if(key != null){
                if(obj.TEMPLATE.SPECIAL > 0){
                    if(obj.UNITTYPE == "PC"){
                        data.Add(key, new());
                        data[key].Add("PTS", obj.TEMPLATE.SPECIAL);
                        data[key].Add("RANGE", 1);
                        data[key].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                        data[key].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                    } else if(obj.UNITCATEGORY == "SURFACE"){
                        if(obj.SSMPTS > 0){
                            //normal SSM
                            data.Add(key, new());
                            data[key].Add("PTS", obj.TEMPLATE.SPECIAL);
                            data[key].Add("RANGE", 1);
                            data[key].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                            data[key].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                            if(obj.SSMPTS >= 2){
                                //intensive SSM
                                data.Add("INTENSIVE " + key, new());
                                data["INTENSIVE " + key].Add("PTS", Math.Floor(obj.TEMPLATE.SSM * 1.5));
                                data["INTENSIVE " + key].Add("RANGE", 1);
                                data["INTENSIVE " + key].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                                data["INTENSIVE " + key].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                                if(obj.SSMPTS >= 3){
                                    //maximum SSM
                                    data.Add("MAXIMUM " + key, new());
                                    data["MAXIMUM " + key].Add("PTS", obj.TEMPLATE.SSM * 2);
                                    data["MAXIMUM " + key].Add("RANGE", 1);
                                    data["MAXIMUM " + key].Add("FAST", obj.TEMPLATE.FASTSSM ? 1 : 0);
                                    data["MAXIMUM " + key].Add("SEASKIMMER", obj.TEMPLATE.SEASKIMMERSSM ? 1 : 0);
                                }
                            }
                        }
                        if(obj.TEMPLATE.SPECIAL - obj.TEMPLATE.SSM > 0){
                            data.Add("NO SSM " + key, new());
                            data["NO SSM " + key].Add("PTS", obj.TEMPLATE.SPECIAL - obj.TEMPLATE.SPECIAL);
                            data["NO SSM " + key].Add("RANGE", 1);
                            data["NO SSM " + key].Add("FAST", 0);
                            data["NO SSM " + key].Add("SEASKIMMER", 0);
                        }
                    }
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> BOMBDATA(GO obj){
            Dictionary<string, Dictionary<string, double>> data = new();
            if(obj.TYPE == "SQN" && !obj.DOCKED){
                if(GETAIRBOMB(obj) > 0 && (obj.HOMEBASE.AIRFIELD || obj.HOMEBASE.BOMBPTS > 0)){
                    //normal SSM
                    data.Add("BOMB", new());
                    data["BOMB"].Add("PTS", GETAIRBOMB(obj));
                    data["BOMB"].Add("RANGE", 0);
                    data["BOMB"].Add("FAST", 0);
                    data["BOMB"].Add("SEASKIMMER", 0);
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> CMDATA(GO obj){
            Dictionary<string, Dictionary<string, double>> data = new();
            if(obj.TEMPLATE.CM > 0 && !obj.DOCKED && !obj.DEEPMODE){
                if(obj.CMPTS > 0){
                    //normal CM
                    data.Add("CM", new());
                    data["CM"].Add("PTS", obj.TEMPLATE.CM);
                    data["CM"].Add("RANGE", obj.TEMPLATE.CMRANGE);
                    data["CM"].Add("FAST", 0);
                    data["CM"].Add("SEASKIMMER", 0);
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> ASWDATA(GO obj, bool defense){
            Dictionary<string, Dictionary<string, double>> data = new();
            if(obj.TEMPLATE.ASW > 0){
                if(obj.ASWPTS > 0 || (obj.UNITCATEGORY == "AIR" && !defense)){
                    if(defense){
                        //defensive ASW
                        data.Add("DEF ASW", new());
                        data["DEF ASW"].Add("PTS", obj.TEMPLATE.ASW);
                        data["DEF ASW"].Add("RANGE", 0);
                        data["DEF ASW"].Add("FAST", 0);
                        data["DEF ASW"].Add("SEASKIMMER", 0);
                    } else if(!obj.DOCKED) {
                        //normal ASW
                        data.Add("ASW", new());
                        data["ASW"].Add("PTS", obj.TEMPLATE.ASW);
                        data["ASW"].Add("RANGE", obj.UNITCATEGORY == "AIR" ? 0 : 1);
                        data["ASW"].Add("FAST", 0);
                        data["ASW"].Add("SEASKIMMER", 0);
                    }
                }
            }
            return data;
        }
        private static Dictionary<string, Dictionary<string, double>> TORPDATA(GO obj){
            Dictionary<string, Dictionary<string, double>> data = new();
            if(obj.UNITCATEGORY == "SUB" && FS.GETSUBTORP(obj) > 0 && !obj.DOCKED){
                if(obj.TORPPTS > 0){
                    //normal
                    data.Add("TORP", new());
                    data["TORP"].Add("PTS", FS.GETSUBTORP(obj));
                    data["TORP"].Add("RANGE", 0);
                    data["TORP"].Add("FAST", 0);
                    data["TORP"].Add("SEASKIMMER", 0);
                }
            }
            return data;
        }
        public static List<GO> ALLSHIPSINHEX(string side, GO loc, bool surface, bool sub){
            List<string> unitcategories = new();
            if(surface){unitcategories.Add("SURFACE");}
            if(sub){unitcategories.Add("SUB");}
            List<GO> returnlist = new();
            foreach(GO obj in FS.TYPESIDELOCATION(loc.GS, "SHIP", side, loc.ID).Where(n => n.ENROUTEDELAY == 0 && unitcategories.Contains(n.UNITCATEGORY))){
                if(FS.ISGROUP(obj)){
                    foreach(GO gm in GROUPMEMBERS(obj)){
                        returnlist.Add(gm);
                    }
                } else {
                    returnlist.Add(obj);
                }
            }
            return returnlist;
        }
        public static void LOCALDETECT(List<GO> objs, bool detect){
            List<GO> grps = objs.Where(ISGROUP).ToList();
            foreach(GO obj in objs.Where(n => !FS.ISGROUP(n))){
                obj.LOCALDETECTED = detect;
                if(obj.GROUP != null){grps.Add(obj.GROUP);}
            }
            foreach(GO obj in grps.Distinct()){
                FS.UPDATEGROUP(obj);
            }
        }
        public static void STRATDETECT(List<GO> objs, bool detect){
            List<GO> grps = objs.Where(ISGROUP).ToList();
            foreach(GO obj in objs.Where(n => !FS.ISGROUP(n))){
                obj.STRATDETECTED = detect;
                if(detect){
                    obj.LOCALDETECTED = detect;
                }
                if(obj.GROUP != null){grps.Add(obj.GROUP);}
            }
            foreach(GO obj in grps.Distinct()){
                FS.UPDATEGROUP(obj);
            }
        }
        public static List<GO> GROUPSANDMEMBERS(List<GO> objs){
            List<GO> returnList = new();
            foreach(GO obj in objs){
                returnList.Add(obj);
                if(ISGROUP(obj)){returnList.AddRange(GROUPMEMBERS(obj));}
            }
            return returnList;
        }
        public static List<GO> SSMTARGETS(GO attackingUnit, GO destinationMarker, List<GO> ENEMYUNITS){
            GameScenario GS = attackingUnit.GS;
            GO attackLoc = destinationMarker.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = ATTACKDATA(groupMembers);
            double maxRange = 0;
            foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                if(attackData[obj].ContainsKey("SSM")){
                    maxRange = Math.Max(maxRange, attackData[obj]["SSM"].Values.Max(n=> n["RANGE"]));
                }
            }
            List<GO> ssmRadius = maxRange == 0 ? new(){attackLoc} : FS.FINDAIRRADIUS(attackLoc, (int)maxRange).Where(n => n.TYPE == "HEX").ToList();
            ssmRadius.RemoveAll(STORM);
            foreach(GO obj in ENEMYUNITS.Where(n => 
                ssmRadius.Contains(n.GAMELOCATION))){

                if(attackingUnit.UNITCATEGORY == "AIR" || obj.GAMELOCATION == attackLoc){
                    TARGETS.Add(obj);
                } else {
                    //calculate straight line, confirm it doesn't cross blocked or land hexside nor travels through restricted
                    List<FSMovement> ssmPath = FS.FINDSSMDIRECTPATH(attackLoc, obj.GAMELOCATION);
                    if(!ssmPath.Any()){continue;}
                    if(ssmPath.Where(n => n != ssmPath.First() && n != ssmPath.Last() && n.MOVEMENTLOCATION.RESTRICTED).Any()){continue;}
                    TARGETS.Add(obj);
                }
            }
            return TARGETS;
        }
        public static List<GO> CMTARGETS(GO attackingUnit, GO destinationMarker, List<GO> ENEMYUNITS){
            GO attackLoc = destinationMarker.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = FS.ATTACKDATA(groupMembers);
            double maxRange = 0;
            foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                if(attackData[obj].ContainsKey("CM")){
                    maxRange = Math.Max(maxRange, attackData[obj]["CM"].Values.Max(n=> n["RANGE"]));
                }
            }
            foreach(GO obj in ENEMYUNITS){
                //straight line distance first.  if more than 150% immediate no, less than 90% immediate yes, otherwise calculate
                GO from = obj.GAMELOCATION;
                GO to = attackLoc;
                double x1 = to.x;
                //map wrap around
                double distance1 = attackingUnit.GS.GetDistance(from, x1, to.y) / FS.HEXDISTANCE;
                if(distance1 >= (maxRange * 1.5)){
                    continue;
                } else if(distance1 <= maxRange * 0.9){
                    TARGETS.Add(obj);
                } else {
                    List<FSMovement> path = FS.FINDAIRMOVEMENTDIRECTPATH(obj.GAMELOCATION, attackLoc, (int)maxRange);
                    if(path.Any()){
                        TARGETS.Add(obj);
                    }
                }
            }
            return TARGETS;
        }
        public static List<GO> ASWTARGETS(GO attackingUnit, GO destinationMarker, List<GO> ENEMYUNITS){
            GameScenario GS = attackingUnit.GS;
            GO attackLoc = destinationMarker.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            string actionType = attackingUnit.UNITCATEGORY;
            List<GO> candidateLocations = actionType == "AIR" ? new(){attackLoc} : 
                    FS.GENERATESEAMOVEMENTCONNECTIONS(attackLoc).Select(n => n.MOVEMENTLOCATION).ToList();
            if(actionType != "SUB"){candidateLocations.RemoveAll(STORM);}
            foreach(GO loc in candidateLocations){
                bool canTargetDocked = actionType switch {
                    "AIR" => false,
                    "SURFACE" => loc.PORTDAMAGELEVEL > 0,
                    _ => true
                };
                List<GO> candidates = ENEMYUNITS.Where(n => PARENTGROUPLOCATION(n) == loc).ToList();
                //area anti air prevent surface and air
                if(actionType != "SUB" && candidates.Where(n => n.UNITCATEGORY == "SURFACE").Any()){continue;}
                List<GO> subs = candidates.Where(n => n.UNITCATEGORY == "SUB").ToList();
                if(!canTargetDocked){subs.RemoveAll(n=> n.DOCKED);}
                if(actionType == "AIR"){subs.RemoveAll(n => n.ATTACKEDBYAIR);}
                if(actionType == "SURFACE"){subs.RemoveAll(n => n.ATTACKEDBYSURFACE);}
                TARGETS.AddRange(subs);
            }
            return TARGETS;
        }
        public static List<GO> TORPTARGETS(GO attackingUnit, GO destinationMarker, List<GO> ENEMYUNITS){
            GameScenario GS = attackingUnit.GS;
            GO attackLoc = destinationMarker.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            string actionType = attackingUnit.UNITCATEGORY;
            List<GO> candidateLocations = FS.GENERATESEAMOVEMENTCONNECTIONS(attackLoc).Select(n => n.MOVEMENTLOCATION).ToList();
            candidateLocations.RemoveAll(STORM);
            foreach(GO loc in candidateLocations){
                TARGETS.AddRange(ENEMYUNITS.Where(n => PARENTGROUPLOCATION(n) == loc));
            }
            return TARGETS;
        }
        public static List<GO> BOMBTARGETS(GO attackingUnit, GO destinationMarker, List<GO> ENEMYUNITS){
            GO attackLoc = destinationMarker.GAMELOCATION;
            List<GO> TARGETS = new();
            List<GO> groupMembers = GROUPMEMBERS(attackingUnit);
            Dictionary<GO, Dictionary<string, Dictionary<string, Dictionary<string, double>>>> attackData = ATTACKDATA(groupMembers);
            
            //BMB cannot bomb ships
            bool nonBMBUnits = false;
            foreach(GO obj in groupMembers.Where(attackData.ContainsKey)){
                if(attackData[obj].ContainsKey("BOMB")){
                    if(obj.UNITTYPE != "BMB"){nonBMBUnits = true;}
                }
            }
            ENEMYUNITS = ENEMYUNITS.Where(n => n.GAMELOCATION == attackLoc && attackLoc.TYPE == "HEX").ToList();
            if(nonBMBUnits){
                TARGETS.AddRange(ENEMYUNITS.Where(n => n.UNITCATEGORY == "SURFACE"));  
            }
            if(attackLoc.SIDE == FS.ENEMY(attackingUnit.SIDE)){
                if((attackLoc.PORT && !attackLoc.PORTDESTROYED) || (attackLoc.AIRFIELD && !attackLoc.AIRFIELDDESTROYED)){
                    TARGETS.AddRange(ENEMYUNITS.Where(n => n.UNITTYPE == "BASE"));
                }
            }                       
            return TARGETS;
        }
        public static void DISCARDLOGIC(GO obj){
            GameScenario GS = obj.GS;
            if(obj.GAMEPIECEID != null){GS.DISCARD(obj.GAMEPIECE);}
            GS.DISCARD(obj);
            GS._TypeObjects[GO.DOMAIN_LOGIC].Remove(obj);
            GS._TypeObjects[obj.TYPE].Remove(obj);
        }
    }
    public class ScenarioCombined : FS
    {
        public ScenarioCombined(string pid, MainWindow pwindow){
            data.ID = pid;
            AddChildPhase(new SetupSegment("SETUP", null, this));
            AddChildPhase(new TurnLoop("*TURN", null, this));
            _Window = pwindow;
            //commit countries
            foreach(string side in ALIGNEDCOUNTRIES.Keys){
                foreach(string country in ALIGNEDCOUNTRIES[side]){Set(country + ".SIDE", side);}
            }
            SetBoolean("SETUP", true);
            Set("ACTIVE.SIDE", "SOV");
            Set("SIDE1", "SOV");
            //SetInt("SY.INFLUENCE", 2);
            //NAVALMOVES
            //SetBoolean("NATO.NORTH", true);
            //SetInt("NATO.ATR.MAX", 17);
            WorldSize = 35352;
            MarkerSize = 80;
            _Window.XY_MARKER_OFFSET = 1;
            //450 miles/day
        }
        public override void Finish()
        {
            if(!GetBoolean("WAR") && GetInt("TURN") == 99){
                Set("RESULT", "NATO Decisive Victory at Peace Turn 99!");
            }
            else
            {
                Set("RESULT", "No Result");
            }
        }
    }
}