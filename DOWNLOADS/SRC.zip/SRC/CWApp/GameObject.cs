using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using CWApp.Helpers;
using System.DirectoryServices.ActiveDirectory;
using System.Windows;
using System.Diagnostics;

namespace CWApp
{
    public class GO
    {
        public GameScenario GS{ get; set; }
        public Dictionary<string, string> SavedState = new();
        public Dictionary<string, string> OriginalState = new();
        public Dictionary<string, string> _data = new();
        public Ellipse ellipseIndicator { get; set; }
        public Line lineIndicator { get; set; }
        public Line lineIndicator2 { get; set; }
        private string _LINECOLOR = "WHITE";
        private string _ELLIPSECOLOR = "WHITE";
        public bool _ELLIPSEFILL = true;
        public double _ELLIPSESIZE = 0;
        public void MakeLineVisible(string color) {
            MakeLineVisible(color, false);
        }
        public void MakeLineVisible(string color, bool force) { 
            if(color != _LINECOLOR || force){
                GS._Window.GOIndicatorsToDraw[_LINECOLOR].Remove(this);
                _LINECOLOR = color;
            }
            GS._Window.GOIndicatorsToDraw[color].Add(this);
        }
        public void MakeEllipseVisible(string color) {
            MakeEllipseVisible(color, true, 20, false);
         }
        public void MakeEllipseVisible(string color, bool fill, double size, bool force) { 
            if(color != _ELLIPSECOLOR || fill != _ELLIPSEFILL || size != _ELLIPSESIZE || force){
                GS._Window.GOIndicatorsToDraw[_ELLIPSECOLOR].Remove(this);
                _ELLIPSECOLOR = color;
                _ELLIPSEFILL = fill;
                _ELLIPSESIZE = size;
            }
            GS._Window.GOIndicatorsToDraw[color].Add(this);
        }
        public Image image { get; set; }
        public Dictionary<string, Rectangle> RECTANGLES = new();  
        public const string DELIM = ".";
        public GO(){}
        public GO(GameScenario gs, Dictionary<string, string> pdata, Dictionary<string, string> odata, Dictionary<string, string> sdata){
            GS = gs;
            if(odata != null){
                foreach(string key in odata.Keys){
                    OriginalState[key] = odata[key];
                }
            }
            if(sdata != null){
                foreach(string key in sdata.Keys){
                    SavedState[key] = sdata[key];
                }
            }
            SetData(pdata);
        }
        private void SetData(Dictionary<string, string> pdata){
            if(pdata != null){
                if(GS != null){
                    foreach(string t in GS.GOTypedFields){
                        if(pdata.ContainsKey(t)){Set(t, pdata[t]);}
                    }
                    GS.SetTypedFields(this);
                    foreach(string key in pdata.Keys.Where(n => !GS.GOTypedFields.Contains(n))){
                        Set(key, pdata[key]);
                    }

                } else {
                    foreach(string key in pdata.Keys){
                        Set(key, pdata[key]);
                    }
                }
                
            }
        }
        public string Get(string key){
            string var = _data.ContainsKey(key) ? _data[key] : null;
            return CWApp.Helpers.CSVFile.ParseString(var);
        }
        public int GetInt(string key){
            string var = Get(key);
            return CWApp.Helpers.CSVFile.ParseInt(var, 0);
        }
        public double GetDouble(string key){
            string var = Get(key);
            return CWApp.Helpers.CSVFile.ParseDouble(var, 0);
        }
        public Boolean GetBoolean(string key){
            return Get(key) == "TRUE";
        }
        public void Set(string key, string value){
            string oldValue = null;
            if(_data.ContainsKey(key)){
                oldValue = _data[key];
            }
            _data[key] = value;
            if(GS != null){
                if(this != GS.data){
                    if(!GS.GOTypedFields.Contains(key)){
                        if(GetDirtyFields(SavedState).Any()){
                            GS._ChangedObjects[this] = GetDirtyFields(OriginalState);
                        } else {
                            GS._ChangedObjects.Remove(this);
                        }
                        if(GS.GOCategorizedFields.Contains(key)){
                            GS.Categorize(this, key, oldValue, value);
                        }
                        if(GS.GOIndicatorFields.Contains(key)){
                            if(DOMAIN != null && GAMELOCATION != null){            
                                GS._Window.DrawMarkerStack(DOMAIN, GAMELOCATION, true);
                            }
                        }
                    }
                }
            }
        }
        public Dictionary<string, string> GetDirtyFields(Dictionary<string, string> compareTo){
            Dictionary<string, string> dirtyFields = new();
            foreach(string k in _data.Keys){
                if(IsDirty(k, compareTo)){
                    dirtyFields[k] = Get(k);
                }
            }
            return dirtyFields;
        }
        private Boolean IsDirty(string k, Dictionary<string, string> compareTo){
            string initVal = compareTo.ContainsKey(k) ? compareTo[k] : null;
            string currVal = Get(k);
            Boolean boolEquivalent = (initVal == "" || initVal == null) && currVal == "FALSE";
            Boolean numericEquivalent = (initVal == "" || initVal == null) && currVal == "0";
            Boolean stringEquivalent = (initVal == "" && currVal == null) || (initVal == null && currVal == "");
            return initVal != currVal && !boolEquivalent && !numericEquivalent && !stringEquivalent;
        }
        public void SetInt(string key, int value){
            Set(key, value + "");
        }
        public void SetDouble(string key, double value){
            Set(key, value + "");
        }
        public void SetBoolean(string key, Boolean value){
            Set(key, (value + "").ToUpper());
        }
        public void IncrementInt(string key, int value){
            Set(key, GetInt(key) + value + "");
        }
        public void IncrementDouble(string key, double value){
            Set(key, GetDouble(key) + value + "");
        }
        public string ID { get{ return Get("ID");} set{ Set("ID", value);} }  
        public string LABEL { get{ return Get("LABEL");} set{ Set("LABEL", value);} }  
        public string AAID { get{ return ID;} }  
        public string PARENTSHEETID { get{ return Get("PARENTSHEETID");} set{ Set("PARENTSHEETID", value); if(value == null){_PARENTSHEET = null;}} }
        private GO _PARENTSHEET { get; set; }
        public GO PARENTSHEET { 
            get {
                if(_PARENTSHEET?.ID != PARENTSHEETID){
                    if(GS != null && PARENTSHEETID != null){
                        List<GO> piecesAndSheets = GS.PIECES();
                        piecesAndSheets.AddRange(GS.SHEETS());
                        _PARENTSHEET = piecesAndSheets.Where(n => n.ID == PARENTSHEETID).Single();
                    } else {
                        _PARENTSHEET = null;
                    }
                }
                return _PARENTSHEET;
            } 
            set {
                _PARENTSHEET = value;
            }
        }  
        public string PARENTMAPID { get{ return Get("PARENTMAPID");} set{ Set("PARENTMAPID", value); if(value == null){_PARENTMAP = null;}} }
        private GO _PARENTMAP { get; set; }
        public GO PARENTMAP { 
            get {
                if(_PARENTMAP?.ID != PARENTMAPID){
                    if(GS != null && PARENTMAPID != null){
                        _PARENTMAP = GS.TYPE("MAP").Where(n => n.ID == PARENTMAPID).Single();
                    } else {
                        _PARENTMAP = null;
                    }
                }
                return _PARENTMAP;
            } 
            set {
                _PARENTMAP = value;
            }
        }  
        public string CARRIERID { get{ return Get("CARRIERID");} set{ Set("CARRIERID", value); if(value == null){_CARRIER = null;}} }
        private GO _CARRIER { get; set; }
        public GO CARRIER { 
            get {
                if(_CARRIER?.ID != CARRIERID){
                    if(GS != null && CARRIERID != null){
                        _CARRIER = GS.PIECE(CARRIERID);
                    } else {
                        _CARRIER = null;
                    }
                }
                return _CARRIER;
            } 
            set {
                _CARRIER = value;
            }
        }  
        public string PARENTPIECEID { get{ return Get("PARENTPIECEID");} set{ Set("PARENTPIECEID", value); if(value == null){_PARENTPIECE = null;}} }
        private GO _PARENTPIECE { get; set; }
        public GO PARENTPIECE { 
            get {
                if(_PARENTPIECE?.ID != PARENTPIECEID){
                    if(GS != null && PARENTPIECEID != null){
                        _PARENTPIECE = GS.PIECE(PARENTPIECEID);
                    } else {
                        _PARENTPIECE = null;
                    }
                }
                return _PARENTPIECE;
            } 
            set {
                _PARENTPIECE = value;
            }
        }  
        public string DOMAIN { get{ return Get("DOMAIN");} set{ Set("DOMAIN", value);} }
        public string AADOMAIN { get{ return DOMAIN;} }  
        public const string DOMAIN_LOCATION = "LOCATION";  
        public const string DOMAIN_PIECE = "PIECE"; 
        public const string DOMAIN_SHEET = "SHEET"; 
        public const string DOMAIN_CONNECTOR = "CONNECTOR";   
        public const string DOMAIN_MOVEMENT = "MOVEMENT";
        public const string DOMAIN_PIECEACTION = "ACTION"; 
        public const string DOMAIN_LOGIC = "LOGIC";
        public const string DOMAIN_MAP = "MAP";
        //categorization
        public string TYPE { get{ return Get("TYPE");} set{ Set("TYPE", value);} }
        public string AATYPE { get{ return TYPE;} }          
        public string SIDE { get{ return Get("SIDE");} set{ Set("SIDE", value);} }
        public string INITSIDE { get{ return Get("INITSIDE");} set{ Set("INITSIDE", value);} }
        public string COUNTRY { get{ return Get("COUNTRY");} set{ Set("COUNTRY", value);} }
        public string SUBCOUNTRY { get{ return Get("SUBCOUNTRY");} set{ Set("SUBCOUNTRY", value);} }
        public string GAMEPIECEID { get{ return Get("GAMEPIECEID");} set{ Set("GAMEPIECEID", value); if(value == null){_GAMEPIECE = null;}} }
        private GO _GAMEPIECE { get; set; }
        public GO GAMEPIECE { 
            get {
                if(_GAMEPIECE?.ID != GAMEPIECEID){
                    if(GS != null && GAMEPIECEID != null){
                        _GAMEPIECE = GS.PIECE(GAMEPIECEID);
                    } else {
                        _GAMEPIECE = null;
                    }
                }
                return _GAMEPIECE;
            } 
            set {
                _GAMEPIECE = value;
            }
        }
        public string DESTINATIONPIECEID { get{ return Get("DESTINATIONPIECEID");} set{ Set("DESTINATIONPIECEID", value); if(value == null){_DESTINATIONPIECE = null;}} }
        private GO _DESTINATIONPIECE { get; set; }
        public GO DESTINATIONPIECE { 
            get {
                if(_DESTINATIONPIECE?.ID != DESTINATIONPIECEID){
                    if(GS != null && DESTINATIONPIECEID != null){
                        _DESTINATIONPIECE = GS.PIECE(DESTINATIONPIECEID);
                    } else {
                        _DESTINATIONPIECE = null;
                    }
                }
                return _DESTINATIONPIECE;
            } 
            set {
                _DESTINATIONPIECE = value;
            }
        }
        public string TACCOORDPIECEID { get{ return Get("TACCOORDPIECEID");} set{ Set("TACCOORDPIECEID", value); if(value == null){_TACCOORDPIECE = null;}} }
        private GO _TACCOORDPIECE { get; set; }
        public GO TACCOORDPIECE { 
            get {
                if(_TACCOORDPIECE?.ID != TACCOORDPIECEID){
                    if(GS != null && TACCOORDPIECEID != null){
                        _TACCOORDPIECE = GS.PIECE(TACCOORDPIECEID);
                    } else {
                        _TACCOORDPIECE = null;
                    }
                }
                return _TACCOORDPIECE;
            } 
            set {
                _TACCOORDPIECE = value;
            }
        }
        public GO SHEETPARENTPIECE { get; set; }  
        public string ACTIONPIECEID { get{ return Get("ACTIONPIECEID");} set{ Set("ACTIONPIECEID", value);} }
        public string AUTODEPLOYLOCATIONID { get{ return Get("AUTODEPLOYLOCATIONID");} set{ Set("AUTODEPLOYLOCATIONID", value);} }
        public string SHEETANCHORLOCATIONID { get{ return Get("SHEETANCHORLOCATIONID");} set{ Set("SHEETANCHORLOCATIONID", value);} }
        public string GAMELOCATIONID { get{ return Get("GAMELOCATIONID");} set{ Set("GAMELOCATIONID", value); if(value == null){_GAMELOCATION = null;}} }
        private GO _GAMELOCATION { get; set; }
        public GO GAMELOCATION { 
            get {
                if(_GAMELOCATION?.ID != GAMELOCATIONID){
                    if(GS != null && GAMELOCATIONID != null){
                        _GAMELOCATION = GS.LOCATION(GAMELOCATIONID);
                    } else {
                        _GAMELOCATION = null;
                    }
                }
                return _GAMELOCATION;
            } 
            set {
                _GAMELOCATION = value;
            }
        }  
        public string TEMPLOCATIONID { get; set; }
        public string CONNECTORLOCATIONID { get{ return Get("CONNECTORLOCATIONID");} set{ Set("CONNECTORLOCATIONID", value); if(value == null){_CONNECTORLOCATION = null;}} }
        private GO _CONNECTORLOCATION { get; set; }
        public GO CONNECTORLOCATION { 
            get {
                if(_CONNECTORLOCATION?.ID != CONNECTORLOCATIONID){
                    if(GS != null && CONNECTORLOCATIONID != null){
                        _CONNECTORLOCATION = GS.LOCATION(CONNECTORLOCATIONID);
                    } else {
                        _CONNECTORLOCATION = null;
                    }
                }
                return _CONNECTORLOCATION;
            } 
            set {
                _CONNECTORLOCATION = value;
            }
        }  
        public string CONNECTORLOCATION2ID { get{ return Get("CONNECTORLOCATION2ID");} set{ Set("CONNECTORLOCATION2ID", value); if(value == null){_CONNECTORLOCATION2 = null;}} }
        private GO _CONNECTORLOCATION2 { get; set; }
        public GO CONNECTORLOCATION2 { 
            get {
                if(_CONNECTORLOCATION2?.ID != CONNECTORLOCATION2ID){
                    if(GS != null && CONNECTORLOCATION2ID != null){
                        _CONNECTORLOCATION2 = GS.LOCATION(CONNECTORLOCATION2ID);
                    } else {
                        _CONNECTORLOCATION2 = null;
                    }
                }
                return _CONNECTORLOCATION2;
            } 
            set {
                _CONNECTORLOCATION2 = value;
            }
        }  
        public Boolean ALWAYSSHOW { get{ return GetBoolean("ALWAYSSHOW");} set{ SetBoolean("ALWAYSSHOW", value);} }
        public double IMAGEWIDTH { get{ return GetDouble("IMAGEWIDTH");} set{ SetDouble("IMAGEWIDTH", value);} }        
        public double IMAGEWIDTHVALUE { 
            get{ 
                    if(TEMPLATE == null){
                        return IMAGEWIDTH;
                    } else {
                        return TEMPLATE.IMAGEWIDTH;
                    }
                }
        }        
        public double IMAGEHEIGHT { get{ return GetDouble("IMAGEHEIGHT");} set{ SetDouble("IMAGEHEIGHT", value);} }        
        public double IMAGEHEIGHTVALUE { 
            get{ 
                    if(TEMPLATE == null){
                        return IMAGEHEIGHT == 0 ? IMAGEWIDTH : IMAGEHEIGHT;
                    } else {
                        return TEMPLATE.IMAGEHEIGHT == 0 ? TEMPLATE.IMAGEWIDTH : TEMPLATE.IMAGEHEIGHT;
                    }
                }
        }        
        public double MINIMIZEDWIDTH { get{ return GetDouble("MINIMIZEDWIDTH");} set{ SetDouble("MINIMIZEDWIDTH", value);} }        
        public double MINIMIZEDWIDTHVALUE { 
            get{ 
                    if(TEMPLATE == null){
                        return MINIMIZEDWIDTH;
                    } else {
                        return TEMPLATE.MINIMIZEDWIDTH;
                    }
                }
        }        
        public Boolean DYNAMICSIZE { get{ return GetBoolean("DYNAMICSIZE");} set{ SetBoolean("DYNAMICSIZE", value);} }
        public string IMAGEFILE { get{ return Get("IMAGEFILE");} set{ Set("IMAGEFILE", value);} }
        public string IMAGEFILENAME { 
            get{ 
                    if(TEMPLATE == null){
                        return IMAGEFILE;
                    } else {
                        return TEMPLATE.IMAGEFILE;
                    }
                }
        }
        //INTERACTIONS
        public string ACTION { get{ return Get("ACTION");} set{ Set("ACTION", value);} }
        public Boolean DRAGGING { get; set; }
        //LOCATION
        public double XCOORD { get{ return GetDouble("XCOORD");} set{ SetDouble("XCOORD", value);} }        
        public double YCOORD { get{ return GetDouble("YCOORD");} set{ SetDouble("YCOORD", value);} }        
        public int ZCOORD { get{ return GetInt("ZCOORD");} set{ SetInt("ZCOORD", value);} }
        public double x = 0;
        public double y = 0;
        public int z = 0; 
        public int z_inspection = 0;       
        public Boolean LOCATIONHIDDEN { get{ return GetBoolean("LOCATIONHIDDEN");} set{ SetBoolean("LOCATIONHIDDEN", value);} }
        public Boolean HIDDEN = false;
        public Boolean EXPANDED = false;
        //Location features
        public Boolean MAJORCITY { get{ return GetBoolean("MAJORCITY");} set{ SetBoolean("MAJORCITY", value);} }
        public Boolean CITY { get{ return GetBoolean("CITY");} set{ SetBoolean("CITY", value);} }
        public Boolean MAINLANDPORT { get{ return GetBoolean("MAINLANDPORT");} set{ SetBoolean("MAINLANDPORT", value);} }
        public Boolean ISLANDPORT { get{ return GetBoolean("ISLANDPORT");} set{ SetBoolean("ISLANDPORT", value);} }
        public Boolean PORT { get{ return GetBoolean("PORT");} set{ SetBoolean("PORT", value);} }
        public Boolean OILFIELD { get{ return GetBoolean("OILFIELD");} set{ SetBoolean("OILFIELD", value);} }
        public string SEAZONE { get{ return Get("SEAZONE");} set{ Set("SEAZONE", value);} }            
        public string PORTSEAZONE { get{ return Get("PORTSEAZONE");} set{ Set("PORTSEAZONE", value);} }            
        public Boolean AIRFIELD { get{ return GetBoolean("AIRFIELD");} set{ SetBoolean("AIRFIELD", value);} }
        public Boolean LOGISTICALBASE { get{ return GetBoolean("LOGISTICALBASE");} set{ SetBoolean("LOGISTICALBASE", value);} }
        public Boolean OBJECTIVE { get{ return GetBoolean("OBJECTIVE");} set{ SetBoolean("OBJECTIVE", value);} }
        public Boolean CAPTURABLE { get{ return GetBoolean("CAPTURABLE");} set{ SetBoolean("CAPTURABLE", value);} }
        public Boolean REINFENTRY { get{ return GetBoolean("REINFENTRY");} set{ SetBoolean("REINFENTRY", value);} }    
        //movement info
        public string TERRAIN { get{ return Get("TERRAIN");} set{ Set("TERRAIN", value);} } 
        public Boolean WOODS { get{ return GetBoolean("WOODS");} set{ SetBoolean("WOODS", value);} }
        public Boolean WILDERNESS { get{ return GetBoolean("WILDERNESS");} set{ SetBoolean("WILDERNESS", value);} }
        public Boolean COASTAL { get{ return GetBoolean("COASTAL");} set{ SetBoolean("COASTAL", value);} }
        public Boolean PASS { get{ return GetBoolean("PASS");} set{ SetBoolean("PASS", value);} }
        public Boolean ARCTIC { get{ return GetBoolean("ARCTIC");} set{ SetBoolean("ARCTIC", value);} }
        public Boolean RIVER { get{ return GetBoolean("RIVER");} set{ SetBoolean("RIVER", value);} }
        public double AIRMISSIONMODIFIER { get{ return WOODS ? 0.5 : 1;}}
        public int ODDSSHIFT { get{ return GetInt("ODDSSHIFT");} set{ SetInt("ODDSSHIFT", value);} }
        public double ODDS { get{ return GetDouble("ODDS");} set{ SetDouble("ODDS", value);} }
        public int ROLLMODIFIER { get{ return GetInt("ROLLMODIFIER");} set{ SetInt("ROLLMODIFIER", value);} }
        public Boolean INTERCEPTIONELIGIBLE { get{ return GetBoolean("INTERCEPTIONELIGIBLE");} set{ SetBoolean("INTERCEPTIONELIGIBLE", value);} }
        public Boolean BOUNCEELIGIBLE { get{ return GetBoolean("BOUNCEELIGIBLE");} set{ SetBoolean("BOUNCEELIGIBLE", value);} }
        public int SOVSTEPLOSSES { get{ return GetInt("SOVSTEPLOSSES");} set{ SetInt("SOVSTEPLOSSES", value);} }
        public int ALLIESSTEPLOSSES { get{ return GetInt("ALLIESSTEPLOSSES");} set{ SetInt("ALLIESSTEPLOSSES", value);} }
        public string NATOZOC { get{ return Get("NATOZOC");} set{ Set("NATOZOC", value);} }            
        public string WPZOC { get{ return Get("WPZOC");} set{ Set("WPZOC", value);} }            
        //UNIT
        public double ATK { get{ return GetDouble("ATK");} set{ SetDouble("ATK", value);} }
        public double DEF { get{ return GetDouble("DEF");} set{ SetDouble("DEF", value);} }
        public int MAINTENANCE { get{ return GetInt("MAINTENANCE");} set{ SetInt("MAINTENANCE", value);} }
        public Boolean MAINTENANCEBONUS { get{ return GetBoolean("MAINTENANCEBONUS");} set{ SetBoolean("MAINTENANCEBONUS", value);} }
        public double ATA { get{ return GetDouble("ATA");} set{ SetDouble("ATA", value);} }
        public double GATK { get{ return GetDouble("GATK");} set{ SetDouble("GATK", value);} }
        public double STRK { get{ return GetDouble("STRK");} set{ SetDouble("STRK", value);} }
        public Boolean ATAWEATHER { get{ return GetBoolean("ATAWEATHER");} set{ SetBoolean("ATAWEATHER", value);} }  //field on unit
        public Boolean STRKWEATHER { get{ return GetBoolean("STRKWEATHER");} set{ SetBoolean("STRKWEATHER", value);} }  //field on unit
        public string AIRMISSION { get{ return Get("AIRMISSION");} set{ Set("AIRMISSION", value);} } //unit
        public string AUTOAIRMISSION { get{ return Get("AUTOAIRMISSION");} set{ Set("AUTOAIRMISSION", value);} } //unit
        public int PROFICIENCY { get{ return GetInt("PROFICIENCY");} set{ SetInt("PROFICIENCY", value);} }
        public Boolean PROFICIENCYBONUS { get{ return GetBoolean("PROFICIENCYBONUS");} set{ SetBoolean("PROFICIENCYBONUS", value);} }
        public Boolean REBEL { get{ return GetBoolean("REBEL");} set{ SetBoolean("REBEL", value);} } 
        public double MOVEMENTPTS { get{ return GetDouble("MOVEMENTPTS");} set{ SetDouble("MOVEMENTPTS", value);} }
        public double MOVEMENTPTSTMP { get; set; }
        public Boolean MOVING { get; set;}
        public double ATATMP { get; set;}
        public double GATKTMP { get; set;}
        public double STRKTMP { get; set;}
        public string AIRCOMBATDISPOSITION { get{ return Get("AIRCOMBATDISPOSITION");} set{ Set("AIRCOMBATDISPOSITION", value);} }
        public string MOBILITYCLASS { get{ return Get("MOBILITYCLASS");} set{ Set("MOBILITYCLASS", value);} } //field on unit
        public Boolean MECH { get{ return GetBoolean("MECH");} set{ SetBoolean("MECH", value);} }  //field on unit
        public Boolean MOT { get{ return GetBoolean("MOT");} set{ SetBoolean("MOT", value);} }  //field on unit
        public Boolean AMOB { get{ return GetBoolean("AMOB");} set{ SetBoolean("AMOB", value);} }  //field on unit
        public Boolean LEG { get{ return GetBoolean("LEG");} set{ SetBoolean("LEG", value);} }  //field on unit
        public string UNITZOC { get{ return Get("UNITZOC");} set{ Set("UNITZOC", value);} } //field on unit
        public string RANGE { get{ return Get("RANGE");} set{ Set("RANGE", value);} } //field on unit
        public Boolean OVERLAND { get{ return GetBoolean("OVERLAND");} set{ SetBoolean("OVERLAND", value);} }  //field on unit
        public Boolean MTN { get{ return GetBoolean("MTN");} set{ SetBoolean("MTN", value);} }  //field on unit  
        public Boolean AMPHIBIOUS { get{ return GetBoolean("AMPHIBIOUS");} set{ SetBoolean("AMPHIBIOUS", value);} }  //field on unit  
        public Boolean PARTIALAMPHIBIOUS { get{ return GetBoolean("PARTIALAMPHIBIOUS");} set{ SetBoolean("PARTIALAMPHIBIOUS", value);} }  //field on unit  
        public Boolean NOCRATERING { get{ return GetBoolean("NOCRATERING");} set{ SetBoolean("NOCRATERING", value);} }  //field on unit  
        public Boolean STEALTH { get{ return GetBoolean("STEALTH");} set{ SetBoolean("STEALTH", value);} }  //field on unit  
        public Boolean AIRBORNE { get{ return GetBoolean("AIRBORNE");} set{ SetBoolean("AIRBORNE", value);} }  //field on unit
        public Boolean CHEMICAL { get{ return GetBoolean("CHEMICAL");} set{ SetBoolean("CHEMICAL", value);} }  //field on unit
        public Boolean NUCLEAR { get{ return GetBoolean("NUCLEAR");} set{ SetBoolean("NUCLEAR", value);} }  //field on unit
        public Boolean LIMITED { get{ return GetBoolean("LIMITED");} set{ SetBoolean("LIMITED", value);} }  //field on unit
        public Boolean LIMITEDBONUS { get{ return GetBoolean("LIMITEDBONUS");} set{ SetBoolean("LIMITEDBONUS", value);} }
        public Boolean TERRITORIAL { get{ return GetBoolean("TERRITORIAL");} set{ SetBoolean("TERRITORIAL", value);} }  //field on unit
        public Boolean ENTRAINED { get{ return GetBoolean("ENTRAINED");} set{ SetBoolean("ENTRAINED", value);} }
        public Boolean ENTRAINING { get{ return GetBoolean("ENTRAINING");} set{ SetBoolean("ENTRAINING", value);} }
        public int STEPS { get{ return GetInt("STEPS");} set{ SetInt("STEPS", value);} }
        public int AIRTRANSPORTCOST { get{ return GetInt("AIRTRANSPORTCOST");} set{ SetInt("AIRTRANSPORTCOST", value);} }
        public string REPLACEID { get{ return Get("REPLACEID");} set{ Set("REPLACEID", value);} }
        public Boolean EMBARKED { get{ return GetBoolean("EMBARKED");} set{ SetBoolean("EMBARKED", value);} }
        public Boolean RESERVED { get{ return GetBoolean("RESERVED");} set{ SetBoolean("RESERVED", value);} }
        public Boolean ACTIVATED { get{ return GetBoolean("ACTIVATED");} set{ SetBoolean("ACTIVATED", value);} }        
        public Boolean DONE { get{ return GetBoolean("DONE");} set{ SetBoolean("DONE", value);} }        
        public Boolean SUPPRESSED { get{ return GetBoolean("SUPPRESSED");} set{ SetBoolean("SUPPRESSED", value);} }
        public Boolean DISRUPTED { get{ return GetBoolean("DISRUPTED");} set{ SetBoolean("DISRUPTED", value);} }
        public double DISRUPTIONS { get{ return GetDouble("DISRUPTIONS");} set{ SetDouble("DISRUPTIONS", value);} }
        public int DISSENT { get{ return GetInt("DISSENT");} set{ SetInt("DISSENT", value);} }
        public Boolean ISOLATED { get{ return GetBoolean("ISOLATED");} set{ SetBoolean("ISOLATED", value);} }
        public Boolean OOSUPPLYCANDIDATE { get{ return GetBoolean("OOSUPPLYCANDIDATE");} set{ SetBoolean("OOSUPPLYCANDIDATE", value);} }
        public Boolean OOSUPPLY { get{ return GetBoolean("OOSUPPLY");} set{ SetBoolean("OOSUPPLY", value);} }
        public Boolean SHAKEN { get{ return GetBoolean("SHAKEN");} set{ SetBoolean("SHAKEN", value);} }
        public Boolean DEMORALIZED { get{ return GetBoolean("DEMORALIZED");} set{ SetBoolean("DEMORALIZED", value);} }
        public string MOBILIZATIONTURN { get{ return Get("MOBILIZATIONTURN");} set{ Set("MOBILIZATIONTURN", value);} }            
        public string ALERTTURN { get{ return Get("ALERTTURN");} set{ Set("ALERTTURN", value);} }
        public string SMDTURN { get{ return Get("SMDTURN");} set{ Set("SMDTURN", value);} }
        public string ORGLEVEL1 { get{ return Get("ORGLEVEL1");} set{ Set("ORGLEVEL1", value);} }            
        public string ORGLEVEL2 { get{ return Get("ORGLEVEL2");} set{ Set("ORGLEVEL2", value);} }            
        public string ORGLEVEL3 { get{ return Get("ORGLEVEL3");} set{ Set("ORGLEVEL3", value);} }            
        public string AIRTHEATER { get{ return Get("AIRTHEATER");} set{ Set("AIRTHEATER", value);} }            
        public string MILDISTRICT { get{ return Get("MILDISTRICT");} set{ Set("MILDISTRICT", value);} }            
        public Boolean CANREPLACE { get{ return GetBoolean("CANREPLACE");} set{ SetBoolean("CANREPLACE", value);} }
        public Boolean CANBREAKDOWN { get{ return GetBoolean("CANBREAKDOWN");} set{ SetBoolean("CANBREAKDOWN", value);} }
        public Boolean CANCOMBINE { get{ return GetBoolean("CANCOMBINE");} set{ SetBoolean("CANCOMBINE", value);} }
        public Boolean UNABLETOATTACK { get{ return GetBoolean("UNABLETOATTACK");} set{ SetBoolean("UNABLETOATTACK", value);} }  //field on unit
        public Boolean UNABLETODEFEND { get{ return GetBoolean("UNABLETODEFEND");} set{ SetBoolean("UNABLETODEFEND", value);} }  //field on unit
        public Boolean UNABLETOREGROUP { get{ return GetBoolean("UNABLETOREGROUP");} set{ SetBoolean("UNABLETOREGROUP", value);} }  //field on unit
        public Boolean AMPHIBIOUSASSAULTING { get{ return GetBoolean("AMPHIBIOUSASSAULTING");} set{ SetBoolean("AMPHIBIOUSASSAULTING", value);} }  //field on unit
        public string EVACUATIONLOCATIONID { get{ return Get("EVACUATIONLOCATIONID");} set{ Set("EVACUATIONLOCATIONID", value);} }
        public Boolean MUSTRETREAT { get{ return GetBoolean("MUSTRETREAT");} set{ SetBoolean("MUSTRETREAT", value);} }  //field on unit
        public Boolean CANRETREAT { get{ return GetBoolean("CANRETREAT");} set{ SetBoolean("CANRETREAT", value);} }  //field on unit
        public string PHASE { get{ return Get("PHASE");} set{ Set("PHASE", value);} }
        //SEA booleans
        public Boolean SHALLOW { get{ return GetBoolean("SHALLOW");} set{ SetBoolean("SHALLOW", value);} }
        public Boolean RESTRICTED { get{ return GetBoolean("RESTRICTED");} set{ SetBoolean("RESTRICTED", value);} }
        public Boolean FJORD { get{ return GetBoolean("FJORD");} set{ SetBoolean("FJORD", value);} }
        public Boolean SHOALS { get{ return GetBoolean("SHOALS");} set{ SetBoolean("SHOALS", value);} }
        public Boolean DRIFTICE { get{ return GetBoolean("DRIFTICE");} set{ SetBoolean("DRIFTICE", value);} }
        public Boolean PACKICE { get{ return GetBoolean("PACKICE");} set{ SetBoolean("PACKICE", value);} }
        public string ZONE { get{ return Get("ZONE");} set{ Set("ZONE", value);} }
        public Boolean LOGLAND { get{ return GetBoolean("LOGLAND");} set{ SetBoolean("LOGLAND", value);} }
        public Boolean LOGSEA { get{ return GetBoolean("LOGSEA");} set{ SetBoolean("LOGSEA", value);} }
        public Boolean LOGAIR { get{ return GetBoolean("LOGAIR");} set{ SetBoolean("LOGAIR", value);} }
        public string TEMPLATEID { get{ return Get("TEMPLATEID");} set{ Set("TEMPLATEID", value); if(value == null){_TEMPLATE = null;}} }
        private GO _TEMPLATE { get; set; }
        public GO TEMPLATE { 
            get {
                if(_TEMPLATE?.ID != TEMPLATEID){
                    if(GS != null && TEMPLATEID != null){
                        _TEMPLATE = GS.PIECE(TEMPLATEID);
                    } else {
                        _TEMPLATE = null;
                    }
                }
                return _TEMPLATE;
            } 
            set {
                _TEMPLATE = value;
            }
        }  
        public string UNITTYPE { get{ return Get("UNITTYPE");} set{ Set("UNITTYPE", value);} }
        public string GRPTYPE { get{ return Get("GRPTYPE");} set{ Set("GRPTYPE", value);} }
        public string UNITCATEGORY { get{ return Get("UNITCATEGORY");} set{ Set("UNITCATEGORY", value);} }
        public double MOVEMENTALLOWANCE { get{ return GetDouble("MOVEMENTALLOWANCE");} set{ SetDouble("MOVEMENTALLOWANCE", value);} }
        public double REMAININGMOVEMENT = 0;
        public double ASW { get{ return GetDouble("ASW");} set{ SetDouble("ASW", value);} }
        public double CAA { get{ return GetDouble("CAA");} set{ SetDouble("CAA", value);} }
        public Boolean NIGHTAA { get{ return GetBoolean("NIGHTAA");} set{ SetBoolean("NIGHTAA", value);} }
        public double AAA { get{ return GetDouble("AAA");} set{ SetDouble("AAA", value);} }
        public Boolean LAA { get{ return GetBoolean("LAA");} set{ SetBoolean("LAA", value);} }
        public double SPECIAL { get{ return GetDouble("SPECIAL");} set{ SetDouble("SPECIAL", value);} }
        public Boolean NIGHTBOMBING { get{ return GetBoolean("NIGHTBOMBING");} set{ SetBoolean("NIGHTBOMBING", value);} }
        public double SSM { get{ return GetDouble("SSM");} set{ SetDouble("SSM", value);} }
        public double SSMRANGE { get{ return GetDouble("SSMRANGE");} set{ SetDouble("SSMRANGE", value);} }
        public double SSM2 { get{ return GetDouble("SSM2");} set{ SetDouble("SSM2", value);} }
        public double SSM2RANGE { get{ return GetDouble("SSM2RANGE");} set{ SetDouble("SSM2RANGE", value);} }
        public Boolean SEASKIMMERSSM { get{ return GetBoolean("SEASKIMMERSSM");} set{ SetBoolean("SEASKIMMERSSM", value);} }
        public Boolean FASTSSM { get{ return GetBoolean("FASTSSM");} set{ SetBoolean("FASTSSM", value);} }
        public double CM { get{ return GetDouble("CM");} set{ SetDouble("CM", value);} }
        public double CMRANGE { get{ return GetDouble("CMRANGE");} set{ SetDouble("CMRANGE", value);} }
        public Boolean DECOYS { get{ return GetBoolean("DECOYS");} set{ SetBoolean("DECOYS", value);} }
        public Boolean DEEPDIVING { get{ return GetBoolean("DEEPDIVING");} set{ SetBoolean("DEEPDIVING", value);} }
        public Boolean DEEPMODE { get{ return GetBoolean("DEEPMODE");} set{ SetBoolean("DEEPMODE", value);} }
        public Boolean NOISY { get{ return GetBoolean("NOISY");} set{ SetBoolean("NOISY", value);} }
        public double NOISELEVEL { get{ return GetDouble("NOISELEVEL");} set{ SetDouble("NOISELEVEL", value);} }
        public Boolean LIMITEDSSM { get{ return GetBoolean("LIMITEDSSM");} set{ SetBoolean("LIMITEDSSM", value);} }
        public Boolean EXPANSION { get{ return GetBoolean("EXPANSION");} set{ SetBoolean("EXPANSION", value);} }
        public Boolean LONGRANGERECON { get{ return GetBoolean("LONGRANGERECON");} set{ SetBoolean("LONGRANGERECON", value);} }
        public int GROUPINDEX { get{ return GetInt("GROUPINDEX");} set{ SetInt("GROUPINDEX", value);} }
        public int DISTANCE { get{ return GetInt("DISTANCE");} set{ SetInt("DISTANCE", value);} }
        public string GROUPID { get{ return Get("GROUPID");} set{ Set("GROUPID", value); if(value == null){_GROUP = null;}} }
        private GO _GROUP { get; set; }
        public GO GROUP { 
            get {
                if(_GROUP?.ID != GROUPID){
                    if(GS != null && GROUPID != null){
                        _GROUP = GS.PIECE(GROUPID);
                    } else {
                        _GROUP = null;
                    }
                }
                return _GROUP;
            } 
            set {
                _GROUP = value;
            }
        }
        public string ACTIVATIONGRPID { get{ return Get("ACTIVATIONGRPID");} set{ Set("ACTIVATIONGRPID", value); if(value == null){_ACTIVATIONGRP = null;}} }
        private GO _ACTIVATIONGRP { get; set; }
        public GO ACTIVATIONGRP { 
            get {
                if(_ACTIVATIONGRP?.ID != ACTIVATIONGRPID){
                    if(GS != null && ACTIVATIONGRPID != null){
                        _ACTIVATIONGRP = GS.PIECE(ACTIVATIONGRPID);
                    } else {
                        _ACTIVATIONGRP = null;
                    }
                }
                return _ACTIVATIONGRP;
            } 
            set {
                _ACTIVATIONGRP = value;
            }
        }
        public int FUELPTS { get{ return GetInt("FUELPTS");} set{ SetInt("FUELPTS", value);} }
        public int SSMPTS { get{ return GetInt("SSMPTS");} set{ SetInt("SSMPTS", value);} }
        public Boolean SSMPORTONLY { get{ return GetBoolean("SSMPORTONLY");} set{ SetBoolean("SSMPORTONLY", value);} }
        public int SSM2PTS { get{ return GetInt("SSM2PTS");} set{ SetInt("SSM2PTS", value);} }
        public Boolean SSM2PORTONLY { get{ return GetBoolean("SSM2PORTONLY");} set{ SetBoolean("SSM2PORTONLY", value);} }
        public int ASWPTS { get{ return GetInt("ASWPTS");} set{ SetInt("ASWPTS", value);} }
        public int AAPTS { get{ return GetInt("AAPTS");} set{ SetInt("AAPTS", value);} }
        public int TORPPTS { get{ return GetInt("TORPPTS");} set{ SetInt("TORPPTS", value);} }
        public int BOMBPTS { get{ return GetInt("BOMBPTS");} set{ SetInt("BOMBPTS", value);} }
        public int AIRSSMPTS { get{ return GetInt("AIRSSMPTS");} set{ SetInt("AIRSSMPTS", value);} }
        public int AIRSSMCOST { get{ return GetInt("AIRSSMCOST");} set{ SetInt("AIRSSMCOST", value);} }
        public int FPTS { get{ return GetInt("FPTS");} set{ SetInt("FPTS", value);} }
        public int APTS { get{ return GetInt("APTS");} set{ SetInt("APTS", value);} }
        public int CMPTS { get{ return GetInt("CMPTS");} set{ SetInt("CMPTS", value);} }
        public int ENROUTEDELAY { get{ return GetInt("ENROUTEDELAY");} set{ SetInt("ENROUTEDELAY", value);} }
        public Boolean STRATDETECTED { get{ return GetBoolean("STRATDETECTED");} set{ SetBoolean("STRATDETECTED", value);} }
        public Boolean LOCALDETECTED { get{ return GetBoolean("LOCALDETECTED");} set{ SetBoolean("LOCALDETECTED", value);} }
        public Boolean ADMINDETECTED { get{ return GetBoolean("ADMINDETECTED");} set{ SetBoolean("ADMINDETECTED", value);} }
        public Boolean DAMAGED { get{ return GetBoolean("DAMAGED");} set{ SetBoolean("DAMAGED", value);} }
        public int UNAPPLIEDDAMAGE { get{ return GetInt("UNAPPLIEDDAMAGE");} set{ SetInt("UNAPPLIEDDAMAGE", value);} }
        public Boolean DESTROYED { get{ return GetBoolean("DESTROYED");} set{ SetBoolean("DESTROYED", value);} }
        public Boolean PORTDESTROYED { get{ return GetBoolean("PORTDESTROYED");} set{ SetBoolean("PORTDESTROYED", value);} }
        public Boolean AIRFIELDDESTROYED { get{ return GetBoolean("AIRFIELDDESTROYED");} set{ SetBoolean("AIRFIELDDESTROYED", value);} }
        public Boolean RECYCLED { get{ return GetBoolean("RECYCLED");} set{ SetBoolean("RECYCLED", value);} }
        public int PORTDAMAGELEVEL { get{ return GetInt("PORTDAMAGELEVEL");} set{ SetInt("PORTDAMAGELEVEL", value);} }
        public int UNAPPLIEDPORTDAMAGE { get{ return GetInt("UNAPPLIEDPORTDAMAGE");} set{ SetInt("UNAPPLIEDPORTDAMAGE", value);} }
        public int AIRFIELDDAMAGELEVEL { get{ return GetInt("AIRFIELDDAMAGELEVEL");} set{ SetInt("AIRFIELDDAMAGELEVEL", value);} }
        public int UNAPPLIEDAIRFIELDDAMAGE { get{ return GetInt("UNAPPLIEDAIRFIELDDAMAGE");} set{ SetInt("UNAPPLIEDAIRFIELDDAMAGE", value);} }
        public string AIRUNITS { get{ return Get("AIRUNITS");} set{ Set("AIRUNITS", value);} }
        public int AIRCAPACITYCOMBAT { get{ return GetInt("AIRCAPACITYCOMBAT");} set{ SetInt("AIRCAPACITYCOMBAT", value);} }
        public int AIRCAPACITYAEW { get{ return GetInt("AIRCAPACITYAEW");} set{ SetInt("AIRCAPACITYAEW", value);} }
        public int AIRCAPACITYEW { get{ return GetInt("AIRCAPACITYEW");} set{ SetInt("AIRCAPACITYEW", value);} }
        public int AIRCAPACITYRCN { get{ return GetInt("AIRCAPACITYRCN");} set{ SetInt("AIRCAPACITYRCN", value);} }
        public int AIRCAPACITYAR { get{ return GetInt("AIRCAPACITYAR");} set{ SetInt("AIRCAPACITYAR", value);} }
        public int AIRCAPACITYMSW { get{ return GetInt("AIRCAPACITYMSW");} set{ SetInt("AIRCAPACITYMSW", value);} }
        public string HOMEBASEID { get{ return Get("HOMEBASEID");} set{ Set("HOMEBASEID", value); if(value == null){_HOMEBASE = null;}} }
        private GO _HOMEBASE { get; set; }
        public GO HOMEBASE { 
            get {
                if(_HOMEBASE?.ID != HOMEBASEID){
                    if(GS != null && HOMEBASEID != null){
                        List<GO> objs = new();
                        objs.AddRange(GS.PIECES().Where(n => n.ID == HOMEBASEID));
                        objs.AddRange(GS.LOCATIONS().Where(n => n.ID == HOMEBASEID));
                        _HOMEBASE = objs.First();
                    } else {
                        _HOMEBASE = null;
                    }
                }
                return _HOMEBASE;
            } 
            set {
                _HOMEBASE = value;
            }
        }  
        public Boolean INSPECTION { get{ return GetBoolean("INSPECTION");} set{ SetBoolean("INSPECTION", value);} }
        public Boolean DOCKED { get{ return GetBoolean("DOCKED");} set{ SetBoolean("DOCKED", value);} }
        public Boolean REPLENISHING { get{ return GetBoolean("REPLENISHING");} set{ SetBoolean("REPLENISHING", value);} }
        public int CMRELOADS { get{ return GetInt("CMRELOADS");} set{ SetInt("CMRELOADS", value);} }
        public int REPLENISHMENTPTSUSED { get{ return GetInt("REPLENISHMENTPTSUSED");} set{ SetInt("REPLENISHMENTPTSUSED", value);} }
        public Boolean LARGEUNITREPLENISHED { get{ return GetBoolean("LARGEUNITREPLENISHED");} set{ SetBoolean("LARGEUNITREPLENISHED", value);} }
        public int ACTIVATEDAIRUNITS { get{ return GetInt("ACTIVATEDAIRUNITS");} set{ SetInt("ACTIVATEDAIRUNITS", value);} }
        public string LOCATIONHISTORY { get{ return Get("LOCATIONHISTORY");} set{ Set("LOCATIONHISTORY", value);} }
        public string LOCATIONFUTURE { get{ return Get("LOCATIONFUTURE");} set{ Set("LOCATIONFUTURE", value);} }
        public int NUMCOMBATS { get{ return GetInt("NUMCOMBATS");} set{ SetInt("NUMCOMBATS", value);} }
        public string ROLE { get{ return Get("ROLE");} set{ Set("ROLE", value);} }
        public Boolean DONESSM { get{ return GetBoolean("DONESSM");} set{ SetBoolean("DONESSM", value);} }
        public Boolean DONEASW { get{ return GetBoolean("DONEASW");} set{ SetBoolean("DONEASW", value);} }
        public Boolean DONECM { get{ return GetBoolean("DONECM");} set{ SetBoolean("DONECM", value);} }
        public Boolean ATTACKEDBYSURFACE { get{ return GetBoolean("ATTACKEDBYSURFACE");} set{ SetBoolean("ATTACKEDBYSURFACE", value);} }
        public Boolean ATTACKEDBYAIR { get{ return GetBoolean("ATTACKEDBYAIR");} set{ SetBoolean("ATTACKEDBYAIR", value);} }
        public Boolean OUTOFFUEL {
            get {
                return TEMPLATE?.FUELPTS > 0 && FUELPTS == 0;
            }
        }
        public Boolean USEDFUEL { get{ return GetBoolean("USEDFUEL");} set{ SetBoolean("USEDFUEL", value);} }
        public int HEXESTRAVELLED { get{ return GetInt("HEXESTRAVELLED");} set{ SetInt("HEXESTRAVELLED", value);} }
        public Boolean MAPLINK { get{ return GetBoolean("MAPLINK");} set{ SetBoolean("MAPLINK", value);} }
        public Boolean DETECTIONATTEMPTED { get{ return GetBoolean("DETECTIONATTEMPTED");} set{ SetBoolean("DETECTIONATTEMPTED", value);} }
        public Boolean OVERSTACKED { get{ return GetBoolean("OVERSTACKED");} set{ SetBoolean("OVERSTACKED", value);} }
        public Boolean FULLSPEED { get{ return GetBoolean("FULLSPEED");} set{ SetBoolean("FULLSPEED", value);} }
        public Boolean PCCOONLY { get{ return GetBoolean("PCCOONLY");} set{ SetBoolean("PCCOONLY", value);} }
        public Boolean EXTENDEDRANGE { get{ return GetBoolean("EXTENDEDRANGE");} set{ SetBoolean("EXTENDEDRANGE", value);} }
        public double FRIENDLYSTRENGTH { get{ return GetDouble("FRIENDLYSTRENGTH");} set{ SetDouble("FRIENDLYSTRENGTH", value);} }
        public double FRIENDLYSUPPLIES { get{ return GetDouble("FRIENDLYSUPPLIES");} set{ SetDouble("FRIENDLYSUPPLIES", value);} }
        public double ENEMYSTRENGTH { get{ return GetDouble("ENEMYSTRENGTH");} set{ SetDouble("ENEMYSTRENGTH", value);} }
        public double ENEMYSUPPLIES { get{ return GetDouble("ENEMYSUPPLIES");} set{ SetDouble("ENEMYSUPPLIES", value);} }
        public Boolean SELECTABLE {
            get {
                return GAMELOCATIONID == "TEMP" || GAMELOCATION?.HIDDEN == false;
            }
        }
        //FSCOMBAT
                public string ATTACKERID { get{ return Get("ATTACKERID");} set{ Set("ATTACKERID", value); if(value == null){_ATTACKER = null;}} }
        private GO _ATTACKER { get; set; }
        public GO ATTACKER { 
            get {
                if(GS != null && _ATTACKER == null && ATTACKERID != null){
                    _ATTACKER = GS.PIECE(ATTACKERID);
                }
                return _ATTACKER;
            } 
            set {
                _ATTACKER = value;
            }
        }  
        public string ATTACKERLOCATIONID { get{ return Get("ATTACKERLOCATIONID");} set{ Set("ATTACKERLOCATIONID", value); if(value == null){_ATTACKERLOCATION = null;}} }
        private GO _ATTACKERLOCATION { get; set; }
        public GO ATTACKERLOCATION { 
            get {
                if(GS != null && _ATTACKERLOCATION == null && ATTACKERLOCATIONID != null){
                    _ATTACKERLOCATION = GS.LOCATION(ATTACKERLOCATIONID);
                }
                return _ATTACKERLOCATION;
            } 
            set {
                _ATTACKERLOCATION = value;
            }
        }
        public string DEFENDERID { get{ return Get("DEFENDERID");} set{ Set("DEFENDERID", value); if(value == null){_DEFENDER = null;}} }
        private GO _DEFENDER { get; set; }
        public GO DEFENDER { 
            get {
                if(GS != null && _DEFENDER == null && DEFENDERID != null){
                    _DEFENDER = GS.PIECE(DEFENDERID);
                }
                return _DEFENDER;
            } 
            set {
                _DEFENDER = value;
            }
        }  
        public string DEFENDERLOCATIONID { get{ return Get("DEFENDERLOCATIONID");} set{ Set("DEFENDERLOCATIONID", value); if(value == null){_DEFENDERLOCATION = null;}} }
        private GO _DEFENDERLOCATION { get; set; }
        public GO DEFENDERLOCATION { 
            get {
                if(GS != null && _DEFENDERLOCATION == null && DEFENDERLOCATIONID != null){
                    _DEFENDERLOCATION = GS.LOCATION(DEFENDERLOCATIONID);
                }
                return _DEFENDERLOCATION;
            } 
            set {
                _DEFENDERLOCATION = value;
            }
        }
        //FSINTERCEPTION
        public string CAPID { get{ return Get("CAPID");} set{ Set("CAPID", value); if(value == null){_CAP = null;}} }
        private GO _CAP { get; set; }
        public GO CAP { 
            get {
                if(GS != null && _CAP == null && CAPID != null){
                    _CAP = GS.PIECE(CAPID);
                }
                return _CAP;
            } 
            set {
                _CAP = value;
            }
        }  
        public string INTERCEPTEDGRPID { get{ return Get("INTERCEPTEDGRPID");} set{ Set("INTERCEPTEDGRPID", value); if(value == null){_INTERCEPTEDGRP = null;}} }
        private GO _INTERCEPTEDGRP { get; set; }
        public GO INTERCEPTEDGRP { 
            get {
                if(GS != null && _INTERCEPTEDGRP == null && INTERCEPTEDGRPID != null){
                    _INTERCEPTEDGRP = GS.PIECE(INTERCEPTEDGRPID);
                }
                return _INTERCEPTEDGRP;
            } 
            set {
                _INTERCEPTEDGRP = value;
            }
        }
    }
    public class GOMovable : GO {
        public GOMovable(GameScenario gs, Dictionary<string, string> pdata, Dictionary<string, string> odata, Dictionary<string, string> sdata) : base(gs, pdata, odata, sdata) { }
        public GOMovable() : base() { }
    }
    public class GOGeography : GO {
        public GOGeography(GameScenario gs, Dictionary<string, string> pdata, Dictionary<string, string> odata, Dictionary<string, string> sdata) : base(gs, pdata, odata, sdata) { }
        public GOGeography() : base() { }
    }
}