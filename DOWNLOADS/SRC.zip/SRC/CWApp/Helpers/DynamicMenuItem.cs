using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.IO;
using CWApp;

namespace CWApp.Helpers
{
    public class DynamicMenuItem
    {
        public string Header { get; set;}
        public string Command { get; set;}
        public DynamicMenuItem(string header, string command){
            Header = header;
            Command = command;
        }
    }
}