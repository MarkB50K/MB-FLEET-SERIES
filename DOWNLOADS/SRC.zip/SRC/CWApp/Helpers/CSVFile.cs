using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.IO;
using System.IO.Enumeration;

namespace CWApp.Helpers
{
    public class CSVFile
    {
        public List<Dictionary<String, String>> csvData { get; set; }
        public CSVFile(String filename){init(filename, new());}
        public CSVFile(String filename, List<string> fields){init(filename, fields);}
        private void init(string filename, List<string> fields){
            Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
            csvData = new List<Dictionary<string, string>>();
            using (StreamReader r = new StreamReader(filename))
            {
                string line;
                string[] header = null;
                while ((line = r.ReadLine()) != null)
                {
                    if(line.Length>1)
                    {
                        if(header == null){
                            header = CSVParser.Split(line);
                            fields.AddRange(header);
                        }
                        else
                        {
                            Dictionary<string, string> lineData = new Dictionary<string, string>();
                            string[] values = CSVParser.Split(line);
                            for(int i = 0; i < values.Count(); i++){
                                string fieldname = header[i];
                                string value = values[i];
                                if(fieldname.Length>0)
                                {
                                    lineData[fieldname] = value;
                                }
                            }
                            if(lineData.Count > 0)
                            {
                                csvData.Add(lineData);
                            }
                        }
                    }
                }
            }
        }
        public static int ParseInt(string sValue, int errorNumber)
        {
            int numberValue;
            if(int.TryParse(sValue, out numberValue))
            {
                return numberValue;
            }
            else
            {
                return errorNumber;
            }
        }

        public static double ParseDouble(string sValue, double errorNumber)
        {
            double numberValue;
            if(double.TryParse(sValue, out numberValue))
            {
                return numberValue;
            }
            else
            {
                return errorNumber;
            }
        }
        public static string ParseString(string sValue)
        {
            if(sValue == "")
            {
                return null;
            }
            else
            {
                return sValue;
            }
        }
    }
}