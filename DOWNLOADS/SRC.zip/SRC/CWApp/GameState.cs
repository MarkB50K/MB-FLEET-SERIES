using System;
using System.Collections.Generic;

namespace CWApp
{
    public class GameState
    {
        public Dictionary<string,string> state = new();
    }
    public class CombinedState{
        public Dictionary<string, Dictionary<string, string>> state = new();
    }
}