using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Media.Imaging;
//using CWApp.TWW;
using System.Dynamic;
using System.Windows.Navigation;
using System.Configuration;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows;
using System.Diagnostics;
using System.Net;
using System.Runtime.Serialization;
//using System.Drawing;

namespace CWApp
{
    public abstract class GameScenario
    {
        public double WorldSize { get; set; }
        public double MarkerSize { get; set; }
        public GO data = new();
        public abstract string TURNTITLE();
        public abstract string TURNPHASE();
        public string INSTRUCTIONS { get; set; }
        public abstract void SHOWINSTRUCTIONS();
        public string RESULT { get; set; }
        public string EXECUTINGPHASE { get{ return data.Get("_EXECUTINGPHASE");} set{ data.Set("_EXECUTINGPHASE", value);} }
        public string HELPTEXT { get; set; }
        public abstract void PostCallProcess();
        public GamePhase ExecutingGamePhase(){
            return _GamePhases.Where(n => n.UNIQUEPATH == EXECUTINGPHASE).SingleOrDefault();
        }
        public MainWindow _Window { get; set; }
        public Dictionary<GO, Dictionary<string, string>> _ChangedObjects = new();
        public void AddChildPhase(GamePhase gp){
            ChildGamePhases.Add(gp);
            AddGamePhase(gp);
        }
        public void AddGamePhase(GamePhase gp){
            _GamePhases.Add(gp);
        }
        public List<GamePhase> _GamePhases = new();
        public Dictionary<string, Dictionary<string, Dictionary<string, List<GO>>>> _CategorizedObjects = new();//TYPEVALUE - FIELDNAME - FIELDVALUE
        public Dictionary<string, List<GO>> _TypeObjects = new(){
            {GO.DOMAIN_PIECE, new()},
            {GO.DOMAIN_SHEET, new()},
            {GO.DOMAIN_LOCATION, new()},
            {GO.DOMAIN_CONNECTOR, new()},
            {GO.DOMAIN_PIECEACTION, new()},
            {GO.DOMAIN_LOGIC, new()}
        };      
        public List<string> GOCategorizedFields = new();
        public List<string> GOTypedFields = new();
        public List<string> GOIndicatorFields = new();
        public List<GO> stackedGOs = new();
        public List<GO> TYPE(string type){
            try{
                return _TypeObjects[type].ToList();
            } catch(Exception ex){
                MainWindow.Alert(ex.Message + ":" + type, false, false);
                return new();
            }
        }
        public List<GO> TYPE(string type, string categoryfield, string value){ 
            try{
                return _CategorizedObjects[type][categoryfield][value].ToList();
            } catch (Exception ex) {
                MainWindow.Alert(ex.Message + ":" + type + " " + categoryfield + " " + value, false, false);
                return new();
            }
        }
        public List<GO> LOCATIONS(){ return TYPE(GO.DOMAIN_LOCATION); }
        public GO LOCATION(string glid){
            return LOCATIONS().Where(n => n.ID == glid).SingleOrDefault();            
        }
        public List<GO> LOCATIONS(GO glc){
            return new(){glc.CONNECTORLOCATION, glc.CONNECTORLOCATION2};
        }
        public List<GO> PIECES(){ return TYPE(GO.DOMAIN_PIECE); }
        public GO PIECE(string id){
            try{
                return PIECES().Where(n => n.ID == id).Single();
            } catch (Exception ex) {
                MainWindow.Alert(ex.Message + ":" + id, true, true);
                throw;
            }
        }
        public List<GO> PIECESATLOCATION(string glid){
            return TYPE("PIECE", "GAMELOCATIONID", glid);
        }
        public abstract List<GO> STACKSATLOCATION(string glid);
        public List<GO> CONNECTORS(){ return TYPE(GO.DOMAIN_CONNECTOR); }
        public List<List<GO>> CONNECTIONS(string glid, string side){
            List<List<GO>> connections = new();
            foreach(GO connector in TYPE(GO.DOMAIN_CONNECTOR , "CONNECTORLOCATIONID", glid).Where(n => n.SIDE == side || n.SIDE == null)){
                connections.Add(new(){connector, connector.CONNECTORLOCATION2});
            }
            return connections;
        }
        public GO CONNECTOR(string glcid){
            return CONNECTORS().Where(n => n.ID == glcid).Single();
        }
        public GO CONNECTOR(GO gl, GO gl2, string side){
            return CONNECTOR(gl.ID, gl2.ID, side);
        }
        public GO CONNECTOR(string gl, string gl2, string side){
            return TYPE(GO.DOMAIN_CONNECTOR , "CONNECTORLOCATIONID", gl).Where(n => (n.SIDE == side || n.SIDE == null) && n.CONNECTORLOCATION2ID == gl2).FirstOrDefault();
        }
        public List<GO> LOGICS(){ return TYPE(GO.DOMAIN_LOGIC); }
        public GO LOGIC(string glcid){
            return LOGICS().Where(n => n.ID == glcid).Single();
        }
        public List<GO> ACTIONS(GO go){
            return TYPE(GO.DOMAIN_PIECEACTION).Where(n => n.ACTIONPIECEID == go.ID).ToList();
        }
        public List<GO> SHEETS(){ return TYPE(GO.DOMAIN_SHEET); }
        public GO SHEET(string id){
            return SHEETS().Where(n => n.ID == id).Single();
        }
        public List<GO> SHEETSATLOCATION(string glid){
            return TYPE("SHEET", "GAMELOCATIONID", glid);
        }
        public Ellipse GetIndicator(GO obj, Boolean reSize){
            return GetIndicator(obj, reSize, obj._ELLIPSESIZE);
        }
        public Ellipse GetIndicator(GO obj, Boolean reSize, double width){
            Ellipse e = new Ellipse();
            if(obj.ellipseIndicator != null){
                e = obj.ellipseIndicator;
            } else {
                reSize = true;
                Ellipse indicator = new()
                {
                    Stroke = System.Windows.Media.Brushes.White,
                    StrokeThickness = 3,
                    Fill = System.Windows.Media.Brushes.Black
                };
                _Window.WORLD_CANVAS.Children.Add(indicator);
                obj.ellipseIndicator = indicator;
                e = indicator;
            }
            if(reSize){
                e.Width = width * _Window.MapZoomLevel;
                e.Height = width * _Window.MapZoomLevel;                        
                Canvas.SetTop(e, (obj.y - (width * 0.5)) * _Window.MapZoomLevel);
                Canvas.SetLeft(e, (obj.x - (width * 0.5)) * _Window.MapZoomLevel);
            }
            return e;
        }
        public Line GetLine(GO glc, Boolean reSize){
            Line l = new();
            if(glc.lineIndicator != null){
                l = glc.lineIndicator;
            } else {
                reSize = true;
                l.Stroke = System.Windows.Media.Brushes.White;
                l.StrokeThickness = 3;
                _Window.WORLD_CANVAS.Children.Add(l);
                Canvas.SetLeft(l, 0);
                Canvas.SetTop(l, 0);
                glc.lineIndicator = l;
                string[] glcIDParts = glc.ID.Split('.');
                string opposite = glcIDParts[1] + "." + glcIDParts[0] + (glcIDParts.Length > 2 ? "." + glcIDParts[2] : "");
                CONNECTOR(opposite).lineIndicator = l;
            }
            if(reSize){
                List<GO> locations = LOCATIONS(glc);
                l.StrokeThickness = 3;
                l.X1 = locations[0].x * _Window.MapZoomLevel;
                l.X2 = locations[1].x * _Window.MapZoomLevel;
                l.Y1 = locations[0].y * _Window.MapZoomLevel;
                l.Y2 = locations[1].y * _Window.MapZoomLevel;
            }
            return l;
        }
        public Line GetLine2(GO glc, Boolean reSize){
            Line l = new();
            if(glc.lineIndicator2 != null){
                l = glc.lineIndicator2;
            } else {
                reSize = true;
                l.Stroke = System.Windows.Media.Brushes.White;
                l.StrokeThickness = 8;
                _Window.WORLD_CANVAS.Children.Add(l);
                Canvas.SetLeft(l, 0);
                Canvas.SetTop(l, 0);
                glc.lineIndicator2 = l;
                string[] glcIDParts = glc.ID.Split('.');
                string opposite = glcIDParts[1] + "." + glcIDParts[0] + (glcIDParts.Length > 2 ? "." + glcIDParts[2] : "");
                CONNECTOR(opposite).lineIndicator2 = l;
            }
            if(reSize){
                List<GO> locations = LOCATIONS(glc);
                double yDiff = Math.Abs(locations[0].y - locations[1].y);
                double xDiff = Math.Abs(locations[0].x - locations[1].x);
                Boolean negativeY = locations[0].y > locations[1].y;
                Boolean horizontal = yDiff < 10;
                l.StrokeThickness = 8;
                l.X1 = (horizontal ? locations.Average(n => n.x) : locations[0].x) * _Window.MapZoomLevel;
                l.X2 = (horizontal ? locations.Average(n => n.x) : locations[1].x) * _Window.MapZoomLevel;
                l.Y1 = (horizontal ? locations.Average(n => n.y) - (xDiff * 31.0 / 107.0)  : locations[0].y + ((locations[1].y - locations[0].y) * 0.666667)) * _Window.MapZoomLevel;
                l.Y2 = (horizontal ? locations.Average(n => n.y) + (xDiff * 31.0 / 107.0) : locations[1].y + ((locations[0].y - locations[1].y) * 0.666667)) * _Window.MapZoomLevel;
            }
            return l;
        }
        public Line GetSheetConnectorLine(GO sheet, Boolean reSize){
            Line l = new();
            if(sheet.lineIndicator != null){
                l = sheet.lineIndicator;
            } else {
                reSize = true;
                l.Stroke = System.Windows.Media.Brushes.White;
                l.StrokeThickness = 3;
                _Window.WORLD_CANVAS.Children.Add(l);
                Canvas.SetLeft(l, 0);
                Canvas.SetTop(l, 0);
                sheet.lineIndicator = l;
            }
            if(reSize){
                List<GO> locations = new();
                locations.Add(sheet.GAMELOCATION);
                locations.Add(sheet.SHEETPARENTPIECE != null && !sheet.SHEETPARENTPIECE.GAMELOCATION.LOCATIONHIDDEN && sheet.SHEETPARENTPIECE.SIDE != null ? sheet.SHEETPARENTPIECE.GAMELOCATION : sheet.GAMELOCATION);
                l.StrokeThickness = 3;
                l.X1 = locations[0].x * _Window.MapZoomLevel;
                l.X2 = locations[1].x * _Window.MapZoomLevel;
                l.Y1 = locations[0].y * _Window.MapZoomLevel;
                l.Y2 = locations[1].y * _Window.MapZoomLevel;
            }
            return l;
        }
        public List<GamePhase> ChildGamePhases = new();
        public void Start(){
            if(ChildGamePhases.Count > 0){
                ChildGamePhases[0].Start(true);
            }
        }
        public Boolean advanced = false;
        public void Advance(GamePhase childPhase){
            Advance(childPhase, true);
        }
        public abstract void PreCallProcess();
        public void Advance(GamePhase childPhase, bool ClearSelectedMarker){
            advanced = true;
            if(ClearSelectedMarker){_Window.ClearSelectedMarker();}                
            Boolean hasParent = childPhase.ParentGamePhase != null;
            List<GamePhase> siblings = hasParent ? childPhase.ParentGamePhase.ChildGamePhases : ChildGamePhases;
            //find next phase and execute it
            GamePhase nextPhase = null;
            if(siblings.Any()){
                if(siblings.Contains(childPhase)){
                    int i = siblings.IndexOf(childPhase);
                    if(i + 1 < siblings.Count){
                        nextPhase = siblings[(i + 1) % siblings.Count];
                    }
                }
            }
            if(nextPhase != null){
                nextPhase.Start(true);
            } else if(hasParent){
                childPhase.ParentGamePhase.End();
                childPhase.ParentGamePhase.Finish();
            } else {
                Finish();
            }
        }
        public abstract void Finish();
        public void ShuffleMarker(GO marker){
            if(marker.GAMELOCATION != InspectedLocation){
                _CategorizedObjects[marker.DOMAIN]["GAMELOCATIONID"][marker.GAMELOCATIONID].Remove(marker);
                _CategorizedObjects[marker.DOMAIN]["GAMELOCATIONID"][marker.GAMELOCATIONID].Add(marker);   
            }         
        }        
        public void ShuffleMarkerToBottom(GO marker){
            _CategorizedObjects[marker.DOMAIN]["GAMELOCATIONID"][marker.GAMELOCATIONID].Remove(marker);
            _CategorizedObjects[marker.DOMAIN]["GAMELOCATIONID"][marker.GAMELOCATIONID].Insert(0, marker);            
        }        
        public List<GO> LoadGameObjects(CWApp.Helpers.CSVFile data){
            List<GO> gameObjects = new();
            foreach(Dictionary<string, string> csvdata in data.csvData){
                gameObjects.Add(new GO(this, csvdata, csvdata, csvdata));
            }
            return gameObjects;
        }
        public void UpsertGOToGame(Dictionary<string, string> data, GO obj){
            if(obj == null){
                obj = new(this, data, null, data);
            } else {
                foreach(string Key in data.Keys){
                    obj.SavedState[Key] = data[Key];
                    obj.Set(Key, data[Key]);
                }
            }
        }
        public void SetTypedFields(GO obj){
            foreach(string k in GOTypedFields.Select(obj.Get)){
                if(k != null && k != ""){
                    if(!_TypeObjects.ContainsKey(k)){
                        _TypeObjects.Add(k, new());
                    }
                    _TypeObjects[k].Add(obj);
                    if(!_CategorizedObjects.ContainsKey(k)){
                        _CategorizedObjects.Add(k, new());
                        foreach(string category in GOCategorizedFields){
                            _CategorizedObjects[k].Add(category, new());
                        }
                    }
                }
            }
        }
        public void Categorize(GO obj){
            Categorize(obj, null, null, null);
        }
        public void Categorize(GO obj, string field, string oldValue, string newValue){
            foreach(string type in GOTypedFields.Select(obj.Get)){
                if(type != null && type != ""){
                    if(field != null){
                        Dictionary<string, List<GO>> dict = _CategorizedObjects[type][field];
                        if(oldValue != null && oldValue != ""){
                            if(!dict.ContainsKey(oldValue)){
                                dict.Add(oldValue, new());
                            }
                            dict[oldValue].Remove(obj);
                        }
                        if(newValue != null && newValue != ""){
                            if(!dict.ContainsKey(newValue)){
                                dict.Add(newValue, new());
                            }
                            dict[newValue].Add(obj);
                        }
                        continue;
                    }                               
                    foreach(string eachfield in GOCategorizedFields){
                        string val = obj.Get(eachfield);
                        if(val != null){
                            if(_CategorizedObjects[type].ContainsKey(eachfield)){
                                _CategorizedObjects[type][eachfield].Add(val, new());
                            }
                            _CategorizedObjects[type][eachfield][val].Add(obj);
                        }
                    }
                }
            }
        }
        public abstract List<Image> GOImages(GO obj, Boolean refreshAll);
        public Dictionary<Image, GO> GOImageMap = new();
        public abstract List<CWRectangleWrapper> GORectangles(GO obj, Boolean refreshAll);
        public abstract string GetScenarioSpecificImage(int column, int row);
        public abstract void ProcessCanvasRightClick(double x, double y);
        public abstract void ProcessMenu(GO obj, bool forceExpansion, bool stackMode);
        public abstract void ProcessDoubleLeftClick(GO obj);
        public abstract void ProcessDoubleRightClick(GO obj);
        public abstract void ProcessStackMenuClick(string header);
        public abstract void ProcessMapMouseMove(double x, double y);
        public abstract string GetToolTip(int column, int row);
        public abstract string INFO(GameScenario GS, GO obj);
        public abstract void ScenarioButtonClick(int column, int row);
        public void LoadGameState(CombinedState combinedState, Dictionary<string, GO> gameObjects, GameState configurationState)
        {
            CombinedState cs = _Window.combinedState;
            foreach(string key in cs.state["SCENARIO.VARS"].Keys){
                data.Set(key, cs.state["SCENARIO.VARS"][key]);
            }
            foreach(string key in configurationState.state.Keys){
                if(!cs.state["SCENARIO.VARS"].ContainsKey(key)){
                    data.Set(key, configurationState.state[key]);
                    cs.state["SCENARIO.VARS"].Add(key, configurationState.state[key]);
                }
            }
            foreach(string id in cs.state.Keys.Where(n => n != "SCENARIO.VARS")){
                UpsertGOToGame(cs.state[id], gameObjects.ContainsKey(id) ? gameObjects[id] : null);
            }
        }
        public abstract void PostLoadProcessing();
        public abstract void PreLoadProcessing();
        public void SetInstructions(List<string> instructions){
            if(instructions.Count == 0){
                return;
            }
            string sInstructions = "";
            for(int i = 0; i < instructions.Count; i++){
                string instruction = instructions[i];
                sInstructions += (sInstructions.Length > 0 ? "          " : "") + instruction;
            }
            INSTRUCTIONS = sInstructions;
        }
        public void CHANGELOCATION(GO obj, string newLocId)
        {
            CHANGELOCATION(obj, newLocId, null);
        }
        public void CHANGELOCATION(GO obj, GO newLoc)
        {
            CHANGELOCATION(obj, newLoc.ID, newLoc);
        }
        public void CHANGELOCATION(GO obj, string newLocId, GO newLoc){
            GO oldLoc = obj.GAMELOCATION;
            obj.GAMELOCATIONID = newLocId;
            obj.GAMELOCATION = newLoc;
            if(oldLoc != null && !oldLoc.HIDDEN && oldLoc.ID != newLocId){_Window.DrawMarkerStack(obj.DOMAIN, oldLoc);}
            //ShuffleMarker(obj);
            newLoc = obj.GAMELOCATION;
            if(newLoc.HIDDEN){
                _Window.HideMarker(obj);
            } else {
                _Window.DrawMarkerStack(obj.DOMAIN, newLoc);
            }
            if(obj.DOMAIN == GO.DOMAIN_SHEET && (oldLoc != newLoc || newLocId == obj.SHEETANCHORLOCATIONID)){
                foreach(GO loc in TYPE(GO.DOMAIN_LOCATION, "PARENTSHEETID", obj.ID)){
                    GO sheetLoc = newLoc;
                    loc.x = sheetLoc.x + loc.XCOORD - obj.IMAGEWIDTHVALUE * 0.5;
                    loc.y = sheetLoc.y + loc.YCOORD - obj.IMAGEHEIGHTVALUE * 0.5;
                    GetIndicator(loc, true);
                }
            }
            obj.PARENTSHEETID = newLoc.PARENTSHEETID;
            obj.PARENTSHEET = newLoc.PARENTSHEET;
        }
        public void CHANGELOCATION(string objid, string newLocId){
            CHANGELOCATION(objid.StartsWith("SHEET") ? SHEET(objid) : PIECE(objid), newLocId);
        }
        public void DISCARD(GO obj){
            CHANGELOCATION(obj, "RECYCLEBIN");
            REMOVEINTERACTIVE(obj);
            obj.RECYCLED = true;
            obj.SIDE = null;
        }
        public void AddAction(GO marker, string action){
            Dictionary<string, string> dict = new(){
                ["DOMAIN"] = GO.DOMAIN_PIECEACTION,
                ["ACTION"] = action,
                ["ACTIONPIECEID"] = marker.ID,
                ["ID"] = marker.ID + GO.DELIM + action
            };

            GO gpa = new(null, dict, null, null);
            _TypeObjects[GO.DOMAIN_PIECEACTION].Add(gpa);
        }
        public GO GetClosestLocation(List<GO> locations, double px, double py){
            return locations.OrderBy(x => GetDistance(x, px, py)).First();
        }
        public double GetDistance(GO location, double x, double y){
            return Math.Sqrt(Math.Pow(location.x - x, 2) + Math.Pow(location.y - y, 2));
        }
        public void ResetBetweenUpdates(){
            //clear all actions
            _TypeObjects[GO.DOMAIN_PIECEACTION].Clear();
        }
        public void ResetBetweenPhases(){
            SelectedMarker = null;
            if(InspectedLocation != null){
                _Window.DrawMarkerStack(GO.DOMAIN_PIECE, InspectedLocation);
                InspectedLocation = null;
            }
            InteractionMap.Clear();
        }
        public GO RANDOMGAMEOBJECT(List<GO> gos){
            if(gos.Any()){
                return gos[RANDOMINT(gos.Count)];
            } else {
                return null;
            }
        }
        public int RANDOMINT(int count){
            return CWConstants._random.Next(count);
        }
        public Boolean CANINTERACT(GO obj){
            return obj != null && InteractionMap.ContainsKey(obj);
        }
        public abstract Boolean CANACTION(GO obj);
        public abstract Boolean CANDRAG(GO obj);
        public abstract List<GO> DRAGTARGETS(GO obj);
        public GO NEXTINTERACTIVE(GO go){
            return NEXT(InteractionMap.Keys.ToList(), go);
        }
        public GO NEXT(List<GO> objs, GO obj){
            GO pickedMarker = obj;
            if(objs.Any()){
                if(objs.Contains(obj)){
                    int i = objs.IndexOf(obj);
                    pickedMarker = objs[(i + 1) % objs.Count];
                }
            }
            return pickedMarker;
        }
        public GO REMOVEINTERACTIVE(GO obj){
            GO pickedMarker = NEXTINTERACTIVE(obj);
            InteractionMap.Remove(obj);
            if(pickedMarker == obj){pickedMarker = null;}
            return pickedMarker;
        }
        public GO PREVIOUSINTERACTIVE(GO obj){
            return PREVIOUS(InteractionMap.Keys.ToList(), obj);
        }
        public GO PREVIOUS(List<GO> objs, GO obj){
            GO pickedMarker = obj;
            if(objs.Any()){
                if(objs.Contains(obj)){
                    int i = objs.IndexOf(obj);
                    pickedMarker = objs[(i - 1 + objs.Count) % objs.Count];
                }
            }
            return pickedMarker;
        }
        public abstract void ProcessControlClick(GO marker);
        //COMMON DATA STRUCTURES
        public Dictionary<GO, List<GO>> InteractionMap = new();
        public GO SelectedMarker = null; 
        public GO InspectedLocation = null;               
        public string Get(string key){
            return data.Get(key);
        }
        public int GetInt(string key){
            return data.GetInt(key);
        }
        public double GetDouble(string key){
            return data.GetDouble(key);
        }
        public Boolean GetBoolean(string key){
            return data.GetBoolean(key);
        }
        public void Set(string key, string value){
            data.Set(key, value);
        }
        public void SetInt(string key, int value){
            data.SetInt(key, value);
        }
        public void SetDouble(string key, double value){
            data.SetDouble(key, value);
        }
        public void SetBoolean(string key, Boolean value){
            data.SetBoolean(key, value);
        }
        public void IncrementInt(string key, int value){
            data.IncrementInt(key, value);
        }
        public void IncrementDouble(string key, double value){
            data.IncrementDouble(key, value);
        }
    }
    public abstract class GamePhase
    {
        public string ID { get; set; }
        public string UNIQUEPATH { get; set; }
        public Boolean DragOver = false;
        public Boolean DragDrop = false;
        public Boolean ManualAdvance = false;
        public Boolean MapClick = false;
        public Boolean MapMouseMove = false;
        public Boolean UniversalDrop = false;
        public Boolean InProgressSave = false;
        public Boolean NoShowLocationIndicators = false;
        public Boolean ShowExpandedMenu = true;
        public Double zoomLevel = 0.8;
        public MainWindow Window(){ return GS._Window; }
        public GamePhase ParentGamePhase { get; set; }
        public GameScenario GS { get; set; }
        public GamePhase(string pid, GamePhase pparent, GameScenario pscenario){
            string path = "";
            GamePhase tmp = pparent;
            while(tmp != null){
                path = tmp.ID + " | " + path;
                tmp = tmp.ParentGamePhase;
            }
            ID = pid;
            UNIQUEPATH = path + pid;
            ParentGamePhase = pparent;
            GS = pscenario;
        }
        public List<GamePhase> ChildGamePhases = new();
        public void AddGamePhase(GamePhase gp){
            ChildGamePhases.Add(gp);
            GS.AddGamePhase(gp);
        }
        public void Start(Boolean init){
            if(ChildGamePhases.Count > 0){
                if(ProcessCheck()){
                    Init();
                    ChildGamePhases[0].Start(init);
                } else {
                    GS.Advance(this);
                }
            } else {
                GS.ResetBetweenUpdates();
                if(GS.advanced){
                    GS.ResetBetweenPhases();
                }
                GS.EXECUTINGPHASE = UNIQUEPATH;
                Execute(init);
            }
        }
        public abstract Boolean ProcessCheck();
        public abstract void Execute(Boolean init);
        public abstract void Update(String data);
        public abstract void Update(double x, double y);
        public abstract void Finish();
        public abstract void Init();
        public abstract void End();
        public string Get(string key){
            return GS.data.Get(key);
        }
        public int GetInt(string key){
            return GS.data.GetInt(key);
        }
        public double GetDouble(string key){
            return GS.data.GetDouble(key);
        }
        public Boolean GetBoolean(string key){
            return GS.data.GetBoolean(key);
        }
        public void Set(string key, string value){
            GS.data.Set(key, value);
        }
        public void SetInt(string key, int value){
            GS.data.SetInt(key, value);
        }
        public void SetDouble(string key, double value){
            GS.data.SetDouble(key, value);
        }
        public void SetBoolean(string key, Boolean value){
            GS.data.SetBoolean(key, value);
        }
        public void IncrementInt(string key, int value){
            GS.data.IncrementInt(key, value);
        }
        public void IncrementDouble(string key, double value){
            GS.data.IncrementDouble(key, value);
        }
    }
    public abstract class GamePhaseAutomated : GamePhase
    {
        public GamePhaseAutomated(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario){}
        public override bool ProcessCheck()
        {
            return true;
        }
        public override void Update(string pData)
        {}
        public override void Update(double x, double y)
        {}
        public override void Finish()
        {}
        public override void Init()
        {}
        public override void End()
        {}
    }
    public abstract class GamePhaseInteractive : GamePhase
    {
        public GamePhaseInteractive(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario){}
        public override bool ProcessCheck()
        {
            return true;
        }
        public override void Finish()
        {}
        public override void Update(double realX, double realY)
        {
        }        
        public override void Init()
        {}
        public override void End()
        {}
    }
    public abstract class GamePhaseGroupLogic : GamePhase
    {
        public GamePhaseGroupLogic(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario){}
        public override void Execute(Boolean init){}
        public override void Update(string pData)
        {}
        public override void Update(double x, double y)
        {}
        public override void Finish()
        {
            GS.Advance(this);
        }
    }
    public abstract class GamePhaseGroup : GamePhaseGroupLogic
    {
        public GamePhaseGroup(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario){}
        public override void Init(){}
        public override void End(){}
    }
    public abstract class GamePhaseLoopLogic : GamePhase
    {
        public GamePhaseLoopLogic(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario){}
        public override void Execute(Boolean init){}
        public override void Update(string pData){}
        public override void Update(double x, double y)
        {}
        public override void Finish()
        {
            Start(true);
        }
    }
    public abstract class GamePhaseLoop : GamePhaseLoopLogic
    {
        public GamePhaseLoop(string pid, GamePhase pparent, GameScenario pscenario) : base(pid, pparent, pscenario){}
        public override void Init(){}
        public override void End(){}
    }
}