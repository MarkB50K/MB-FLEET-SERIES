using System;
using System.Windows.Media;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Shapes;

namespace CWApp
{
    public class CWRectangleWrapper{
        public double width = 0;
        public double height = 0;
        public double x { get; set; }
        public double y { get; set; }
        public double thickness = 1;
        public Rectangle rect { get; set; }
        public Boolean show { get; set; }
        public int z = 0;
    }
    public static class CWConstants
    {
        public static Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
        public static Random _random = new Random();


        public static List<string> turnNames = new List<string>
        {
            "Jan/Feb",
            "Mar/Apr",
            "May/Jun",
            "Jul/Aug",
            "Sep/Oct",
            "Nov/Dec"
        };

        public static double IMPULSES_PER_TURN = 6.0; //throttles bp production - winter, goes up by 2 in spring, fall, up by another 2 in summer
        public static double PRODUCTION_INCREASE_FACTOR = 0.1;  //multipler against production as time passes
        public static double PRODUCTION_PER_IMPULSE_FACTOR = 0.15;
        public static double PURCHASE_SIZE = 10;
        //HexSide
        public static int NORMAL = 0;
        public static int RIVER = 1;
        public static int STRAIT = 2;
        public static int LAK_HEXSIDE = 3;
        public static int SEA_HEXSIDE = 4;
        public static int ALPINE = 5;
        public static int COASTAL = 6;
        public static int QAT_HEXSIDE = 7;
        public static int RAIL = 10;
        public static int BOUNDARY = 100;
        public static int W = 0;
        public static int NW = 1;
        public static int NE = 2;
        public static int E = 3;
        public static int SE = 4;
        public static int SW = 5;
        public static int E_W = 1;
        public static int NW_SE = 2;
        public static int NE_SW = 3;
        public static List<int> landSideTypes = new List<int>{NORMAL, RIVER, STRAIT};

        //HEXWRAPPER
        //production awards
        public static double BP_PER_FACTORY = 1.0;
        public static double BP_PER_CITY = 0.25;
        public static double BP_PER_PORT = 0.10;

        //one time awards
        public static int FINE = 0;
        public static int RAIN = 1;
        public static int SNOW = 2;
        public static int STORM = 3;
        public static int BLIZZARD = 4;
        public static int SEA = 0;
        public static int LAK = 1;
        public static int CLR = 2;
        public static int FOR = 3;
        public static int JNG = 4;
        public static int MTN = 5;
        public static int SWP = 6;
        public static int DES = 7;
        public static int DMTN = 8;
        public static int TUN = 9;
        public static int ICE = 10;
        public static int QAT = 11;
        public static List<int> railTerrains = new List<int>
        {
            CLR,
            DES,
            FOR,
            JNG,
            SWP,
            MTN,
            DMTN,
            TUN,
            ICE
        };
        public static List<int> railHexSides = new List<int>
        {
            NORMAL,
            RIVER,
            STRAIT
        };
        public static List<string> terrainTypeNames = new List<string>
        {
            "SEA",
            "LAK",
            "CLR",
            "FOR",
            "JNG",
            "MTN",
            "SWP",
            "DES",
            "DMTN",
            "TUN",
            "ICE",
            "QAT"
        };
        public static double GetTerrainModifier(int terrainType)
        {
            if(terrainType == CLR || terrainType == DES || terrainType == TUN)
                return 1.0;
            else if(terrainType == FOR || terrainType == ICE)
                return 0.9;
            else if(terrainType == JNG)
                return 0.7;
            else if(terrainType == MTN || terrainType == SWP || terrainType == DMTN)
                return 0.5;
            else
                return 0;
        }
        public static List<List<int>> terrainShades = new List<List<int>>() {
            //RGB
            new List<int>() {0,0,0}, //SEA
            new List<int>() {0,0,0}, //LAK
            new List<int>() {204,215,161}, //CLR
            new List<int>() {101,138,43}, //FOR
            new List<int>() {80,136,17}, //JNG
            new List<int>() {116,114,102}, //MTN
            new List<int>() {105,162,124}, //SWP
            new List<int>() {224,194,103}, //DES
            new List<int>() {169,139,45}, //DMTN
            new List<int>() {255,255,255}, //TUN
            new List<int>() {255,255,255}, //ICE
            new List<int>() {120,60,60} //QAT
        };
        public static string getTerrainShader(int side, int terrainType)
        {
            return getTerrainShader(terrainShades[terrainType]);
        }
        public static string getTerrainShader(List<int> colors)
        {
            int red = colors[0];
            int green = colors[1];
            int blue = colors[2];
            return "#" + red.ToString("X2") + green.ToString("X2") + blue.ToString("X2");
        }
        public static int[,,] weatherMatrix = new int[,,]
        {
            {
                {RAIN, FINE, FINE, FINE, FINE, FINE, 0},
                {RAIN, RAIN, FINE, FINE, FINE, FINE, 0},
                {STORM, RAIN, FINE, FINE, RAIN, FINE, 0},
                {SNOW, STORM, FINE, FINE, RAIN, FINE, 1},
                {SNOW, SNOW, RAIN, FINE, RAIN, FINE, 1},
                {SNOW, SNOW, RAIN, FINE, STORM, FINE, 1},
                {SNOW, SNOW, STORM, FINE, STORM, FINE, 1},
                {BLIZZARD, SNOW, STORM, FINE, STORM, FINE, 2},
                {BLIZZARD, SNOW, SNOW, FINE, STORM, RAIN, 2},
                {BLIZZARD, BLIZZARD, SNOW, FINE, STORM, RAIN, 2},
                {BLIZZARD, BLIZZARD, BLIZZARD, RAIN, STORM, RAIN, 3},
                {BLIZZARD, BLIZZARD, BLIZZARD, RAIN, STORM, STORM, 3}
            },
            {
                {BLIZZARD, BLIZZARD, SNOW, RAIN, STORM, STORM, 2},
                {BLIZZARD, SNOW, STORM, RAIN, STORM, STORM, 1},
                {SNOW, SNOW, RAIN, RAIN, STORM, RAIN, 0},
                {SNOW, STORM, RAIN, FINE, STORM, RAIN, 0},
                {STORM, STORM, RAIN, FINE, RAIN, FINE, 0},
                {STORM, RAIN, FINE, FINE, RAIN, FINE, 0},
                {RAIN, RAIN, FINE, FINE, RAIN, FINE, 0},
                {RAIN, FINE, FINE, FINE, FINE, FINE, 0},
                {RAIN, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0}
            },
            {
                {SNOW, STORM, RAIN, STORM, STORM, STORM, 2},
                {STORM, RAIN, FINE, STORM, RAIN, RAIN, 1},
                {RAIN, FINE, FINE, STORM, RAIN, FINE, 0},
                {FINE, FINE, FINE, RAIN, FINE, FINE, 0},
                {FINE, FINE, FINE, RAIN, FINE, FINE, 0},
                {FINE, FINE, FINE, RAIN, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0}
            },
            {
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, RAIN, FINE, FINE, 0},
                {FINE, FINE, FINE, RAIN, FINE, FINE, 0},
                {FINE, FINE, FINE, RAIN, FINE, FINE, 0},
                {FINE, FINE, FINE, STORM, FINE, FINE, 0},
                {FINE, FINE, FINE, STORM, FINE, FINE, 0},
                {FINE, FINE, FINE, STORM, FINE, FINE, 0},
                {FINE, FINE, FINE, STORM, FINE, FINE, 0},
                {FINE, FINE, FINE, STORM, FINE, FINE, 0},
                {FINE, FINE, FINE, STORM, FINE, FINE, 1},
                {RAIN, FINE, FINE, STORM, RAIN, RAIN, 2},
                {STORM, RAIN, RAIN, STORM, STORM, SNOW, 2}
            },
            {
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {RAIN, FINE, FINE, RAIN, FINE, FINE, 0},
                {RAIN, FINE, FINE, RAIN, FINE, FINE, 0},
                {RAIN, RAIN, FINE, RAIN, FINE, FINE, 0},
                {RAIN, RAIN, FINE, STORM, FINE, FINE, 1},
                {STORM, RAIN, RAIN, STORM, FINE, FINE, 1},
                {STORM, STORM, RAIN, STORM, RAIN, FINE, 2},
                {SNOW, STORM, RAIN, STORM, RAIN, RAIN, 2},
                {BLIZZARD, SNOW, STORM, STORM, STORM, RAIN, 2}
            },
            {
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {FINE, FINE, FINE, FINE, FINE, FINE, 0},
                {RAIN, FINE, FINE, FINE, FINE, FINE, 0},
                {RAIN, RAIN, FINE, FINE, FINE, FINE, 0},
                {STORM, RAIN, FINE, FINE, FINE, FINE, 0},
                {SNOW, STORM, RAIN, FINE, RAIN, FINE, 1},
                {SNOW, SNOW, RAIN, FINE, RAIN, FINE, 1},
                {SNOW, SNOW, RAIN, FINE, RAIN, FINE, 1},
                {BLIZZARD, SNOW, STORM, FINE, STORM, FINE, 2},
                {BLIZZARD, SNOW, SNOW, RAIN, STORM, RAIN, 2},
                {BLIZZARD, BLIZZARD, SNOW, RAIN, STORM, RAIN, 2},
                {BLIZZARD, BLIZZARD, BLIZZARD, STORM, STORM, RAIN, 2}
            }
        };
    }
}