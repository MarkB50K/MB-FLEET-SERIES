﻿using System;
using System.Data;
using System.Configuration;
using System.Reflection;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CWApp.Helpers;
using log4net;
using Newtonsoft.Json;
using Microsoft.Win32;
using System.Windows.Markup;
using System.Windows.Automation;
using System.Windows.Media.TextFormatting;
namespace CWApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //files we need
        //public string BaseDir = System.AppDomain.CurrentDomain.BaseDirectory;//"C:/Users/MBRP/Data";
        public string AppDir;// = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);//System.AppDomain.CurrentDomain.BaseDirectory;// + "/CWApp";
        string gameDir = null;
        string scenarioDir = null;
        string sessionDir = null;
        string GetImageDir(){
            return AppDir + "/Images";
        }
        public string GetScenarioImageDir(){
            return AppDir + "/" + gameDir + "/Images";
        }
        const string GameStateFile = "1.scenario.cwsav";
        public string GetGameSaveDir(){
            return AppDir + "/" + gameDir + "/Scenarios/" + scenarioDir + "/SavedGames";
        }
        public string GetGameSessionDir(){
            return GetGameSaveDir() + "/" + sessionDir;
        }
        string GetGameStateFile(){
            return GetGameSessionDir() + "/" + GameStateFile;
        }
        const string GameObjectFile = "GameObjects.csv";
        public List<string> GameObjectFields = new();
        string GetGOFile(){
            return AppDir + "/" + gameDir + "/Scenarios/" + scenarioDir + "/" + GameObjectFile;
        }
        const string GameLocationFile = "GameLocations.csv";
        public List<string> GameLocationFields = new();
        string GetGLFile(){
            return AppDir + "/" + gameDir + "/Scenarios/" + scenarioDir + "/" + GameLocationFile;
        }
        const string GameConnectorFile = "GameConnectors.csv";
        public List<string> GameConnectorFields = new();
        string GetGConnFile(){
            return AppDir + "/" + gameDir + "/Scenarios/" + scenarioDir + "/" + GameConnectorFile;
        }
        JsonSerializerSettings JSONSettings = new()
        {
            Formatting = Newtonsoft.Json.Formatting.Indented
        };
        public const int Z_HIDDEN = 1;
        public const int Z_BORDER_INDICATOR = 1004;
        public const int Z_CONNECTOR_INDICATOR = 99;
        public const int Z_MAP_CONNECTOR_INDICATOR = 15;
        public const int Z_LOCATION_INDICATOR = 99;
        public const int Z_MARKER_INDICATOR = 99; 
        public const int Z_MARKER = 100;
        public const int Z_DRAGGING_MARKER_INDICATOR = 1000015; 
        public const int Z_DRAGGING_MARKER = 1000025;
        public int XY_MARKER_OFFSET = 3;
        public const int Z_MARKER_OFFSET = 10;
        public const int Z_MARKER_RECTANGLE_OFFSET = 1;
        public double MapZoomLevel = 1;
        public GameState configurationState;
        public CombinedState combinedState = new();
        public GO DraggingGO;
        public GO OriginGO;
        public List<GO> DropTargets;
        public HashSet<GO> ExpandedGOs = new();
        //data structures
        Dictionary<string, HashSet<GO>> GOsToRefresh = new(){
            {GO.DOMAIN_PIECE, new()},
            {GO.DOMAIN_SHEET, new()}
        };
        Dictionary<string, HashSet<GO>> GOsToDraw = new(){
            {GO.DOMAIN_PIECE, new()},
            {GO.DOMAIN_SHEET, new()}
        };
        public Dictionary<string, HashSet<GO>> GOIndicatorsToDraw = new(){
            {"GRAY", new()},
            {"LIGHTGRAY", new()},
            {"BLACK", new()},
            {"WHITE", new()},
            {"RED", new()},
            {"LIGHTBLUE", new()}
        };
        public Dictionary<string, HashSet<GO>> GOIndicatorsDrawn = new(){
            {"GRAY", new()},
            {"LIGHTGRAY", new()},
            {"BLACK", new()},
            {"WHITE", new()},
            {"RED", new()},
            {"LIGHTBLUE", new()}
        };
        Dictionary<string, SolidColorBrush> GOIndicatorColorMap = new(){
            {"RED", System.Windows.Media.Brushes.Red},
            {"WHITE", System.Windows.Media.Brushes.White},
            {"LIGHTGRAY", System.Windows.Media.Brushes.LightGray},
            {"GRAY", System.Windows.Media.Brushes.Gray},
            {"BLACK", System.Windows.Media.Brushes.Black},            
            {"LIGHTBLUE", System.Windows.Media.Brushes.LightBlue}
        };
        GameScenario GS;
        Ellipse MarkerIndicator = new Ellipse();
        public Menu MarkerMenu{ get{return (Menu)this.FindName("menuMarkerMenu");}}
        public ContextMenu MapDynamicMenu = new ContextMenu();
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public Canvas WORLD_CANVAS{ get{return (Canvas)this.FindName("worldCanvas");}}
        public ScrollViewer CANVAS_SCROLL_VIEWER{ get{return (ScrollViewer)this.FindName("svCanvas");}}
        Image SELECTED_MARKER_IMAGE{ get{return (Image)this.FindName("imgSelectedMarker");}}
        Image CLICKED_MARKER_IMAGE{ get{return (Image)this.FindName("imgClickedMarker");}}
        bool VIEWREFRESHED = false;
        public void throwError(Exception ex)
        {
            log.Error("Error: " + ex.Message + " " + ex.StackTrace);
            MessageBox.Show(ex.Message.ToString());
        }
        public string GenerateSessionID(){
            return scenarioDir + "." + DateTime.Now.ToString("yyyyMMdd.HHmmss");
        }
        public MainWindow()
        {
            try
            {
                var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
                log4net.Config.XmlConfigurator.Configure(logRepository, new FileInfo(ConfigurationManager.AppSettings.Get("log4net-config-file")));
                InitializeComponent();                
                //initialize marker indicator
                WORLD_CANVAS.Children.Add(MarkerIndicator);
                MarkerIndicator.Width = 10;
                MarkerIndicator.Height = 10;
                MarkerIndicator.Stroke = Brushes.Black;
                MarkerIndicator.StrokeThickness = 3;

                //MarkerDynamicMenu = (Menu)this.FindName("MarkerMenu");
                //WORLD_CANVAS.Children.Add(MarkerDynamicMenu);
                HideMenus();
                Canvas.SetTop(MarkerIndicator, 0);
                Canvas.SetLeft(MarkerIndicator, 0);
                Canvas.SetZIndex(MarkerIndicator, Z_HIDDEN);
                ///CHOOSE SAVE DIRECTORY AND LOAD GAME STATE
                //determine session (savegame)
                string[] clargs = System.Environment.GetCommandLineArgs();
                AppDir = clargs.Length > 1 ? clargs[1] : System.IO.Path.GetDirectoryName(clargs[0]);
                OpenFileDialog openFileDialog = new()
                {
                    Filter = "CW App Saved Games (*.cwsav)|*.cwsav"
                };
                string dir = System.IO.Path.GetFullPath(AppDir + "/FS/Scenarios/CombinedGame/SavedGames");
			    openFileDialog.InitialDirectory = dir;
			
			    if(openFileDialog.ShowDialog() == true){
                    string oFDfn = openFileDialog.FileName;
                    DirectoryInfo dirInfo = new(System.IO.Path.GetDirectoryName(oFDfn));
                    scenarioDir = dirInfo.Parent.Parent.Name;
                    gameDir = dirInfo.Parent.Parent.Parent.Parent.Name;
				    sessionDir = dirInfo.Name;
                    if(sessionDir == "NEW"){
                        configurationState = JsonConvert.DeserializeObject<GameState>(File.ReadAllText(GetGameStateFile()));
                        sessionDir = GenerateSessionID();
                        Directory.CreateDirectory(GetGameSessionDir());
                    }
                } else {
                    return;
                }
                try{
                    combinedState = JsonConvert.DeserializeObject<CombinedState>(File.ReadAllText(GetGameStateFile()));
                }
                catch(Exception e){
                    String debug = e.Message;
                    combinedState.state.Add("SCENARIO.VARS", new());
                }
                /*
                string[] ofiles = Directory.GetFiles(GetGameSessionDir(), "*.o.txt");
                List<GameState> objs = new();
                foreach(string ofile in ofiles){
                    objs.Add(JsonConvert.DeserializeObject<GameState>(File.ReadAllText(ofile)));
                }*/
                //scenario setup
                GS = null;
                switch(gameDir){
                    case "TWW":
                        switch(scenarioDir){
                            case "CombinedGame":
                                //GS = new TWW.ScenarioCombined(scenarioDir, this);
                                break;
                            default:
                                break;
                        }
                        break;
                    case "FS":
                        switch(scenarioDir){
                            case "CombinedGame":
                                GS = new FS.ScenarioCombined(scenarioDir, this);
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;
                }
                GS.PreLoadProcessing();
                Dictionary<string, GO> allGOsMap = new();
                GS.LoadGameObjects(new CSVFile(GetGOFile(), GameObjectFields)).ForEach(n => allGOsMap.Add(n.ID, n));
                GS.LoadGameObjects(new CSVFile(GetGLFile(), GameLocationFields)).ForEach(n => allGOsMap.Add(n.ID, n));
                GS.LoadGameObjects(new CSVFile(GetGConnFile(), GameConnectorFields)).ForEach(n => allGOsMap.Add(n.ID, n));
                GS.LoadGameState(combinedState, allGOsMap, configurationState);
                GS.PostLoadProcessing();
                
                //kick off where we left off
                GamePhase startPhase = GS.ExecutingGamePhase();
                GS.PreCallProcess();
                if(startPhase == null){
                    GS.Start();
                }
                else{
                    startPhase.Execute(true);            
                }
                foreach(GO location in GS.PIECES().Where(n => n.GAMELOCATIONID != null).Select(n => n.GAMELOCATION).Distinct()){
                    DrawMarkerStack(GO.DOMAIN_PIECE, location, false);
                } 
                foreach(GO location in GS.SHEETS().Where(n => n.GAMELOCATIONID != null).Select(n => n.GAMELOCATION).Distinct()){
                    DrawMarkerStack(GO.DOMAIN_SHEET, location, false);
                } 
                HandleScenarioCall(true, false);
                if(GS.advanced){
                    SaveGameStateToLocalFiles(); 
                    GS.advanced = false;
                }
                ////////
                //SaveGameStateToLocalFiles(); 
                ///////
                //END LOAD GAME STATE
                
                List<Image> menuImages = new(){
                    (Image)this.FindName("imgPreviousMarker"),
                    (Image)this.FindName("imgNextMarker")
                };
                List<string> menuImageFilenames = new(){"Icon_Previous.png", "Icon_Next.png"};

                for(int i = 0; i < menuImages.Count; i++){
                    Image img = menuImages[i];
                    string filename = menuImageFilenames[i];
                    SetImage(img, GetImageDir() + "/" + filename, 30);
                }
                for(int row = 0; row <= 1; row++){
                    for(int column = 0; column <= 9; column++){
                        Image ssImage = (Image)this.FindName("imgbtn0" + column + "0" + row);
                        string filename = GS.GetScenarioSpecificImage(column, row);
                        SetImage(ssImage, GetScenarioImageDir() + "/" + filename, 30);
                    }
                }
                SetImage(CLICKED_MARKER_IMAGE, GetImageDir() + "/EMPTY.png", 200);
                if(GS.ExecutingGamePhase().zoomLevel != MapZoomLevel){
                    MapZoomLevel = GS.ExecutingGamePhase().zoomLevel;
                    ZoomAll();
                } else {
                    SetBackground();
                    SetImageForMaps();
                }
                ((Button)this.FindName("btn0000")).ToolTip = GS.GetToolTip(0, 0);
                ((Button)this.FindName("btn0001")).ToolTip = GS.GetToolTip(0, 1);
                ((Button)this.FindName("btn0100")).ToolTip = GS.GetToolTip(1, 0);
                ((Button)this.FindName("btn0101")).ToolTip = GS.GetToolTip(1, 1);
                ((Button)this.FindName("btn0200")).ToolTip = GS.GetToolTip(2, 0);
                ((Button)this.FindName("btn0201")).ToolTip = GS.GetToolTip(2, 1);
                ((Button)this.FindName("btn0300")).ToolTip = GS.GetToolTip(3, 0);
                ((Button)this.FindName("btn0301")).ToolTip = GS.GetToolTip(3, 1);
                ((Button)this.FindName("btn0400")).ToolTip = GS.GetToolTip(4, 0);
                ((Button)this.FindName("btn0401")).ToolTip = GS.GetToolTip(4, 1);
                ((Button)this.FindName("btn0500")).ToolTip = GS.GetToolTip(5, 0);
                ((Button)this.FindName("btn0501")).ToolTip = GS.GetToolTip(5, 1);
                ((Button)this.FindName("btn0600")).ToolTip = GS.GetToolTip(6, 0);
                ((Button)this.FindName("btn0601")).ToolTip = GS.GetToolTip(6, 1);
                ((Button)this.FindName("btn0700")).ToolTip = GS.GetToolTip(7, 0);
                ((Button)this.FindName("btn0701")).ToolTip = GS.GetToolTip(7, 1);
                ((Button)this.FindName("btn0800")).ToolTip = GS.GetToolTip(8, 0);
                ((Button)this.FindName("btn0801")).ToolTip = GS.GetToolTip(8, 1);
                ((Button)this.FindName("btn0900")).ToolTip = GS.GetToolTip(9, 0);
                ((Button)this.FindName("btn0901")).ToolTip = GS.GetToolTip(9, 1);   

                GS.ProcessMenu(GS.SelectedMarker, false, false);
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void Line_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
        }
        public void UpdateScenario(string data){
            GamePhase phase = GS.ExecutingGamePhase();
            GS.PreCallProcess();
            phase.Update(data);
            Boolean phaseChanged = GS.ExecutingGamePhase() != phase;    
            HandleScenarioCall(true, phaseChanged);
            if(phaseChanged){
                if(GS.ExecutingGamePhase().zoomLevel != MapZoomLevel){
                    MapZoomLevel = GS.ExecutingGamePhase().zoomLevel;
                    ZoomAll();
                } 
            } 
            if(GS.advanced){
                SaveGameStateToLocalFiles();
                GS.advanced = false;
            }
            GS.ProcessMenu(GS.SelectedMarker, false, false);    
        }
        public void UpdateScenario(double realX, double realY){
            GamePhase phase = GS.ExecutingGamePhase();
            GS.PreCallProcess();
            phase.Update(realX, realY);
            Boolean phaseChanged = GS.ExecutingGamePhase() != phase;    
            HandleScenarioCall(true, phaseChanged);
            if(phaseChanged){
                if(GS.ExecutingGamePhase().zoomLevel != MapZoomLevel){
                    MapZoomLevel = GS.ExecutingGamePhase().zoomLevel;
                    ZoomAll();
                } 
            }       
            if(GS.advanced){
                SaveGameStateToLocalFiles();
                GS.advanced = false;
            }      
            GS.ProcessMenu(GS.SelectedMarker, false, false);   
        }
        public void RefreshScenario(Boolean scrollToSelectedMarker){
            GS.PreCallProcess();
            GS.ExecutingGamePhase().Start(false);    
            HandleScenarioCall(scrollToSelectedMarker, false);        
            GS.ProcessMenu(GS.SelectedMarker, false, false);     
        }
        public void HandleScenarioCall(Boolean scrollToSelectedMarker, Boolean phaseHasChanged){
            GS.PostCallProcess();
            Title = gameDir + " | " + scenarioDir + " | " + sessionDir + " | " + GS.TURNTITLE() + " | " + GS.TURNPHASE();
            GS.SHOWINSTRUCTIONS();
            if(GS.RESULT != null){
                MessageBox.Show("Scenario " + GS.data.ID + " is over. " + GS.RESULT);
            }
            if(GS.SelectedMarker != null){
                if(scrollToSelectedMarker){
                    PickMarker(GS.SelectedMarker);
                } else {
                    SelectMarker(GS.SelectedMarker);
                    ShuffleMarker(GS.SelectedMarker);
                    DrawMarkerStack(GO.DOMAIN_PIECE, GS.SelectedMarker.GAMELOCATION);
                }
            }
            if(phaseHasChanged){
                foreach(GO loc in ExpandedGOs){
                    loc.EXPANDED = false;
                    DrawMarkerStack(GO.DOMAIN_PIECE, loc);                    
                }
                ExpandedGOs.Clear();
            }
            foreach(string domain in GOsToDraw.Keys){
                foreach(GO loc in GOsToDraw[domain]){
                    DrawMarkerStackImmediately(domain, loc);
                }
                GOsToDraw[domain].Clear();
            }
            foreach(string domain in GOsToRefresh.Keys){
                foreach(GO loc in GOsToRefresh[domain]){
                    DrawMarkerStackImmediately(domain, loc, true);
                }
                GOsToRefresh[domain].Clear();
            }
            DrawIndicators();

            /*foreach(string imagefile in Directory.GetFiles(GetScenarioImageDir(), "*")){
                string imagefileName = System.IO.Path.GetFileName(imagefile);
                if(!imagefileName.Contains('.')){
                    string[] nameParts = imagefileName.Split(' ');
                    string first = nameParts.First();
                    string rest = "";
                    for(int n = 1; n < nameParts.Length; n++){
                        rest += nameParts[n] + " ";
                    }
                    rest = rest.Trim();
                    string newfileName = GetScenarioImageDir() + "/" + rest + " " + first + ".png";
                    System.IO.File.Move(imagefile, newfileName);
                }
            }*/
            VIEWREFRESHED = true;
        }
        public int RollDice(int d1sides, int d2sides){
            int rollResult = 0;
            //reset die images
            //SetImage((Image)this.FindName("imgDie1"), GetImageDir() + "/" + "EMPTY.png", 25);
            //SetImage((Image)this.FindName("imgDie2"), GetImageDir() + "/" + "EMPTY.png", 25);

            if(d1sides > 0){
                int dieResult = CWConstants._random.Next(d1sides) + 1;
                rollResult += dieResult;
                //SetImage((Image)this.FindName("imgDie1"), GetImageDir() + "/" + "D6_Black" + dieResult + ".png", 25);
            }
            if(d2sides > 0){
                int dieResult = CWConstants._random.Next(d2sides) + 1;
                rollResult += dieResult;
                //SetImage((Image)this.FindName("imgDie2"), GetImageDir() + "/" + "D6_Black" + dieResult + ".png", 25);
            }

            return rollResult;
        }
        public static void Alert(string alert){
            Alert(alert, true, true);
        }
        public void Alert(GO obj, string alert){
            ScrollToMarker(obj, true);
            Alert(alert, true, true);           
        }
        public static void Alert(string alert, bool popup, bool print){
            if(popup){MessageBox.Show(alert);}
            if(print){Log(alert);}
        }
        public static void Log(string alert){
            Debug.Print(alert);
        }
        public void DrawMarkerStackImmediately(string domain, GO location){
            DrawMarkerStackImmediately(domain, location, false);            
        }
        public void DrawMarkerStack(string domain, GO location){
            DrawMarkerStack(domain, location, false);
        }
        public void DrawMarkerStackImmediately(string domain, GO location, Boolean refreshImages){
            if(domain == GO.DOMAIN_PIECE){DrawMarkers(GS.STACKSATLOCATION(location.ID), location.x, location.y, location == GS.InspectedLocation ? location.z_inspection : location.z, location.HIDDEN, location.EXPANDED, false, refreshImages, location == GS.InspectedLocation);}
            if(domain == GO.DOMAIN_SHEET){DrawMarkers(GS.SHEETSATLOCATION(location.ID), location.x, location.y, location.z, location.HIDDEN, location.EXPANDED, true, refreshImages, false);}
        }
        public void DrawMarkerStack(string domain, GO location, Boolean refreshImages){
            if(refreshImages){
                GOsToRefresh[domain].Add(location);
            } else {
                GOsToDraw[domain].Add(location);
            }
        }
        public void HideMarker(GO marker){
            foreach(Image img in GS.GOImages(marker, false)){
                Canvas.SetZIndex(img, Z_HIDDEN);
            }
            //build rectangles
            foreach(CWRectangleWrapper rw in GS.GORectangles(marker, false)){
                Canvas.SetZIndex(rw.rect, Z_HIDDEN);
            }
        }
        private void DrawMarkers(List<GO> gameObjects, 
                                double xStart, 
                                double yStart, 
                                int zStart, 
                                Boolean hidden, 
                                Boolean expanded, 
                                Boolean sheet,
                                Boolean refreshImages,
                                Boolean inspecting){
            List<GO> hideList = gameObjects.Where(n => n.HIDDEN || hidden).ToList();
            gameObjects.RemoveAll(hideList.Contains);
            //hide
            foreach(GO marker in hideList){
                Image img = GS.GOImages(marker, refreshImages).First();
                Canvas.SetTop(img, 0);
                Canvas.SetLeft(img, 0);
                Canvas.SetZIndex(img, Z_HIDDEN);           
                foreach(CWRectangleWrapper rw in GS.GORectangles(marker, refreshImages)){
                    Rectangle rect = rw.rect;
                    Canvas.SetTop(rect, 0);
                    Canvas.SetLeft(rect, 0);
                    Canvas.SetZIndex(rect, Z_HIDDEN);
                } 
            }
            inspecting = inspecting && gameObjects.Count > 1;
            List<List<double>> MARKEROFFSETS = gameObjects.Any() && inspecting ? INSPECTOFFSETS(gameObjects) : new();
            //show
            foreach(GO marker in gameObjects){
                Image img = GS.GOImages(marker, refreshImages).First();
                bool minimized = sheet && (marker.DRAGGING || !marker.EXPANDED);
                int i = gameObjects.IndexOf(marker);
                int xyOffset = inspecting ? 0 : XY_MARKER_OFFSET * i * (expanded ? 3 : 1);
                int zOffset = zStart + (inspecting ? 0 : Z_MARKER_OFFSET * i);
                List<double> markerOffsets = inspecting switch{
                    true => MARKEROFFSETS[i],
                    false => new(){(minimized ? marker.MINIMIZEDWIDTHVALUE : marker.IMAGEWIDTHVALUE) * -0.5, 
                                    (minimized ? marker.MINIMIZEDWIDTH / marker.IMAGEWIDTHVALUE * marker.IMAGEHEIGHTVALUE : marker.IMAGEHEIGHTVALUE) * -0.5}
                };
                double top = (yStart + markerOffsets[1] - xyOffset) * MapZoomLevel;
                double left = (xStart + markerOffsets[0] + xyOffset) * MapZoomLevel;
                int z = sheet ? marker.z : Z_MARKER + zOffset;
                Canvas.SetTop(img, top);
                Canvas.SetLeft(img, left);
                Canvas.SetZIndex(img, z);
                foreach(CWRectangleWrapper rw in GS.GORectangles(marker, refreshImages)){
                    Rectangle rect = rw.rect;
                    Canvas.SetTop(rect, top + rw.y * MapZoomLevel);
                    Canvas.SetLeft(rect, left + rw.x * MapZoomLevel);
                    Canvas.SetZIndex(rect, !rw.show ? Z_HIDDEN : z + Z_MARKER_RECTANGLE_OFFSET + rw.z);
                }
            }
        }
        private List<List<double>> INSPECTOFFSETS(List<GO> objects){
            double numObjects = objects.Count;
            List<List<double>> returnList = new();
            double SLOT = GS.MarkerSize * 1.25;
            double MARGIN = GS.MarkerSize * 0.125;
            double XSLOTS = 1;
            double YSLOTS = 1;
            while(XSLOTS * YSLOTS < numObjects){
                if(XSLOTS == YSLOTS){XSLOTS++;} else {YSLOTS++;}
            }
            double XORIGIN = XSLOTS * -0.5 * SLOT;
            double YORIGIN = YSLOTS * -0.5 * SLOT;
            for(int i = 0; i < numObjects; i++){
                double column = i % XSLOTS;
                double row = Math.Floor(i / XSLOTS); 
                double x = XORIGIN + (column * SLOT) + MARGIN + ((GS.MarkerSize - objects[i].IMAGEWIDTHVALUE) * 0.5);
                double y = YORIGIN + (row * SLOT) + MARGIN + ((GS.MarkerSize - objects[i].IMAGEHEIGHTVALUE) * 0.5);
                returnList.Add(new(){x, y});
            }
            return returnList;
        }
        private void DrawIndicators(){
            List<UIElement> hideUIList = new();
            List<UIElement> visibleUIList = new();
            foreach(string typecolorkey in GOIndicatorsToDraw.Keys){
                List<GO> staticList = GOIndicatorsDrawn[typecolorkey].Intersect(GOIndicatorsToDraw[typecolorkey]).ToList();
                List<GO> hideList = GOIndicatorsDrawn[typecolorkey].Where(n => !staticList.Contains(n)).ToList();
                List<GO> showList = GOIndicatorsToDraw[typecolorkey].Where(n => !staticList.Contains(n)).ToList();
                foreach(GO obj in hideList){
                    if(obj.DOMAIN == GO.DOMAIN_CONNECTOR || obj.DOMAIN == GO.DOMAIN_SHEET && obj.SHEETANCHORLOCATIONID != null){
                        hideUIList.Add(obj.lineIndicator);
                    } else {
                        hideUIList.Add(obj.ellipseIndicator);
                    }
                }
                foreach(GO obj in showList){
                    if(obj.DOMAIN == GO.DOMAIN_CONNECTOR || obj.DOMAIN == GO.DOMAIN_SHEET && obj.SHEETANCHORLOCATIONID != null)
                    {
                        Line l = obj.DOMAIN == GO.DOMAIN_CONNECTOR ? GS.GetLine(obj, false) : GS.GetSheetConnectorLine(obj, true);
                        l.Stroke = GOIndicatorColorMap[typecolorkey];
                        Canvas.SetZIndex(l, obj.ALWAYSSHOW ? Z_MAP_CONNECTOR_INDICATOR : Z_CONNECTOR_INDICATOR);
                        visibleUIList.Add(l);
                    }
                    else
                    {
                        Ellipse e = GS.GetIndicator(obj, true);
                        if(obj.HIDDEN){
                            hideUIList.Add(e);
                        } else {
                            e.Fill = obj._ELLIPSEFILL ? GOIndicatorColorMap[typecolorkey] : null;
                            e.Stroke = obj._ELLIPSEFILL ? null : GOIndicatorColorMap[typecolorkey];
                            int z = obj.PARENTSHEETID != null ? obj.PARENTSHEET.z + Z_LOCATION_INDICATOR : Z_LOCATION_INDICATOR;
                            visibleUIList.Add(e);
                            Canvas.SetZIndex(e, z);
                        }
                    }
                }
                GOIndicatorsDrawn[typecolorkey] = new(GOIndicatorsToDraw[typecolorkey]);
                GOIndicatorsToDraw[typecolorkey].RemoveWhere(n => !n.ALWAYSSHOW);
            }
            foreach(UIElement obj in hideUIList.Where(n => !visibleUIList.Contains(n))){
                Canvas.SetZIndex(obj, MainWindow.Z_HIDDEN);
            }
        }
        private void ShiftMarkerIndicator(GO marker){
            HideMarkerIndicator();
            GO location = marker.GAMELOCATION;
            MarkerIndicator.Width = marker.IMAGEWIDTHVALUE * 2 * MapZoomLevel;
            MarkerIndicator.Height = marker.IMAGEWIDTHVALUE * 2 * MapZoomLevel;
            DrawMarkerIndicator((location.y - marker.IMAGEWIDTHVALUE) * MapZoomLevel, (location.x - marker.IMAGEWIDTHVALUE) * MapZoomLevel, location.z + Z_MARKER_INDICATOR);
        }
        private void DrawMarkerIndicator(double top, double left, int z){
            Canvas.SetTop(MarkerIndicator, top);
            Canvas.SetLeft(MarkerIndicator, left);
            Canvas.SetZIndex(MarkerIndicator, z);
        }
        public void HideMarkerIndicator(){
            //remove marker indicator from current position
            DrawMarkerIndicator(0, 0, Z_HIDDEN);
        }
        public void ScrollToMarker(GO marker, Boolean forceScroll){
            ScrollToCoordinate(marker.GAMELOCATION.x, marker.GAMELOCATION.y, forceScroll);
        }
        public void ScrollToCoordinate(double x, double y, Boolean forceScroll){
            //center on indicator
            double currentWidth = Math.Max(CANVAS_SCROLL_VIEWER.ViewportWidth, 1000);
            double currentHeight = Math.Max(CANVAS_SCROLL_VIEWER.ViewportHeight, 500);
            double currentOffsetWidth = CANVAS_SCROLL_VIEWER.HorizontalOffset;
            double currentOffsetHeight = CANVAS_SCROLL_VIEWER.VerticalOffset;
            double nearEdgeDistance = 100 * MapZoomLevel * 0.5;
            double left = currentOffsetWidth + nearEdgeDistance;
            double right = (currentOffsetWidth + currentWidth) - nearEdgeDistance;
            double top = currentOffsetHeight + nearEdgeDistance;
            double bottom = (currentOffsetHeight + currentHeight) - nearEdgeDistance;
            
            //if location coordinates are near or beyond the edge, scroll
            double locationX = x * MapZoomLevel;
            double locationY = y * MapZoomLevel;
            if(locationX <= left || locationX >= right || locationY <= top || locationY >= bottom || forceScroll){
                double rectLeft = Math.Max(0, locationX - (currentWidth * 0.5));
                double rectTop = Math.Max(0, locationY - (currentHeight * 0.5));
                CANVAS_SCROLL_VIEWER.ScrollToHorizontalOffset(rectLeft);
                CANVAS_SCROLL_VIEWER.ScrollToVerticalOffset(rectTop);
            }
        }
        private void SetBackground(){
            //GO background = GS.TYPE("BACKGROUND").First();
            StackPanel sp = (StackPanel)this.FindName("spMap");
            sp.Width = GS.WorldSize * MapZoomLevel;
            sp.Height = GS.WorldSize * MapZoomLevel;
            sp.Background = System.Windows.Media.Brushes.Gray;
            //SetZoomableImage((Image)this.FindName("imgBackground"), GetImageDir() + "/BACKGROUND.png", GS.WorldSize);
        }
        private void SetImageForMaps(){
            foreach(GO map in GS.TYPE("MAP")){
                Image img = GS.GOImages(map, true).First();
                Canvas.SetTop(img, map.YCOORD * MapZoomLevel);
                Canvas.SetLeft(img, map.XCOORD * MapZoomLevel);
                Canvas.SetZIndex(img, map.ZCOORD);
                if(map.GetInt("ROTATION") != 0){
                    RotateTransform rotateTransform = new RotateTransform(map.GetInt("ROTATION"));
                    img.RenderTransform = rotateTransform; 
                }             
            }
        }
        public void SetZoomableImage(Image img, string filename, double width){
            SetImage(img, filename, width * MapZoomLevel);
        }
        public void SetImage(Image img, string filename, double width){
            try{
                BitmapImage bmImg = new();
                bmImg.BeginInit();
                bmImg.UriSource = new Uri(filename, UriKind.Absolute);
                bmImg.DecodePixelWidth = (int)width;
                bmImg.EndInit();
                img.Width = width;
                img.Source = bmImg;
            } catch(Exception ex){
                BitmapImage bmImg = new();
                bmImg.BeginInit();
                bmImg.UriSource = new Uri(GetImageDir() + "/EMPTY.png", UriKind.Absolute);
                bmImg.DecodePixelWidth = (int)width;
                bmImg.EndInit();
                img.Width = width;
                img.Source = bmImg;
                log.Error("Error: " + ex.Message + " " + ex.StackTrace);
            }
        }
        public void SetZoomableImage(Image img, string filename, double width, double height){
            SetImage(img, filename, width * MapZoomLevel, height * MapZoomLevel);
        }
        public void SetImage(Image img, string filename, double width, double height){
            try{
                BitmapImage bmImg = new();
                bmImg.BeginInit();
                bmImg.UriSource = new Uri(filename, UriKind.Absolute);
                bmImg.DecodePixelWidth = (int)width;
                bmImg.DecodePixelHeight = (int)height;
                bmImg.EndInit();
                img.Width = width;
                img.Height = height;
                img.Source = bmImg;
            } catch(Exception ex){
                BitmapImage bmImg = new();
                bmImg.BeginInit();
                bmImg.UriSource = new Uri(GetImageDir() + "/EMPTY.png", UriKind.Absolute);
                bmImg.DecodePixelWidth = (int)width;
                bmImg.EndInit();
                img.Width = width;
                img.Source = bmImg;
                log.Error("Error: " + ex.Message + " " + ex.StackTrace);
            }
        }
        public void ExpandOrCollapseSheet(GO obj, Boolean expanded){
            ExpandOrCollapseSheet(obj, expanded, false);
        }
        public void ExpandOrCollapseSheet(GO obj, Boolean expanded, Boolean immediately){
            obj.EXPANDED = expanded;
            if(immediately){DrawMarkerStackImmediately(obj.DOMAIN, obj.GAMELOCATION, true);} else {DrawMarkerStack(obj.DOMAIN, obj.GAMELOCATION, true);}
            List<GO> sheetLocs = GS.TYPE(GO.DOMAIN_PIECE, "PARENTSHEETID", obj.ID).Select(n => n.GAMELOCATION).ToList();
            foreach(GO loc in GS.TYPE(GO.DOMAIN_LOCATION, "PARENTSHEETID", obj.ID)){
                loc.HIDDEN = !obj.EXPANDED;
                if(sheetLocs.Contains(loc)){
                    if(immediately){DrawMarkerStackImmediately(GO.DOMAIN_PIECE, loc);} else {DrawMarkerStack(GO.DOMAIN_PIECE, loc);}
                }
            }
        }
        public void Img_MouseMove(object sender, MouseEventArgs e)
        {
            //show x, y of location
            Point clickPoint = e.GetPosition(WORLD_CANVAS);
            double realY = clickPoint.Y / MapZoomLevel;
            double realX = clickPoint.X / MapZoomLevel;
            if(GS.ExecutingGamePhase().MapMouseMove){
                GS.ProcessMapMouseMove(realX, realY);
            }
            Title = gameDir + " | " + scenarioDir + " | " + sessionDir + " | " + GS.TURNTITLE() + " | " + GS.TURNPHASE() + " | " + Math.Round(realX, 0) + " | " + Math.Round(realY, 0);
            if(VIEWREFRESHED){
                VIEWREFRESHED = false;
                string path = GS.EXECUTINGPHASE;
                if(!GS.GetBoolean(path)){
                    GS.SetBoolean(path, true);
                    if(GS.GetBoolean("_CONFIG_SHOW_HELP_FIRST_TIME_THROUGH")){
                        Alert(GS.HELPTEXT);
                    }
                }
            }
        }
        private void Img_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    Image clickedImage = (Image)e.Source;
                    GO marker = GetMarkerFromImage(clickedImage);
                    bool PIECE = marker.DOMAIN == GO.DOMAIN_PIECE;
                    bool SHEET = !PIECE;
                    bool UNIVERSALDROP = GS.ExecutingGamePhase().UniversalDrop;
                    Boolean canInteract = GS.CANINTERACT(marker);
                    if(e.ClickCount == 1){
                        HideMenus();
                        Boolean canDrag = GS.CANDRAG(marker) || (PIECE && canInteract && UNIVERSALDROP);
                        if(PIECE){
                            if(canInteract){
                                PickMarkerImmediately(marker);
                            } else {
                                ClickMarker(marker);                               
                            }
                        }
                        if(Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) {
                            GS.ProcessControlClick(marker);
                            RefreshScenario(false);
                        } else if(canDrag){
                            marker.TEMPLOCATIONID = marker.GAMELOCATIONID;
                            DraggingGO = marker;
                            DropTargets = new();
                            if(!UNIVERSALDROP || marker.DOMAIN == GO.DOMAIN_SHEET){
                                DropTargets = GS.DRAGTARGETS(marker);
                                if(marker.DOMAIN == GO.DOMAIN_PIECE){DropTargets.Add(marker.GAMELOCATION); }
                            }                  
                            if((GS.ExecutingGamePhase().DragOver || GS.ExecutingGamePhase().DragDrop) && GS.InteractionMap.ContainsKey(DraggingGO)){
                                UpdateScenario(null);
                            }
                            if(marker.DOMAIN == GO.DOMAIN_SHEET && marker.EXPANDED){ExpandOrCollapseSheet(marker, false, true); marker.EXPANDED = true;}
                            OriginGO = new(){
                                x = Canvas.GetLeft(clickedImage), 
                                y = Canvas.GetTop(clickedImage),
                                z = Canvas.GetZIndex(clickedImage)
                            };
                            DragDrop.DoDragDrop(clickedImage, new DataObject(DataFormats.Serializable, marker), DragDropEffects.Move);
                        } else if(canInteract){
                            RefreshScenario(false);
                        }
                    } else if(e.ClickCount == 2){
                        GS.ProcessDoubleLeftClick(marker);     
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void Img_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    Image clickedImage = (Image)e.Source;
                    GO marker = GetMarkerFromImage(clickedImage);
                    bool PIECE = marker.DOMAIN == GO.DOMAIN_PIECE;
                    Boolean canInteract = GS.CANINTERACT(marker);
                    if(e.ClickCount == 1){
                        HideMenus();
                        if(PIECE){
                            if(canInteract){
                                PickMarkerImmediately(marker);
                            } else {
                                ClickMarker(marker);                               
                            }
                        }
                    } else if(e.ClickCount == 2){
                        GS.ProcessDoubleRightClick(marker);     
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void worldCanvas_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Serializable))
            {
                DraggingGO.DRAGGING = true;
                Point dropPoint = e.GetPosition(WORLD_CANVAS);
                double realY = dropPoint.Y / MapZoomLevel;
                double realX = dropPoint.X / MapZoomLevel;
                List<GO> gameObjects = new(){ DraggingGO };
                        
                if(DraggingGO.DOMAIN == GO.DOMAIN_PIECE){
                    HideMenus();
                    DrawMarkers(gameObjects, realX, realY, Z_DRAGGING_MARKER, false, false, false, false, false);
                    double top = (realY - (DraggingGO.IMAGEHEIGHTVALUE == 0 ? DraggingGO.IMAGEWIDTHVALUE : DraggingGO.IMAGEHEIGHTVALUE)) * MapZoomLevel;
                    double left = (realX - DraggingGO.IMAGEWIDTHVALUE) * MapZoomLevel;
                    DrawMarkerIndicator(top, left, Z_DRAGGING_MARKER_INDICATOR);
                    if(GS.ExecutingGamePhase().DragOver && DropTargets.Any()){
                        //we can only drag to hexes or the current location the marker is at
                        GO nearestLocation = DropTargets.OrderBy(x => GetDistance(x, realX, realY)).First();
                        if(nearestLocation.ID != DraggingGO.TEMPLOCATIONID){
                            DraggingGO.TEMPLOCATIONID = nearestLocation.ID;
                            if(GS.InteractionMap.ContainsKey(DraggingGO)){
                                UpdateScenario(null);
                                DropTargets = GS.DRAGTARGETS(DraggingGO);
                                DropTargets.Add(DraggingGO.GAMELOCATION);
                            }
                        }
                    }
                } else if(DraggingGO.DOMAIN == GO.DOMAIN_SHEET){
                    DrawMarkers(gameObjects, realX, realY, Z_MARKER, false, false, true, false, false);
                    /*GO nearestLocation = DropTargets.OrderBy(x => GetDistance(x, realX, realY)).First();
                    if(nearestLocation.ID != DraggingGO.TEMPLOCATIONID){
                        DraggingGO.TEMPLOCATIONID = nearestLocation.ID;
                    }*/              
                }
            }
        }
        private void worldCanvas_Drop(object sender, DragEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    if (e.Data.GetDataPresent(DataFormats.Serializable))
                    {   
                        Point dropPoint = e.GetPosition(WORLD_CANVAS);
                        double realY = dropPoint.Y / MapZoomLevel;
                        double realX = dropPoint.X / MapZoomLevel;
                        bool DIDNTMOVE =    Math.Abs(OriginGO.x - Canvas.GetLeft(DraggingGO.image)) <= 1 &&
                                            Math.Abs(OriginGO.y - Canvas.GetTop(DraggingGO.image)) <= 1;
                        Canvas.SetZIndex(DraggingGO.image, OriginGO.z);
                        OriginGO = null;
                        if(DraggingGO.DOMAIN == GO.DOMAIN_SHEET){
                            GO nearestLocation = DropTargets.OrderBy(x => GetDistance(x, realX, realY)).FirstOrDefault();
                            if(DraggingGO.SHEETANCHORLOCATIONID != null){
                                DraggingGO.TEMPLOCATIONID = DraggingGO.SHEETANCHORLOCATIONID;
                                //where do we move the anchor. if too far away from drop targets, snap to nearest drop target
                                GO anchorLocation = GS.LOCATION(DraggingGO.SHEETANCHORLOCATIONID);
                                if(nearestLocation != null && GetDistance(nearestLocation, realX, realY) >= 60){
                                    realX = nearestLocation.x;
                                    realY = nearestLocation.y;
                                }
                                anchorLocation.x = realX;
                                anchorLocation.XCOORD = realX;
                                anchorLocation.y = realY;
                                anchorLocation.YCOORD = realY;
                            } else if(nearestLocation != null){
                                DraggingGO.TEMPLOCATIONID = nearestLocation.ID;
                            } else {
                                DraggingGO.TEMPLOCATIONID = DraggingGO.GAMELOCATIONID;
                            }
                        } else if(!GS.ExecutingGamePhase().DragOver && !DIDNTMOVE){
                            GO nearestLocation = DropTargets.OrderBy(x => GetDistance(x, realX, realY)).FirstOrDefault();
                            nearestLocation ??= GS.LOCATIONS().Where(n => !n.HIDDEN).OrderBy(x => GetDistance(x, realX, realY)).First();
                            DraggingGO.TEMPLOCATIONID = nearestLocation.ID;
                        }
                        DropTargets = null;
                        if(DraggingGO.DOMAIN == GO.DOMAIN_PIECE){
                            if(DraggingGO.DRAGGING){
                                DraggingGO.DRAGGING = false;
                                if(GS.InteractionMap.ContainsKey(DraggingGO)){
                                    if(GS.ExecutingGamePhase().DragDrop){
                                        UpdateScenario(null);
                                    }
                                }
                            }
                            DraggingGO.TEMPLOCATIONID = null;
                            DraggingGO = null;
                        } else if(DraggingGO.DOMAIN == GO.DOMAIN_SHEET){
                            DraggingGO.DRAGGING = false;
                            string dropLoc = DraggingGO.TEMPLOCATIONID;
                            GO droppedSheet = DraggingGO;
                            DraggingGO.TEMPLOCATIONID = null;
                            DraggingGO = null;  
                            GS.CHANGELOCATION(droppedSheet, dropLoc);
                            ExpandOrCollapseSheet(droppedSheet, droppedSheet.EXPANDED);
                            RefreshScenario(false);
                        }                
                    }
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void ImgSelected_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Image clickedImage = (Image)e.Source;
            GO marker = clickedImage == SELECTED_MARKER_IMAGE ? GS.SelectedMarker : GetMarkerFromImage(clickedImage);
            PickMarkerImmediately(marker);
            if(Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) {
                GS.ProcessControlClick(marker);
            }
            RefreshScenario(false);
        }
        private GO GetMarkerFromImage(Image img){
            return GS.GOImageMap[img];
        }
        private List<GO> GetConnectorsFromLine(Line l){
            return GS.CONNECTORS().Where(n => n.lineIndicator == l || n.lineIndicator2 == l).ToList();
        }
        public void HideMenus(){
            foreach (Menu m in new List<Menu>{MarkerMenu}){
                Canvas.SetLeft(m, 1);
                Canvas.SetTop(m, 1);
                Canvas.SetZIndex(m, Z_HIDDEN);
            }
        }
        
        public void MarkercmiImg_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    HideMenus();
                    MenuItem mi = sender as MenuItem;
                    string header = mi.Header.ToString();
                    UpdateScenario(header);                                      
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void Expandcmi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    GS.ProcessMenu(GS.SelectedMarker, true, false);                                      
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void StackcmiImg_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    HideMenus();
                    MenuItem mi = sender as MenuItem;                    
                    string header = mi.Header.ToString();
                    GS.ProcessStackMenuClick(header);
                    RefreshScenario(false);                                      
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void MapcmiImg_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    MenuItem mi = sender as MenuItem;
                    string header = mi.Header.ToString();
                    UpdateScenario(header);                                      
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void Img_MouseEnter(object sender, MouseEventArgs e)
        {         
        }
        private void Img_MouseLeave(object sender, MouseEventArgs e)
        {
        }
        public static double GetDistance(GO location, double x, double y){
            return Math.Sqrt(Math.Pow(location.x - x, 2) + Math.Pow(location.y - y, 2));
        }  
        public void ClickMarker(GO marker){
            SetImage(CLICKED_MARKER_IMAGE, GetScenarioImageDir() + "/" + marker.IMAGEFILENAME, 200);
            ((TextBlock)this.FindName("txtClickedMarkerInfo")).Text = GS.INFO(GS, marker);   
            ShuffleMarker(marker);
            DrawMarkerStackImmediately(marker.DOMAIN, marker.GAMELOCATION);    
        }      
        public void ShuffleMarker(GO marker){
            GS.ShuffleMarker(marker);
        }
        public void PickMarker(GO pickedMarker){
            SelectMarker(pickedMarker);
            ShuffleMarker(pickedMarker);
            ScrollToMarker(pickedMarker, false);
            DrawMarkerStack(pickedMarker.DOMAIN, pickedMarker.GAMELOCATION);                        
        }
        public void PickMarkerImmediately(GO pickedMarker){
            SelectMarker(pickedMarker);
            ShuffleMarker(pickedMarker);
            ScrollToMarker(pickedMarker, false);
            DrawMarkerStackImmediately(pickedMarker.DOMAIN, pickedMarker.GAMELOCATION);                        
        }
        public void SelectMarker(GO selectedMarker){
            SetImage(SELECTED_MARKER_IMAGE, GetScenarioImageDir() + "/" + selectedMarker.IMAGEFILENAME, 200);
            ((TextBlock)this.FindName("txtSelectedMarkerInfo")).Text = GS.INFO(GS, selectedMarker);
            //clear clicked on marker info
            SetImage(CLICKED_MARKER_IMAGE, GetImageDir() + "/EMPTY.png", 200);
            ((TextBlock)this.FindName("txtClickedMarkerInfo")).Text = "";
            GS.SelectedMarker = selectedMarker;
            ShiftMarkerIndicator(selectedMarker);
        }
        public void ClearSelectedMarker(){
            SetImage(SELECTED_MARKER_IMAGE, GetImageDir() + "/EMPTY.png", 200);
            ((TextBlock)this.FindName("txtSelectedMarkerInfo")).Text = "";
            //clear clicked on marker info
            SetImage(CLICKED_MARKER_IMAGE, GetImageDir() + "/EMPTY.png", 200);
            ((TextBlock)this.FindName("txtClickedMarkerInfo")).Text = "";
            GS.SelectedMarker = null;
            HideMarkerIndicator();
        }
        public void AddImageToGame(Image img){
            img.MouseMove += Img_MouseMove;
            img.MouseLeftButtonDown += Img_MouseLeftButtonDown;
            img.MouseRightButtonDown += Img_MouseRightButtonDown;
            img.MouseEnter += Img_MouseEnter;
            img.MouseLeave += Img_MouseLeave;
            WORLD_CANVAS.Children.Add(img);
        }
        public void AddRectToGame(Rectangle rect){
            WORLD_CANVAS.Children.Add(rect);
        }
        private void btn0000_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(0, 0);}
        private void btn0001_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(0, 1);}
        private void btn0100_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(1, 0);}
        private void btn0101_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(1, 1);}
        private void btn0200_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(2, 0);}
        private void btn0201_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(2, 1);}
        private void btn0300_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(3, 0);}
        private void btn0301_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(3, 1);}
        private void btn0400_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(4, 0);}
        private void btn0401_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(4, 1);}
        private void btn0500_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(5, 0);}
        private void btn0501_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(5, 1);}
        private void btn0600_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(6, 0);}
        private void btn0601_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(6, 1);}
        private void btn0700_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(7, 0);}
        private void btn0701_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(7, 1);}
        private void btn0800_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(8, 0);}
        private void btn0801_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(8, 1);}
        private void btn0900_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(9, 0);}
        private void btn0901_Click(object sender, RoutedEventArgs e){ScenarioButtonClick(9, 1);}
        public void ZoomAll(){
            SetBackground();
            SetImageForMaps();
            foreach(GO obj in GS.LOCATIONS()){
                if(obj.ellipseIndicator != null){
                    GS.GetIndicator(obj, true);
                }
            }
            foreach(GO obj in GS.CONNECTORS()){
                if(obj.lineIndicator != null){
                    GS.GetLine(obj, true);
                }
                if(obj.lineIndicator2 != null){
                    GS.GetLine2(obj, true);
                }
            }
            foreach(GO obj in GS.SHEETS().Where(n => n.SHEETANCHORLOCATIONID != null && n.SHEETPARENTPIECE != null)){
                if(obj.lineIndicator != null){
                    GS.GetSheetConnectorLine(obj, true);
                }
            }
            foreach(GO location in GS.PIECES().Where(n => n.GAMELOCATION != null).Select(n => n.GAMELOCATION).Distinct()){
                DrawMarkerStackImmediately(GO.DOMAIN_PIECE, location, true);
            }
            foreach(GO location in GS.SHEETS().Where(n => n.GAMELOCATION != null).Select(n => n.GAMELOCATION).Distinct()){
                DrawMarkerStackImmediately(GO.DOMAIN_SHEET, location, true);
            }
            if(GS.SelectedMarker != null){
                ShiftMarkerIndicator(GS.SelectedMarker);
                ScrollToMarker(GS.SelectedMarker, false);
            }
        }
        private void mnuNextMarker_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    GS.SelectedMarker = GS.NEXTINTERACTIVE(GS.SelectedMarker);
                    RefreshScenario(true);        
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        private void ScenarioButtonClick(int column, int row)
        {
            try
            {
                using(new WaitCursor())
                {
                    GS.ScenarioButtonClick(column, row);
                    RefreshScenario(true);        
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }

        private void mnuPreviousMarker_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    GS.SelectedMarker = GS.PREVIOUSINTERACTIVE(GS.SelectedMarker);
                    RefreshScenario(true); 
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
        public void SaveGameStateToLocalFiles()
        {
            combinedState.state["SCENARIO.VARS"].Clear();
            foreach(string k in GS.data._data.Keys.Order()){
                combinedState.state["SCENARIO.VARS"].Add(k, GS.data._data[k]);
            };
            foreach(GO obj in GS._ChangedObjects.Keys){
                if(obj.RECYCLED || !GS._ChangedObjects[obj].Any()){
                    combinedState.state.Remove(obj.ID);
                } else {
                    combinedState.state[obj.ID] = GS._ChangedObjects[obj];
                }
            }
            using (StreamWriter file = File.CreateText(GetGameStateFile())){
                JsonSerializer serializer = JsonSerializer.Create(JSONSettings);                
                serializer.Serialize(file, combinedState);
            }
            GS._ChangedObjects.Clear();

            /*gameState = GS.GetScenarioState();
            using (StreamWriter file = File.CreateText(GetGameStateFile())){
                JsonSerializer serializer = JsonSerializer.Create(JSONSettings);                
                serializer.Serialize(file, gameState);
            }
            foreach(GameState discard in GS.GetObjectStates(true)){
                DeleteFile(discard.state["ID"]);
            }
            foreach(GameState update in GS.GetObjectStates(false)){
                string filename = GetGameSessionDir() + "/" + update.state["ID"] + ".o.txt";
                using StreamWriter file = File.CreateText(filename);
                JsonSerializer serializer = JsonSerializer.Create(JSONSettings);
                serializer.Serialize(file, update);
            }
            GS._ChangedObjects.Clear();*/
        }
        public void DeleteFile(string id){
            try{
                File.Delete(GetGameSessionDir() + "/" + id + ".o.txt");
            } catch(Exception e){
                String debug = e.Message;
            }
        }
        public void SaveConnectors()
        {
            using (StreamWriter outputFile = new StreamWriter(GetGConnFile()))
            {
                outputFile.WriteLine(String.Join(',',GameConnectorFields));
                foreach (GO obj in GS.CONNECTORS()){
                    string line = "";
                    foreach(string field in GameConnectorFields){
                        line += (line.Length > 0 ? "," : "") + obj.Get(field);
                    }
                    outputFile.WriteLine(line);
                }
            }
        }
        public void SaveLocations()
        {
            using (StreamWriter outputFile = new StreamWriter(GetGLFile()))
            {
                outputFile.WriteLine(String.Join(',',GameLocationFields));
                foreach (GO obj in GS.LOCATIONS()){
                    string line = "";
                    foreach(string field in GameLocationFields){
                        line += (line.Length > 0 ? "," : "") + obj.Get(field);
                    }
                    outputFile.WriteLine(line);
                }
            }
        }
        Boolean scrollingMap = false;
        Point scrollMousePoint = new Point();
        double hOff = 1;
        double vOff = 1;
        private void worldCanvas_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                scrollMousePoint = e.GetPosition(CANVAS_SCROLL_VIEWER);
                hOff = CANVAS_SCROLL_VIEWER.HorizontalOffset;
                vOff = CANVAS_SCROLL_VIEWER.VerticalOffset;
                scrollingMap = true;  
                if(e.ClickCount == 1){
                    if(GS.ExecutingGamePhase().MapClick){
                        Point clickPoint = e.GetPosition(WORLD_CANVAS);
                        double realY = clickPoint.Y / MapZoomLevel;
                        double realX = clickPoint.X / MapZoomLevel;
                        UpdateScenario(realX, realY);
                    }
                }
            }
        }
        private void worldCanvas_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if(scrollingMap){
                CANVAS_SCROLL_VIEWER.ScrollToHorizontalOffset(hOff + (scrollMousePoint.X - e.GetPosition(CANVAS_SCROLL_VIEWER).X));
                CANVAS_SCROLL_VIEWER.ScrollToVerticalOffset(vOff + (scrollMousePoint.Y - e.GetPosition(CANVAS_SCROLL_VIEWER).Y));
            }
        }
        private void worldCanvas_MouseRightButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                if(GS.ExecutingGamePhase().MapClick){
                    Point clickPoint = e.GetPosition(WORLD_CANVAS);
                    double realY = clickPoint.Y / MapZoomLevel;
                    double realX = clickPoint.X / MapZoomLevel;
                    GS.ProcessCanvasRightClick(realX, realY); 
                }               
            }
        }
        private void worldCanvas_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            scrollingMap = false;
        }
        private void worldCanvas_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            scrollingMap = false;
        }
        private void Window_MouseWheel(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
            Point currentPoint = e.GetPosition(this);
            double x = currentPoint.X;
            double y = currentPoint.Y;
        }
        private void mnuNextPhase_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using(new WaitCursor())
                {
                    if(GS.RESULT != null){
                        MessageBox.Show("Scenario " + GS.data.ID + " is over. " + GS.RESULT);
                        return;
                    }
                    UpdateScenario("NEXT");
                }
            }
            catch (Exception ex)
            {
                throwError(ex);
            }
        }
    }
}
        /*public void Line_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Line clickedLine = (Line)e.Source;
            List<GameObject> connectors = GetConnectorsFromLine(clickedLine);
            if(e.ClickCount == 1){
                List<string> connectorTypes = new(){
                    "LAND", 
                    "MOUNTAIN",
                    "PASS", 
                    "MOUNTAINMINORRIVER",
                    "MOUNTAINMAJORRIVER",
                    "MOUNTAINSEA",
                    "MOUNTAINSALT",
                    "PASSMINORRIVER", 
                    "MINORRIVER", 
                    "MAJORRIVER", 
                    "BRIDGE",
                    "SALT", 
                    "SEA"};
                List<System.Windows.Media.SolidColorBrush> colorBrushes = new(){
                    System.Windows.Media.Brushes.White, 
                    System.Windows.Media.Brushes.Brown,
                    System.Windows.Media.Brushes.Yellow,
                    System.Windows.Media.Brushes.Pink,
                    System.Windows.Media.Brushes.Orange,
                    System.Windows.Media.Brushes.Red,
                    System.Windows.Media.Brushes.Gold,
                    System.Windows.Media.Brushes.PaleVioletRed,
                    System.Windows.Media.Brushes.LightBlue, 
                    System.Windows.Media.Brushes.Blue,
                    System.Windows.Media.Brushes.Gray,
                    System.Windows.Media.Brushes.Tan,
                    System.Windows.Media.Brushes.Transparent};
                int index = connectorTypes.IndexOf(connectors[0].CONNECTORTYPE);
                int newIndex = (index + 1) % connectorTypes.Count;
                foreach(GameObject connector in connectors){
                    connector.CONNECTORTYPE = connectorTypes[newIndex];
                }
                clickedLine.Stroke = colorBrushes[newIndex];
                clickedLine.StrokeThickness = 5;
                foreach(GameObject location in GS.LOCATIONS(connectors[0]).Where(n => n.TERRAIN == "MOUNTAIN")){
                    List<GameObject> borders = GS.CONNECTORS(location);
                    if((location.PASS && borders.Where(n => n.CONNECTORTYPE.Contains("PASS")).Count() < 2) || borders.Where(n => !n.CONNECTORTYPE.Contains("MOUNTAIN") && !n.CONNECTORTYPE.Contains("PASS")).Any()){
                        location.INDICATORWIDTH = 20;
                        DrawEllipse(location);
                    }
                    else
                    {
                        Canvas.SetZIndex(GS.GetIndicator(location), MainWindow.Z_HIDDEN);
                    }
                }
                SaveConnectors();
            }
        }*/
