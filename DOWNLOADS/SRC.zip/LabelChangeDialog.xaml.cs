﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CWApp
{
    /// <summary>
    /// Interaction logic for LabelChangeDialog.xaml
    /// </summary>
    public partial class LabelChangeDialog : Window
    {
        public GO obj { get; set; }
        public LabelChangeDialog(GO o)
        {
            obj = o;
            InitializeComponent();
            TXTLABEL.Text = obj.LABEL;
            TXTLABEL.Focus();
            TXTLABEL.SelectionStart = 0;
            TXTLABEL.SelectionLength = TXTLABEL.Text.Length;
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle OK button click here
            // Close the popup or perform other actions
            if (!string.IsNullOrWhiteSpace(TXTLABEL.Text))
            {
                obj.LABEL = TXTLABEL.Text;
                this.Close();
            }
            else
            {
                MessageBox.Show("Label cannot be empty.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle Cancel button click here
            // Close the popup or perform other actions
            this.Close();
        }
    }
}
