﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CWApp
{
    /// <summary>
    /// Interaction logic for ScenarioOptions.xaml
    /// </summary>
    public partial class ScenarioOptions : Window
    {
        public Dictionary<string, string> obj { get; set; }
        public ScenarioOptions(Dictionary<string, string> o)
        {
            obj = o;
            InitializeComponent();
            RULES.Text = obj["RULES"];
            Title = obj["TITLE"];
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle OK button click here
            // Close the popup or perform other actions
            obj["SOVAI"] = SOVAI.IsChecked == true || BOTHAI.IsChecked == true ? "true" : "false";
            obj["ALLIESAI"] = ALLIESAI.IsChecked == true || BOTHAI.IsChecked == true ? "true" : "false";
            obj["SKIPSETUP"] = QUICKSTART.IsChecked == true ? "true" : "false";
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle Cancel button click here
            // Close the popup or perform other actions
            //this.Close();
        }
    }
}
