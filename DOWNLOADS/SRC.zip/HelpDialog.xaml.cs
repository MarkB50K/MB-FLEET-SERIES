﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Shell;

namespace CWApp
{
    /// <summary>
    /// Interaction logic for HelpDialog.xaml
    /// </summary>
    public partial class HelpDialog : Window
    {
        public Dictionary<string, string> obj { get; set; }
        public HelpDialog(Dictionary<string, string> o)
        {
            obj = o;
            InitializeComponent();
            Title = typeof(MainWindow).Assembly.GetName().Version?.ToString();
            string mode = obj["MODE"];
            TBINFO.Text = obj[mode];
            RBPHASE.IsChecked = mode == "PHASE";
            RBRULES.IsChecked = mode == "RULES";
        }

        private void UpdateInfo(object sender, RoutedEventArgs e)
        {
            RadioButton li = (sender as RadioButton);
            string mode = RBPHASE.IsChecked == true ? "PHASE" : "RULES";
            TBINFO.Text = obj[mode];
        }
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CopyToClipboardButton_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(obj["SAVEDGAME"]);
            TBINFO.Text = "Save Game Data Copied to Clipboard.  Please paste to a text file and provide to the game author MB with a description of the issue\n\nThank you";
        }
    }
}
